using UnityEngine;

/// <summary>One warned lane hazard per reserved tile; the centre and opposite lane remain open.</summary>
public sealed class CourierStreetEvent : MonoBehaviour
{
    public enum Kind{VanDoor,CargoCart,Barrier}
    [SerializeField] private Kind kind;
    private Transform hazard,warning;
    private Collider[] colliders;
    private float elapsed;
    private bool triggered,skipped;
    public Kind EventKind=>kind;
    public float WarningTime=>elapsed;
    public bool Skipped=>skipped;
    public bool Moving=>triggered&&!skipped&&elapsed>=1.25f;
    public void Configure(GameObject[] packages,int quota,float height)
    {
        gameObject.SetActive(true);ResetEvent();
        for(int i=0;i<packages.Length;i++)
        {var p=packages[i];if(!p)continue;p.SetActive(false);if(i<quota){p.transform.position=transform.TransformPoint(new Vector3(0,height,5+i*17f/Mathf.Max(1,quota)));p.SetActive(true);}}
    }
    private void Awake(){Resolve();}
    private void Resolve(){hazard=transform.Find("Moving hazard");warning=transform.Find("Lane warning");if(hazard)colliders=hazard.GetComponentsInChildren<Collider>(true);}
    public void SetKind(Kind value){kind=value;}
    public void ResetEvent()
    {
        Resolve();elapsed=0;triggered=skipped=false;
        if(hazard){foreach(var child in hazard.GetComponentsInChildren<Transform>(true))child.gameObject.SetActive(true);SetPose(0);foreach(var c in colliders)c.enabled=false;}
        if(warning)warning.gameObject.SetActive(false);
    }
    private void Update()
    {
        if(!CourierJourney.Active||!CourierWeather.Runner)return;
        float ahead=transform.position.z+17-CourierWeather.Runner.transform.position.z;
        float speed=CourierWeather.Runner.CurrentForwardSpeed*(CourierCargoManifest.Instance?CourierCargoManifest.Instance.SpeedMultiplier:1);
        Step(Time.deltaTime,ahead,speed);
    }
    public void Step(float dt,float metresAhead,float speed)
    {
        if(!CourierJourney.Active||!hazard)return;
        if(!triggered&&metresAhead<=Mathf.Max(42,speed*2.4f))
        {
            triggered=true;
            // A recycled/late-loaded event may never appear immediately in front of the player.
            skipped=metresAhead<Mathf.Max(22,speed*1.85f);
            if(warning)warning.gameObject.SetActive(!skipped);
        }
        if(!triggered||skipped)return;
        elapsed+=dt;float p=Mathf.SmoothStep(0,1,Mathf.Clamp01((elapsed-1.25f)/.45f));SetPose(p);
        foreach(var c in colliders)c.enabled=p>.02f&&metresAhead>-5;
        if(warning){warning.gameObject.SetActive(metresAhead>-3);warning.localScale=new Vector3(1,1,1+Mathf.Sin(elapsed*9)*.07f);}
    }
    private void SetPose(float p)
    {
        if(!hazard)return;
        if(kind==Kind.VanDoor){hazard.localPosition=new Vector3(-3.6f,.9f,17);hazard.localRotation=Quaternion.Euler(0,Mathf.Lerp(0,-88,p),0);}
        else if(kind==Kind.CargoCart){hazard.localPosition=new Vector3(Mathf.Lerp(4.4f,2.5f,p),.5f,17);hazard.localRotation=Quaternion.identity;}
        else{hazard.localPosition=new Vector3(-3.65f,.15f,17);hazard.localRotation=Quaternion.Euler(0,0,Mathf.Lerp(88,0,p));}
    }
}

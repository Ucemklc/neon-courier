using UnityEngine;

/// <summary>Small, allocation-free idle and receiving poses for the delivery android.</summary>
[DisallowMultipleComponent]
public sealed class DeliveryReceiverVisual : MonoBehaviour
{
    [SerializeField] private Transform head;
    [SerializeField] private Transform leftArm;
    [SerializeField] private Transform rightArm;
    [SerializeField] private Transform leftForearm;
    [SerializeField] private Transform rightForearm;
    private Quaternion headRest, leftRest, rightRest, leftForeRest, rightForeRest;
    private float receiveUntil;
    private float blend;
    private bool restCached;

    private void Awake() { CacheRest(); }
    private void CacheRest()
    {
        if (restCached) return;
        restCached = true;
        headRest = Rotation(head); leftRest = Rotation(leftArm); rightRest = Rotation(rightArm);
        leftForeRest = Rotation(leftForearm); rightForeRest = Rotation(rightForearm);
    }

    private void OnEnable() { CacheRest(); receiveUntil = 0f; blend = 0f; }
    public void Receive(float duration) { receiveUntil = Time.time + duration; }
    public void ResetPose()
    {
        CacheRest();
        receiveUntil = 0f; blend = 0f;
        Pose(head, headRest); Pose(leftArm, leftRest); Pose(rightArm, rightRest);
        Pose(leftForearm, leftForeRest); Pose(rightForearm, rightForeRest);
    }

    private void LateUpdate()
    {
        blend = Mathf.MoveTowards(blend, Time.time < receiveUntil ? 1f : 0f, Time.deltaTime * 5f);
        float breath = Mathf.Sin(Time.time * 1.7f);
        Pose(head, headRest * Quaternion.Euler(Mathf.Lerp(breath * 2f, 12f, blend), breath * 3f, 0f));
        Pose(leftArm, leftRest * Quaternion.Euler(-52f * blend, 0f, breath * 1.5f));
        Pose(rightArm, rightRest * Quaternion.Euler(-52f * blend, 0f, -breath * 1.5f));
        Pose(leftForearm, leftForeRest * Quaternion.Euler(-40f * blend, 0f, 0f));
        Pose(rightForearm, rightForeRest * Quaternion.Euler(-40f * blend, 0f, 0f));
    }

    private static Quaternion Rotation(Transform part) => part ? part.localRotation : Quaternion.identity;
    private static void Pose(Transform part, Quaternion rotation) { if (part) part.localRotation = rotation; }
}

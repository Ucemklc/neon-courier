using UnityEngine;

/// <summary>Three pooled district silhouettes; the original neon skyline remains the first district.</summary>
public sealed class CourierDistrictTile : MonoBehaviour
{
    private readonly GameObject[] districts=new GameObject[5];
    public CourierDistrict District { get; private set; }
    public void Refresh()
    {
        District=CourierWorldRules.DistrictAt(transform.position.z);
        Transform original=transform.Find("__GeneratedCityBuildings");
        if(original)original.gameObject.SetActive(District==CourierDistrict.Neon);
        for(int i=0;i<districts.Length;i++)if(districts[i])districts[i].SetActive(false);
        int index=(int)District;
        if(!districts[index])
        {
            var asset=Resources.Load<GameObject>((index<3?"CourierExpansion/":"CourierCareer/")+"District"+index);
            if(!asset)return;
            districts[index]=Instantiate(asset,transform,false);
        }
        districts[index].SetActive(true);
    }
}

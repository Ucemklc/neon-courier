using System.Collections;
using TMPro;
using UnityEngine;
using UnityEngine.InputSystem;

public class TutorialController : MonoBehaviour
{
    private enum TutorialGesture
    {
        Left,
        Right,
        Up,
        Down
    }

    [Header("References")]
    [SerializeField]
    private GameObject tutorialPanel;

    [SerializeField]
    private CanvasGroup tutorialCanvasGroup;

    [SerializeField]
    private TMP_Text gestureText;

    [SerializeField]
    private TMP_Text instructionText;

    [SerializeField]
    private TMP_Text progressText;

    [SerializeField]
    private RunnerController runnerController;

    [Header("Swipe")]
    [SerializeField, Range(0.03f, 0.25f)]
    private float minimumSwipeFraction = 0.07f;

    [SerializeField, Min(0.1f)]
    private float maximumSwipeDuration = 0.8f;

    [Header("Timing")]
    [SerializeField, Min(0f)]
    private float fadeDuration = 0.2f;

    [SerializeField, Min(0f)]
    private float successDisplayDuration = 0.35f;

    [SerializeField, Min(0f)]
    private float informationDisplayDuration = 1.5f;

    [Header("Testing")]
    [SerializeField]
    private bool alwaysShowForTesting;

    private const string TutorialCompletedKey =
        "NeonCourier.TutorialCompleted";

    private readonly TutorialGesture[] tutorialSteps =
    {
        TutorialGesture.Left,
        TutorialGesture.Right,
        TutorialGesture.Up,
        TutorialGesture.Down
    };

    private GameManager gameManager;

    private Vector2 pointerStartPosition;
    private float pointerStartTime;

    private int currentStepIndex;

    private bool pointerIsDown;
    private bool tutorialIsActive;
    private bool waitingForGesture;
    private bool tutorialHasStarted;
    private bool runnerWasEnabled;
    private bool audioWasPaused;

    private Coroutine tutorialCoroutine;

    private void Awake()
    {
        if (tutorialPanel != null)
        {
            tutorialPanel.SetActive(false);
        }

        if (tutorialCanvasGroup != null)
        {
            tutorialCanvasGroup.alpha = 0f;
            tutorialCanvasGroup.interactable = false;
            tutorialCanvasGroup.blocksRaycasts = false;
        }
    }

    private IEnumerator Start()
    {
        yield return null;

        gameManager = GameManager.Instance;

        if (gameManager == null)
        {
            Debug.LogError(
                "TutorialController: GameManager bulunamadı.",
                this
            );

            enabled = false;
            yield break;
        }

        if (runnerController == null)
        {
            runnerController =
                FindFirstObjectByType<RunnerController>();
        }

        if (runnerController == null)
        {
            Debug.LogError(
                "TutorialController: RunnerController bulunamadı.",
                this
            );

            enabled = false;
            yield break;
        }

        gameManager.CountdownChanged +=
            HandleCountdownChanged;

        gameManager.GameOverTriggered +=
            HandleGameOver;
    }

    private void Update()
    {
        if (
            !tutorialIsActive ||
            !waitingForGesture
        )
        {
            return;
        }

        ReadKeyboardInput();
        ReadTouchInput();
        ReadMouseInput();
    }

    private void OnDestroy()
    {
        if (gameManager != null)
        {
            gameManager.CountdownChanged -=
                HandleCountdownChanged;

            gameManager.GameOverTriggered -=
                HandleGameOver;
        }

        RestoreGameState();
    }

    private void HandleCountdownChanged(
        string countdownValue
    )
    {
        if (tutorialHasStarted)
        {
            return;
        }

        if (
            !string.IsNullOrWhiteSpace(
                countdownValue
            )
        )
        {
            return;
        }

        if (
            gameManager == null ||
            !gameManager.IsRunActive
        )
        {
            return;
        }

        if (!ShouldShowTutorial())
        {
            return;
        }

        tutorialHasStarted = true;

        tutorialCoroutine =
            StartCoroutine(
                TutorialRoutine()
            );
    }

    private bool ShouldShowTutorial()
    {
        if (alwaysShowForTesting)
        {
            return true;
        }

        return PlayerPrefs.GetInt(
            TutorialCompletedKey,
            0
        ) == 0;
    }

    private IEnumerator TutorialRoutine()
    {
        tutorialIsActive = true;
        waitingForGesture = false;
        currentStepIndex = 0;

        runnerWasEnabled =
            runnerController.enabled;

        audioWasPaused =
            AudioListener.pause;

        runnerController.enabled = false;

        Time.timeScale = 0f;
        AudioListener.pause = true;

        if (tutorialPanel != null)
        {
            tutorialPanel.SetActive(true);
        }

        if (tutorialCanvasGroup != null)
        {
            tutorialCanvasGroup.interactable =
                true;

            tutorialCanvasGroup.blocksRaycasts =
                true;

            yield return FadeCanvasGroup(
                0f,
                1f
            );
        }

        ShowCurrentGestureStep();

        while (
            currentStepIndex <
            tutorialSteps.Length
        )
        {
            yield return null;
        }

        yield return ShowInformationStep(
            "PAKET",
            "YOLDAKİ PAKETLERİ TOPLA"
        );

        yield return ShowInformationStep(
            "HEDEF",
            "PAKETLERİ TESLİMAT ALANINA ULAŞTIR"
        );

        yield return ShowInformationStep(
            "HAZIR",
            "ŞİMDİ KOŞUYA DEVAM ET!"
        );

        CompleteTutorial();
    }

    private void ShowCurrentGestureStep()
    {
        if (
            currentStepIndex < 0 ||
            currentStepIndex >=
            tutorialSteps.Length
        )
        {
            waitingForGesture = false;
            return;
        }

        TutorialGesture gesture =
            tutorialSteps[currentStepIndex];

        switch (gesture)
        {
            case TutorialGesture.Left:
                SetTutorialText(
                    "←",
                    "SOLA KAYDIR",
                    "ŞERİT DEĞİŞTİR"
                );
                break;

            case TutorialGesture.Right:
                SetTutorialText(
                    "→",
                    "SAĞA KAYDIR",
                    "ŞERİT DEĞİŞTİR"
                );
                break;

            case TutorialGesture.Up:
                SetTutorialText(
                    "↑",
                    "YUKARI KAYDIR",
                    "ZIPLA"
                );
                break;

            case TutorialGesture.Down:
                SetTutorialText(
                    "↓",
                    "AŞAĞI KAYDIR",
                    "KAY"
                );
                break;
        }

        if (progressText != null)
        {
            progressText.text =
                $"{currentStepIndex + 1} / " +
                $"{tutorialSteps.Length}";
        }

        waitingForGesture = true;
    }

    private void SetTutorialText(
        string gesture,
        string instruction,
        string description
    )
    {
        if (gestureText != null)
        {
            gestureText.text = gesture;
        }

        if (instructionText != null)
        {
            instructionText.text =
                $"{instruction}\n" +
                $"<size=65%>{description}</size>";
        }
    }

    private IEnumerator AcceptCurrentGesture()
    {
        waitingForGesture = false;

        if (gestureText != null)
        {
            // Keep this feedback within the glyphs available in TiltWarp SDF.
            gestureText.text = "OK";
        }

        if (instructionText != null)
        {
            instructionText.text =
                "HARİKA!";
        }

        yield return new WaitForSecondsRealtime(
            successDisplayDuration
        );

        currentStepIndex++;

        if (
            currentStepIndex <
            tutorialSteps.Length
        )
        {
            ShowCurrentGestureStep();
        }
    }

    private IEnumerator ShowInformationStep(
        string heading,
        string description
    )
    {
        waitingForGesture = false;

        if (gestureText != null)
        {
            gestureText.text = heading;
        }

        if (instructionText != null)
        {
            instructionText.text =
                description;
        }

        if (progressText != null)
        {
            progressText.text =
                string.Empty;
        }

        yield return new WaitForSecondsRealtime(
            informationDisplayDuration
        );
    }

    private void CompleteTutorial()
    {
        PlayerPrefs.SetInt(
            TutorialCompletedKey,
            1
        );

        PlayerPrefs.Save();

        StartCoroutine(
            FinishTutorialRoutine()
        );
    }

    private IEnumerator FinishTutorialRoutine()
    {
        if (tutorialCanvasGroup != null)
        {
            yield return FadeCanvasGroup(
                1f,
                0f
            );

            tutorialCanvasGroup.interactable =
                false;

            tutorialCanvasGroup.blocksRaycasts =
                false;
        }

        if (tutorialPanel != null)
        {
            tutorialPanel.SetActive(false);
        }

        RestoreGameState();
        tutorialCoroutine = null;
    }

    private IEnumerator FadeCanvasGroup(
        float startAlpha,
        float targetAlpha
    )
    {
        if (tutorialCanvasGroup == null)
        {
            yield break;
        }

        if (fadeDuration <= 0f)
        {
            tutorialCanvasGroup.alpha =
                targetAlpha;

            yield break;
        }

        float elapsedTime = 0f;

        tutorialCanvasGroup.alpha =
            startAlpha;

        while (
            elapsedTime <
            fadeDuration
        )
        {
            elapsedTime +=
                Time.unscaledDeltaTime;

            float progress =
                Mathf.Clamp01(
                    elapsedTime /
                    fadeDuration
                );

            tutorialCanvasGroup.alpha =
                Mathf.Lerp(
                    startAlpha,
                    targetAlpha,
                    progress
                );

            yield return null;
        }

        tutorialCanvasGroup.alpha =
            targetAlpha;
    }

    private void RestoreGameState()
    {
        if (!tutorialIsActive)
        {
            return;
        }

        bool gameIsPaused =
            gameManager != null &&
            gameManager.IsPaused;

        bool gameIsOver =
            gameManager != null &&
            gameManager.IsGameOver;

        bool canResumeRun =
            gameManager != null &&
            gameManager.IsRunActive &&
            !gameIsPaused &&
            !gameIsOver &&
            !gameManager.IsMainMenuActive;

        Time.timeScale =
            gameIsPaused || gameIsOver
                ? 0f
                : 1f;

        AudioListener.pause =
            gameIsPaused ||
            (!gameIsOver && audioWasPaused);

        if (runnerController != null && canResumeRun)
        {
            runnerController.enabled =
                runnerWasEnabled;
        }

        tutorialIsActive = false;
        waitingForGesture = false;
    }

    private void HandleGameOver()
    {
        if (!tutorialIsActive)
        {
            return;
        }

        if (tutorialCoroutine != null)
        {
            StopCoroutine(
                tutorialCoroutine
            );

            tutorialCoroutine = null;
        }

        if (tutorialPanel != null)
        {
            tutorialPanel.SetActive(false);
        }

        RestoreGameState();
    }

    private void ReadKeyboardInput()
    {
        if (Keyboard.current == null)
        {
            return;
        }

        TutorialGesture? detectedGesture =
            null;

        if (
            Keyboard.current.leftArrowKey
                .wasPressedThisFrame ||
            Keyboard.current.aKey
                .wasPressedThisFrame
        )
        {
            detectedGesture =
                TutorialGesture.Left;
        }
        else if (
            Keyboard.current.rightArrowKey
                .wasPressedThisFrame ||
            Keyboard.current.dKey
                .wasPressedThisFrame
        )
        {
            detectedGesture =
                TutorialGesture.Right;
        }
        else if (
            Keyboard.current.upArrowKey
                .wasPressedThisFrame ||
            Keyboard.current.wKey
                .wasPressedThisFrame ||
            Keyboard.current.spaceKey
                .wasPressedThisFrame
        )
        {
            detectedGesture =
                TutorialGesture.Up;
        }
        else if (
            Keyboard.current.downArrowKey
                .wasPressedThisFrame ||
            Keyboard.current.sKey
                .wasPressedThisFrame
        )
        {
            detectedGesture =
                TutorialGesture.Down;
        }

        if (detectedGesture.HasValue)
        {
            TryAcceptGesture(
                detectedGesture.Value
            );
        }
    }

    private void ReadTouchInput()
    {
        if (Touchscreen.current == null)
        {
            return;
        }

        var primaryTouch =
            Touchscreen.current.primaryTouch;

        if (
            primaryTouch.press
                .wasPressedThisFrame
        )
        {
            BeginPointer(
                primaryTouch.position
                    .ReadValue()
            );
        }

        if (
            primaryTouch.press
                .wasReleasedThisFrame
        )
        {
            EndPointer(
                primaryTouch.position
                    .ReadValue(),
                true
            );
        }
    }

    private void ReadMouseInput()
    {
#if UNITY_EDITOR || UNITY_STANDALONE
        if (Mouse.current == null)
        {
            return;
        }

        if (
            Mouse.current.leftButton
                .wasPressedThisFrame
        )
        {
            BeginPointer(
                Mouse.current.position
                    .ReadValue()
            );
        }

        if (
            Mouse.current.leftButton
                .wasReleasedThisFrame
        )
        {
            EndPointer(
                Mouse.current.position
                    .ReadValue(),
                true
            );
        }
#endif
    }

    private void BeginPointer(
        Vector2 screenPosition
    )
    {
        pointerStartPosition =
            screenPosition;

        pointerStartTime =
            Time.unscaledTime;

        pointerIsDown = true;
    }

    private void EndPointer(
        Vector2 screenPosition,
        bool processSwipe
    )
    {
        if (!pointerIsDown)
        {
            return;
        }

        float swipeDuration =
            Time.unscaledTime -
            pointerStartTime;

        Vector2 swipeDelta =
            screenPosition -
            pointerStartPosition;

        pointerIsDown = false;

        if (!processSwipe)
        {
            return;
        }

        if (
            swipeDuration >
            maximumSwipeDuration
        )
        {
            return;
        }

        float minimumSwipeDistance =
            Mathf.Min(
                Screen.width,
                Screen.height
            ) * minimumSwipeFraction;

        if (
            swipeDelta.magnitude <
            minimumSwipeDistance
        )
        {
            return;
        }

        TutorialGesture detectedGesture =
            DetectSwipeGesture(
                swipeDelta
            );

        TryAcceptGesture(
            detectedGesture
        );
    }

    private TutorialGesture DetectSwipeGesture(
        Vector2 swipeDelta
    )
    {
        bool isHorizontal =
            Mathf.Abs(swipeDelta.x) >
            Mathf.Abs(swipeDelta.y);

        if (isHorizontal)
        {
            return swipeDelta.x > 0f
                ? TutorialGesture.Right
                : TutorialGesture.Left;
        }

        return swipeDelta.y > 0f
            ? TutorialGesture.Up
            : TutorialGesture.Down;
    }

    private void TryAcceptGesture(
        TutorialGesture detectedGesture
    )
    {
        if (
            !waitingForGesture ||
            currentStepIndex < 0 ||
            currentStepIndex >=
            tutorialSteps.Length
        )
        {
            return;
        }

        TutorialGesture expectedGesture =
            tutorialSteps[currentStepIndex];

        if (
            detectedGesture !=
            expectedGesture
        )
        {
            StartCoroutine(
                ShowWrongGestureFeedback()
            );

            return;
        }

        StartCoroutine(
            AcceptCurrentGesture()
        );
    }

    private IEnumerator ShowWrongGestureFeedback()
    {
        waitingForGesture = false;

        string previousText =
            instructionText != null
                ? instructionText.text
                : string.Empty;

        if (instructionText != null)
        {
            instructionText.text =
                "DİĞER YÖNÜ DENE";
        }

        yield return new WaitForSecondsRealtime(
            0.3f
        );

        if (instructionText != null)
        {
            instructionText.text =
                previousText;
        }

        waitingForGesture = true;
    }

    [ContextMenu("Reset Tutorial Progress")]
    private void ResetTutorialProgress()
    {
        PlayerPrefs.DeleteKey(
            TutorialCompletedKey
        );

        PlayerPrefs.Save();

        Debug.Log(
            "Neon Courier eğitim kaydı sıfırlandı."
        );
    }
}

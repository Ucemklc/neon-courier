#if UNITY_EDITOR
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;
using Object=UnityEngine.Object;

/// <summary>Shared, lightweight art for the three neighborhoods and optional routes.</summary>
public static class CourierExpansionAssets
{
    private const string Folder="Assets/Resources/CourierExpansion";
    private static Material navy,slate,cyan,orange,white,steel,water,pink,gold;
    [InitializeOnLoadMethod]
    private static void InstallMissingAssets()
    {
        // First import prepares the expansion; subsequent editor reloads leave existing art alone.
        EditorApplication.delayCall+=()=>
        {
            if(EditorApplication.isPlayingOrWillChangePlaymode || EditorApplication.isCompiling || EditorApplication.isUpdating)return;
            if(!AssetDatabase.LoadAssetAtPath<GameObject>(Folder+"/BackpackPreview.prefab"))Build();
        };
    }
    [MenuItem("Neon Courier/Build City Expansion Assets")]
    public static void Build()
    {
        if(EditorApplication.isPlayingOrWillChangePlaymode)throw new Exception("Stop Play Mode before building art.");
        Ensure(Folder+"/Materials");Ensure(Folder+"/Meshes");
        navy=Material("DeepNavy",new Color(.045f,.085f,.13f));slate=Material("BlueSlate",new Color(.13f,.23f,.29f));
        cyan=Material("NeonCyan",new Color(.04f,.75f,.95f),1.2f);orange=Material("SafetyOrange",new Color(1,.34f,.065f));
        white=Material("Porcelain",new Color(.75f,.83f,.84f));steel=Material("DarkSteel",new Color(.055f,.07f,.085f));
        water=Material("HarborWater",new Color(.025f,.21f,.30f));pink=Material("FragilePink",new Color(1,.22f,.55f),.8f);gold=Material("HeavyGold",new Color(1,.67f,.06f),.5f);
        Scene scene=EditorSceneManager.NewPreviewScene();var root=new GameObject("Expansion asset build");SceneManager.MoveGameObjectToScene(root,scene);
        try
        {
            for(int i=0;i<3;i++)Save(District(root.transform,i),"District"+i);
            for(int district=1;district<=2;district++)for(int kind=0;kind<3;kind++)Save(DistrictObstacle(root.transform,district,kind),"Obstacle"+district+"_"+kind);
            Save(Roof(root.transform),"RooftopShortcut");Save(Tunnel(root.transform),"ServiceTunnel");
            for(int i=1;i<=3;i++)Save(Stop(root.transform,i),"DeliveryStop"+i);
            for(int i=1;i<=3;i++)Save(Badge(root.transform,i,false),"CargoBadge"+i);
            for(int i=0;i<3;i++)Save(Badge(root.transform,i,true),"BagPatch"+i);
            var beacon=Node("TrainWarningBeacon",root.transform);Box(beacon,"Backing",V(0,0,0),V(.65f,.45f,.08f),steel);
            Box(beacon,"WarningStem",V(0,.055f,-.05f),V(.055f,.20f,.02f),gold);Box(beacon,"WarningDot",V(0,-.105f,-.05f),V(.06f,.055f,.02f),gold);
            foreach(float x in new[]{-.25f,.25f})Box(beacon,"AmberLight",V(x,0,-.04f),V(.06f,.31f,.025f),orange);
            Save(beacon.gameObject,"TrainWarningBeacon");
            var bag=Object.Instantiate(AssetDatabase.LoadAssetAtPath<GameObject>("Assets/_Game/Art/CourierSet/CourierBackpack.prefab"),root.transform);
            bag.name="BackpackPreview";PrefabUtility.SaveAsPrefabAsset(bag,Folder+"/BackpackPreview.prefab");
        }
        finally{EditorSceneManager.ClosePreviewScene(scene);}
        AssetDatabase.SaveAssets();Validate();Capture();
        Debug.Log("COURIER_EXPANSION_ASSETS_OK");
    }

    private static GameObject District(Transform parent,int type)
    {
        var root=Node("District"+type,parent);
        for(int side=-1;side<=1;side+=2)
        {
            Box(root,"LaneEdge",V(side*4.02f,.035f,15),V(.06f,.04f,29),type==1?orange:cyan);
            if(type==0)
            {
                for(int i=0;i<3;i++)
                {
                    float z=4+i*10;Box(root,"SignalPost",V(side*4.9f,2.2f,z),V(.16f,4.4f,.16f),steel);
                    Box(root,"LightPanel",V(side*4.9f,3.4f,z),V(.4f,1.4f,.22f),cyan);
                    Box(root,"BannerFrame",V(side*5.15f,4.9f,z),V(.16f,1.2f,2.6f),navy);
                    for(int stripe=0;stripe<3;stripe++)Box(root,"NeonBannerStripe",V(side*5.03f,4.6f+stripe*.24f,z),V(.025f,.1f,2.1f-stripe*.3f),stripe%2==0?cyan:pink);
                }
            }
            else if(type==1)
            {
                for(int i=0;i<2;i++)
                {
                    float z=7+i*15;Box(root,"Warehouse",V(side*9,2.9f,z),V(6.7f,5.8f,11),slate);
                    Box(root,"WarehouseRoof",V(side*9,5.9f,z),V(7,.24f,11.3f),steel);
                    for(int bay=0;bay<3;bay++)
                    {
                        float doorZ=z-3.6f+bay*3.6f;
                        Box(root,"LoadingDoor",V(side*5.58f,1.7f,doorZ),V(.035f,3.2f,2.5f),steel);
                        for(int bar=0;bar<6;bar++)Box(root,"RollerDoorRib",V(side*5.55f,.45f+bar*.43f,doorZ),V(.04f,.06f,2.4f),white);
                        Box(root,"DoorLamp",V(side*5.50f,3.65f,doorZ),V(.08f,.12f,2.2f),orange);
                    }
                    for(int chimney=0;chimney<2;chimney++)
                    {
                        float cx=side*(8+chimney*2);Cylinder(root,"Chimney",V(cx,8,z),V(.65f,2.2f,.65f),steel);
                        Cylinder(root,"ChimneyBand",V(cx,9.2f,z),V(.68f,.19f,.68f),orange);
                    }
                }
                Box(root,"UtilityPipe",V(side*5.3f,4.9f,15),V(.23f,.23f,29),orange);
            }
            else
            {
                Box(root,"HarborWater",V(side*14,-.10f,15),V(15,.08f,30),water);
                Box(root,"Quay",V(side*7.2f,-.02f,15),V(5.4f,.18f,30),slate);
                for(int stack=0;stack<3;stack++)
                {
                    float z=4.6f+stack*10;
                    for(int level=0;level<2+(stack%2);level++)
                    {
                        Box(root,"ShippingContainer",V(side*8.2f,1.35f+level*2.65f,z),V(4.5f,2.55f,7.3f),(level+stack)%2==0?navy:orange);
                        for(int rib=0;rib<9;rib++)Box(root,"ContainerRib",V(side*5.91f,1.35f+level*2.65f,z-3.2f+rib*.8f),V(.07f,2.3f,.075f),steel);
                        Box(root,"ContainerStripe",V(side*5.84f,1.35f+level*2.65f,z),V(.035f,.20f,2.3f),white);
                    }
                }
                Box(root,"CraneMast",V(side*11,6.3f,15),V(.6f,12.6f,.6f),orange);
                Box(root,"CraneJib",V(side*8.6f,12.2f,15),V(8.6f,.36f,.4f),orange);
                Box(root,"HoistCable",V(side*5.6f,8.8f,15),V(.045f,6.4f,.045f),steel);
                Box(root,"CraneHook",V(side*5.6f,5.6f,15),V(.32f,.36f,.22f),gold);
                for(int line=0;line<8;line++)Box(root,"WaterReflection",V(side*(12+line%3),-.049f,2+line*3.5f),V(2.4f,.004f,.07f),cyan);
            }
        }
        return root.gameObject;
    }

    private static GameObject Roof(Transform parent)
    {
        var root=Node("RooftopShortcut",parent);root.gameObject.AddComponent<RailRideSurface>();
        foreach(var pair in new[]{new Vector2(7,12),new Vector2(16,20)})
        {
            float z=(pair.x+pair.y)*.5f,length=pair.y-pair.x;
            Box(root,"UtilityBuilding",V(0,1.2f,z),V(1.9f,2.4f,length),slate,true);
            Box(root,"RoofEdge",V(0,2.38f,z),V(1.94f,.04f,length),navy);
            foreach(int side in new[]{-1,1})for(int window=0;window<3;window++)
                Box(root,"BuildingWindow",V(side*.96f,1.35f,pair.x+.8f+window*(length-1.6f)/2),V(.025f,.7f,.85f),cyan);
            foreach(int side in new[]{-1,1})Box(root,"RoofGuide",V(side*.80f,2.425f,z),V(.045f,.015f,length),cyan);
        }
        var train=AssetDatabase.LoadAssetAtPath<GameObject>("Assets/Resources/NeonRail/NeonCargoTrain.prefab");
        var entry=Object.Instantiate(train.transform.Find("Entry Ramp - 28 Degrees").gameObject,root);
        entry.transform.localPosition=V(0,0,2.5f);
        var exit=Object.Instantiate(train.transform.Find("Exit Ramp - 28 Degrees").gameObject,root);
        exit.transform.localPosition=V(0,0,24.5f);
        foreach(float z in new[]{3.5f,4.7f,5.9f})Arrow(root,V(0,(z-2.5f)/4.5f*2.4f+.03f,z),cyan,-28);
        foreach(float z in new[]{8.5f,10.2f,17.5f})Arrow(root,V(0,2.43f,z),z<12?gold:cyan,0);
        Gate(root,false,V(0,3.3f,8.7f),V(1.4f,1.65f,.65f));Gate(root,true,V(0,4.5f,19f),V(1.4f,4.2f,.65f));
        return root.gameObject;
    }
    private static GameObject Tunnel(Transform parent)
    {
        var root=Node("ServiceTunnel",parent);root.gameObject.AddComponent<RailRideSurface>();
        Box(root,"TunnelCeiling",V(0,3.25f,13),V(2.05f,.24f,16),navy,true);
        for(int i=0;i<5;i++)
        {
            float z=5+i*4;foreach(int side in new[]{-1,1})Box(root,"TunnelColumn",V(side*1.0f,1.55f,z),V(.1f,3.1f,.18f),slate,true);
            Box(root,"TunnelBeam",V(0,3.05f,z),V(2.05f,.17f,.25f),slate);
            Box(root,"CeilingLight",V(0,2.948f,z),V(1.7f,.026f,.09f),cyan);
        }
        foreach(float x in new[]{-.85f,.85f})Box(root,"FloorGuide",V(x,.035f,13),V(.04f,.035f,18),cyan);
        for(int i=0;i<5;i++)Box(root,"LowGateWarning",V(-.8f+i*.4f,2.80f,5),V(.24f,.24f,.06f),i%2==0?orange:steel);
        foreach(float z in new[]{4f,8f,18f,22f})Arrow(root,V(0,.035f,z),cyan,0);
        Gate(root,false,V(0,1f,5f),V(1.4f,1.8f,.65f));Gate(root,true,V(0,1f,21.7f),V(1.4f,1.8f,.65f));
        return root.gameObject;
    }
    private static void Gate(Transform parent,bool exit,Vector3 position,Vector3 size)
    {
        var root=Node(exit?"ShortcutExit":"ShortcutEntry",parent);root.localPosition=position;
        var collider=root.gameObject.AddComponent<BoxCollider>();collider.isTrigger=true;collider.size=size;
        var body=root.gameObject.AddComponent<Rigidbody>();body.isKinematic=true;body.useGravity=false;
        root.gameObject.AddComponent<CourierRouteGate>().Exit=exit;
    }

    private static GameObject DistrictObstacle(Transform parent,int district,int kind)
    {
        var root=Node("DistrictObstacle",parent);Material body=district==1?orange:slate;
        if(kind==0)
        {
            Box(root,"CargoBase",V(0,.1f,0),V(1.5f,.2f,1.35f),steel);
            Box(root,district==1?"MachineCrate":"HarborCargo",V(0,.64f,0),V(1.48f,.9f,1.32f),body);
            foreach(float x in new[]{-.51f,.51f})Box(root,"CargoStrap",V(x,.65f,-.67f),V(.08f,.90f,.025f),white);
            Box(root,"JumpGuide",V(0,1.095f,0),V(1.5f,.025f,1.3f),cyan);
        }
        else if(kind==1)
        {
            foreach(float x in new[]{-.80f,.80f})Box(root,"Support",V(x,1.18f,0),V(.10f,2.36f,.9f),steel);
            if(district==1)
            {
                var pipe=Node("LowServicePipe",root);pipe.localPosition=V(0,1.75f,0);pipe.localRotation=Quaternion.Euler(0,0,90);
                Cylinder(pipe,"Pipe",Vector3.zero,V(.5f,.75f,.5f),orange);
                foreach(float y in new[]{-.60f,.60f})Cylinder(pipe,"PipeCollar",V(0,y,0),V(.54f,.065f,.54f),steel);
            }
            else
            {
                Box(root,"SuspendedCargo",V(0,1.75f,0),V(1.5f,.5f,1.35f),slate);
                foreach(float x in new[]{-.58f,.58f})Box(root,"HoistStrap",V(x,2.1f,0),V(.06f,.70f,.08f),orange);
            }
            Box(root,"SlideWarning",V(0,1.51f,-.71f),V(1.5f,.05f,.03f),gold);
        }
        else
        {
            Box(root,district==1?"IndustrialUnit":"BlockedContainer",V(0,1.3f,0),V(2.28f,2.6f,1.33f),body);
            for(int i=0;i<8;i++)Box(root,"Rib",V(-1.01f+i*.29f,1.3f,-.68f),V(.055f,2.46f,.025f),steel);
            Box(root,"StopPanel",V(0,1.35f,-.71f),V(1.35f,1.35f,.04f),navy);
            foreach(float angle in new[]{45f,-45f})Box(root,"ClosedCross",V(0,1.35f,-.75f),V(1.22f,.13f,.03f),pink,false,V(0,0,angle));
            Box(root,"HazardTop",V(0,2.55f,-.69f),V(2.24f,.08f,.04f),gold);
        }
        return root.gameObject;
    }
    private static GameObject Stop(Transform parent,int kind)
    {
        var root=Node("DeliveryStop"+kind,parent);float height=kind==2?4.2f:2.65f;
        Box(root,"Facade",V(0,height*.5f,-.22f),V(2.65f,height,.42f),slate);
        Box(root,"BaseStep",V(0,.07f,.1f),V(2.9f,.14f,.9f),steel);
        Box(root,"TopSign",V(0,height-.20f,.05f),V(2.7f,.4f,.15f),navy);
        for(int i=0;i<3;i++)Box(root,"AddressMark",V(-.30f+i*.30f,height-.20f,.14f),V(.16f,.14f,.025f),cyan);
        if(kind==1)
        {
            Box(root,"ShopWindow",V(-.4f,1.5f,.025f),V(1.40f,1.2f,.08f),navy);
            Box(root,"WindowRail",V(-.4f,1.48f,.07f),V(1.43f,.055f,.065f),cyan);
            Box(root,"Counter",V(-.4f,.89f,.38f),V(1.45f,.20f,.70f),orange);
            Box(root,"Awning",V(0,2.25f,.52f),V(2.8f,.14f,1.1f),orange);
            for(int i=0;i<7;i++)Box(root,"AwningStripe",V(-1.2f+i*.4f,2.325f,.52f),V(.18f,.018f,1.05f),white);
            var parcel=Object.Instantiate(AssetDatabase.LoadAssetAtPath<GameObject>("Assets/_Game/Art/CourierSet/CourierParcel.prefab"),root);parcel.transform.localPosition=V(-.45f,1.20f,.46f);parcel.transform.localScale=Vector3.one*.65f;
        }
        else if(kind==2)
        {
            for(int x=-1;x<=1;x+=2)for(int row=0;row<2;row++)
                Box(root,"ApartmentWindow",V(x*.72f,2.4f+row*.95f,.025f),V(.66f,.7f,.065f),cyan);
            Box(root,"EntryCanopy",V(0,1.95f,.45f),V(1.7f,.12f,.9f),orange);
            Box(root,"Intercom",V(.80f,1.2f,.07f),V(.22f,.37f,.09f),steel);
            Box(root,"IntercomLight",V(.80f,1.3f,.122f),V(.11f,.04f,.02f),cyan);
        }
        else
        {
            for(int x=0;x<3;x++)for(int row=0;row<3;row++)
            {
                float px=(x-1)*.82f,py=.55f+row*.68f;
                Box(root,"LockerDoor",V(px,py,.02f),V(.75f,.61f,.13f),(row+x)%3==0?orange:navy);
                Box(root,"LockerNumber",V(px-.17f,py+.14f,.091f),V(.20f,.065f,.013f),white);
                Box(root,"LockerHandle",V(px+.24f,py,.108f),V(.035f,.16f,.055f),steel);
            }
        }
        var pivot=Node("DoorPivot",root);pivot.localPosition=kind==3?V(-.38f,.25f,.20f):V(kind==1?.48f:-.5f,.15f,.10f);
        Box(pivot,"OpeningDoor",V(kind==3?.38f:.42f,kind==3?.3f:.75f,0),V(kind==3?.75f:.84f,kind==3?.6f:1.5f,.10f),navy);
        Box(pivot,"DoorHandle",V(kind==3?.65f:.72f,kind==3?.3f:.75f,.072f),V(.04f,.17f,.07f),orange);
        Box(root,"ConfirmationLight",V(1.1f,2.27f,.16f),V(.18f,.18f,.05f),cyan);
        return root.gameObject;
    }

    private static GameObject Badge(Transform parent,int kind,bool patch)
    {
        var root=Node(patch?"BagPatch":"CargoBadge",parent);float scale=patch?1f:1.5f;
        Box(root,"BadgeBack",V(0,0,0),V(.26f,.18f,.015f),navy);
        Material ink=patch?white:kind==1?cyan:kind==2?pink:gold;
        if(patch && kind==0)
        {
            Box(root,"EnvelopeTop",V(0,.055f,-.012f),V(.19f,.012f,.014f),ink);Box(root,"EnvelopeBottom",V(0,-.055f,-.012f),V(.19f,.012f,.014f),ink);
            foreach(int side in new[]{-1,1}){Box(root,"EnvelopeSide",V(side*.09f,0,-.012f),V(.012f,.11f,.014f),ink);Box(root,"EnvelopeFold",V(side*.045f,.013f,-.012f),V(.113f,.012f,.014f),ink,false,V(0,0,side*34));}
        }
        else if(patch && kind==1)
            Polygon(root,"Lightning",new[]{new Vector2(-.015f,.076f),new Vector2(.069f,.076f),new Vector2(.014f,.018f),new Vector2(.063f,.018f),new Vector2(-.055f,-.080f),new Vector2(-.020f,-.012f),new Vector2(-.067f,-.012f)},ink);
        else if(patch)
        {
            var points=new Vector2[10];for(int i=0;i<10;i++){float angle=(90+i*36)*Mathf.Deg2Rad;points[i]=new Vector2(Mathf.Cos(angle),Mathf.Sin(angle))*(i%2==0?.08f:.035f);}Polygon(root,"Star",points,ink);
        }
        else if(kind==1)
        {
            for(int i=0;i<12;i++){float angle=i*Mathf.PI/6;Box(root,"ClockTick",V(Mathf.Sin(angle)*.06f,Mathf.Cos(angle)*.06f,-.016f),V(.012f,.013f,.012f),ink);}
            Box(root,"ClockHand",V(0,.02f,-.02f),V(.012f,.05f,.015f),ink);Box(root,"ClockHandShort",V(.018f,0,-.02f),V(.046f,.012f,.015f),ink);
        }
        else if(kind==2)
        {
            Polygon(root,"GlassCup",new[]{new Vector2(-.055f,.066f),new Vector2(.055f,.066f),new Vector2(.038f,-.008f),new Vector2(-.038f,-.008f)},ink);
            Box(root,"GlassStem",V(0,-.027f,-.018f),V(.012f,.065f,.012f),ink);Box(root,"GlassBase",V(0,-.06f,-.018f),V(.08f,.012f,.012f),ink);
        }
        else
        {
            Polygon(root,"Weight",new[]{new Vector2(-.046f,.043f),new Vector2(.046f,.043f),new Vector2(.073f,-.06f),new Vector2(-.073f,-.06f)},ink);
            Box(root,"WeightHandle",V(0,.059f,-.018f),V(.044f,.025f,.012f),ink);
        }
        root.localScale=Vector3.one*scale;return root.gameObject;
    }
    private static void Arrow(Transform parent,Vector3 pos,Material mat,float pitch)
    {
        var root=Node("RouteArrow",parent);root.localPosition=pos;root.localRotation=Quaternion.Euler(pitch,0,0);
        Box(root,"ArrowShaft",V(0,0,-.14f),V(.16f,.025f,.60f),mat);
        Box(root,"ArrowWingL",V(-.16f,0,.16f),V(.13f,.025f,.47f),mat,false,V(0,45,0));
        Box(root,"ArrowWingR",V(.16f,0,.16f),V(.13f,.025f,.47f),mat,false,V(0,-45,0));
    }
    private static void Polygon(Transform parent,string name,Vector2[] points,Material material)
    {
        var mesh=new Mesh{name=name};var vertices=new Vector3[points.Length+1];Vector2 center=Vector2.zero;foreach(var p in points)center+=p;center/=points.Length;
        vertices[0]=V(center.x,center.y,-.021f);for(int i=0;i<points.Length;i++)vertices[i+1]=V(points[i].x,points[i].y,-.021f);
        var triangles=new List<int>();for(int i=0;i<points.Length;i++){int a=(i+1)%points.Length+1,b=i+1;if(Vector3.Cross(vertices[a]-vertices[0],vertices[b]-vertices[0]).z>0){int temp=a;a=b;b=temp;}triangles.Add(0);triangles.Add(a);triangles.Add(b);}
        mesh.vertices=vertices;mesh.triangles=triangles.ToArray();mesh.RecalculateNormals();mesh.RecalculateBounds();
        var node=Node(name,parent);node.gameObject.AddComponent<MeshFilter>().sharedMesh=mesh;node.gameObject.AddComponent<MeshRenderer>().sharedMaterial=material;
    }
    private static Transform Node(string name,Transform parent){var t=new GameObject(name).transform;t.SetParent(parent,false);return t;}
    private static Vector3 V(float x,float y,float z)=>new Vector3(x,y,z);
    private static void Box(Transform parent,string name,Vector3 position,Vector3 size,Material material,bool collider=false,Vector3 rotation=default)
    {Primitive(parent,name,PrimitiveType.Cube,position,size,material,collider,rotation);}
    private static void Cylinder(Transform parent,string name,Vector3 position,Vector3 size,Material material)
    {Primitive(parent,name,PrimitiveType.Cylinder,position,size,material,false,Vector3.zero);}
    private static void Primitive(Transform parent,string name,PrimitiveType type,Vector3 pos,Vector3 size,Material material,bool collider,Vector3 rot)
    {
        var go=GameObject.CreatePrimitive(type);go.name=name;go.transform.SetParent(parent,false);go.transform.localPosition=pos;go.transform.localScale=size;go.transform.localRotation=Quaternion.Euler(rot);
        if(!collider)Object.DestroyImmediate(go.GetComponent<Collider>());go.GetComponent<Renderer>().sharedMaterial=material;
    }
    private static Material Material(string name,Color color,float emission=0)
    {
        string path=Folder+"/Materials/"+name+".mat";var mat=AssetDatabase.LoadAssetAtPath<Material>(path);
        if(!mat){mat=new Material(Shader.Find("Universal Render Pipeline/Lit"));AssetDatabase.CreateAsset(mat,path);}
        mat.name=name;mat.SetColor("_BaseColor",color);mat.SetFloat("_Smoothness",.32f);mat.SetFloat("_Metallic",.18f);
        if(emission>0){mat.EnableKeyword("_EMISSION");mat.SetColor("_EmissionColor",color*emission);}EditorUtility.SetDirty(mat);return mat;
    }
    private static void Save(GameObject root,string name)
    {
        root.name=name;
        foreach(var parent in root.GetComponentsInChildren<Transform>(true).Reverse().ToArray())
        {
            var parts=parent.Cast<Transform>().Where(t=>t.GetComponent<MeshFilter>() && !t.GetComponent<Collider>() && t.name!="ConfirmationLight").ToArray();
            foreach(var group in parts.GroupBy(t=>t.GetComponent<MeshRenderer>().sharedMaterial))
            {
                var mesh=new Mesh{name=name+"_"+parent.name+"_"+group.Key.name};
                mesh.CombineMeshes(group.Select(t=>new CombineInstance{mesh=t.GetComponent<MeshFilter>().sharedMesh,transform=Matrix4x4.TRS(t.localPosition,t.localRotation,t.localScale)}).ToArray(),true,true);
                string path=Folder+"/Meshes/"+mesh.name+".asset";var stored=AssetDatabase.LoadAssetAtPath<Mesh>(path);
                if(stored){EditorUtility.CopySerialized(mesh,stored);Object.DestroyImmediate(mesh);}else{stored=mesh;AssetDatabase.CreateAsset(stored,path);}
                foreach(var part in group){var source=part.GetComponent<MeshFilter>().sharedMesh;Object.DestroyImmediate(part.gameObject);if(source && !EditorUtility.IsPersistent(source))Object.DestroyImmediate(source);}
                var target=Node(group.Key.name,parent);target.gameObject.AddComponent<MeshFilter>().sharedMesh=stored;target.gameObject.AddComponent<MeshRenderer>().sharedMaterial=group.Key;
            }
        }
        PrefabUtility.SaveAsPrefabAsset(root,Folder+"/"+name+".prefab",out bool success);if(!success)throw new Exception("Failed asset: "+name);
    }
    private static void Ensure(string path)
    {if(AssetDatabase.IsValidFolder(path))return;string parent=Path.GetDirectoryName(path).Replace('\\','/');Ensure(parent);AssetDatabase.CreateFolder(parent,Path.GetFileName(path));}

    [MenuItem("Neon Courier/Validate City Expansion Assets")]
    public static void Validate()
    {
        var report=new List<string>();
        foreach(var name in new[]{"District0","District1","District2","RooftopShortcut","ServiceTunnel","DeliveryStop1","DeliveryStop2","DeliveryStop3","CargoBadge1","CargoBadge2","CargoBadge3","BagPatch0","BagPatch1","BagPatch2","TrainWarningBeacon","BackpackPreview","Obstacle1_0","Obstacle1_1","Obstacle1_2","Obstacle2_0","Obstacle2_1","Obstacle2_2"})
        {
            var prefab=AssetDatabase.LoadAssetAtPath<GameObject>(Folder+"/"+name+".prefab");if(!prefab)throw new Exception("Missing "+name);
            foreach(var filter in prefab.GetComponentsInChildren<MeshFilter>(true))if(!filter.sharedMesh || !EditorUtility.IsPersistent(filter.sharedMesh))throw new Exception("Unsaved mesh "+filter.name);
            if(name.StartsWith("District")||name.StartsWith("DeliveryStop")||name.StartsWith("Obstacle"))if(prefab.GetComponentsInChildren<Collider>(true).Length>0)throw new Exception("Decorative collider "+name);
            if(name=="RooftopShortcut"||name=="ServiceTunnel")if(prefab.GetComponentsInChildren<CourierRouteGate>().Length!=2)throw new Exception("Route trigger count "+name);
            report.Add("PASS "+name+" persistent and connected");
        }
        Directory.CreateDirectory("Logs");File.WriteAllLines("Logs/CityExpansionAssets.txt",report);Debug.Log("CITY_EXPANSION_ASSETS_VALIDATED");
    }
    [MenuItem("Neon Courier/Capture City Expansion Preview")]
    public static void Capture()
    {
        foreach(string name in new[]{"District1","District2","RooftopShortcut","ServiceTunnel","DeliveryStop1","DeliveryStop2","DeliveryStop3"})
        {
            var preview=new PreviewRenderUtility();Texture2D image=null;
            try
            {
                var instance=Object.Instantiate(AssetDatabase.LoadAssetAtPath<GameObject>(Folder+"/"+name+".prefab"));preview.AddSingleGO(instance);
                bool district=name.StartsWith("District"),stop=name.StartsWith("Delivery");
                preview.camera.transform.position=stop?V(-4,3.3f,6):district?V(-28,23,-28):V(-9,10,-14);
                preview.camera.transform.LookAt(stop?V(0,1.6f,0):V(0,district?3:1,13));preview.camera.fieldOfView=40;preview.camera.nearClipPlane=.1f;preview.camera.farClipPlane=200;
                preview.camera.clearFlags=CameraClearFlags.SolidColor;preview.camera.backgroundColor=new Color(.014f,.025f,.038f);
                preview.ambientColor=new Color(.5f,.55f,.62f);preview.lights[0].intensity=1.6f;preview.lights[0].transform.rotation=Quaternion.Euler(35,25,0);
                preview.lights[1].intensity=1.1f;preview.lights[1].transform.rotation=Quaternion.Euler(45,-150,0);
                preview.BeginStaticPreview(new Rect(0,0,1300,1000));preview.Render(true,false);image=preview.EndStaticPreview();
                Directory.CreateDirectory("Logs");File.WriteAllBytes("Logs/Expansion-"+name+".png",image.EncodeToPNG());
            }
            finally{if(image)Object.DestroyImmediate(image);preview.Cleanup();}
        }
    }
}
#endif

#if UNITY_EDITOR
using System.IO;
using UnityEditor;
using UnityEngine;
using Object=UnityEngine.Object;

public static class CourierReferencePreview
{
    [MenuItem("Neon Courier/Capture Reference Characters")]
    public static void Capture(){Draw(false);Draw(true);}
    private static void Draw(bool back)
    {
        var selection=Object.FindAnyObjectByType<CharacterSelectionManager>();if(!selection)return;
        var entries=new SerializedObject(selection).FindProperty("characters");var preview=new PreviewRenderUtility();Texture2D image=null;
        try
        {
            var root=new GameObject("Reference lineup");preview.AddSingleGO(root);
            for(int i=0;i<4;i++)
            {
                var source=(GameObject)entries.GetArrayElementAtIndex(i).FindPropertyRelative("characterRoot").objectReferenceValue;
                var prefab=(GameObject)PrefabUtility.GetCorrespondingObjectFromSource(source);var clone=Object.Instantiate(prefab?prefab:source,root.transform,false);
                clone.transform.localScale=source.transform.localScale;clone.transform.localPosition=new Vector3((1.5f-i)*1.7f,0,0);clone.transform.localRotation=Quaternion.Euler(0,back?165:-12,0);clone.SetActive(true);
                foreach(var behavior in clone.GetComponentsInChildren<MonoBehaviour>(true))behavior.enabled=false;
                var rig=clone.GetComponent<Animator>();if(!rig)rig=clone.GetComponentInChildren<Animator>();var original=source.GetComponent<Animator>();
                if(original)rig.runtimeAnimatorController=original.runtimeAnimatorController;rig.Rebind();rig.Update(0);rig.enabled=false;
                Arm(rig,HumanBodyBones.LeftUpperArm,HumanBodyBones.LeftLowerArm,new Vector3(-.20f,-.60f,.03f));
                Arm(rig,HumanBodyBones.RightUpperArm,HumanBodyBones.RightLowerArm,new Vector3(.20f,-.60f,.03f));
                Arm(rig,HumanBodyBones.LeftLowerArm,HumanBodyBones.LeftHand,new Vector3(-.08f,-.45f,.13f));
                Arm(rig,HumanBodyBones.RightLowerArm,HumanBodyBones.RightHand,new Vector3(.08f,-.45f,.13f));
                var uniform=clone.GetComponent<CourierUniform>();if(!uniform)uniform=clone.AddComponent<CourierUniform>();uniform.Configure(i);uniform.FitNow();uniform.enabled=false;
                var chest=rig.GetBoneTransform(HumanBodyBones.Chest);if(!chest)chest=rig.GetBoneTransform(HumanBodyBones.Spine);var hips=rig.GetBoneTransform(HumanBodyBones.Hips);var head=rig.GetBoneTransform(HumanBodyBones.Head);
                Vector3 up=(head.position-hips.position).normalized,forward=Vector3.ProjectOnPlane(rig.transform.forward,up).normalized;float size=Mathf.Clamp(Vector3.Distance(head.position,hips.position)*1.3f,.7f,1.05f);
                var bag=Object.Instantiate(Resources.Load<GameObject>("CourierReference/Bag"+i),root.transform,false);bag.transform.SetPositionAndRotation(chest.position-up*.06f*size-forward*.31f*size,Quaternion.LookRotation(forward,up));bag.transform.localScale=Vector3.one*size;
            }
            preview.camera.transform.position=new Vector3(0,2.4f,10);preview.camera.transform.LookAt(new Vector3(0,1.2f,0));preview.camera.orthographic=true;preview.camera.orthographicSize=1.7f;preview.camera.nearClipPlane=.1f;preview.camera.farClipPlane=100;
            preview.camera.clearFlags=CameraClearFlags.SolidColor;preview.camera.backgroundColor=new Color(.035f,.045f,.075f);preview.ambientColor=new Color(.72f,.72f,.78f);
            preview.lights[0].intensity=1.6f;preview.lights[0].transform.rotation=Quaternion.Euler(25,155,0);preview.lights[1].intensity=.8f;preview.lights[1].transform.rotation=Quaternion.Euler(10,-30,0);
            preview.BeginStaticPreview(new Rect(0,0,1800,850));preview.Render(true,false);image=preview.EndStaticPreview();Directory.CreateDirectory("Logs");File.WriteAllBytes("Logs/Reference-"+(back?"Backpacks":"Lineup")+".png",image.EncodeToPNG());
        }
        finally{if(image)Object.DestroyImmediate(image);preview.Cleanup();}
    }
    private static void Arm(Animator rig,HumanBodyBones a,HumanBodyBones b,Vector3 direction)
    {var start=rig.GetBoneTransform(a);var end=rig.GetBoneTransform(b);if(start&&end)start.rotation=Quaternion.FromToRotation(end.position-start.position,rig.transform.TransformDirection(direction))*start.rotation;}
}
#endif

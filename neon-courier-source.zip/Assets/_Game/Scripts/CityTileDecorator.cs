using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering;

[DisallowMultipleComponent]
public sealed class CityTileDecorator : MonoBehaviour
{
    [Serializable]
    private sealed class BuildingEntry
    {
        [Tooltip("Track Tile çevresinde kullanılacak bina prefabı.")]
        public GameObject prefab;

        [Tooltip("Bu binayı diğerlerinden biraz daha uzun veya kısa yapmak için kullanılır.")]
        [Min(0.1f)]
        public float heightMultiplier = 1f;

        [Tooltip("Yalnızca bu prefab için ilave Y dönüş düzeltmesi.")]
        public float yawCorrection = 0f;

        [Tooltip("Bu binayı yol kenarından biraz daha uzağa taşır.")]
        [Min(0f)]
        public float extraSetback = 0f;
    }

    private const string GeneratedRootName =
        "__GeneratedCityBuildings";

    [Header("Building Prefabs")]
    [SerializeField]
    private List<BuildingEntry> buildingPrefabs =
        new List<BuildingEntry>();

    [Header("Track Tile Measurements")]
    [Tooltip("Track Tile'ın yerel Z başlangıcı.")]
    [SerializeField]
    private float tileStartZ = 0f;

    [Tooltip("Bir Track Tile'ın toplam uzunluğu.")]
    [SerializeField, Min(1f)]
    private float tileLength = 30f;

    [Tooltip("Track Tile başlangıcında boş bırakılacak mesafe.")]
    [SerializeField, Min(0f)]
    private float startMargin = 1.5f;

    [Tooltip("Track Tile sonunda boş bırakılacak mesafe.")]
    [SerializeField, Min(0f)]
    private float endMargin = 1.5f;

    [Header("Road Placement")]
    [Tooltip("Yol merkezinden yol kenarına kadar olan mesafe.")]
    [SerializeField, Min(0.1f)]
    private float roadHalfWidth = 4.25f;

    [Tooltip("Yol kenarı ile en yakın bina yüzü arasındaki boşluk.")]
    [SerializeField, Min(0f)]
    private float sidewalkSetback = 1.25f;

    [Tooltip("Binaların oturacağı yerel Y seviyesi.")]
    [SerializeField]
    private float groundY = 0f;

    [Tooltip("Binaların yol kenarından uzaklığında uygulanacak çeşitlilik.")]
    [SerializeField, Min(0f)]
    private float setbackVariation = 0.6f;

    [Header("Building Size")]
    [Tooltip("Binaların hedef yükseklik aralığı.")]
    [SerializeField]
    private Vector2 targetHeightRange =
        new Vector2(10f, 16f);

    [Tooltip("Bir binanın yolun dışına doğru kaplayabileceği maksimum derinlik.")]
    [SerializeField, Min(0.1f)]
    private float maximumBuildingDepth = 6f;

    [Tooltip("Bir binanın pist boyunca kaplayabileceği maksimum uzunluk.")]
    [SerializeField, Min(0.1f)]
    private float maximumBuildingLength = 7f;

    [Header("Spacing")]
    [Tooltip("Her tarafta oluşturulabilecek maksimum bina sayısı.")]
    [SerializeField, Min(1)]
    private int maximumBuildingsPerSide = 5;

    [Tooltip("Ardışık binalar arasındaki boşluk.")]
    [SerializeField]
    private Vector2 buildingGapRange =
        new Vector2(0.8f, 1.4f);

    [Header("Orientation")]
    [Tooltip("Sol taraftaki binaların temel Y dönüşü.")]
    [SerializeField]
    private float leftSideRotationY = 90f;

    [Tooltip("Sağ taraftaki binaların temel Y dönüşü.")]
    [SerializeField]
    private float rightSideRotationY = -90f;

    [Header("Renderer Settings")]
    [SerializeField]
    private bool castShadows = true;

    [SerializeField]
    private bool receiveShadows = true;

    [Tooltip("Bina prefablarındaki collider bileşenlerini kapatır.")]
    [SerializeField]
    private bool disableBuildingColliders = true;

    [Header("Generation")]
    [SerializeField]
    private bool generateOnAwake = true;

    [Tooltip("Track sistemi tile'ı yenilediğinde bina düzenini yeniden oluşturur.")]
    [SerializeField]
    private bool regenerateWhenRefreshed = false;

    [Tooltip("Her üretimde farklı bina düzeni oluşturur.")]
    [SerializeField]
    private bool randomizeEveryGeneration = true;

    [SerializeField]
    private int fixedSeed = 2026;

    private Transform generatedRoot;

    private void Awake()
    {
        if (generateOnAwake)
        {
            GenerateBuildings();
        }
    }

    /*
     * TrackManager bu metodu çağırıyor.
     * Regenerate When Refreshed kapalıysa mevcut
     * binalar korunur ve tile ile birlikte taşınır.
     */
    public void RefreshLayout()
    {
        RefreshDecoration();
    }

    public void RefreshLayout(int customSeed)
    {
        GenerateBuildings(customSeed);
    }

    public void RefreshDecoration()
    {
        if (
            regenerateWhenRefreshed ||
            !HasGeneratedBuildings()
        )
        {
            GenerateBuildings();
        }
    }

    /*
     * Eski veya farklı TrackManager sürümleriyle
     * uyumluluk için alternatif metot isimleri.
     */
    public void GenerateDecoration()
    {
        RefreshDecoration();
    }

    public void Decorate()
    {
        RefreshDecoration();
    }

    public void DecorateTile()
    {
        RefreshDecoration();
    }

    public void RegenerateDecoration()
    {
        GenerateBuildings();
    }

    public void RefreshDecoration(int customSeed)
    {
        GenerateBuildings(customSeed);
    }

    [ContextMenu("Preview / Generate Buildings")]
    public void GenerateBuildings()
    {
        int seed = CalculateSeed();

        GenerateBuildings(seed);
    }

    public void GenerateBuildings(int generationSeed)
    {
        List<BuildingEntry> validEntries =
            GetValidBuildingEntries();

        if (validEntries.Count == 0)
        {
            Debug.LogWarning(
                "CityTileDecorator: Building Prefabs listesinde geçerli prefab bulunamadı.",
                this
            );

            ClearBuildings();
            return;
        }

        ClearBuildings();
        CreateGeneratedRoot();

        UnityEngine.Random.State previousState =
            UnityEngine.Random.state;

        UnityEngine.Random.InitState(
            generationSeed
        );

        GenerateSide(
            -1,
            validEntries
        );

        GenerateSide(
            1,
            validEntries
        );

        UnityEngine.Random.state =
            previousState;
    }

    [ContextMenu("Preview / Clear Buildings")]
    public void ClearBuildings()
    {
        Transform existingRoot =
            FindGeneratedRoot();

        if (existingRoot == null)
        {
            generatedRoot = null;
            return;
        }

        existingRoot.gameObject.SetActive(
            false
        );

        if (Application.isPlaying)
        {
            Destroy(
                existingRoot.gameObject
            );
        }
        else
        {
            DestroyImmediate(
                existingRoot.gameObject
            );
        }

        generatedRoot = null;
    }

    private void GenerateSide(
        int side,
        List<BuildingEntry> validEntries
    )
    {
        float currentZ =
            tileStartZ +
            startMargin;

        float maximumZ =
            tileStartZ +
            tileLength -
            endMargin;

        int placedBuildingCount = 0;
        int attemptCount = 0;
        int lastPrefabIndex = -1;

        int maximumAttempts =
            Mathf.Max(
                maximumBuildingsPerSide * 6,
                12
            );

        while (
            placedBuildingCount <
                maximumBuildingsPerSide &&
            attemptCount <
                maximumAttempts &&
            currentZ <
                maximumZ
        )
        {
            attemptCount++;

            int prefabIndex =
                SelectPrefabIndex(
                    validEntries.Count,
                    lastPrefabIndex
                );

            BuildingEntry entry =
                validEntries[prefabIndex];

            GameObject building =
                Instantiate(
                    entry.prefab,
                    generatedRoot,
                    false
                );

            string sideName =
                side < 0
                    ? "Left"
                    : "Right";

            building.name =
                $"{sideName}_{placedBuildingCount}_{entry.prefab.name}";

            ResetBuildingTransform(
                building.transform
            );

            float baseRotationY =
                side < 0
                    ? leftSideRotationY
                    : rightSideRotationY;

            building.transform.localRotation =
                Quaternion.Euler(
                    0f,
                    baseRotationY +
                    entry.yawCorrection,
                    0f
                );

            ApplyBuildingComponentSettings(
                building
            );

            if (
                !TryGetBoundsInGeneratedSpace(
                    building,
                    out Bounds initialBounds
                )
            )
            {
                Debug.LogWarning(
                    $"CityTileDecorator: {entry.prefab.name} üzerinde Renderer bulunamadı.",
                    entry.prefab
                );

                DestroyGeneratedObject(
                    building
                );

                continue;
            }

            float targetHeight =
                UnityEngine.Random.Range(
                    targetHeightRange.x,
                    targetHeightRange.y
                );

            targetHeight *=
                Mathf.Max(
                    0.1f,
                    entry.heightMultiplier
                );

            float heightScale =
                targetHeight /
                Mathf.Max(
                    0.001f,
                    initialBounds.size.y
                );

            building.transform.localScale =
                Vector3.one *
                heightScale;

            if (
                !TryGetBoundsInGeneratedSpace(
                    building,
                    out Bounds scaledBounds
                )
            )
            {
                DestroyGeneratedObject(
                    building
                );

                continue;
            }

            float footprintScale = 1f;

            if (
                scaledBounds.size.x >
                maximumBuildingDepth
            )
            {
                footprintScale =
                    Mathf.Min(
                        footprintScale,
                        maximumBuildingDepth /
                        scaledBounds.size.x
                    );
            }

            if (
                scaledBounds.size.z >
                maximumBuildingLength
            )
            {
                footprintScale =
                    Mathf.Min(
                        footprintScale,
                        maximumBuildingLength /
                        scaledBounds.size.z
                    );
            }

            if (footprintScale < 1f)
            {
                building.transform.localScale *=
                    footprintScale;
            }

            if (
                !TryGetBoundsInGeneratedSpace(
                    building,
                    out Bounds finalBounds
                )
            )
            {
                DestroyGeneratedObject(
                    building
                );

                continue;
            }

            float requiredEndZ =
                currentZ +
                finalBounds.size.z;

            if (requiredEndZ > maximumZ)
            {
                DestroyGeneratedObject(
                    building
                );

                continue;
            }

            float randomSetback =
                UnityEngine.Random.Range(
                    0f,
                    setbackVariation
                );

            float totalSetback =
                sidewalkSetback +
                randomSetback +
                Mathf.Max(
                    0f,
                    entry.extraSetback
                );

            float targetNearEdgeX =
                side < 0
                    ? -roadHalfWidth -
                      totalSetback
                    : roadHalfWidth +
                      totalSetback;

            Vector3 placementOffset =
                Vector3.zero;

            if (side < 0)
            {
                placementOffset.x =
                    targetNearEdgeX -
                    finalBounds.max.x;
            }
            else
            {
                placementOffset.x =
                    targetNearEdgeX -
                    finalBounds.min.x;
            }

            placementOffset.y =
                groundY -
                finalBounds.min.y;

            placementOffset.z =
                currentZ -
                finalBounds.min.z;

            building.transform.localPosition +=
                placementOffset;

            float buildingGap =
                UnityEngine.Random.Range(
                    buildingGapRange.x,
                    buildingGapRange.y
                );

            currentZ +=
                finalBounds.size.z +
                buildingGap;

            lastPrefabIndex =
                prefabIndex;

            placedBuildingCount++;
        }
    }

    private void ResetBuildingTransform(
        Transform buildingTransform
    )
    {
        buildingTransform.localPosition =
            Vector3.zero;

        buildingTransform.localRotation =
            Quaternion.identity;

        buildingTransform.localScale =
            Vector3.one;
    }

    private void ApplyBuildingComponentSettings(
        GameObject building
    )
    {
        Renderer[] renderers =
            building.GetComponentsInChildren
                <Renderer>(true);

        foreach (
            Renderer buildingRenderer
            in renderers
        )
        {
            if (buildingRenderer == null)
            {
                continue;
            }

            buildingRenderer.shadowCastingMode =
                castShadows
                    ? ShadowCastingMode.On
                    : ShadowCastingMode.Off;

            buildingRenderer.receiveShadows =
                receiveShadows;
        }

        if (!disableBuildingColliders)
        {
            return;
        }

        Collider[] colliders =
            building.GetComponentsInChildren
                <Collider>(true);

        foreach (
            Collider buildingCollider
            in colliders
        )
        {
            if (buildingCollider != null)
            {
                buildingCollider.enabled =
                    false;
            }
        }
    }

    private bool TryGetBoundsInGeneratedSpace(
        GameObject target,
        out Bounds combinedBounds
    )
    {
        combinedBounds =
            new Bounds();

        if (
            target == null ||
            generatedRoot == null
        )
        {
            return false;
        }

        Renderer[] renderers =
            target.GetComponentsInChildren
                <Renderer>(true);

        bool hasBounds = false;

        foreach (
            Renderer targetRenderer
            in renderers
        )
        {
            if (targetRenderer == null)
            {
                continue;
            }

            Bounds rendererLocalBounds =
                targetRenderer.localBounds;

            Vector3 rendererMinimum =
                rendererLocalBounds.min;

            Vector3 rendererMaximum =
                rendererLocalBounds.max;

            for (int x = 0; x <= 1; x++)
            {
                for (int y = 0; y <= 1; y++)
                {
                    for (int z = 0; z <= 1; z++)
                    {
                        Vector3 rendererCorner =
                            new Vector3(
                                x == 0
                                    ? rendererMinimum.x
                                    : rendererMaximum.x,
                                y == 0
                                    ? rendererMinimum.y
                                    : rendererMaximum.y,
                                z == 0
                                    ? rendererMinimum.z
                                    : rendererMaximum.z
                            );

                        Vector3 worldCorner =
                            targetRenderer.transform
                                .TransformPoint(
                                    rendererCorner
                                );

                        Vector3 generatedLocalCorner =
                            generatedRoot
                                .InverseTransformPoint(
                                    worldCorner
                                );

                        if (!hasBounds)
                        {
                            combinedBounds =
                                new Bounds(
                                    generatedLocalCorner,
                                    Vector3.zero
                                );

                            hasBounds = true;
                        }
                        else
                        {
                            combinedBounds.Encapsulate(
                                generatedLocalCorner
                            );
                        }
                    }
                }
            }
        }

        return
            hasBounds &&
            combinedBounds.size.sqrMagnitude >
            0.000001f;
    }

    private List<BuildingEntry>
        GetValidBuildingEntries()
    {
        List<BuildingEntry> validEntries =
            new List<BuildingEntry>();

        foreach (
            BuildingEntry buildingEntry
            in buildingPrefabs
        )
        {
            if (
                buildingEntry != null &&
                buildingEntry.prefab != null
            )
            {
                validEntries.Add(
                    buildingEntry
                );
            }
        }

        return validEntries;
    }

    private int SelectPrefabIndex(
        int entryCount,
        int previousIndex
    )
    {
        if (entryCount <= 1)
        {
            return 0;
        }

        int selectedIndex =
            UnityEngine.Random.Range(
                0,
                entryCount
            );

        int safetyCounter = 0;

        while (
            selectedIndex ==
                previousIndex &&
            safetyCounter < 8
        )
        {
            selectedIndex =
                UnityEngine.Random.Range(
                    0,
                    entryCount
                );

            safetyCounter++;
        }

        return selectedIndex;
    }

    private int CalculateSeed()
    {
        if (randomizeEveryGeneration)
        {
            unchecked
            {
                return
                    Environment.TickCount ^
                    GetInstanceID() * 397;
            }
        }

        unchecked
        {
            int calculatedSeed =
                fixedSeed;

            calculatedSeed =
                calculatedSeed * 31 +
                transform.GetSiblingIndex();

            calculatedSeed =
                calculatedSeed * 31 +
                Mathf.RoundToInt(
                    transform.position.z *
                    10f
                );

            return calculatedSeed;
        }
    }

    private void CreateGeneratedRoot()
    {
        GameObject rootObject =
            new GameObject(
                GeneratedRootName
            );

        generatedRoot =
            rootObject.transform;

        generatedRoot.SetParent(
            transform,
            false
        );

        generatedRoot.localPosition =
            Vector3.zero;

        generatedRoot.localRotation =
            Quaternion.identity;

        generatedRoot.localScale =
            Vector3.one;
    }

    private Transform FindGeneratedRoot()
    {
        if (generatedRoot != null)
        {
            return generatedRoot;
        }

        generatedRoot =
            transform.Find(
                GeneratedRootName
            );

        return generatedRoot;
    }

    private bool HasGeneratedBuildings()
    {
        Transform existingRoot =
            FindGeneratedRoot();

        return
            existingRoot != null &&
            existingRoot.childCount > 0;
    }

    private void DestroyGeneratedObject(
        GameObject target
    )
    {
        if (target == null)
        {
            return;
        }

        target.SetActive(false);

        if (Application.isPlaying)
        {
            Destroy(target);
        }
        else
        {
            DestroyImmediate(target);
        }
    }

    private void OnValidate()
    {
        tileLength =
            Mathf.Max(
                1f,
                tileLength
            );

        startMargin =
            Mathf.Max(
                0f,
                startMargin
            );

        endMargin =
            Mathf.Max(
                0f,
                endMargin
            );

        roadHalfWidth =
            Mathf.Max(
                0.1f,
                roadHalfWidth
            );

        sidewalkSetback =
            Mathf.Max(
                0f,
                sidewalkSetback
            );

        targetHeightRange.x =
            Mathf.Max(
                0.1f,
                targetHeightRange.x
            );

        targetHeightRange.y =
            Mathf.Max(
                targetHeightRange.x,
                targetHeightRange.y
            );

        buildingGapRange.x =
            Mathf.Max(
                0f,
                buildingGapRange.x
            );

        buildingGapRange.y =
            Mathf.Max(
                buildingGapRange.x,
                buildingGapRange.y
            );

        maximumBuildingDepth =
            Mathf.Max(
                0.1f,
                maximumBuildingDepth
            );

        maximumBuildingLength =
            Mathf.Max(
                0.1f,
                maximumBuildingLength
            );

        maximumBuildingsPerSide =
            Mathf.Max(
                1,
                maximumBuildingsPerSide
            );
    }

    private void OnDrawGizmosSelected()
    {
        Gizmos.matrix =
            transform.localToWorldMatrix;

        float minimumZ =
            tileStartZ;

        float maximumZ =
            tileStartZ +
            tileLength;

        Gizmos.DrawLine(
            new Vector3(
                -roadHalfWidth,
                groundY,
                minimumZ
            ),
            new Vector3(
                -roadHalfWidth,
                groundY,
                maximumZ
            )
        );

        Gizmos.DrawLine(
            new Vector3(
                roadHalfWidth,
                groundY,
                minimumZ
            ),
            new Vector3(
                roadHalfWidth,
                groundY,
                maximumZ
            )
        );
    }
}
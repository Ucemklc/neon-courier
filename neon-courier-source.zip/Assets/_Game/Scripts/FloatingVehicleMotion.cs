using UnityEngine;

[DisallowMultipleComponent]
public sealed class FloatingVehicleMotion : MonoBehaviour
{
    [Header("General")]
    [SerializeField]
    private bool animateOnlyInPlayMode = true;

    [SerializeField]
    private bool useUnscaledTime = false;

    [Header("Vertical Hover")]
    [SerializeField]
    private Vector2 bobAmplitudeRange =
        new Vector2(0.15f, 0.35f);

    [SerializeField]
    private Vector2 bobSpeedRange =
        new Vector2(0.8f, 1.3f);

    [Header("Side Drift")]
    [SerializeField]
    private Vector3 driftAxis =
        Vector3.forward;

    [SerializeField]
    private Vector2 driftDistanceRange =
        new Vector2(0.4f, 1.2f);

    [SerializeField]
    private Vector2 driftSpeedRange =
        new Vector2(0.35f, 0.8f);

    [Header("Tilt")]
    [SerializeField]
    private Vector2 rollAngleRange =
        new Vector2(2f, 5f);

    [SerializeField]
    private Vector2 rollSpeedRange =
        new Vector2(0.4f, 0.9f);

    private Vector3 anchorLocalPosition;
    private Quaternion anchorLocalRotation;

    private Vector3 normalizedDriftAxis;

    private float bobAmplitude;
    private float bobSpeed;
    private float driftDistance;
    private float driftSpeed;
    private float rollAngle;
    private float rollSpeed;
    private float phaseOffset;

    private bool initialized;

    private void Awake()
    {
        InitializeMotion();
        CaptureAnchor();
    }

    private void OnEnable()
    {
        if (!initialized)
        {
            InitializeMotion();
        }

        CaptureAnchor();
    }

    private void InitializeMotion()
    {
        normalizedDriftAxis =
            driftAxis.sqrMagnitude > 0.0001f
                ? driftAxis.normalized
                : Vector3.forward;

        bobAmplitude =
            Random.Range(
                bobAmplitudeRange.x,
                bobAmplitudeRange.y
            );

        bobSpeed =
            Random.Range(
                bobSpeedRange.x,
                bobSpeedRange.y
            );

        driftDistance =
            Random.Range(
                driftDistanceRange.x,
                driftDistanceRange.y
            );

        driftSpeed =
            Random.Range(
                driftSpeedRange.x,
                driftSpeedRange.y
            );

        rollAngle =
            Random.Range(
                rollAngleRange.x,
                rollAngleRange.y
            );

        rollSpeed =
            Random.Range(
                rollSpeedRange.x,
                rollSpeedRange.y
            );

        phaseOffset =
            Random.Range(0f, 100f);

        initialized = true;
    }

    private void CaptureAnchor()
    {
        anchorLocalPosition =
            transform.localPosition;

        anchorLocalRotation =
            transform.localRotation;
    }

    private void Update()
    {
        if (
            animateOnlyInPlayMode &&
            !Application.isPlaying
        )
        {
            return;
        }

        float t =
            useUnscaledTime
                ? Time.unscaledTime
                : Time.time;

        float bobOffset =
            Mathf.Sin(
                (t + phaseOffset) *
                bobSpeed
            ) * bobAmplitude;

        float driftOffset =
            Mathf.Sin(
                (t + phaseOffset) *
                driftSpeed
            ) * driftDistance;

        float rollOffset =
            Mathf.Sin(
                (t + phaseOffset) *
                rollSpeed
            ) * rollAngle;

        Vector3 targetLocalPosition =
            anchorLocalPosition +
            normalizedDriftAxis * driftOffset;

        targetLocalPosition.y +=
            bobOffset;

        transform.localPosition =
            targetLocalPosition;

        transform.localRotation =
            anchorLocalRotation *
            Quaternion.Euler(
                0f,
                0f,
                rollOffset
            );
    }
}
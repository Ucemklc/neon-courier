using TMPro;
using UnityEngine;
using UnityEngine.UI;

public sealed class CourierMenuLayout : MonoBehaviour
{
    [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
    private static void Install()
    {var hud=FindAnyObjectByType<HUDController>();if(hud&&!hud.GetComponent<CourierMenuLayout>())hud.gameObject.AddComponent<CourierMenuLayout>();}
    private void Awake(){Apply();}
    public static void Apply()
    {
        Button play=null;
        foreach(var b in FindObjectsByType<Button>(FindObjectsInactive.Include,FindObjectsSortMode.None))if(b.name=="PlayButton"){play=b;break;}
        if(!play)return;
        var panel=(RectTransform)play.transform.parent;
        var outer=panel.parent as RectTransform;
        if(outer && !outer.GetComponent<Canvas>())Stretch(outer);
        Stretch(panel);
        var background=panel.GetComponent<Image>();if(background){background.sprite=null;background.color=new Color(.022f,.038f,.067f,.94f);background.raycastTarget=false;}
        foreach(var g in panel.GetComponentsInChildren<Graphic>(true))g.raycastTarget=false;
        foreach(var b in panel.GetComponentsInChildren<Button>(true))
        {
            float y=b.name=="PlayButton"?910:b.name=="MissionsButton"?720:b.name=="CharacterButton"?545:-1;
            if(y<0)continue;
            Place((RectTransform)b.transform,new Vector2(.5f,0),new Vector2(0,y),new Vector2(820,b==play?160:140));
            var style=b.GetComponent<CourierMenuButton>();if(!style)style=b.gameObject.AddComponent<CourierMenuButton>();style.Style(b==play);
            b.transform.SetAsLastSibling();
        }
        Text(panel,"GameTitle",new Vector2(.5f,1),new Vector2(0,-370),new Vector2(940,170),78);
        Text(panel,"GameSubtitle",new Vector2(.5f,1),new Vector2(0,-505),new Vector2(900,70),28);
        Text(panel,"MainMenuHighScoreText",new Vector2(.5f,0),new Vector2(-220,1125),new Vector2(350,120),32);
        Text(panel,"MainMenuCoinText",new Vector2(.5f,0),new Vector2(220,1125),new Vector2(350,120),32);
        var duplicate=panel.Find("CoinText");if(duplicate)duplicate.gameObject.SetActive(false);
    }
    private static void Text(Transform parent,string name,Vector2 anchor,Vector2 pos,Vector2 size,float font)
    {
        var child=parent.Find(name);if(!child)return;Place((RectTransform)child,anchor,pos,size);
        var t=child.GetComponent<TMP_Text>();if(!t)return;t.font=TMP_Settings.defaultFontAsset;t.fontSharedMaterial=t.font.material;
        t.fontSize=font;t.fontStyle=FontStyles.Bold;t.color=Color.white;t.outlineWidth=0;t.alignment=TextAlignmentOptions.Center;t.raycastTarget=false;
    }
    private static void Stretch(RectTransform r){r.localScale=Vector3.one;r.localRotation=Quaternion.identity;r.anchorMin=Vector2.zero;r.anchorMax=Vector2.one;r.offsetMin=r.offsetMax=Vector2.zero;r.localPosition=new Vector3(r.localPosition.x,r.localPosition.y,0);}
    public static void Place(RectTransform r,Vector2 a,Vector2 p,Vector2 s){r.localScale=Vector3.one;r.localRotation=Quaternion.identity;r.anchorMin=r.anchorMax=a;r.pivot=new Vector2(.5f,.5f);r.anchoredPosition3D=new Vector3(p.x,p.y,0);r.sizeDelta=s;}
}

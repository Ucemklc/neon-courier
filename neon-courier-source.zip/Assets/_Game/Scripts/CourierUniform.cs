using System.Collections.Generic;
using UnityEngine;

/// <summary>Animated courier uniforms use the existing humanoid skeleton and saved character slots.</summary>
[DefaultExecutionOrder(90)]
[DisallowMultipleComponent]
public sealed class CourierUniform : MonoBehaviour
{
    [SerializeField] private int styleIndex;
    private Animator rig;
    private Transform visual,helmet,jacket,hips,leftHand,rightHand,leftShoe,rightShoe,leftBoost,rightBoost;
    private readonly List<Limb> limbs=new List<Limb>();
    private Renderer[] accentRenderers;
    public bool HasReferenceOutfit {get;private set;}
    public int StyleIndex=>styleIndex;
    private Transform[] capeTails;
    private int lastSkin=-1,lastOutfit=-1;
    private sealed class Limb{public Transform start,end,part;public float width;}
    public static string DisplayName(int index)
    {
        string[] tr={"AKI · NEON KURYE","TANAKA · ZIRHLI KURYE","REN · DOĞA KURYESİ","LYRA · GÖLGE KURYE"};
        string[] en={"AKI · NEON RUNNER","TANAKA · HEAVY COURIER","REN · ECO RUNNER","LYRA · SHADOW RUNNER"};
        return (PlayerPrefs.GetInt("NeonCourier.Language",0)==1?en:tr)[Mathf.Clamp(index,0,3)];
    }
    public void Configure(int index){styleIndex=Mathf.Clamp(index,0,3);Build();FitNow();}
    private void Start(){Build();}
    private Transform Bone(HumanBodyBones bone)=>rig.GetBoneTransform(bone);
    private Transform Part(string asset)
    {
        string replacement=asset.StartsWith("Helmet")?"Head":asset=="Jacket"?"Torso":asset;
        var prefab=HasReferenceOutfit?Resources.Load<GameObject>("CourierReference/"+replacement+styleIndex):null;
        if(!prefab)prefab=Resources.Load<GameObject>("CourierPolish/"+asset);if(!prefab)return null;
        return Instantiate(prefab,visual,false).transform;
    }
    public void Build()
    {
        if(visual)return;HasReferenceOutfit=Resources.Load<GameObject>("CourierReference/Head"+styleIndex);rig=GetComponent<Animator>();if(!rig)rig=GetComponentInChildren<Animator>(true);
        if(!rig || !rig.isHuman || !Resources.Load<GameObject>("CourierPolish/Helmet"+styleIndex))return;
        var old=GetComponentsInChildren<Renderer>(true);
        visual=new GameObject("CourierUniformVisual").transform;visual.SetParent(transform,false);
        helmet=Part("Helmet"+styleIndex);jacket=Part("Jacket");hips=Part("Hips");
        leftHand=Part("Glove");rightHand=Part("Glove");leftShoe=Part("Boot");rightShoe=Part("Boot");
        leftBoost=Part("JumpBoost");rightBoost=Part("JumpBoost");
        // Join the rigid suit pieces so the helmet and torso stay connected in motion.
        var torsoBone=Bone(HumanBodyBones.Chest)?HumanBodyBones.Chest:HumanBodyBones.Spine;
        AddLimb(torsoBone,HumanBodyBones.Head,.13f);
        AddLimb(HumanBodyBones.Hips,torsoBone,.34f);
        AddLimb(torsoBone,HumanBodyBones.LeftUpperArm,.17f);
        AddLimb(torsoBone,HumanBodyBones.RightUpperArm,.17f);
        AddLimb(HumanBodyBones.LeftUpperArm,HumanBodyBones.LeftLowerArm,.17f);
        AddLimb(HumanBodyBones.LeftLowerArm,HumanBodyBones.LeftHand,.16f);
        AddLimb(HumanBodyBones.RightUpperArm,HumanBodyBones.RightLowerArm,.17f);
        AddLimb(HumanBodyBones.RightLowerArm,HumanBodyBones.RightHand,.16f);
        AddLimb(HumanBodyBones.LeftUpperLeg,HumanBodyBones.LeftLowerLeg,.22f);
        AddLimb(HumanBodyBones.LeftLowerLeg,HumanBodyBones.LeftFoot,.19f);
        AddLimb(HumanBodyBones.RightUpperLeg,HumanBodyBones.RightLowerLeg,.22f);
        AddLimb(HumanBodyBones.RightLowerLeg,HumanBodyBones.RightFoot,.19f);
        // Hit blinking can toggle renderer.enabled; keep the replaced mesh hidden through it.
        foreach(var r in old){r.enabled=false;r.forceRenderingOff=true;}
        rig.cullingMode=AnimatorCullingMode.AlwaysAnimate;
        accentRenderers=visual.GetComponentsInChildren<Renderer>(true);
        var capes=new List<Transform>();foreach(var t in jacket.GetComponentsInChildren<Transform>())if(t.name.StartsWith("CapeTail"))capes.Add(t);capeTails=capes.ToArray();
        RefreshPalette();
    }
    private void AddLimb(HumanBodyBones a,HumanBodyBones b,float width)
    {
        var start=Bone(a);var end=Bone(b);if(!start||!end)return;
        bool arm=a==HumanBodyBones.LeftUpperArm||a==HumanBodyBones.LeftLowerArm||a==HumanBodyBones.RightUpperArm||a==HumanBodyBones.RightLowerArm;
        bool leg=a==HumanBodyBones.LeftUpperLeg||a==HumanBodyBones.LeftLowerLeg||a==HumanBodyBones.RightUpperLeg||a==HumanBodyBones.RightLowerLeg;
        string part=HasReferenceOutfit?(arm?"Arm":leg?"Leg":"Joint"):"Limb";
        limbs.Add(new Limb{start=start,end=end,part=Part(part),width=width*(HasReferenceOutfit&&styleIndex==1&&(arm||leg)?1.32f:1)});
    }
    private void LateUpdate(){FitNow();}
    public void FitNow()
    {
        if(!visual||!rig)return;
        if(GameManager.Instance&&GameManager.Instance.IsPaused)return;
        CourierScooterRide.Instance?.ApplyPose(rig);
        CourierPowerEffects.Instance?.ApplyPose(rig);
        var h=Bone(HumanBodyBones.Hips);var head=Bone(HumanBodyBones.Head);var chest=Bone(HumanBodyBones.Chest);
        if(!chest)chest=Bone(HumanBodyBones.Spine);if(!h||!head||!chest)return;
        Vector3 up=(head.position-h.position).normalized;
        Vector3 forward=Vector3.ProjectOnPlane(rig.transform.forward,up).normalized;
        if(forward.sqrMagnitude<.5f)return;
        var facing=Quaternion.LookRotation(forward,up);
        float size=Mathf.Clamp(Vector3.Distance(head.position,h.position)*1.3f,.7f,1.05f);
        Fit(helmet,head.position+up*.12f*size,facing,Vector3.one*size);
        if(capeTails!=null&&CourierJourney.Active)foreach(var cape in capeTails)cape.localRotation=Quaternion.Euler(6+Mathf.Sin(Time.time*5+cape.localPosition.x*8)*7,Mathf.Sin(Time.time*3)*5,0);
        Fit(jacket,chest.position-up*.10f*size,facing,Vector3.one*size);
        Fit(hips,h.position,facing,Vector3.one*size);
        foreach(var l in limbs)
        {
            Vector3 delta=l.end.position-l.start.position;
            // Keep the garment's long axis exactly on the limb, including forward-bent knees/elbows.
            Vector3 limbForward=Vector3.ProjectOnPlane(forward,delta.normalized);
            if(limbForward.sqrMagnitude<.0001f)limbForward=Vector3.ProjectOnPlane(facing*Vector3.right,delta.normalized);
            Fit(l.part,(l.start.position+l.end.position)*.5f,Quaternion.LookRotation(limbForward.normalized,delta.normalized),new Vector3(l.width*size,delta.magnitude,l.width*size));
        }
        FitHand(leftHand,HumanBodyBones.LeftHand,facing,size);FitHand(rightHand,HumanBodyBones.RightHand,facing,size);
        FitFoot(leftShoe,leftBoost,HumanBodyBones.LeftFoot,HumanBodyBones.LeftToes,facing,size);
        FitFoot(rightShoe,rightBoost,HumanBodyBones.RightFoot,HumanBodyBones.RightToes,facing,size);
        if(lastSkin!=CourierBackpackStyle.Skin||lastOutfit!=CourierCareerProgress.Outfit)RefreshPalette();
    }
    private void FitHand(Transform part,HumanBodyBones bone,Quaternion rotation,float size)
    {var b=Bone(bone);if(b)Fit(part,b.position,rotation,Vector3.one*size);}
    private void FitFoot(Transform shoe,Transform boost,HumanBodyBones foot,HumanBodyBones toes,Quaternion fallback,float size)
    {
        var b=Bone(foot);if(!b)return;var tip=Bone(toes);
        Vector3 forward=tip?tip.position-b.position:fallback*Vector3.forward;
        var rotation=forward.sqrMagnitude>.0001f?Quaternion.LookRotation(forward.normalized,fallback*Vector3.up):fallback;
        Fit(shoe,b.position,rotation,Vector3.one*size);Fit(boost,b.position,rotation,Vector3.one*size);
        if(boost)boost.gameObject.SetActive(PowerUpController.Instance&&PowerUpController.Instance.IsJumpShoesActive);
    }
    private static void Fit(Transform t,Vector3 pos,Quaternion rot,Vector3 size)
    {
        if(!t)return;t.SetPositionAndRotation(pos,rot);var scale=t.parent.lossyScale;
        t.localScale=new Vector3(size.x/Mathf.Max(.001f,Mathf.Abs(scale.x)),size.y/Mathf.Max(.001f,Mathf.Abs(scale.y)),size.z/Mathf.Max(.001f,Mathf.Abs(scale.z)));
    }
    private void RefreshPalette()
    {
        lastSkin=CourierBackpackStyle.Skin;var color=CourierBackpackStyle.Accents[lastSkin];
        lastOutfit=CourierCareerProgress.Outfit;
        var block=new MaterialPropertyBlock();
        foreach(var r in accentRenderers)
        {
            if(!r || !r.sharedMaterial)continue;
            string material=r.sharedMaterial.name;Color tint;
            if(material=="SafetyTangerine")tint=color;
            else if(material=="BlueSlate")tint=lastOutfit==1?new Color(.12f,.34f,.44f):lastOutfit==2?new Color(.16f,.19f,.29f):r.sharedMaterial.GetColor("_BaseColor");
            else if(material=="Porcelain")tint=lastOutfit==2?new Color(1,.72f,.22f):r.sharedMaterial.GetColor("_BaseColor");
            else continue;
            block.Clear();block.SetColor("_BaseColor",tint);block.SetColor("_Color",tint);r.SetPropertyBlock(block);
        }
    }
}

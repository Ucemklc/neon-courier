using System;
using System.Globalization;
using UnityEngine;

public enum DailyMissionType
{
    RunDistance,
    CollectPackages,
    DeliverPackages,
    ReachCombo
}

public class DailyMissionManager : MonoBehaviour
{
    public static DailyMissionManager Instance
    {
        get;
        private set;
    }

    [Header("Run Distance")]
    [SerializeField, Min(1)]
    private int distanceTarget = 500;

    [SerializeField, Min(1)]
    private int distanceReward = 50;

    [Header("Collect Packages")]
    [SerializeField, Min(1)]
    private int collectTarget = 10;

    [SerializeField, Min(1)]
    private int collectReward = 75;

    [Header("Deliver Packages")]
    [SerializeField, Min(1)]
    private int deliverTarget = 5;

    [SerializeField, Min(1)]
    private int deliverReward = 100;

    [Header("Reach Combo")]
    [SerializeField, Min(1)]
    private int comboTarget = 3;

    [SerializeField, Min(1)]
    private int comboReward = 125;

    [Header("Saving")]
    [SerializeField, Min(1)]
    private int distanceSaveInterval = 25;

    public event Action MissionsChanged;

    private const string Prefix =
        "NeonCourier.DailyMission.";

    private const string DateKey =
        Prefix + "Date";

    private const string DistanceProgressKey =
        Prefix + "DistanceProgress";

    private const string CollectProgressKey =
        Prefix + "CollectProgress";

    private const string DeliverProgressKey =
        Prefix + "DeliverProgress";

    private const string ComboProgressKey =
        Prefix + "ComboProgress";

    private const string DistanceClaimedKey =
        Prefix + "DistanceClaimed";

    private const string CollectClaimedKey =
        Prefix + "CollectClaimed";

    private const string DeliverClaimedKey =
        Prefix + "DeliverClaimed";

    private const string ComboClaimedKey =
        Prefix + "ComboClaimed";

    private GameManager gameManager;

    private int distanceProgress;
    private int collectProgress;
    private int deliverProgress;
    private int comboProgress;

    private bool distanceClaimed;
    private bool collectClaimed;
    private bool deliverClaimed;
    private bool comboClaimed;

    private int previousRunDistance;
    private int previousCarriedPackages;
    private int previousDeliveredPackages;
    private int previousCombo;

    private int lastFlushedDistanceProgress;

    private void Awake()
    {
        if (
            Instance != null &&
            Instance != this
        )
        {
            Destroy(gameObject);
            return;
        }

        Instance = this;

        EnsureCurrentDay();
        LoadProgress();
    }

    private void Start()
    {
        gameManager = GameManager.Instance;

        if (gameManager == null)
        {
            Debug.LogError(
                "DailyMissionManager: GameManager bulunamadı.",
                this
            );

            enabled = false;
            return;
        }

        ResetSnapshots();

        gameManager.StatsChanged +=
            HandleStatsChanged;

        MissionsChanged?.Invoke();
    }

    private void OnDestroy()
    {
        if (gameManager != null)
        {
            gameManager.StatsChanged -=
                HandleStatsChanged;
        }

        SaveProgress(true);

        if (Instance == this)
        {
            Instance = null;
        }
    }

    private void OnApplicationPause(
        bool pauseStatus
    )
    {
        if (pauseStatus)
        {
            SaveProgress(true);
        }
    }

    private void OnApplicationFocus(
        bool hasFocus
    )
    {
        if (!hasFocus)
        {
            return;
        }

        bool dayChanged =
            EnsureCurrentDay();

        if (!dayChanged)
        {
            return;
        }

        LoadProgress();
        ResetSnapshots();

        MissionsChanged?.Invoke();
    }

    private void HandleStatsChanged()
    {
        if (gameManager == null)
        {
            return;
        }

        int currentDistance =
            gameManager.DistanceMeters;

        int currentCarriedPackages =
            gameManager.CarriedPackages;

        int currentDeliveredPackages =
            gameManager.DeliveredPackages;

        int currentCombo =
            gameManager.ComboMultiplier;

        int distanceDelta =
            Mathf.Max(
                0,
                currentDistance -
                previousRunDistance
            );

        int collectedDelta =
            Mathf.Max(
                0,
                currentCarriedPackages -
                previousCarriedPackages
            );

        int deliveredDelta =
            Mathf.Max(
                0,
                currentDeliveredPackages -
                previousDeliveredPackages
            );

        bool progressChanged = false;
        bool saveImmediately = false;

        if (
            distanceDelta > 0 &&
            distanceProgress < distanceTarget
        )
        {
            distanceProgress =
                Mathf.Min(
                    distanceTarget,
                    distanceProgress +
                    distanceDelta
                );

            progressChanged = true;
        }

        if (
            collectedDelta > 0 &&
            collectProgress < collectTarget
        )
        {
            collectProgress =
                Mathf.Min(
                    collectTarget,
                    collectProgress +
                    collectedDelta
                );

            progressChanged = true;
            saveImmediately = true;
        }

        if (
            deliveredDelta > 0 &&
            deliverProgress < deliverTarget
        )
        {
            deliverProgress =
                Mathf.Min(
                    deliverTarget,
                    deliverProgress +
                    deliveredDelta
                );

            progressChanged = true;
            saveImmediately = true;
        }

        if (
            currentCombo > comboProgress &&
            comboProgress < comboTarget
        )
        {
            comboProgress =
                Mathf.Min(
                    comboTarget,
                    currentCombo
                );

            progressChanged = true;
            saveImmediately = true;
        }

        previousRunDistance =
            currentDistance;

        previousCarriedPackages =
            currentCarriedPackages;

        previousDeliveredPackages =
            currentDeliveredPackages;

        previousCombo =
            currentCombo;

        if (!progressChanged)
        {
            return;
        }

        bool reachedDistanceSavePoint =
            distanceProgress -
            lastFlushedDistanceProgress >=
            distanceSaveInterval;

        SaveProgress(
            saveImmediately ||
            reachedDistanceSavePoint ||
            IsCompleted(
                DailyMissionType.RunDistance
            )
        );

        MissionsChanged?.Invoke();
    }

    public string GetTitle(
        DailyMissionType missionType
    )
    {
        switch (missionType)
        {
            case DailyMissionType.RunDistance:
                return $"{distanceTarget} METRE KOŞ";

            case DailyMissionType.CollectPackages:
                return $"{collectTarget} PAKET TOPLA";

            case DailyMissionType.DeliverPackages:
                return $"{deliverTarget} PAKET TESLİM ET";

            case DailyMissionType.ReachCombo:
                return $"COMBO x{comboTarget} SEVİYESİNE ULAŞ";

            default:
                return "GÖREV";
        }
    }

    public int GetProgress(
        DailyMissionType missionType
    )
    {
        switch (missionType)
        {
            case DailyMissionType.RunDistance:
                return distanceProgress;

            case DailyMissionType.CollectPackages:
                return collectProgress;

            case DailyMissionType.DeliverPackages:
                return deliverProgress;

            case DailyMissionType.ReachCombo:
                return comboProgress;

            default:
                return 0;
        }
    }

    public int GetTarget(
        DailyMissionType missionType
    )
    {
        switch (missionType)
        {
            case DailyMissionType.RunDistance:
                return distanceTarget;

            case DailyMissionType.CollectPackages:
                return collectTarget;

            case DailyMissionType.DeliverPackages:
                return deliverTarget;

            case DailyMissionType.ReachCombo:
                return comboTarget;

            default:
                return 1;
        }
    }

    public int GetReward(
        DailyMissionType missionType
    )
    {
        switch (missionType)
        {
            case DailyMissionType.RunDistance:
                return distanceReward;

            case DailyMissionType.CollectPackages:
                return collectReward;

            case DailyMissionType.DeliverPackages:
                return deliverReward;

            case DailyMissionType.ReachCombo:
                return comboReward;

            default:
                return 0;
        }
    }

    public float GetNormalizedProgress(
        DailyMissionType missionType
    )
    {
        int target =
            Mathf.Max(
                1,
                GetTarget(missionType)
            );

        return Mathf.Clamp01(
            (float)GetProgress(missionType) /
            target
        );
    }

    public bool IsCompleted(
        DailyMissionType missionType
    )
    {
        return
            GetProgress(missionType) >=
            GetTarget(missionType);
    }

    public bool IsClaimed(
        DailyMissionType missionType
    )
    {
        switch (missionType)
        {
            case DailyMissionType.RunDistance:
                return distanceClaimed;

            case DailyMissionType.CollectPackages:
                return collectClaimed;

            case DailyMissionType.DeliverPackages:
                return deliverClaimed;

            case DailyMissionType.ReachCombo:
                return comboClaimed;

            default:
                return false;
        }
    }

    public bool ClaimMission(
        DailyMissionType missionType
    )
    {
        if (
            gameManager == null ||
            !IsCompleted(missionType) ||
            IsClaimed(missionType)
        )
        {
            return false;
        }

        SetClaimed(
            missionType,
            true
        );

        int reward =
            GetReward(missionType);

        gameManager.AddCoins(reward);

        SaveProgress(true);
        MissionsChanged?.Invoke();

        return true;
    }

    private void SetClaimed(
        DailyMissionType missionType,
        bool claimed
    )
    {
        switch (missionType)
        {
            case DailyMissionType.RunDistance:
                distanceClaimed = claimed;
                break;

            case DailyMissionType.CollectPackages:
                collectClaimed = claimed;
                break;

            case DailyMissionType.DeliverPackages:
                deliverClaimed = claimed;
                break;

            case DailyMissionType.ReachCombo:
                comboClaimed = claimed;
                break;
        }
    }

    private void ResetSnapshots()
    {
        if (gameManager == null)
        {
            previousRunDistance = 0;
            previousCarriedPackages = 0;
            previousDeliveredPackages = 0;
            previousCombo = 1;
            return;
        }

        previousRunDistance =
            gameManager.DistanceMeters;

        previousCarriedPackages =
            gameManager.CarriedPackages;

        previousDeliveredPackages =
            gameManager.DeliveredPackages;

        previousCombo =
            gameManager.ComboMultiplier;
    }

    private bool EnsureCurrentDay()
    {
        string today =
            DateTime.Now.ToString(
                "yyyyMMdd",
                CultureInfo.InvariantCulture
            );

        string savedDate =
            PlayerPrefs.GetString(
                DateKey,
                string.Empty
            );

        if (savedDate == today)
        {
            return false;
        }

        PlayerPrefs.SetString(
            DateKey,
            today
        );

        ResetSavedMissionValues();

        PlayerPrefs.Save();

        return true;
    }

    private void LoadProgress()
    {
        distanceProgress =
            PlayerPrefs.GetInt(
                DistanceProgressKey,
                0
            );

        collectProgress =
            PlayerPrefs.GetInt(
                CollectProgressKey,
                0
            );

        deliverProgress =
            PlayerPrefs.GetInt(
                DeliverProgressKey,
                0
            );

        comboProgress =
            PlayerPrefs.GetInt(
                ComboProgressKey,
                0
            );

        distanceClaimed =
            PlayerPrefs.GetInt(
                DistanceClaimedKey,
                0
            ) == 1;

        collectClaimed =
            PlayerPrefs.GetInt(
                CollectClaimedKey,
                0
            ) == 1;

        deliverClaimed =
            PlayerPrefs.GetInt(
                DeliverClaimedKey,
                0
            ) == 1;

        comboClaimed =
            PlayerPrefs.GetInt(
                ComboClaimedKey,
                0
            ) == 1;

        lastFlushedDistanceProgress =
            distanceProgress;
    }

    private void SaveProgress(
        bool flushToDisk
    )
    {
        PlayerPrefs.SetInt(
            DistanceProgressKey,
            distanceProgress
        );

        PlayerPrefs.SetInt(
            CollectProgressKey,
            collectProgress
        );

        PlayerPrefs.SetInt(
            DeliverProgressKey,
            deliverProgress
        );

        PlayerPrefs.SetInt(
            ComboProgressKey,
            comboProgress
        );

        PlayerPrefs.SetInt(
            DistanceClaimedKey,
            distanceClaimed ? 1 : 0
        );

        PlayerPrefs.SetInt(
            CollectClaimedKey,
            collectClaimed ? 1 : 0
        );

        PlayerPrefs.SetInt(
            DeliverClaimedKey,
            deliverClaimed ? 1 : 0
        );

        PlayerPrefs.SetInt(
            ComboClaimedKey,
            comboClaimed ? 1 : 0
        );

        if (!flushToDisk)
        {
            return;
        }

        lastFlushedDistanceProgress =
            distanceProgress;

        PlayerPrefs.Save();
    }

    private void ResetSavedMissionValues()
    {
        PlayerPrefs.SetInt(
            DistanceProgressKey,
            0
        );

        PlayerPrefs.SetInt(
            CollectProgressKey,
            0
        );

        PlayerPrefs.SetInt(
            DeliverProgressKey,
            0
        );

        PlayerPrefs.SetInt(
            ComboProgressKey,
            0
        );

        PlayerPrefs.SetInt(
            DistanceClaimedKey,
            0
        );

        PlayerPrefs.SetInt(
            CollectClaimedKey,
            0
        );

        PlayerPrefs.SetInt(
            DeliverClaimedKey,
            0
        );

        PlayerPrefs.SetInt(
            ComboClaimedKey,
            0
        );
    }

    [ContextMenu("Reset Daily Mission Progress")]
    private void ResetDailyMissionProgress()
    {
        ResetSavedMissionValues();
        PlayerPrefs.Save();

        LoadProgress();
        ResetSnapshots();

        MissionsChanged?.Invoke();

        Debug.Log(
            "Günlük görev ilerlemeleri sıfırlandı."
        );
    }
}
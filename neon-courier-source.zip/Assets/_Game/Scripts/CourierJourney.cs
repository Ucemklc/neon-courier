using UnityEngine;
using UnityEngine.SceneManagement;

public static class CourierJourney
{
    public static bool Active=>GameManager.Instance&&GameManager.Instance.IsRunActive&&!GameManager.Instance.IsPaused&&!GameManager.Instance.IsGameOver&&!GameManager.Instance.IsMainMenuActive;
    [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
    private static void Install(){SceneManager.sceneLoaded-=Loaded;SceneManager.sceneLoaded+=Loaded;Loaded(SceneManager.GetActiveScene(),LoadSceneMode.Single);}
    private static void Loaded(Scene scene,LoadSceneMode mode)
    {
        var gm=Object.FindAnyObjectByType<GameManager>();if(!gm)return;
        Add<CourierTimedDelivery>(gm);Add<CourierGhostRace>(gm);Add<CourierScooterRide>(gm);Add<CourierWeather>(gm);Add<CourierJourneyHUD>(gm);
    }
    private static void Add<T>(GameManager gm) where T:Component{if(!gm.GetComponent<T>())gm.gameObject.AddComponent<T>();}
}

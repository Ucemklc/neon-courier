using System;
using System.Collections.Generic;
using System.IO;
using UnityEngine;

/// <summary>Bounded, local replay of the best scoring run. Replay never participates in physics.</summary>
public sealed class CourierGhostRace : MonoBehaviour
{
    public const string EnabledKey="NeonCourier.GhostEnabled";
    [Serializable] public struct Sample{public float t,x,y,z;public bool slide,scooter;}
    [Serializable] public sealed class Replay{public int version=1,score,distance;public List<Sample> samples=new List<Sample>();}
    private GameManager manager;
    private RunnerController runner;
    private Replay opponent,recording=new Replay();
    private Transform ghost;
    private float clock,nextSample,interval=.2f;
    private int cursor,savedScore;
    public float RunClock=>clock;
    public bool HasRecord=>opponent!=null;
    public float LeadMetres {get;private set;}
    public bool RaceEnabled=>PlayerPrefs.GetInt(EnabledKey,1)==1;
    public string SavePath=>Path.Combine(Application.persistentDataPath,"courier-best-run-v1.json");
    private void Start()
    {
        manager=GetComponent<GameManager>();runner=FindAnyObjectByType<RunnerController>();
        opponent=Load(SavePath);savedScore=opponent?.score??0;
        var prefab=Resources.Load<GameObject>("CourierJourney/RecordGhost");
        if(prefab){ghost=Instantiate(prefab).transform;ghost.gameObject.SetActive(false);}
        manager.GameOverTriggered+=SaveBest;manager.MainMenuChanged+=Menu;
    }
    private void OnDestroy(){if(manager){manager.GameOverTriggered-=SaveBest;manager.MainMenuChanged-=Menu;}if(ghost)Destroy(ghost.gameObject);}
    public void Toggle(){PlayerPrefs.SetInt(EnabledKey,RaceEnabled?0:1);PlayerPrefs.Save();}
    private void Menu(bool open)
    {
        if(!open)return;clock=nextSample=0;interval=.2f;cursor=0;recording=new Replay();
        opponent=Load(SavePath);savedScore=opponent?.score??0;if(ghost)ghost.gameObject.SetActive(false);
    }
    private void LateUpdate()
    {
        if(!runner)return;
        if(!CourierJourney.Active){if(ghost)ghost.gameObject.SetActive(false);return;}
        clock+=Time.deltaTime;
        if(clock>=nextSample)
        {
            if(recording.samples.Count>=6000){for(int i=recording.samples.Count-2;i>0;i-=2)recording.samples.RemoveAt(i);interval*=2;}
            var p=runner.transform.position;recording.samples.Add(new Sample{t=clock,x=p.x,y=p.y,z=p.z,slide=runner.IsSliding,scooter=CourierScooterRide.Instance&&CourierScooterRide.Instance.IsRiding});nextSample=clock+interval;
        }
        if(!ghost||!RaceEnabled||opponent==null){if(ghost)ghost.gameObject.SetActive(false);return;}
        Sample s=At(opponent,clock,ref cursor);LeadMetres=runner.transform.position.z-s.z;
        bool visible=Mathf.Abs(LeadMetres)<75&&clock<=opponent.samples[opponent.samples.Count-1].t;
        ghost.gameObject.SetActive(visible);
        if(!visible)return;
        ghost.position=new Vector3(s.x,s.y-1f,s.z);
        ghost.localScale=new Vector3(1,s.slide?.55f:1,1);
        var left=ghost.Find("Left leg");var right=ghost.Find("Right leg");float swing=s.scooter?0:Mathf.Sin(clock*11)*28;
        if(left)left.localRotation=Quaternion.Euler(swing,0,0);if(right)right.localRotation=Quaternion.Euler(-swing,0,0);
    }
    public void SaveBest()
    {
        if(!manager||recording.samples.Count<5||manager.Score<=savedScore)return;
        // Automated editor checks must never replace a player's replay.
#if UNITY_EDITOR
        if(!string.IsNullOrEmpty(UnityEditor.SessionState.GetString("CourierPolish.Prefs","")))return;
#endif
        recording.score=manager.Score;recording.distance=manager.DistanceMeters;
        if(Save(SavePath,recording))savedScore=recording.score;
    }
    public static bool Valid(Replay data)
    {
        if(data==null||data.version!=1||data.score<=0||data.distance<0||data.samples==null||data.samples.Count<2||data.samples.Count>6001)return false;
        float previous=-1;
        foreach(var s in data.samples){if(!Finite(s.t)||!Finite(s.x)||!Finite(s.y)||!Finite(s.z)||s.t<=previous||s.t<0||Mathf.Abs(s.x)>100||Mathf.Abs(s.y)>100||Mathf.Abs(s.z)>10000000)return false;previous=s.t;}return true;
    }
    private static bool Finite(float f)=>!float.IsNaN(f)&&!float.IsInfinity(f);
    public static Replay Load(string path)
    {
        try{if(!File.Exists(path)||new FileInfo(path).Length>2000000)return null;var data=JsonUtility.FromJson<Replay>(File.ReadAllText(path));return Valid(data)?data:null;}
        catch(Exception e) when(e is IOException||e is UnauthorizedAccessException||e is ArgumentException){return null;}
    }
    public static bool Save(string path,Replay data)
    {
        if(!Valid(data))return false;
        try{Directory.CreateDirectory(Path.GetDirectoryName(path));File.WriteAllText(path+".tmp",JsonUtility.ToJson(data));if(File.Exists(path))File.Replace(path+".tmp",path,null);else File.Move(path+".tmp",path);return true;}
        catch(Exception e) when(e is IOException||e is UnauthorizedAccessException||e is ArgumentException){Debug.LogWarning("Courier replay could not be saved: "+e.Message);return false;}
    }
    public static Sample At(Replay data,float t,ref int index)
    {
        index=Mathf.Clamp(index,0,data.samples.Count-2);
        if(t<data.samples[index].t)index=0;
        while(index<data.samples.Count-2&&data.samples[index+1].t<t)index++;
        Sample a=data.samples[index],b=data.samples[index+1];float f=Mathf.InverseLerp(a.t,b.t,t);
        return new Sample{t=t,x=Mathf.Lerp(a.x,b.x,f),y=Mathf.Lerp(a.y,b.y,f),z=Mathf.Lerp(a.z,b.z,f),slide=f<.5f?a.slide:b.slide,scooter=f<.5f?a.scooter:b.scooter};
    }
}

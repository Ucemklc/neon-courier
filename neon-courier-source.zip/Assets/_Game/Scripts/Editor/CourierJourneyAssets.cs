#if UNITY_EDITOR
using System.IO;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.SceneManagement;
using Object=UnityEngine.Object;

public static class CourierJourneyAssets
{
    private const string Folder="Assets/Resources/CourierJourney";
    private static Material navy,slate,cyan,orange,white,ghost,wet,reflection;
    [MenuItem("Neon Courier/Generate Journey Assets")]
    public static void Generate()
    {
        if(EditorApplication.isPlayingOrWillChangePlaymode)return;
        Directory.CreateDirectory(Folder);AssetDatabase.Refresh();
        navy=Load("MidnightShell");slate=Load("BlueSlate");cyan=Load("SignalCyan");orange=Load("SafetyTangerine");white=Load("Porcelain");
        ghost=Material("GhostGlass",new Color(.12f,.82f,1,.30f),true);wet=Material("WetAsphalt",new Color(.04f,.09f,.13f,.40f),true);wet.SetFloat("_Smoothness",.97f);wet.SetFloat("_Metallic",.65f);
        reflection=Material("NeonReflection",new Color(.1f,.68f,.8f,.27f),true);
        var scene=EditorSceneManager.NewPreviewScene();var build=new GameObject("Journey asset build");SceneManager.MoveGameObjectToScene(build,scene);
        try
        {
            Parcel(build.transform);Ghost(build.transform);Scooter(build.transform);ScooterRoad(build.transform);
            for(int i=0;i<3;i++)Street(build.transform,i);Weather(build.transform);
            AssetDatabase.SaveAssets();Directory.CreateDirectory("Logs");File.WriteAllText("Logs/CourierJourneyAssets.txt","PASS Parcel, animated ghost, rideable garage scooter, road section, three street events, rain and neon puddles generated.\n");
        }
        finally{EditorSceneManager.ClosePreviewScene(scene);}
    }
    private static Material Load(string name)=>AssetDatabase.LoadAssetAtPath<Material>("Assets/_Game/Art/CourierSet/Materials/"+name+".mat");
    private static Material Material(string name,Color color,bool transparent)
    {
        string path=Folder+"/"+name+".mat";var m=AssetDatabase.LoadAssetAtPath<Material>(path);
        if(!m){m=new Material(Shader.Find("Universal Render Pipeline/Lit"));AssetDatabase.CreateAsset(m,path);}
        m.SetColor("_BaseColor",color);m.SetFloat("_Smoothness",.5f);
        if(transparent){m.SetFloat("_Surface",1);m.SetFloat("_SrcBlend",(int)BlendMode.SrcAlpha);m.SetFloat("_DstBlend",(int)BlendMode.OneMinusSrcAlpha);m.SetFloat("_ZWrite",0);m.EnableKeyword("_SURFACE_TYPE_TRANSPARENT");m.renderQueue=3000;m.SetOverrideTag("RenderType","Transparent");m.SetShaderPassEnabled("ShadowCaster",false);}
        EditorUtility.SetDirty(m);return m;
    }
    private static GameObject Root(string name,Transform parent){var go=new GameObject(name);go.transform.SetParent(parent,false);return go;}
    private static GameObject Box(GameObject root,string name,Vector3 pos,Vector3 size,Material material,bool solid=false)
    {
        var go=GameObject.CreatePrimitive(PrimitiveType.Cube);go.name=name;go.transform.SetParent(root.transform,false);go.transform.localPosition=pos;go.transform.localScale=size;go.GetComponent<Renderer>().sharedMaterial=material;
        if(!solid)Object.DestroyImmediate(go.GetComponent<Collider>());else go.tag="Obstacle";return go;
    }
    private static void Save(GameObject go,string name){PrefabUtility.SaveAsPrefabAsset(go,Folder+"/"+name+".prefab");go.SetActive(false);}
    private static void Parcel(Transform parent)
    {
        var root=Root("ThrowParcel",parent);
        Box(root,"Orange parcel",Vector3.zero,new Vector3(.48f,.42f,.36f),orange);
        Box(root,"Parcel strap",new Vector3(0,0,-.19f),new Vector3(.09f,.44f,.035f),white);
        Box(root,"Top strap",new Vector3(0,.22f,0),new Vector3(.09f,.02f,.37f),white);
        Box(root,"Destination label",new Vector3(.14f,.06f,-.2f),new Vector3(.13f,.11f,.015f),cyan);Save(root,"ThrowParcel");
    }
    private static void Ghost(Transform parent)
    {
        var root=Root("RecordGhost",parent);
        var helmet=Object.Instantiate(Resources.Load<GameObject>("CourierPolish/Helmet0"),root.transform,false);helmet.transform.localPosition=new Vector3(0,1.83f,0);
        var jacket=Object.Instantiate(Resources.Load<GameObject>("CourierPolish/Jacket"),root.transform,false);jacket.transform.localPosition=new Vector3(0,1.3f,0);
        Box(root,"Hips",new Vector3(0,.95f,0),new Vector3(.47f,.24f,.32f),ghost);
        Box(root,"Backpack",new Vector3(0,1.25f,-.32f),new Vector3(.55f,.65f,.30f),ghost);
        foreach(int side in new[]{-1,1})
        {
            var leg=Root(side<0?"Left leg":"Right leg",root.transform);leg.transform.localPosition=new Vector3(side*.17f,.90f,0);
            Box(leg,"Shin",new Vector3(0,-.39f,0),new Vector3(.20f,.78f,.20f),ghost);Box(leg,"Boot",new Vector3(0,-.82f,.10f),new Vector3(.24f,.15f,.43f),ghost);
            Box(root,"Arm",new Vector3(side*.36f,1.21f,.08f),new Vector3(.17f,.59f,.18f),ghost).transform.localRotation=Quaternion.Euler(side*14,0,side*12);
        }
        foreach(var renderer in root.GetComponentsInChildren<Renderer>()){renderer.sharedMaterial=ghost;renderer.shadowCastingMode=ShadowCastingMode.Off;renderer.receiveShadows=false;}
        Save(root,"RecordGhost");
    }
    private static void Scooter(Transform parent)
    {
        var root=Root("RideScooter",parent);var garage=Resources.Load<GameObject>("CourierCareer/CourierGarage");
        var source=garage?garage.transform.Find("Courier hover bike"):null;
        if(!source)throw new System.InvalidOperationException("Garage bike asset is missing");
        var bike=Object.Instantiate(source.gameObject,root.transform,false);bike.name="Garage delivery scooter";bike.transform.localPosition=Vector3.zero;bike.transform.localRotation=Quaternion.Euler(0,180,0);
        var seat=bike.transform.Find("Seat");if(seat)Object.DestroyImmediate(seat.gameObject);
        var box=bike.transform.Find("Delivery case");if(box){box.localPosition=new Vector3(0,.25f,.83f);box.localScale=new Vector3(.6f,.45f,.5f);}
        var band=bike.transform.Find("Case band");if(band){band.localPosition=new Vector3(0,.25f,.57f);band.localScale=new Vector3(.14f,.46f,.04f);}
        foreach(var c in root.GetComponentsInChildren<Collider>())Object.DestroyImmediate(c);
        Save(root,"RideScooter");
    }
    private static void ScooterRoad(Transform parent)
    {
        var root=Root("ScooterRoad",parent);root.AddComponent<CourierScooterSegment>();
        foreach(float x in new[]{-3.85f,3.85f})Box(root,"Scooter route light",new Vector3(x,.035f,15),new Vector3(.10f,.035f,29),cyan);
        for(int lane=0;lane<3;lane++)
        {
            var crate=Root("Road crate "+lane,root.transform);crate.transform.localPosition=new Vector3((lane-1)*2.5f,.0f,14+lane*4);
            Box(crate,"Cargo obstruction",new Vector3(0,.50f,0),new Vector3(1.75f,1,.9f),navy,true);
            Box(crate,"Safety stripe",new Vector3(0,.80f,-.46f),new Vector3(1.7f,.16f,.035f),orange);
        }
        var start=Root("Scooter pickup",root.transform);start.transform.localPosition=new Vector3(0,0,1);
        Box(start,"Start line",new Vector3(0,.025f,0),new Vector3(7.5f,.035f,.28f),cyan);
        var parked=Object.Instantiate(AssetDatabase.LoadAssetAtPath<GameObject>(Folder+"/RideScooter.prefab"),start.transform,false);parked.SetActive(true);parked.transform.localPosition=new Vector3(4.6f,.4f,2);
        Sign(start,"SCOOTER",new Vector3(4.7f,2.7f,2),cyan);
        var end=Root("Finish lights",root.transform);Box(end,"Scooter exit line",new Vector3(0,.025f,28),new Vector3(7.5f,.035f,.28f),orange);
        Save(root,"ScooterRoad");
    }
    private static void Sign(GameObject root,string text,Vector3 pos,Material color)
    {
        Box(root,"Sign post",pos+Vector3.down*1.3f,new Vector3(.1f,2.6f,.1f),slate);
        Box(root,"Sign face",pos,new Vector3(2,.7f,.12f),navy);
        var go=Root(text,root.transform);go.transform.localPosition=pos+new Vector3(0,0,-.08f);
        var label=go.AddComponent<TMPro.TextMeshPro>();label.text=text;label.fontSize=4;label.fontSizeMax=4;label.fontSizeMin=2;label.enableAutoSizing=true;label.textWrappingMode=TMPro.TextWrappingModes.NoWrap;label.alignment=TMPro.TextAlignmentOptions.Center;label.rectTransform.sizeDelta=new Vector2(1.85f,.6f);label.color=color==cyan?new Color(.2f,.9f,1):new Color(1,.7f,.2f);label.font=TMPro.TMP_Settings.defaultFontAsset;
    }
    private static void Street(Transform parent,int kind)
    {
        var root=Root("StreetEvent"+kind,parent);var script=root.AddComponent<CourierStreetEvent>();script.SetKind((CourierStreetEvent.Kind)kind);
        var moving=Root("Moving hazard",root.transform);
        if(kind==0)
        {
            Box(root,"Delivery van",new Vector3(-4.7f,1.0f,17.9f),new Vector3(1.8f,2,4.2f),navy);
            Box(root,"Van cargo panel",new Vector3(-3.79f,1.1f,18.4f),new Vector3(.04f,1.3f,2.1f),orange);
            Box(root,"Van windshield",new Vector3(-4.7f,1.5f,15.77f),new Vector3(1.6f,.6f,.04f),cyan);
            Box(moving,"Opening door",new Vector3(0,0,-.72f),new Vector3(.16f,1.8f,1.45f),orange,true);
            Box(moving,"Door glass",new Vector3(.09f,.40f,-.72f),new Vector3(.04f,.5f,1.1f),cyan);
        }
        else if(kind==1)
        {
            Box(moving,"Rolling cart",Vector3.zero,new Vector3(1.6f,.22f,1.6f),slate,true);
            Box(moving,"Cart parcel",new Vector3(0,.50f,0),new Vector3(1.35f,.85f,1.35f),orange,true);
            Box(moving,"Cart parcel strap",new Vector3(0,.5f,-.7f),new Vector3(.18f,.9f,.04f),white);
            foreach(float x in new[]{-.58f,.58f})foreach(float z in new[]{-.57f,.57f})Box(moving,"Cart wheel",new Vector3(x,-.25f,z),new Vector3(.2f,.3f,.3f),navy);
        }
        else
        {
            Box(root,"Barrier motor",new Vector3(-4,.65f,17),new Vector3(.65f,1.3f,.7f),navy);
            Box(moving,"Lowering barrier",new Vector3(.65f,.85f,0),new Vector3(2.15f,.3f,.4f),orange,true);
            for(int k=0;k<4;k++)Box(moving,"Barrier stripe",new Vector3(-.1f+k*.45f,.85f,-.21f),new Vector3(.19f,.32f,.025f),white);
        }
        float lane=kind==1?2.5f:-2.5f;
        var warning=Root("Lane warning",root.transform);
        Box(warning,"Amber lane marker",new Vector3(lane,.025f,14),new Vector3(1.9f,.035f,7.5f),orange);
        for(int i=0;i<3;i++)Box(warning,"Warning chevron",new Vector3(lane,.05f,11+i*1.7f),new Vector3(1.6f,.02f,.15f),white);
        Sign(root,"!",new Vector3(kind==1?3.9f:-3.9f,2.6f,13),orange);
        script.ResetEvent();Save(root,"StreetEvent"+kind);
    }
    private static void Weather(Transform parent)
    {
        var root=Root("Rain",parent);var ps=root.AddComponent<ParticleSystem>();ps.Stop(true,ParticleSystemStopBehavior.StopEmittingAndClear);
        var main=ps.main;main.loop=true;main.playOnAwake=false;main.duration=4;main.startLifetime=.7f;main.startSpeed=0;main.startSize=.035f;main.startColor=new Color(.65f,.85f,1,.45f);main.maxParticles=500;main.simulationSpace=ParticleSystemSimulationSpace.World;
        var emission=ps.emission;emission.rateOverTime=420;var shape=ps.shape;shape.shapeType=ParticleSystemShapeType.Box;shape.scale=new Vector3(20,2,32);
        var velocity=ps.velocityOverLifetime;velocity.enabled=true;velocity.space=ParticleSystemSimulationSpace.World;velocity.y=-24;velocity.x=-2;velocity.z=-4;
        var renderer=root.GetComponent<ParticleSystemRenderer>();renderer.renderMode=ParticleSystemRenderMode.Stretch;renderer.lengthScale=7;renderer.velocityScale=0;renderer.sharedMaterial=ghost;renderer.shadowCastingMode=ShadowCastingMode.Off;Save(root,"Rain");
        root=Root("Puddles",parent);
        for(int i=0;i<24;i++)
        {
            float x=(i%2==0?-1:1)*(i%3==0?3.2f:1.15f),z=-30+i*6;
            var patch=Root("Wet road patch",root.transform);patch.transform.localPosition=new Vector3(x,.013f,z);patch.transform.localScale=new Vector3(.65f+i%3*.3f,1,2.1f+i%4*.45f);
            patch.AddComponent<MeshFilter>().sharedMesh=PuddleMesh(i%4);var mr=patch.AddComponent<MeshRenderer>();mr.sharedMaterial=wet;mr.shadowCastingMode=ShadowCastingMode.Off;mr.receiveShadows=false;
            for(int j=0;j<3;j++){var streak=Box(root,"Stretched neon reflection",new Vector3(x+(j-1)*.16f,.019f,z),new Vector3(.045f,.006f,1.1f+j*.5f),reflection);streak.GetComponent<Renderer>().shadowCastingMode=ShadowCastingMode.Off;}
        }
        Save(root,"Puddles");
    }
    private static Mesh PuddleMesh(int variant)
    {
        string path=Folder+"/PuddleShape"+variant+".asset";var mesh=AssetDatabase.LoadAssetAtPath<Mesh>(path);if(mesh)return mesh;
        var vertices=new Vector3[19];var triangles=new int[54];
        for(int i=0;i<18;i++){float a=i*Mathf.PI*2/18,r=.5f+.065f*Mathf.Sin(i*2.4f+variant);vertices[i+1]=new Vector3(Mathf.Cos(a)*r,0,Mathf.Sin(a)*r);triangles[i*3]=0;triangles[i*3+1]=(i+1)%18+1;triangles[i*3+2]=i+1;}
        mesh=new Mesh{name="Puddle shape "+variant,vertices=vertices,triangles=triangles};mesh.RecalculateNormals();mesh.RecalculateBounds();AssetDatabase.CreateAsset(mesh,path);return mesh;
    }
}
#endif

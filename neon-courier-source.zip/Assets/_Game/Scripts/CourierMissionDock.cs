using TMPro;
using UnityEngine;

/// <summary>Shares the cargo HUD's canvas, so screen scaling cannot make the two cards overlap.</summary>
public sealed class CourierMissionDock : MonoBehaviour
{
    private void OnEnable(){Dock();}
    private void LateUpdate(){Dock();}
    private void Dock()
    {
        var ui=FindAnyObjectByType<CourierRunPolishHUD>();if(!ui)return;
        transform.SetParent(ui.transform,false);
        CourierMenuLayout.Place((RectTransform)transform,new Vector2(.5f,0),new Vector2(0,140),new Vector2(940,82));
        var title=transform.Find("MissionTitle")?.GetComponent<TMP_Text>();
        var progress=transform.Find("MissionProgress")?.GetComponent<TMP_Text>();
        if(title){title.fontSize=27;title.rectTransform.sizeDelta=new Vector2(700,36);}
        if(progress){progress.fontSize=25;progress.rectTransform.sizeDelta=new Vector2(175,36);}
        enabled=false;
    }
}

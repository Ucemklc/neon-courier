using System;
using UnityEngine;

[DisallowMultipleComponent]
public sealed class ObstacleAppearanceRandomizer : MonoBehaviour
{
    [Serializable]
    private sealed class VisualVariant
    {
        [Tooltip("Bu engel türü için kullanılacak görünüm nesnesi.")]
        public GameObject visual;

        [Tooltip("Yüksek değer bu görünümün daha sık seçilmesini sağlar.")]
        [Min(0f)]
        public float weight = 1f;
    }

    [Header("Visual Variants")]
    [SerializeField]
    private VisualVariant[] visualVariants =
        Array.Empty<VisualVariant>();

    [Header("Selection")]
    [SerializeField]
    private bool avoidImmediateRepeat = true;

    [SerializeField]
    private bool randomizeEveryEnable = true;

    [Header("Debug")]
    [SerializeField]
    private bool debugLogs = false;

    public GameObject CurrentVisual { get; private set; }

    private int lastSelectedIndex = -1;

    private void Awake()
    {
        DisableAllVisuals();
    }

    private void OnEnable()
    {
        if (
            randomizeEveryEnable ||
            CurrentVisual == null
        )
        {
            SelectRandomVisual();
        }
        else
        {
            CurrentVisual.SetActive(true);
        }
    }

    private void OnDisable()
    {
        DisableAllVisuals();
    }

    [ContextMenu("Preview / Select Random Visual")]
    public void SelectRandomVisual()
    {
        int selectedIndex =
            SelectWeightedIndex();

        if (selectedIndex < 0)
        {
            CurrentVisual = null;

            if (debugLogs)
            {
                Debug.LogWarning(
                    "ObstacleAppearanceRandomizer: Geçerli görünüm bulunamadı.",
                    this
                );
            }

            return;
        }

        DisableAllVisuals();

        CurrentVisual =
            visualVariants[selectedIndex]
                .visual;

        CurrentVisual.SetActive(true);

        lastSelectedIndex =
            selectedIndex;

        if (debugLogs)
        {
            Debug.Log(
                $"Obstacle appearance selected: {CurrentVisual.name}",
                this
            );
        }
    }

    [ContextMenu("Preview / Disable All Visuals")]
    public void DisableAllVisuals()
    {
        if (visualVariants == null)
        {
            return;
        }

        foreach (
            VisualVariant variant
            in visualVariants
        )
        {
            if (
                variant == null ||
                variant.visual == null
            )
            {
                continue;
            }

            variant.visual.SetActive(false);
        }
    }

    private int SelectWeightedIndex()
    {
        int validCount =
            CountValidVariants();

        if (validCount == 0)
        {
            return -1;
        }

        if (validCount == 1)
        {
            return FindFirstValidIndex();
        }

        float totalWeight = 0f;

        for (
            int index = 0;
            index < visualVariants.Length;
            index++
        )
        {
            if (
                !IsVariantValid(index) ||
                ShouldExcludeLastIndex(
                    index,
                    validCount
                )
            )
            {
                continue;
            }

            totalWeight +=
                visualVariants[index]
                    .weight;
        }

        if (totalWeight <= 0f)
        {
            return FindFirstValidIndex();
        }

        float randomValue =
            UnityEngine.Random.Range(
                0f,
                totalWeight
            );

        float accumulatedWeight = 0f;

        for (
            int index = 0;
            index < visualVariants.Length;
            index++
        )
        {
            if (
                !IsVariantValid(index) ||
                ShouldExcludeLastIndex(
                    index,
                    validCount
                )
            )
            {
                continue;
            }

            accumulatedWeight +=
                visualVariants[index]
                    .weight;

            if (
                randomValue <=
                accumulatedWeight
            )
            {
                return index;
            }
        }

        return FindFirstValidIndex();
    }

    private int CountValidVariants()
    {
        if (visualVariants == null)
        {
            return 0;
        }

        int count = 0;

        for (
            int index = 0;
            index < visualVariants.Length;
            index++
        )
        {
            if (IsVariantValid(index))
            {
                count++;
            }
        }

        return count;
    }

    private int FindFirstValidIndex()
    {
        if (visualVariants == null)
        {
            return -1;
        }

        for (
            int index = 0;
            index < visualVariants.Length;
            index++
        )
        {
            if (
                IsVariantValid(index) &&
                !ShouldExcludeLastIndex(
                    index,
                    CountValidVariants()
                )
            )
            {
                return index;
            }
        }

        for (
            int index = 0;
            index < visualVariants.Length;
            index++
        )
        {
            if (IsVariantValid(index))
            {
                return index;
            }
        }

        return -1;
    }

    private bool IsVariantValid(
        int index
    )
    {
        if (
            visualVariants == null ||
            index < 0 ||
            index >= visualVariants.Length
        )
        {
            return false;
        }

        VisualVariant variant =
            visualVariants[index];

        return
            variant != null &&
            variant.visual != null &&
            variant.weight > 0f;
    }

    private bool ShouldExcludeLastIndex(
        int index,
        int validCount
    )
    {
        return
            avoidImmediateRepeat &&
            validCount > 1 &&
            index == lastSelectedIndex;
    }
}
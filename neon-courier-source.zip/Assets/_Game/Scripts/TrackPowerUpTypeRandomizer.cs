using UnityEngine;

[DefaultExecutionOrder(100)]
[DisallowMultipleComponent]
[RequireComponent(typeof(PowerUpPickup))]
public sealed class TrackPowerUpTypeRandomizer :
    MonoBehaviour
{
    [Header("Random Power-up Selection")]
    [Tooltip(
        "Nesne her aktif edildiğinde yeni bir power-up türü seçer."
    )]
    [SerializeField]
    private bool randomizeOnEnable = true;

    [Tooltip(
        "Üretilen power-up'ın Hoverboard olma ihtimali."
    )]
    [SerializeField, Range(0f, 1f)]
    private float hoverboardChance = 0.25f;

    [Header("Other Power-ups")]
    [SerializeField]
    private bool allowMagnet = true;

    [SerializeField]
    private bool allowShield = true;

    [SerializeField]
    private bool allowDoubleCoin = true;

    [SerializeField] private bool allowJumpShoes = true;

    private PowerUpPickup powerUpPickup;

    private void Awake()
    {
        ResolvePowerUpPickup();
    }

    private void OnEnable()
    {
        if (
            !Application.isPlaying ||
            !randomizeOnEnable
        )
        {
            return;
        }

        ResolvePowerUpPickup();

        if (powerUpPickup == null)
        {
            return;
        }

        PowerUpType selectedType =
            SelectRandomPowerUpType();

        powerUpPickup.Configure(
            selectedType
        );
    }

    private void ResolvePowerUpPickup()
    {
        if (powerUpPickup != null)
        {
            return;
        }

        powerUpPickup =
            GetComponent<PowerUpPickup>();

        if (powerUpPickup == null)
        {
            Debug.LogError(
                "TrackPowerUpTypeRandomizer: " +
                "PowerUpPickup bulunamadı.",
                this
            );
        }
    }

    private PowerUpType SelectRandomPowerUpType()
    {
        float clampedHoverboardChance =
            Mathf.Clamp01(
                hoverboardChance
            );

        if (
            Random.value <
            clampedHoverboardChance
        )
        {
            return PowerUpType.Hoverboard;
        }

        if (allowJumpShoes && Random.value < .25f) return PowerUpType.JumpShoes;

        int availableNormalTypeCount = 0;

        if (allowMagnet)
        {
            availableNormalTypeCount++;
        }

        if (allowShield)
        {
            availableNormalTypeCount++;
        }

        if (allowDoubleCoin)
        {
            availableNormalTypeCount++;
        }

        if (availableNormalTypeCount <= 0)
        {
            return PowerUpType.Hoverboard;
        }

        int selectedIndex =
            Random.Range(
                0,
                availableNormalTypeCount
            );

        if (allowMagnet)
        {
            if (selectedIndex == 0)
            {
                return PowerUpType.Magnet;
            }

            selectedIndex--;
        }

        if (allowShield)
        {
            if (selectedIndex == 0)
            {
                return PowerUpType.Shield;
            }

            selectedIndex--;
        }

        return PowerUpType.DoubleCoin;
    }

    private void OnValidate()
    {
        hoverboardChance =
            Mathf.Clamp01(
                hoverboardChance
            );
    }
}
using UnityEngine;

[DisallowMultipleComponent]
public sealed class NearMissManager : MonoBehaviour
{
    public static NearMissManager Instance { get; private set; }

    [Header("Reward")]
    [SerializeField, Min(1)]
    private int rewardEveryStreak = 3;

    [SerializeField, Min(0)]
    private int coinReward = 1;

    [SerializeField, Min(0.1f)]
    private float streakResetTime = 4f;

    [SerializeField, Min(0.05f)]
    private float registrationCooldown = 0.65f;

    public int CurrentStreak { get; private set; }

    public int HitVersion { get; private set; }

    private GameManager gameManager;

    private float lastNearMissTime = -100f;
    private float lastRegistrationTime = -100f;

    private void Awake()
    {
        if (
            Instance != null &&
            Instance != this
        )
        {
            Destroy(this);
            return;
        }

        Instance = this;

    }

    private void Start()
    {
        ResolveGameManager();
        SubscribeToEvents();
    }

    private void OnDestroy()
    {
        UnsubscribeFromEvents();

        if (Instance == this)
        {
            Instance = null;
        }
    }

    public bool RegisterNearMiss()
    {
        ResolveGameManager();

        if (
            gameManager == null ||
            !gameManager.IsRunActive ||
            gameManager.IsPaused ||
            gameManager.IsGameOver ||
            gameManager.IsMainMenuActive
        )
        {
            return false;
        }

        float currentTime = Time.unscaledTime;

        if (
            currentTime - lastRegistrationTime <
            registrationCooldown
        )
        {
            return false;
        }

        if (
            currentTime - lastNearMissTime >
            streakResetTime
        )
        {
            CurrentStreak = 0;
        }

        CurrentStreak++;
        lastNearMissTime = currentTime;
        lastRegistrationTime = currentTime;

        bool rewardEarned =
            rewardEveryStreak > 0 &&
            CurrentStreak % rewardEveryStreak == 0;

        if (
            rewardEarned &&
            coinReward > 0
        )
        {
            gameManager.AddCoins(coinReward);
        }


        return true;
    }

    private void ResolveGameManager()
    {
        if (gameManager != null)
        {
            return;
        }

        gameManager = GameManager.Instance;

        if (gameManager == null)
        {
            gameManager =
                FindAnyObjectByType<GameManager>();
        }
    }

    private void SubscribeToEvents()
    {
        if (gameManager == null)
        {
            return;
        }

        gameManager.PlayerHit +=
            HandlePlayerHit;

        gameManager.GameOverTriggered +=
            ResetSystem;

        gameManager.MainMenuChanged +=
            HandleMainMenuChanged;

        gameManager.RunStateChanged +=
            HandleRunStateChanged;
    }

    private void UnsubscribeFromEvents()
    {
        if (gameManager == null)
        {
            return;
        }

        gameManager.PlayerHit -=
            HandlePlayerHit;

        gameManager.GameOverTriggered -=
            ResetSystem;

        gameManager.MainMenuChanged -=
            HandleMainMenuChanged;

        gameManager.RunStateChanged -=
            HandleRunStateChanged;
    }

    private void HandlePlayerHit()
    {
        HitVersion++;
        CurrentStreak = 0;
        lastNearMissTime = -100f;

    }

    private void HandleMainMenuChanged(
        bool isMainMenuOpen
    )
    {
        if (isMainMenuOpen)
        {
            ResetSystem();
        }
    }

    private void HandleRunStateChanged(
        bool isRunActive
    )
    {
        if (!isRunActive)
        {
            return;
        }

        lastRegistrationTime = -100f;
    }

    private void ResetSystem()
    {
        CurrentStreak = 0;
        HitVersion = 0;

        lastNearMissTime = -100f;
        lastRegistrationTime = -100f;

    }

}

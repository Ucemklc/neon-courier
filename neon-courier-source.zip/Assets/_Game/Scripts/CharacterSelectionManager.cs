using System;
using UnityEngine;

[DefaultExecutionOrder(-50)]
public class CharacterSelectionManager :
    MonoBehaviour
{
    [Serializable]
    private class CharacterEntry
    {
        [Tooltip("Boşluk içermeyen benzersiz kimlik.")]
        public string characterId =
            "courier_01";

        public string displayName =
            "NEON RUNNER";

        [Min(0)]
        public int unlockPrice;

        public GameObject characterRoot;

        public Animator characterAnimator;
    }

    [Header("References")]
    [SerializeField]
    private RunnerController runnerController;

    [Header("Characters")]
    [SerializeField]
    private CharacterEntry[] characters;

    public event Action SelectionChanged;

    public int SelectedIndex
    {
        get;
        private set;
    }

    public int CharacterCount =>
        characters == null
            ? 0
            : characters.Length;

    private const string SelectedCharacterKey =
        "NeonCourier.SelectedCharacter";

    private const string UnlockPrefix =
        "NeonCourier.CharacterUnlocked.";

    private void Awake()
    {
        ResolveRunnerController();

        if (CharacterCount <= 0)
        {
            Debug.LogError(
                "CharacterSelectionManager: Karakter listesi boş.",
                this
            );

            enabled = false;
            return;
        }

        for (int i = 0; i < characters.Length; i++)
        {
            characters[i].displayName = CourierUniform.DisplayName(i);
            if (i == 0) characters[i].unlockPrice = 0;
            if (characters[i].characterRoot == null) continue;
            var uniform = characters[i].characterRoot.GetComponent<CourierUniform>();
            if (!uniform) uniform = characters[i].characterRoot.AddComponent<CourierUniform>();
            uniform.Configure(i);
        }

        UnlockFirstCharacter();

        SelectedIndex =
            PlayerPrefs.GetInt(
                SelectedCharacterKey,
                0
            );

        if (
            !IsValidIndex(SelectedIndex) ||
            !IsUnlocked(SelectedIndex)
        )
        {
            SelectedIndex = 0;
        }

        ApplySelectedCharacter();
    }

    private void Start()
    {
        ResolveRunnerController();
        ApplySelectedCharacter();

        SelectionChanged?.Invoke();
    }

    private void ResolveRunnerController()
    {
        if (runnerController == null)
        {
            runnerController =
                FindFirstObjectByType
                    <RunnerController>();
        }
    }

    private void UnlockFirstCharacter()
    {
        if (CharacterCount <= 0)
        {
            return;
        }

        PlayerPrefs.SetInt(
            GetUnlockKey(0),
            1
        );

        PlayerPrefs.Save();
    }

    public string GetDisplayName(
        int index
    )
    {
        if (!IsValidIndex(index))
        {
            return "KARAKTER";
        }

        return CourierUniform.DisplayName(index);
    }

    public int GetPrice(
        int index
    )
    {
        if (!IsValidIndex(index))
        {
            return 0;
        }

        return Mathf.Max(
            0,
            characters[index].unlockPrice
        );
    }

    public bool IsUnlocked(
        int index
    )
    {
        if (!IsValidIndex(index))
        {
            return false;
        }

        if (index == 0)
        {
            return true;
        }

        return PlayerPrefs.GetInt(
            GetUnlockKey(index),
            0
        ) == 1;
    }

    public bool IsSelected(
        int index
    )
    {
        return
            IsValidIndex(index) &&
            SelectedIndex == index;
    }

    public bool TryUnlockOrSelect(
        int index
    )
    {
        if (!IsValidIndex(index))
        {
            return false;
        }

        GameManager gameManager =
            GameManager.Instance;

        if (
            gameManager != null &&
            !gameManager.IsMainMenuActive
        )
        {
            return false;
        }

        if (!IsUnlocked(index))
        {
            int price =
                GetPrice(index);

            if (
                price > 0 &&
                (
                    gameManager == null ||
                    !gameManager.TrySpendCoins(
                        price
                    )
                )
            )
            {
                return false;
            }

            PlayerPrefs.SetInt(
                GetUnlockKey(index),
                1
            );

            PlayerPrefs.Save();
        }

        return SelectCharacter(index);
    }

    public bool SelectCharacter(
        int index
    )
    {
        if (
            !IsValidIndex(index) ||
            !IsUnlocked(index)
        )
        {
            return false;
        }

        SelectedIndex = index;

        PlayerPrefs.SetInt(
            SelectedCharacterKey,
            SelectedIndex
        );

        PlayerPrefs.Save();

        ApplySelectedCharacter();

        SelectionChanged?.Invoke();

        return true;
    }

    private void ApplySelectedCharacter()
    {
        if (
            !IsValidIndex(SelectedIndex)
        )
        {
            return;
        }

        Animator selectedAnimator = null;

        for (
            int index = 0;
            index < CharacterCount;
            index++
        )
        {
            CharacterEntry entry =
                characters[index];

            bool shouldBeActive =
                index == SelectedIndex;

            if (entry.characterRoot != null)
            {
                entry.characterRoot.SetActive(
                    shouldBeActive
                );
            }

            if (!shouldBeActive)
            {
                continue;
            }

            selectedAnimator =
                entry.characterAnimator;

            if (
                selectedAnimator == null &&
                entry.characterRoot != null
            )
            {
                selectedAnimator =
                    entry.characterRoot
                        .GetComponentInChildren
                            <Animator>(true);
            }
        }

        ResolveRunnerController();

        if (
            runnerController != null &&
            selectedAnimator != null
        )
        {
            runnerController.SetAnimator(
                selectedAnimator
            );
        }
        else
        {
            Debug.LogError(
                "CharacterSelectionManager: Seçilen karakterin Animator bağlantısı bulunamadı.",
                this
            );
        }
    }

    private bool IsValidIndex(
        int index
    )
    {
        return
            characters != null &&
            index >= 0 &&
            index < characters.Length;
    }

    private string GetUnlockKey(
        int index
    )
    {
        string characterId =
            characters[index].characterId;

        if (
            string.IsNullOrWhiteSpace(
                characterId
            )
        )
        {
            characterId =
                $"character_{index}";
        }

        return
            UnlockPrefix +
            characterId.Trim();
    }

    [ContextMenu("Reset Character Progress")]
    private void ResetCharacterProgress()
    {
        if (characters != null)
        {
            for (
                int index = 0;
                index < characters.Length;
                index++
            )
            {
                PlayerPrefs.DeleteKey(
                    GetUnlockKey(index)
                );
            }
        }

        PlayerPrefs.DeleteKey(
            SelectedCharacterKey
        );

        PlayerPrefs.Save();

        UnlockFirstCharacter();

        SelectedIndex = 0;

        ApplySelectedCharacter();

        SelectionChanged?.Invoke();

        Debug.Log(
            "Karakter açma ve seçim kayıtları sıfırlandı."
        );
    }
}
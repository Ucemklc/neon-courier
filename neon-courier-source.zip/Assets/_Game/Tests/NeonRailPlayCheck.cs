#if UNITY_EDITOR
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;

// Editor-only, opt-in validation harness; excluded from player builds.
public sealed class NeonRailPlayCheck : MonoBehaviour
{
    private static readonly List<string> Results = new List<string>();
    private static readonly BindingFlags Private = BindingFlags.NonPublic | BindingFlags.Instance;
    private int failures;
    private GameManager previousGameManager;
    private PowerUpController previousPowerUps;
    private float previousTimeScale;
    private float previousCaptureDeltaTime;
    private int previousTargetFrameRate;
    private UnityEngine.Random.State previousRandomState;
    private readonly Dictionary<FieldInfo, object> previousRouteState = new Dictionary<FieldInfo, object>();
    private bool globalsCaptured;

    [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
    private static void Boot()
    {
        if (!SessionState.GetBool("NeonRail.QA", false)) return;
        SessionState.SetBool("NeonRail.QA", false);
        Results.Clear();
        // Only in Play Mode: the user's scene and unsaved edit state are restored
        // by Unity when checks finish. Never save or replace the user's scene.
        for (int i = 0; i < SceneManager.sceneCount; i++)
        {
            Scene scene = SceneManager.GetSceneAt(i);
            if (scene.isLoaded)
                foreach (var root in scene.GetRootGameObjects()) root.SetActive(false);
        }
        new GameObject("Rail QA").AddComponent<NeonRailPlayCheck>();
    }

    private IEnumerator Start()
    {
        previousGameManager = GameManager.Instance;
        previousPowerUps = PowerUpController.Instance;
        previousTimeScale = Time.timeScale;
        previousCaptureDeltaTime = Time.captureDeltaTime;
        previousTargetFrameRate = Application.targetFrameRate;
        previousRandomState = UnityEngine.Random.state;
        foreach (FieldInfo field in typeof(TrackTileContent).GetFields(BindingFlags.NonPublic | BindingFlags.Static))
            if (!field.IsInitOnly && field.FieldType == typeof(int)) previousRouteState[field] = field.GetValue(null);
        globalsCaptured = true;
        SetSingleton(typeof(GameManager), null);
        SetSingleton(typeof(PowerUpController), null);
        Time.timeScale = 1f;
        Time.captureDeltaTime = 1f / 60f;
        Application.targetFrameRate = -1;
        UnityEngine.Random.InitState(20260925);

        // Drive nested enumerators here so any setup/reflection/physics failure is
        // reported and exits Play Mode instead of silently stopping a coroutine.
        var pending = new Stack<IEnumerator>();
        pending.Push(RunChecks());
        double deadline = EditorApplication.timeSinceStartup + 120d;
        try
        {
            while (pending.Count > 0)
            {
                if (EditorApplication.timeSinceStartup > deadline)
                {
                    Check(false, "QA exceeded the 120 second wall-clock limit");
                    break;
                }
                object next = null;
                bool advanced = false;
                bool faulted = false;
                try
                {
                    advanced = pending.Peek().MoveNext();
                    if (advanced) next = pending.Peek().Current;
                }
                catch (Exception exception)
                {
                    Exception cause = exception is TargetInvocationException && exception.InnerException != null
                        ? exception.InnerException : exception;
                    Check(false, "unexpected exception: " + cause);
                    faulted = true;
                }
                if (faulted) break;
                if (!advanced)
                {
                    (pending.Pop() as IDisposable)?.Dispose();
                    continue;
                }
                if (next is IEnumerator nested) pending.Push(nested);
                else yield return next;
            }
        }
        finally
        {
            while (pending.Count > 0) (pending.Pop() as IDisposable)?.Dispose();
            RestoreGlobals();
        }

        try
        {
            Directory.CreateDirectory("Logs");
            File.WriteAllLines(Path.GetFullPath("Logs/NeonRailValidation.txt"), Results);
        }
        catch (Exception exception) { Check(false, "Unable to write QA report: " + exception.Message); }
        Debug.Log("NEON_RAIL_QA_COMPLETE failures=" + failures);
        if (Application.isBatchMode) EditorApplication.Exit(failures == 0 ? 0 : 1);
        else EditorApplication.isPlaying = false;
    }

    private IEnumerator RunChecks()
    {
        foreach (float speed in new[] { 8f, 15.5f, 25f })
        {
            yield return Traverse(speed, false, false);
            yield return Traverse(speed, true, false);
        }
        // At 15.5 m/s a roof jump starting at z=10 overshoots the 19.5 m car.
        yield return Traverse(8f, true, true);
        yield return FrontCollision();
        yield return HoverboardLanding();
        ValidatePoolingAndQuotas();
    }

    private static void SetSingleton(Type type, object value)
    {
        MethodInfo setter = type.GetProperty("Instance", BindingFlags.Public | BindingFlags.Static)?.GetSetMethod(true);
        if (setter == null) throw new MissingMethodException(type.Name + ".Instance setter");
        setter.Invoke(null, new[] { value });
    }

    private void RestoreGlobals()
    {
        if (!globalsCaptured) return;
        globalsCaptured = false;
        SetSingleton(typeof(GameManager), previousGameManager);
        SetSingleton(typeof(PowerUpController), previousPowerUps);
        foreach (var entry in previousRouteState) entry.Key.SetValue(null, entry.Value);
        Time.timeScale = previousTimeScale;
        Time.captureDeltaTime = previousCaptureDeltaTime;
        Application.targetFrameRate = previousTargetFrameRate;
        UnityEngine.Random.state = previousRandomState;
    }

    private void OnDisable() { RestoreGlobals(); }

    private GameObject CaseRoot(string name)
    {
        var root = new GameObject(name);
        root.transform.SetParent(transform, false);
        return root;
    }

    private IEnumerator Traverse(float speed, bool jump, bool transfer)
    {
        var root = CaseRoot("Case");
        var ground = GameObject.CreatePrimitive(PrimitiveType.Cube);
        ground.transform.SetParent(root.transform);
        ground.transform.position = new Vector3(0f, -.25f, 15f);
        ground.transform.localScale = new Vector3(15f, .5f, 80f);
        var train = NeonRailFactory.CreateTrain(root.transform);
        train.transform.localPosition = new Vector3(0f, 0f, 7.5f);
        if (transfer)
        {
            var neighbour = NeonRailFactory.CreateTrain(root.transform, 2.5f, false);
            neighbour.transform.localPosition = new Vector3(2.5f, 0f, 7.5f);
        }
        var player = new GameObject("Runner");
        player.transform.SetParent(root.transform);
        player.transform.position = new Vector3(0f, 1.01f, 0f);
        var cc = player.AddComponent<CharacterController>();
        cc.height = 2f;
        cc.center = Vector3.zero;
        cc.radius = .5f;
        cc.skinWidth = .08f;
        cc.stepOffset = .3f;
        cc.slopeLimit = 45f;
        var runner = player.AddComponent<RunnerController>();
        player.AddComponent<PlayerCollisionHandler>();
        runner.SetForwardSpeed(speed);
        Physics.SyncTransforms();
        bool jumped = false;
        bool roofGrounded = false;
        bool landedOnNeighbour = false;
        float maxHeight = player.transform.position.y;
        int frames = 0;
        int frameLimit = Mathf.CeilToInt((40f / speed + 4f) * 60f);
        while (player.transform.position.z < 40f && frames++ < frameLimit)
        {
            if (player.transform.position.z > 7.7f && player.transform.position.z < 19.3f &&
                runner.IsGrounded && player.transform.position.y > 3.2f) roofGrounded = true;
            if (jump && !jumped && player.transform.position.z > (transfer ? 8.1f : 10f))
            {
                typeof(RunnerController).GetMethod("TryJump", Private).Invoke(runner, null);
                if (transfer) typeof(RunnerController).GetMethod("MoveRight", Private).Invoke(runner, null);
                jumped = true;
            }
            if (transfer && player.transform.position.x > 2.3f && runner.IsGrounded &&
                player.transform.position.y > 3.2f) landedOnNeighbour = true;
            maxHeight = Mathf.Max(maxHeight, player.transform.position.y);
            yield return null;
        }
        string label = "speed=" + speed + " jump=" + jump + " transfer=" + transfer;
        Check(frames < frameLimit, label + " completes before timeout");
        Check(train.activeSelf, label + " safe contacts preserve train");
        Check(roofGrounded, label + " grounded on roof");
        Check(player.transform.position.z >= 40f && Mathf.Abs(player.transform.position.y - 1f) < .15f,
            label + " returns to road (y=" + player.transform.position.y + ")");
        if (jump) Check(maxHeight > 5.2f, label + " jump starts from roof (maxY=" + maxHeight + ")");
        if (transfer) Check(landedOnNeighbour, label + " lands on adjacent roof");
        Destroy(root);
        yield return null;
    }

    private IEnumerator FrontCollision()
    {
        var root = CaseRoot("FrontCollision");
        var ground = GameObject.CreatePrimitive(PrimitiveType.Cube);
        ground.transform.SetParent(root.transform);
        ground.transform.localScale = new Vector3(10f, .5f, 50f);
        ground.transform.position = new Vector3(0f, -.25f, 10f);
        var train = NeonRailFactory.CreateTrain(root.transform, 2.5f, false);
        train.transform.position = new Vector3(0f, 0f, 7.5f);
        var player = new GameObject("Runner");
        player.transform.SetParent(root.transform);
        player.transform.position = new Vector3(0f, 1.01f, 0f);
        var cc = player.AddComponent<CharacterController>();
        cc.height = 2f; cc.radius = .5f; cc.center = Vector3.zero;
        var runner = player.AddComponent<RunnerController>();
        player.AddComponent<PlayerCollisionHandler>();
        runner.SetForwardSpeed(15.5f);
        Physics.SyncTransforms();
        for (int i = 0; i < 120 && player.transform.position.z < 12f; i++) yield return null;
        Check(!train.activeSelf && player.transform.position.z > 10f, "front hit clears train without trapping runner");
        Destroy(root);
        yield return null;
    }

    private IEnumerator HoverboardLanding()
    {
        var root = CaseRoot("Hoverboard landing");
        var ground = GameObject.CreatePrimitive(PrimitiveType.Cube);
        ground.transform.SetParent(root.transform);
        ground.transform.position = new Vector3(0f, -.25f, 20f);
        ground.transform.localScale = new Vector3(15f, .5f, 80f);
        var train = NeonRailFactory.CreateTrain(root.transform);
        train.transform.localPosition = new Vector3(0f, 0f, 7.5f);
        var player = new GameObject("Board runner");
        player.transform.SetParent(root.transform);
        player.transform.position = new Vector3(0f, 1.01f, 0f);
        var cc = player.AddComponent<CharacterController>();
        cc.height = 2f; cc.radius = .5f; cc.center = Vector3.zero;
        var power = player.AddComponent<PowerUpController>();
        var runner = player.AddComponent<RunnerController>();
        typeof(RunnerController).GetField("hoverboardHeight", Private).SetValue(runner, 6.8f);
        runner.SetForwardSpeed(8f);
        player.AddComponent<PlayerCollisionHandler>();
        Physics.SyncTransforms();
        power.ActivatePowerUp(PowerUpType.Hoverboard);
        bool expired = false, onRoof = false, sliding = false;
        float maxY = 0f;
        for (int i = 0; i < 400 && player.transform.position.z < 32f; i++)
        {
            maxY = Mathf.Max(maxY, player.transform.position.y);
            if (!expired && player.transform.position.z > 10f)
            {
                typeof(PowerUpController).GetField("hoverboardTimeRemaining", Private).SetValue(power, 0f);
                expired = true;
            }
            if (expired && runner.IsGrounded && player.transform.position.y > 3.2f &&
                player.transform.position.z < 19f)
            {
                onRoof = true;
                if (!sliding)
                {
                    typeof(RunnerController).GetMethod("TrySlide", Private).Invoke(runner, null);
                    sliding = runner.IsSliding;
                }
            }
            yield return null;
        }
        Check(maxY > 7.5f, "hoverboard keeps the scene's 6.8 m flight height");
        Check(onRoof, "expired hoverboard lands on the train roof");
        Check(sliding, "slide can start after landing on a roof");
        Check(train.activeSelf && Mathf.Abs(player.transform.position.y - 1f) < .15f,
            "hoverboard descent preserves train and returns to road");
        Destroy(root);
        yield return null;
    }

    private void ValidatePoolingAndQuotas()
    {
        MethodInfo reset = typeof(TrackTileContent).GetMethod("ResetStaticRouteState", BindingFlags.NonPublic | BindingFlags.Static);
        if (reset == null) throw new MissingMethodException("TrackTileContent.ResetStaticRouteState");
        reset.Invoke(null, null);
        var root = CaseRoot("PatternTest");
        root.SetActive(false);
        var content = root.AddComponent<TrackTileContent>();
        var templateRoot = CaseRoot("Templates");
        templateRoot.SetActive(false);
        var obstacle = new GameObject("ObstacleTemplate");
        obstacle.transform.SetParent(templateRoot.transform);
        obstacle.AddComponent<ObstacleVisualController>();
        var package = new GameObject("PackageTemplate");
        package.transform.SetParent(templateRoot.transform);
        var delivery = new GameObject("DeliveryTemplate");
        delivery.transform.SetParent(templateRoot.transform);
        delivery.AddComponent<BoxCollider>();
        delivery.AddComponent<Rigidbody>();
        delivery.AddComponent<DeliveryZone>();
        typeof(TrackTileContent).GetField("obstaclePrefab", Private).SetValue(content, obstacle);
        typeof(TrackTileContent).GetField("packagePrefab", Private).SetValue(content, package);
        typeof(TrackTileContent).GetField("deliveryZonePrefab", Private).SetValue(content, delivery);
        typeof(TrackTileContent).GetField("overrideDifficultyForTesting", Private).SetValue(content, true);
        root.SetActive(true);
        int totalPackages = 0, deliveries = 0, rails = 0;
        bool safe = true;
        HashSet<int> warmedPool = null;
        bool poolReused = true;
        bool freeLane = true;
        for (int i = 0; i < 120; i++)
        {
            typeof(TrackTileContent).GetField("testDifficultyLevel", Private).SetValue(content, (i / 30) % 4);
            content.RefreshPattern();
            var packages = (GameObject[])typeof(TrackTileContent).GetField("packageSlots", Private).GetValue(content);
            foreach (var item in packages) if (item.activeSelf) totalPackages++;
            var zone = (DeliveryZone)typeof(TrackTileContent).GetField("deliveryZone", Private).GetValue(content);
            if (zone.gameObject.activeSelf) deliveries++;
            var surfaces = root.GetComponentsInChildren<RailRideSurface>();
            var alternate = root.GetComponent<CourierAlternateRoute>();
            if (surfaces.Length > 0 && !(alternate != null && alternate.Active))
            {
                rails++;
                freeLane &= surfaces.Length <= 2;
                foreach (var item in packages)
                    if (item.activeSelf && item.transform.localPosition.z >= 13f && (i / 30) % 4 >= 2) safe = false;
            }
            var pool = new HashSet<int>();
            // Existing street obstacles lazily create visuals at higher difficulty;
            // Warm through difficulty 1 so the moving-wagon beacon is present.
            // Shortcuts are checked separately by CityExpansionPlayCheck.
            foreach (RailRideSurface surface in root.GetComponentsInChildren<RailRideSurface>(true))
                if (surface.GetComponentInChildren<CourierRouteGate>(true) == null)
                foreach (Transform item in surface.GetComponentsInChildren<Transform>(true))
                    pool.Add(item.GetInstanceID());
            if (i == 59) warmedPool = pool;
            else if (i > 59) poolReused &= warmedPool.SetEquals(pool);
        }
        Check(totalPackages == 300 && deliveries == 30, "120 recycled tiles retain 10 packages / 4 tiles: packages=" + totalPackages + ", deliveries=" + deliveries);
        Check(rails == 37, "mixed course schedule creates 37 rail routes / 120 tiles (actual=" + rails + ")");
        Check(freeLane, "every rail pattern leaves at least one ground lane free");
        Check(safe, "roof packages remain before roof obstacle");
        Check(poolReused, "pool reuses the same transform instances after warmup");
        content.ClearPattern();
        Check(root.GetComponentsInChildren<RailRideSurface>().Length == 0, "ClearPattern disables all trains");
        Destroy(root); Destroy(templateRoot);
    }

    private void Check(bool success, string message)
    {
        if (!success) failures++;
        string result = (success ? "PASS " : "FAIL ") + message;
        Results.Add(result);
        Debug.Log(result);
    }
}
#endif


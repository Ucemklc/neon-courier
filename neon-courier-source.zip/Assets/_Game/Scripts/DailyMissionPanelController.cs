using System;
using System.Collections;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class DailyMissionPanelController : MonoBehaviour
{
    [Serializable]
    private class MissionRowUI
    {
        public TMP_Text titleText;
        public TMP_Text progressText;
        public TMP_Text rewardText;
        public Slider progressSlider;
        public Button claimButton;
        public TMP_Text claimButtonText;
    }

    [Header("References")]
    [SerializeField]
    private DailyMissionManager missionManager;

    [SerializeField]
    private GameObject missionPanel;
    public bool IsOpen => missionPanel && missionPanel.activeInHierarchy;

    [SerializeField]
    private Button openMissionButton;

    [SerializeField]
    private Button closeMissionButton;

    [Header("Mission Rows")]
    [SerializeField]
    private MissionRowUI distanceMission;

    [SerializeField]
    private MissionRowUI collectMission;

    [SerializeField]
    private MissionRowUI deliverMission;

    [SerializeField]
    private MissionRowUI comboMission;

    private GameManager gameManager;
    private CourierMissionMenu menu;
    private bool English => PlayerPrefs.GetInt("NeonCourier.Language",0)==1;

    private RectTransform runMissionHudRoot;
    private TMP_Text runMissionTitleText;
    private TMP_Text runMissionProgressText;
    private Image runMissionProgressFill;

    private static readonly DailyMissionType[]
        RunMissionPriority =
        {
            DailyMissionType.RunDistance,
            DailyMissionType.CollectPackages,
            DailyMissionType.DeliverPackages,
            DailyMissionType.ReachCombo
        };

    private IEnumerator Start()
    {
        yield return null;

        if (missionManager == null)
        {
            missionManager =
                DailyMissionManager.Instance;
        }

        gameManager =
            GameManager.Instance;

        if (
            missionManager == null ||
            gameManager == null
        )
        {
            Debug.LogError(
                "DailyMissionPanelController: Gerekli yöneticiler bulunamadı.",
                this
            );

            enabled = false;
            yield break;
        }

        CreateRunMissionHUD();
        BuildMenu();

        if (missionPanel != null)
        {
            missionPanel.SetActive(false);
        }

        AddButtonListeners();

        missionManager.MissionsChanged +=
            RefreshAllMissions;

        gameManager.MainMenuChanged +=
            HandleMainMenuChanged;

        RefreshAllMissions();
    }

    private void OnDestroy()
    {
        RemoveButtonListeners();

        if (missionManager != null)
        {
            missionManager.MissionsChanged -=
                RefreshAllMissions;
        }

        if (gameManager != null)
        {
            gameManager.MainMenuChanged -=
                HandleMainMenuChanged;
        }
    }

    private void BuildMenu()
    {
        if(!missionPanel)return;
        menu=missionPanel.GetComponent<CourierMissionMenu>();if(menu)return;
        menu=missionPanel.AddComponent<CourierMissionMenu>();menu.Build(closeMissionButton);
        var rows=new[]{distanceMission,collectMission,deliverMission,comboMission};
        for(int i=0;i<rows.Length;i++){var row=rows[i];menu.Row(i,row.titleText,row.progressText,row.rewardText,row.progressSlider,row.claimButton,row.claimButtonText);}
    }

    private void Update()
    {
        if (runMissionHudRoot == null || gameManager == null)
        {
            return;
        }

        bool shouldShow =
            gameManager.IsRunActive &&
            !gameManager.IsMainMenuActive &&
            !gameManager.IsGameOver;

        if (runMissionHudRoot.gameObject.activeSelf != shouldShow)
        {
            runMissionHudRoot.gameObject.SetActive(shouldShow);
        }
    }

    private void AddButtonListeners()
    {
        if (openMissionButton != null)
        {
            openMissionButton.onClick
                .AddListener(OpenMissionPanel);
        }

        if (closeMissionButton != null)
        {
            closeMissionButton.onClick
                .AddListener(CloseMissionPanel);
        }

        if (distanceMission.claimButton != null)
        {
            distanceMission.claimButton.onClick
                .AddListener(
                    ClaimDistanceMission
                );
        }

        if (collectMission.claimButton != null)
        {
            collectMission.claimButton.onClick
                .AddListener(
                    ClaimCollectMission
                );
        }

        if (deliverMission.claimButton != null)
        {
            deliverMission.claimButton.onClick
                .AddListener(
                    ClaimDeliverMission
                );
        }

        if (comboMission.claimButton != null)
        {
            comboMission.claimButton.onClick
                .AddListener(
                    ClaimComboMission
                );
        }
    }

    private void RemoveButtonListeners()
    {
        if (openMissionButton != null)
        {
            openMissionButton.onClick
                .RemoveListener(
                    OpenMissionPanel
                );
        }

        if (closeMissionButton != null)
        {
            closeMissionButton.onClick
                .RemoveListener(
                    CloseMissionPanel
                );
        }

        if (distanceMission.claimButton != null)
        {
            distanceMission.claimButton.onClick
                .RemoveListener(
                    ClaimDistanceMission
                );
        }

        if (collectMission.claimButton != null)
        {
            collectMission.claimButton.onClick
                .RemoveListener(
                    ClaimCollectMission
                );
        }

        if (deliverMission.claimButton != null)
        {
            deliverMission.claimButton.onClick
                .RemoveListener(
                    ClaimDeliverMission
                );
        }

        if (comboMission.claimButton != null)
        {
            comboMission.claimButton.onClick
                .RemoveListener(
                    ClaimComboMission
                );
        }
    }

    public void OpenMissionPanel()
    {
        if (
            missionPanel == null ||
            gameManager == null ||
            !gameManager.IsMainMenuActive
        )
        {
            return;
        }

        RefreshAllMissions();

        missionPanel.SetActive(true);
        missionPanel.transform.SetAsLastSibling();
    }

    public void CloseMissionPanel()
    {
        if (missionPanel != null)
        {
            missionPanel.SetActive(false);
        }
    }

    public void ClaimDistanceMission()
    {
        ClaimMission(
            DailyMissionType.RunDistance
        );
    }

    public void ClaimCollectMission()
    {
        ClaimMission(
            DailyMissionType.CollectPackages
        );
    }

    public void ClaimDeliverMission()
    {
        ClaimMission(
            DailyMissionType.DeliverPackages
        );
    }

    public void ClaimComboMission()
    {
        ClaimMission(
            DailyMissionType.ReachCombo
        );
    }

    private void ClaimMission(
        DailyMissionType missionType
    )
    {
        if (missionManager == null)
        {
            return;
        }

        missionManager.ClaimMission(
            missionType
        );

        RefreshAllMissions();
    }

    private void HandleMainMenuChanged(
        bool isMainMenuOpen
    )
    {
        if (!isMainMenuOpen)
        {
            CloseMissionPanel();
        }
    }

    private void RefreshAllMissions()
    {
        if (missionManager == null)
        {
            return;
        }

        RefreshMissionRow(
            DailyMissionType.RunDistance,
            distanceMission
        );

        RefreshMissionRow(
            DailyMissionType.CollectPackages,
            collectMission
        );

        RefreshMissionRow(
            DailyMissionType.DeliverPackages,
            deliverMission
        );

        RefreshMissionRow(
            DailyMissionType.ReachCombo,
            comboMission
        );

        RefreshRunMissionHUD();
        if(menu)menu.Refresh(missionManager,English);
    }

    private void CreateRunMissionHUD()
    {
        Canvas canvas = GetComponentInParent<Canvas>();

        if (canvas == null)
        {
            canvas = FindAnyObjectByType<Canvas>();
        }

        Transform parent = canvas != null
            ? canvas.transform
            : transform;

        GameObject cardObject = new GameObject(
            "InRunMissionHUD",
            typeof(RectTransform),
            typeof(CanvasRenderer),
            typeof(Image)
        );

        cardObject.transform.SetParent(parent, false);

        runMissionHudRoot = cardObject.GetComponent<RectTransform>();
        runMissionHudRoot.anchorMin = Vector2.zero;
        runMissionHudRoot.anchorMax = Vector2.zero;
        runMissionHudRoot.pivot = Vector2.zero;
        runMissionHudRoot.anchoredPosition = new Vector2(24f, 220f);
        runMissionHudRoot.sizeDelta = new Vector2(360f, 82f);

        Image cardImage = cardObject.GetComponent<Image>();
        cardImage.color = new Color(0.025f, 0.07f, 0.12f, 0.82f);
        cardImage.raycastTarget = false;

        TMP_FontAsset font = distanceMission.titleText != null
            ? distanceMission.titleText.font
            : TMP_Settings.defaultFontAsset;

        runMissionTitleText = CreateMissionHudText(
            "MissionTitle",
            runMissionHudRoot,
            font,
            17f,
            new Vector2(14f, -10f),
            new Vector2(240f, 28f),
            TextAlignmentOptions.Left
        );

        runMissionProgressText = CreateMissionHudText(
            "MissionProgress",
            runMissionHudRoot,
            font,
            15f,
            new Vector2(-14f, -10f),
            new Vector2(92f, 28f),
            TextAlignmentOptions.Right
        );

        RectTransform progressTextRect =
            runMissionProgressText.rectTransform;

        progressTextRect.anchorMin = new Vector2(1f, 1f);
        progressTextRect.anchorMax = new Vector2(1f, 1f);
        progressTextRect.pivot = new Vector2(1f, 1f);

        GameObject trackObject = new GameObject(
            "MissionProgressTrack",
            typeof(RectTransform),
            typeof(CanvasRenderer),
            typeof(Image)
        );

        trackObject.transform.SetParent(runMissionHudRoot, false);

        RectTransform trackRect = trackObject.GetComponent<RectTransform>();
        trackRect.anchorMin = new Vector2(0f, 0f);
        trackRect.anchorMax = new Vector2(1f, 0f);
        trackRect.pivot = new Vector2(0.5f, 0f);
        trackRect.anchoredPosition = new Vector2(0f, 14f);
        trackRect.sizeDelta = new Vector2(-28f, 10f);

        Image trackImage = trackObject.GetComponent<Image>();
        trackImage.color = new Color(0.02f, 0.11f, 0.16f, 1f);
        trackImage.raycastTarget = false;

        GameObject fillObject = new GameObject(
            "MissionProgressFill",
            typeof(RectTransform),
            typeof(CanvasRenderer),
            typeof(Image)
        );

        fillObject.transform.SetParent(trackObject.transform, false);

        RectTransform fillRect = fillObject.GetComponent<RectTransform>();
        fillRect.anchorMin = Vector2.zero;
        fillRect.anchorMax = Vector2.one;
        fillRect.offsetMin = Vector2.zero;
        fillRect.offsetMax = Vector2.zero;

        runMissionProgressFill = fillObject.GetComponent<Image>();
        runMissionProgressFill.type = Image.Type.Filled;
        runMissionProgressFill.fillMethod = Image.FillMethod.Horizontal;
        runMissionProgressFill.fillOrigin = (int)Image.OriginHorizontal.Left;
        runMissionProgressFill.color = new Color(0.15f, 0.9f, 0.95f, 1f);
        runMissionProgressFill.raycastTarget = false;

        cardObject.transform.SetAsFirstSibling();
        cardObject.AddComponent<CourierMissionDock>();
        cardObject.SetActive(false);
    }

    private TMP_Text CreateMissionHudText(
        string objectName,
        Transform parent,
        TMP_FontAsset font,
        float fontSize,
        Vector2 anchoredPosition,
        Vector2 size,
        TextAlignmentOptions alignment
    )
    {
        GameObject textObject = new GameObject(
            objectName,
            typeof(RectTransform),
            typeof(CanvasRenderer),
            typeof(TextMeshProUGUI)
        );

        textObject.transform.SetParent(parent, false);

        RectTransform textRect = textObject.GetComponent<RectTransform>();
        textRect.anchorMin = new Vector2(0f, 1f);
        textRect.anchorMax = new Vector2(0f, 1f);
        textRect.pivot = new Vector2(0f, 1f);
        textRect.anchoredPosition = anchoredPosition;
        textRect.sizeDelta = size;

        TMP_Text text = textObject.GetComponent<TextMeshProUGUI>();
        text.font = font;
        text.fontSize = fontSize;
        text.color = Color.white;
        text.alignment = alignment;
        text.textWrappingMode = TextWrappingModes.NoWrap;
        text.overflowMode = TextOverflowModes.Ellipsis;
        text.raycastTarget = false;

        return text;
    }

    private void RefreshRunMissionHUD()
    {
        if (
            missionManager == null ||
            runMissionTitleText == null ||
            runMissionProgressText == null
        )
        {
            return;
        }

        DailyMissionType? currentMission = null;
        float highestProgress = -1f;

        for (int i = 0; i < RunMissionPriority.Length; i++)
        {
            DailyMissionType missionType = RunMissionPriority[i];

            if (missionManager.IsCompleted(missionType))
            {
                continue;
            }

            float normalizedProgress =
                missionManager.GetNormalizedProgress(missionType);

            if (normalizedProgress > highestProgress)
            {
                currentMission = missionType;
                highestProgress = normalizedProgress;
            }
        }

        if (!currentMission.HasValue)
        {
            runMissionTitleText.text = "GÜNLÜK GÖREVLER TAMAMLANDI";
            runMissionProgressText.text = "TAMAM";

            if (runMissionProgressFill != null)
            {
                runMissionProgressFill.fillAmount = 1f;
                runMissionProgressFill.color = new Color(0.35f, 0.95f, 0.5f, 1f);
            }

            return;
        }

        DailyMissionType activeMission = currentMission.Value;
        int progress = missionManager.GetProgress(activeMission);
        int target = Mathf.Max(1, missionManager.GetTarget(activeMission));

        runMissionTitleText.text =
            missionManager.GetTitle(activeMission);

        runMissionProgressText.text =
            $"{progress:N0}/{target:N0}";

        if (runMissionProgressFill != null)
        {
            runMissionProgressFill.fillAmount =
                missionManager.GetNormalizedProgress(activeMission);

            runMissionProgressFill.color =
                new Color(0.15f, 0.9f, 0.95f, 1f);
        }
    }

    private void RefreshMissionRow(
        DailyMissionType missionType,
        MissionRowUI row
    )
    {
        int progress =
            missionManager.GetProgress(
                missionType
            );

        int target =
            missionManager.GetTarget(
                missionType
            );

        int reward =
            missionManager.GetReward(
                missionType
            );

        bool completed =
            missionManager.IsCompleted(
                missionType
            );

        bool claimed =
            missionManager.IsClaimed(
                missionType
            );

        if (row.titleText != null)
        {
            row.titleText.text =
                English ? EnglishTitle(missionType,target) : missionManager.GetTitle(missionType);
        }

        if (row.progressText != null)
        {
            row.progressText.text =
                $"{progress:N0} / {target:N0}";
        }

        if (row.rewardText != null)
        {
            row.rewardText.text =
                $"+{reward:N0} COIN";
        }

        if (row.progressSlider != null)
        {
            row.progressSlider.minValue = 0f;
            row.progressSlider.maxValue = target;
            row.progressSlider.value = progress;
            row.progressSlider.interactable =
                false;
        }

        if (row.claimButton != null)
        {
            row.claimButton.interactable =
                completed && !claimed;
        }

        if (row.claimButtonText != null)
        {
            if (claimed)
            {
                row.claimButtonText.text =
                    English ? "CLAIMED" : "ALINDI";
            }
            else if (completed)
            {
                row.claimButtonText.text =
                    English ? "CLAIM REWARD" : "ÖDÜLÜ AL";
            }
            else
            {
                row.claimButtonText.text =
                    English ? "IN PROGRESS" : "SÜRÜYOR";
            }
        }
    }
    private static string EnglishTitle(DailyMissionType type,int target)
    {
        switch(type){case DailyMissionType.RunDistance:return "RUN "+target+" METERS";case DailyMissionType.CollectPackages:return "COLLECT "+target+" PARCELS";case DailyMissionType.DeliverPackages:return "DELIVER "+target+" PARCELS";default:return "REACH COMBO x"+target;}
    }
}

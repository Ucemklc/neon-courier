using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering;

[DisallowMultipleComponent]
public sealed class AirTrafficDecorator : MonoBehaviour
{
    [Serializable]
    private sealed class AirVehicleEntry
    {
        public GameObject prefab;

        [Min(0.1f)]
        public float scaleMultiplier = 1f;

        public float yawCorrection = 0f;

        public float extraHeight = 0f;
    }

    private const string GeneratedRootName =
        "__GeneratedAirTraffic";

    [Header("Vehicle Prefabs")]
    [SerializeField]
    private List<AirVehicleEntry> vehiclePrefabs =
        new List<AirVehicleEntry>();

    [Header("Track Tile Range")]
    [SerializeField]
    private float tileStartZ = 0f;

    [SerializeField, Min(1f)]
    private float tileLength = 30f;

    [SerializeField, Min(0f)]
    private float startMargin = 4f;

    [SerializeField, Min(0f)]
    private float endMargin = 4f;

    [Header("Spawn Density")]
    [SerializeField, Range(0f, 1f)]
    private float spawnChancePerTile = 0.65f;

    [SerializeField, Min(0)]
    private int minimumVehiclesPerTile = 0;

    [SerializeField, Min(0)]
    private int maximumVehiclesPerTile = 1;

    [SerializeField, Min(0.1f)]
    private float minimumSpacingAlongZ = 10f;

    [Header("Placement")]
    [SerializeField, Range(0f, 1f)]
    private float sideSpawnChance = 0.75f;

    [SerializeField]
    private Vector2 flightHeightRange =
        new Vector2(7f, 11f);

    [SerializeField]
    private Vector2 sideXRange =
        new Vector2(8.5f, 12f);

    [SerializeField]
    private Vector2 roadXRange =
        new Vector2(-2f, 2f);

    [SerializeField]
    private Vector2 scaleRange =
        new Vector2(1f, 1.2f);

    [Header("Rotation")]
    [SerializeField]
    private float baseRotationY = 180f;

    [SerializeField]
    private float randomYawVariation = 10f;

    [Header("Rendering")]
    [SerializeField]
    private bool castShadows = false;

    [SerializeField]
    private bool receiveShadows = false;

    [SerializeField]
    private bool disableVehicleColliders = true;

    [Header("Motion")]
    [SerializeField]
    private bool addFloatingMotion = true;

    [Header("Generation")]
    [SerializeField]
    private bool generateOnAwake = true;

    [SerializeField]
    private bool regenerateWhenRefreshed = false;

    [SerializeField]
    private bool randomizeEveryGeneration = true;

    [SerializeField]
    private int fixedSeed = 2026;

    private Transform generatedRoot;

    private void Awake()
    {
        if (generateOnAwake)
        {
            GenerateAirTraffic();
        }
    }

    public void RefreshLayout()
    {
        RefreshDecoration();
    }

    public void RefreshDecoration()
    {
        if (
            regenerateWhenRefreshed ||
            !HasGeneratedVehicles()
        )
        {
            GenerateAirTraffic();
        }
    }

    public void RegenerateDecoration()
    {
        GenerateAirTraffic();
    }

    [ContextMenu("Preview / Generate Air Traffic")]
    public void GenerateAirTraffic()
    {
        List<AirVehicleEntry> validEntries =
            GetValidEntries();

        if (validEntries.Count == 0)
        {
            Debug.LogWarning(
                "AirTrafficDecorator: Geçerli hava aracı prefabı bulunamadı.",
                this
            );

            ClearAirTraffic();
            return;
        }

        ClearAirTraffic();
        CreateGeneratedRoot();

        UnityEngine.Random.State previousState =
            UnityEngine.Random.state;

        UnityEngine.Random.InitState(
            CalculateSeed()
        );

        int vehicleCount =
            GetVehicleCountToSpawn();

        List<float> usedZPositions =
            new List<float>();

        int attempts = 0;
        int maximumAttempts =
            Mathf.Max(
                vehicleCount * 8,
                8
            );

        for (
            int i = 0;
            i < vehicleCount &&
            attempts < maximumAttempts;
            attempts++
        )
        {
            AirVehicleEntry entry =
                validEntries[
                    UnityEngine.Random.Range(
                        0,
                        validEntries.Count
                    )
                ];

            float candidateZ =
                UnityEngine.Random.Range(
                    tileStartZ + startMargin,
                    tileStartZ + tileLength - endMargin
                );

            if (
                !IsFarEnoughFromOthers(
                    candidateZ,
                    usedZPositions
                )
            )
            {
                continue;
            }

            bool spawnAtSide =
                UnityEngine.Random.value <=
                sideSpawnChance;

            float xPosition;

            if (spawnAtSide)
            {
                bool spawnLeft =
                    UnityEngine.Random.value < 0.5f;

                float distanceFromCenter =
                    UnityEngine.Random.Range(
                        sideXRange.x,
                        sideXRange.y
                    );

                xPosition =
                    spawnLeft
                        ? -distanceFromCenter
                        : distanceFromCenter;
            }
            else
            {
                xPosition =
                    UnityEngine.Random.Range(
                        roadXRange.x,
                        roadXRange.y
                    );
            }

            float yPosition =
                UnityEngine.Random.Range(
                    flightHeightRange.x,
                    flightHeightRange.y
                ) +
                entry.extraHeight;

            float finalScale =
                UnityEngine.Random.Range(
                    scaleRange.x,
                    scaleRange.y
                ) *
                Mathf.Max(
                    0.1f,
                    entry.scaleMultiplier
                );

            float finalYaw =
                baseRotationY +
                entry.yawCorrection +
                UnityEngine.Random.Range(
                    -randomYawVariation,
                    randomYawVariation
                );

            GameObject vehicle =
                Instantiate(
                    entry.prefab,
                    generatedRoot,
                    false
                );

            vehicle.name =
                $"AirVehicle_{i}_{entry.prefab.name}";

            vehicle.transform.localPosition =
                new Vector3(
                    xPosition,
                    yPosition,
                    candidateZ
                );

            vehicle.transform.localRotation =
                Quaternion.Euler(
                    0f,
                    finalYaw,
                    0f
                );

            vehicle.transform.localScale =
                Vector3.one * finalScale;

            ApplyComponentSettings(
                vehicle
            );

            if (addFloatingMotion)
            {
                EnsureFloatingMotion(
                    vehicle
                );
            }

            usedZPositions.Add(
                candidateZ
            );

            i++;
        }

        UnityEngine.Random.state =
            previousState;
    }

    [ContextMenu("Preview / Clear Air Traffic")]
    public void ClearAirTraffic()
    {
        Transform existingRoot =
            FindGeneratedRoot();

        if (existingRoot == null)
        {
            generatedRoot = null;
            return;
        }

        existingRoot.gameObject.SetActive(
            false
        );

        if (Application.isPlaying)
        {
            Destroy(
                existingRoot.gameObject
            );
        }
        else
        {
            DestroyImmediate(
                existingRoot.gameObject
            );
        }

        generatedRoot = null;
    }

    private int GetVehicleCountToSpawn()
    {
        if (
            maximumVehiclesPerTile <= 0 ||
            UnityEngine.Random.value >
            spawnChancePerTile
        )
        {
            return 0;
        }

        int minCount =
            Mathf.Clamp(
                minimumVehiclesPerTile,
                0,
                maximumVehiclesPerTile
            );

        int maxCount =
            Mathf.Max(
                minCount,
                maximumVehiclesPerTile
            );

        if (minCount == 0)
        {
            minCount = 1;
        }

        return UnityEngine.Random.Range(
            minCount,
            maxCount + 1
        );
    }

    private bool IsFarEnoughFromOthers(
        float candidateZ,
        List<float> usedZPositions
    )
    {
        foreach (float usedZ in usedZPositions)
        {
            if (
                Mathf.Abs(candidateZ - usedZ) <
                minimumSpacingAlongZ
            )
            {
                return false;
            }
        }

        return true;
    }

    private void ApplyComponentSettings(
        GameObject vehicle
    )
    {
        Renderer[] renderers =
            vehicle.GetComponentsInChildren
                <Renderer>(true);

        foreach (Renderer targetRenderer in renderers)
        {
            if (targetRenderer == null)
            {
                continue;
            }

            targetRenderer.shadowCastingMode =
                castShadows
                    ? ShadowCastingMode.On
                    : ShadowCastingMode.Off;

            targetRenderer.receiveShadows =
                receiveShadows;
        }

        if (!disableVehicleColliders)
        {
            return;
        }

        Collider[] colliders =
            vehicle.GetComponentsInChildren
                <Collider>(true);

        foreach (Collider targetCollider in colliders)
        {
            if (targetCollider != null)
            {
                targetCollider.enabled = false;
            }
        }
    }

    private void EnsureFloatingMotion(
        GameObject vehicle
    )
    {
        if (
            vehicle.GetComponent
                <FloatingVehicleMotion>() != null
        )
        {
            return;
        }

        vehicle.AddComponent
            <FloatingVehicleMotion>();
    }

    private List<AirVehicleEntry> GetValidEntries()
    {
        List<AirVehicleEntry> validEntries =
            new List<AirVehicleEntry>();

        foreach (
            AirVehicleEntry entry
            in vehiclePrefabs
        )
        {
            if (
                entry != null &&
                entry.prefab != null
            )
            {
                validEntries.Add(entry);
            }
        }

        return validEntries;
    }

    private void CreateGeneratedRoot()
    {
        GameObject rootObject =
            new GameObject(
                GeneratedRootName
            );

        generatedRoot =
            rootObject.transform;

        generatedRoot.SetParent(
            transform,
            false
        );

        generatedRoot.localPosition =
            Vector3.zero;

        generatedRoot.localRotation =
            Quaternion.identity;

        generatedRoot.localScale =
            Vector3.one;
    }

    private Transform FindGeneratedRoot()
    {
        if (generatedRoot != null)
        {
            return generatedRoot;
        }

        generatedRoot =
            transform.Find(
                GeneratedRootName
            );

        return generatedRoot;
    }

    private bool HasGeneratedVehicles()
    {
        Transform existingRoot =
            FindGeneratedRoot();

        return
            existingRoot != null &&
            existingRoot.childCount > 0;
    }

    private int CalculateSeed()
    {
        if (randomizeEveryGeneration)
        {
            unchecked
            {
                return
                    Environment.TickCount ^
                    GetInstanceID() * 397;
            }
        }

        unchecked
        {
            int calculatedSeed =
                fixedSeed;

            calculatedSeed =
                calculatedSeed * 31 +
                transform.GetSiblingIndex();

            calculatedSeed =
                calculatedSeed * 31 +
                Mathf.RoundToInt(
                    transform.position.z * 10f
                );

            return calculatedSeed;
        }
    }

    private void OnValidate()
    {
        tileLength =
            Mathf.Max(1f, tileLength);

        startMargin =
            Mathf.Max(0f, startMargin);

        endMargin =
            Mathf.Max(0f, endMargin);

        maximumVehiclesPerTile =
            Mathf.Max(0, maximumVehiclesPerTile);

        minimumVehiclesPerTile =
            Mathf.Clamp(
                minimumVehiclesPerTile,
                0,
                maximumVehiclesPerTile
            );

        minimumSpacingAlongZ =
            Mathf.Max(
                0.1f,
                minimumSpacingAlongZ
            );

        flightHeightRange.x =
            Mathf.Min(
                flightHeightRange.x,
                flightHeightRange.y
            );

        flightHeightRange.y =
            Mathf.Max(
                flightHeightRange.x,
                flightHeightRange.y
            );

        scaleRange.x =
            Mathf.Max(0.1f, scaleRange.x);

        scaleRange.y =
            Mathf.Max(scaleRange.x, scaleRange.y);
    }
}
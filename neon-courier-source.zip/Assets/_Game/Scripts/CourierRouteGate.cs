using UnityEngine;

public sealed class CourierRouteGate : MonoBehaviour
{
    public bool Exit;
    [System.NonSerialized] public CourierAlternateRoute Owner;
    private void OnTriggerEnter(Collider other){if(Owner)Owner.Pass(Exit,other.GetComponentInParent<RunnerController>());}
}

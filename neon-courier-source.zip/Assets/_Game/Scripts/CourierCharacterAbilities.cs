using System.Collections.Generic;
using UnityEngine;

public sealed class CourierCharacterAbilities : MonoBehaviour
{
    public static CourierCharacterAbilities Instance { get; private set; }
    public static int ActiveIndex=>Instance&&Instance.selection?Instance.selection.SelectedIndex:0;
    public static float HeavyPenalty=>ActiveIndex==2?.03f:.08f;
    public static float MinimumHeavySpeed=>ActiveIndex==2?.94f:.84f;
    public float SpeedFactor=>TimeLeft>0?1.12f:1;
    public float TimeLeft { get; private set; }
    public int VisibleBeacons { get; private set; }
    private CharacterSelectionManager selection;
    private GameManager manager;
    private RunnerController runner;
    private readonly List<GameObject> beacons=new List<GameObject>();
    private readonly List<PackagePickup> tracked=new List<PackagePickup>();
    private float nextScan;
    private void Awake(){Instance=this;manager=GetComponent<GameManager>();selection=FindAnyObjectByType<CharacterSelectionManager>();runner=FindAnyObjectByType<RunnerController>();}
    private void Start(){manager.DeliveryCompleted+=Delivered;manager.MainMenuChanged+=MenuChanged;}
    private void OnDestroy(){if(manager){manager.DeliveryCompleted-=Delivered;manager.MainMenuChanged-=MenuChanged;}if(Instance==this)Instance=null;}
    private void Delivered(int packages){if(ActiveIndex==1&&packages>0)TimeLeft=2.5f;}
    private void MenuChanged(bool open){if(open)TimeLeft=0;}
    public static string Description(int index,bool en=false)
    {
        return en?new[]{"Contract bonus +10 coins","Delivery: +12% speed for 2.5s","Heavy cargo slows you 3%","Scanner reveals distant parcels"}[Mathf.Clamp(index,0,3)]:new[]{"Sözleşme bonusu +10 coin","Teslimat: 2,5 sn +%12 hız","Ağır yük yalnızca %3 yavaşlatır","Tarayıcı uzaktaki paketleri gösterir"}[Mathf.Clamp(index,0,3)];
    }
    private void Update()
    {
        bool running=manager&&manager.IsRunActive&&!manager.IsPaused&&!manager.IsGameOver;
        if(running)TimeLeft=Mathf.Max(0,TimeLeft-Time.deltaTime);
        bool scan=running&&ActiveIndex==3&&runner;
        if(scan&&Time.unscaledTime>=nextScan)
        {
            nextScan=Time.unscaledTime+.3f;tracked.Clear();
            var candidates=FindObjectsByType<PackagePickup>(FindObjectsSortMode.None);
            System.Array.Sort(candidates,(a,b)=>a.transform.position.z.CompareTo(b.transform.position.z));
            foreach(var package in candidates)
            {float ahead=package.transform.position.z-runner.transform.position.z;if(ahead>10&&ahead<55&&tracked.Count<8)tracked.Add(package);}
            var prefab=Resources.Load<GameObject>("CourierCareer/PackageBeacon");
            while(prefab&&beacons.Count<tracked.Count)beacons.Add(Instantiate(prefab,transform));
        }
        VisibleBeacons=0;
        for(int i=0;i<beacons.Count;i++)
        {
            bool visible=scan&&i<tracked.Count&&tracked[i]&&tracked[i].isActiveAndEnabled;
            beacons[i].SetActive(visible);if(!visible)continue;VisibleBeacons++;
            beacons[i].transform.position=tracked[i].transform.position+Vector3.up*(1.2f+Mathf.Sin(Time.time*3)*.1f);
        }
    }
}

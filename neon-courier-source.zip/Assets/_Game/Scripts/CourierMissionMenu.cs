using TMPro;
using UnityEngine;
using UnityEngine.UI;

public sealed class CourierMissionMenu : MonoBehaviour
{
    private TMP_Text title,subtitle,summary,footer,closeLabel;
    public void Build(Button close)
    {
        var content=CourierPanelSurface.Prepare(gameObject).Content;
        title=CourierPanelSurface.Label(content,"DailyTitle",new Vector2(0,-145),new Vector2(940,100),55,CourierPanelSurface.Cyan);
        subtitle=CourierPanelSurface.Label(content,"DailySubtitle",new Vector2(0,-245),new Vector2(940,75),29,CourierPanelSurface.Muted);
        summary=CourierPanelSurface.Label(content,"DailySummary",new Vector2(0,-335),new Vector2(940,75),30,Color.white);
        footer=CourierPanelSurface.Label(content,"DailyResetHint",new Vector2(0,-1650),new Vector2(940,90),27,CourierPanelSurface.Muted);
        CourierPanelSurface.Button(close,content,new Vector2(0,-1800),new Vector2(820,120),false);
        closeLabel=close.GetComponentInChildren<TMP_Text>();
    }
    public void Row(int index,TMP_Text title,TMP_Text progress,TMP_Text reward,Slider slider,Button claim,TMP_Text claimText)
    {
        var content=GetComponent<CourierPanelSurface>().Content;
        var card=CourierPanelSurface.Card(content,"DailyCard"+index,new Vector2(0,-540-index*295),new Vector2(940,265));
        CourierPanelSurface.Put(title,card.transform,new Vector2(0,78),new Vector2(850,64),35,true);
        CourierPanelSurface.Put(progress,card.transform,new Vector2(-280,8),new Vector2(300,48),29,true);progress.color=CourierPanelSurface.Muted;
        CourierPanelSurface.Put(reward,card.transform,new Vector2(-260,-77),new Vector2(350,65),32,true);reward.color=new Color(1,.77f,.31f);
        if(slider)
        {
            CourierPanelSurface.Place((RectTransform)slider.transform,card.transform,new Vector2(165,8),new Vector2(470,14),true);
            foreach(Transform child in slider.transform)child.gameObject.SetActive(false);
            slider.handleRect=null;slider.interactable=false;slider.transition=Selectable.Transition.None;slider.direction=Slider.Direction.LeftToRight;
            var track=new GameObject("DailyProgressTrack",typeof(RectTransform),typeof(Image));
            CourierPanelSurface.Place((RectTransform)track.transform,slider.transform,Vector2.zero,new Vector2(470,14),true);
            track.GetComponent<Image>().color=new Color(.12f,.21f,.28f);track.GetComponent<Image>().raycastTarget=false;
            var fill=new GameObject("DailyProgressFill",typeof(RectTransform),typeof(Image));fill.transform.SetParent(track.transform,false);
            var rect=(RectTransform)fill.transform;rect.anchorMin=Vector2.zero;rect.anchorMax=Vector2.one;rect.offsetMin=rect.offsetMax=Vector2.zero;
            fill.GetComponent<Image>().color=CourierPanelSurface.Cyan;fill.GetComponent<Image>().raycastTarget=false;slider.fillRect=rect;
        }
        CourierPanelSurface.Button(claim,card.transform,new Vector2(235,-77),new Vector2(350,90),true,claimText,true);
    }
    public void Refresh(DailyMissionManager manager,bool en)
    {
        int done=0,claimed=0,total=0;
        foreach(DailyMissionType type in System.Enum.GetValues(typeof(DailyMissionType))){if(manager.IsCompleted(type))done++;if(manager.IsClaimed(type))claimed++;total+=manager.GetReward(type);}
        title.text=en?"DAILY MISSIONS":"GÜNLÜK GÖREVLER";
        subtitle.text=en?"Run. Deliver. Collect your rewards.":"Koş, teslim et, ödüllerini topla.";
        summary.text=(en?"COMPLETED ":"TAMAMLANAN ")+done+"/4  •  "+(en?"TOTAL ":"TOPLAM ")+total+" COIN";
        footer.text=claimed==4?(en?"All rewards collected. Come back tomorrow!":"Tüm ödüller alındı. Yarın yeniden bekleriz!"):(en?"Missions reset every day at midnight.":"Görevler her gün gece yarısı yenilenir.");
        closeLabel.text=en?"BACK TO MENU":"ANA MENÜYE DÖN";
    }
}

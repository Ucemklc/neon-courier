using UnityEngine;

/// <summary>Run-local milestones: each reward can be earned once, including across a revive.</summary>
public sealed class CourierRunGoals : MonoBehaviour
{
    private static readonly int[] Distances={250,500,1000,2000};
    private static readonly int[] Rewards={15,25,50,100};
    private GameManager manager;
    private int reached;
    private bool started;
    private float noticeUntil;
    private int lastDistance,lastReward;
    public int MilestonesReached=>reached;
    public int BonusCoins { get; private set; }
    public int StartingRecord { get; private set; }
    public int PeakCombo { get; private set; }=1;
    public int NextDistance=>reached<Distances.Length?Distances[reached]:0;
    public int NextReward=>reached<Rewards.Length?Rewards[reached]:0;
    public bool HasNotice=>Time.unscaledTime<noticeUntil;
    public string Notice(bool en)=>(en?"MILESTONE ":"MESAFE HEDEFİ ")+lastDistance+" m  +"+lastReward+" COIN";
    private void Start()
    {
        manager=GetComponent<GameManager>();StartingRecord=manager.HighScore;
        manager.RunStateChanged+=RunChanged;manager.MainMenuChanged+=MenuChanged;
        manager.StatsChanged+=Stats;
    }
    private void OnDestroy()
    {
        if(!manager)return;manager.RunStateChanged-=RunChanged;
        manager.MainMenuChanged-=MenuChanged;manager.StatsChanged-=Stats;
    }
    private void MenuChanged(bool open)
    {
        if(!open)return;started=false;reached=0;BonusCoins=0;PeakCombo=1;noticeUntil=0;
    }
    private void RunChanged(bool active)
    {
        if(!active||started)return;started=true;StartingRecord=manager.HighScore;
    }
    private void Stats(){PeakCombo=Mathf.Max(PeakCombo,manager.ComboMultiplier);}
    private void Update()
    {
        if(!manager||!manager.IsRunActive||manager.IsPaused||manager.IsGameOver||manager.IsMainMenuActive)return;
        while(reached<Distances.Length&&manager.DistanceMeters>=Distances[reached])
        {
            lastDistance=Distances[reached];lastReward=Rewards[reached];
            reached++;BonusCoins+=lastReward;
            manager.GrantRunBonus(lastReward);noticeUntil=Time.unscaledTime+3f;
        }
    }
}

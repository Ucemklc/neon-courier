using System;
using UnityEngine;

public static class CourierBackpackStyle
{
    public static event Action Changed;
    public static int Skin=>Mathf.Clamp(PlayerPrefs.GetInt("NeonCourier.BagSkin",0),0,5);
    public static int Patch=>Mathf.Clamp(PlayerPrefs.GetInt("NeonCourier.BagPatch",0),0,4);
    public static int Glow=>Mathf.Clamp(PlayerPrefs.GetInt("NeonCourier.BagGlow",0),0,2);
    public static readonly Color[] Accents={new Color(1,.31f,.055f),new Color(.15f,.82f,1),new Color(.73f,.3f,1),new Color(.22f,.72f,.43f),new Color(1,.48f,.43f),new Color(.09f,.16f,.23f)};
    public static void Set(int skin,int patch,int glow)
    {
        patch=Mathf.Clamp(patch,0,4);if(!CourierCareerProgress.PatchUnlocked(patch))patch=Patch;
        PlayerPrefs.SetInt("NeonCourier.BagSkin",Mathf.Clamp(skin,0,5));PlayerPrefs.SetInt("NeonCourier.BagPatch",patch);PlayerPrefs.SetInt("NeonCourier.BagGlow",Mathf.Clamp(glow,0,2));PlayerPrefs.Save();Changed?.Invoke();
    }
}

[DisallowMultipleComponent]
public sealed class CourierBackpackAppearance : MonoBehaviour
{
    private Renderer[] renderers;
    private readonly GameObject[] patches=new GameObject[5];
    private MaterialPropertyBlock block;
    private float nextGlow;
    private bool compactPatch;
    public void UseCompactPatch(){compactPatch=true;Apply();}
    private void Awake(){renderers=GetComponentsInChildren<Renderer>(true);block=new MaterialPropertyBlock();}
    private void OnEnable(){CourierBackpackStyle.Changed+=Apply;Apply();}
    private void OnDisable(){CourierBackpackStyle.Changed-=Apply;}
    private void Update(){if(CourierBackpackStyle.Glow!=0 && Time.unscaledTime>=nextGlow){ApplyColors();nextGlow=Time.unscaledTime+.08f;}}
    public void Apply()
    {
        if(renderers==null){renderers=GetComponentsInChildren<Renderer>(true);block=new MaterialPropertyBlock();}
        ApplyColors();int selected=CourierBackpackStyle.Patch;
        if(!patches[selected])
        {
            var prefab=Resources.Load<GameObject>((selected<3?"CourierExpansion/":"CourierCareer/")+"BagPatch"+selected);
            if(prefab){patches[selected]=Instantiate(prefab,transform,false);patches[selected].transform.localPosition=new Vector3(0,-.02f,-.35f);foreach(var child in patches[selected].GetComponentsInChildren<Transform>(true))child.gameObject.layer=gameObject.layer;}
        }
        for(int i=0;i<patches.Length;i++)if(patches[i])
        {
            patches[i].SetActive(i==selected);
            if(compactPatch){patches[i].transform.localPosition=new Vector3(0,-.14f,-.415f);patches[i].transform.localScale=Vector3.one*.45f;}
        }
    }
    private void ApplyColors()
    {
        Color accent=CourierBackpackStyle.Accents[CourierBackpackStyle.Skin];
        Color shell=CourierBackpackStyle.Skin==1?new Color(.72f,.82f,.86f):Color.Lerp(new Color(.027f,.055f,.095f),accent,.14f);
        Color glow=CourierBackpackStyle.Glow==2?Color.HSVToRGB(Mathf.Repeat(Time.unscaledTime*.13f,1),.72f,1):Color.Lerp(new Color(.04f,.8f,1),accent,.25f);
        float power=CourierBackpackStyle.Glow==1?.75f+.45f*Mathf.Sin(Time.unscaledTime*3):1.1f;
        foreach(var renderer in renderers)
        {
            if(!renderer || !renderer.sharedMaterial)continue;
            string name=renderer.sharedMaterial.name;Color color;
            if(name.Contains("SafetyTangerine"))color=accent;
            else if(name.Contains("MidnightShell"))color=shell;
            else if(name.Contains("BlueSlate"))color=Color.Lerp(shell,new Color(.32f,.4f,.46f),.42f);
            else if(name.Contains("SignalCyan"))color=glow;
            else continue;
            renderer.GetPropertyBlock(block);block.SetColor("_BaseColor",color);
            if(name.Contains("SignalCyan"))block.SetColor("_EmissionColor",glow*power);
            renderer.SetPropertyBlock(block);
        }
    }
}

#if UNITY_EDITOR
using UnityEditor;

public static class NeonRailCheckMenu
{
    [MenuItem("Neon Courier/Run Rail Physics Checks")]
    public static void Run()
    {
        if (EditorApplication.isPlayingOrWillChangePlaymode) return;
        NeonRailUpgrade.ValidateAndGenerate();
        SessionState.SetBool("NeonRail.QA", true);
        EditorApplication.EnterPlaymode();
    }
}
#endif

using UnityEngine;

/// <summary>One reserved, three-gate course at a time; pause and mute obey the existing game settings.</summary>
public sealed class CourierDroneChallenge : MonoBehaviour
{
    public static CourierDroneChallenge Instance { get; private set; }
    private GameManager manager;
    private SecurityDroneChase drone;
    private CourierDroneCourse current;
    private Light alarm;
    private AudioSource sound;
    private AudioClip ping;
    private int entryHits;
    private float pulse,nextPing,messageUntil;
    private bool escaped;
    public bool Active=>current;
    public bool AlarmPlaying=>sound&&sound.isPlaying;
    public int EscapesThisRun { get; private set; }
    public bool ShowMessage=>Active||Time.unscaledTime<messageUntil;
    public string Message(bool en)=>Active?(en?"DRONE PURSUIT • CLEAR THREE GATES":"DRONE TAKİBİ • ÜÇ GEÇİDİ HASARSIZ GEÇ"):escaped?(en?"PURSUIT EVADED! +20 COINS":"TAKİPTEN KURTULDUN! +20 COIN"):(en?"PURSUIT ENDED • TRY A CLEAN RUN":"TAKİP BİTTİ • SONRAKİ PARKURDA TEKRAR DENE");
    private void Awake(){Instance=this;manager=GetComponent<GameManager>();}
    private void Start()
    {
        drone=FindAnyObjectByType<SecurityDroneChase>();manager.MainMenuChanged+=MenuChanged;manager.GameOverTriggered+=Stop;
        var go=new GameObject("Pursuit alarm",typeof(Light));go.transform.SetParent(drone?drone.transform:transform,false);
        alarm=go.GetComponent<Light>();alarm.type=LightType.Point;alarm.color=new Color(1,.12f,.04f);alarm.range=9;alarm.intensity=0;alarm.shadows=LightShadows.None;
        sound=gameObject.AddComponent<AudioSource>();sound.playOnAwake=false;sound.spatialBlend=0;sound.volume=.11f;
        const int rate=22050;var samples=new float[rate/7];
        for(int i=0;i<samples.Length;i++){float t=(float)i/rate;float fade=Mathf.Sin(Mathf.PI*i/(samples.Length-1));samples[i]=Mathf.Sin(t*880*Mathf.PI*2)*fade*.5f;}
        ping=AudioClip.Create("Drone warning pulse",samples.Length,1,rate,false);ping.SetData(samples,0);
    }
    private void OnDestroy(){if(manager){manager.MainMenuChanged-=MenuChanged;manager.GameOverTriggered-=Stop;}if(ping)Destroy(ping);if(alarm)Destroy(alarm.gameObject);if(Instance==this)Instance=null;}
    private void MenuChanged(bool open){if(open){Stop();EscapesThisRun=0;messageUntil=0;}}
    public bool Begin(CourierDroneCourse course)
    {
        if(!course||current||!manager||!manager.IsRunActive||manager.IsPaused||manager.IsGameOver)return false;
        current=course;entryHits=CourierCargoManifest.Instance?CourierCargoManifest.Instance.HitVersion:0;pulse=0;nextPing=0;
        drone?.MoveCloser(2);return true;
    }
    public bool Finish(CourierDroneCourse course)
    {
        if(!current||course!=current||manager.IsPaused||!manager.IsRunActive||manager.IsGameOver)return false;
        escaped=!CourierCargoManifest.Instance||CourierCargoManifest.Instance.HitVersion==entryHits;
        if(escaped){EscapesThisRun++;manager.GrantRunBonus(20);CourierCareerProgress.RecordEscape();drone?.PushBack(3);}
        else drone?.ResetChaseDistance();
        Stop();messageUntil=Time.unscaledTime+3;return true;
    }
    private void Stop(){current=null;if(alarm)alarm.intensity=0;if(sound)sound.Stop();}
    private void Update()
    {
        if(!Active){if(alarm)alarm.intensity=0;return;}
        if(manager.IsPaused){if(alarm)alarm.intensity=0;if(sound)sound.Stop();return;}
        if(!current.gameObject.activeInHierarchy){Stop();drone?.ResetChaseDistance();return;}
        pulse+=Time.deltaTime;
        if(alarm)alarm.intensity=Mathf.Sin(pulse*14)>0?4:0;
        if(!manager.IsSoundEnabled){sound.Stop();return;}
        if(pulse>=nextPing){sound.PlayOneShot(ping);nextPing=pulse+.75f;}
    }
}

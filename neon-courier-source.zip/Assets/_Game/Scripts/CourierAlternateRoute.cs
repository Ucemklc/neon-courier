using UnityEngine;

/// <summary>A roof shortcut or low tunnel, leaving both other ground lanes unobstructed.</summary>
public sealed class CourierAlternateRoute : MonoBehaviour
{
    private readonly GameObject[] routes=new GameObject[2];
    private GameObject active;
    private bool roof;
    private bool entered;
    private bool rewarded;
    private int hitVersion;
    private float laneX;
    private GameManager manager;
    private static readonly float[] RoofPackages={5.8f,9.5f,17.7f,18.7f,19.2f};
    private static readonly float[] TunnelPackages={5f,8.5f,18f,20f,21f};
    public bool IsRoof=>roof;
    public bool Active=>active && active.activeInHierarchy;
    public void Clear(){foreach(var route in routes)if(route)route.SetActive(false);entered=false;rewarded=false;}
    public bool Configure(float laneDistance,int sequence,GameObject[] packages,int count,float packageHeight,ObstacleVisualController obstacle)
    {
        Clear();roof=(sequence/6)%2==0;int index=roof?0:1;
        if(!routes[index])
        {
            var prefab=Resources.Load<GameObject>("CourierExpansion/"+(roof?"RooftopShortcut":"ServiceTunnel"));
            if(!prefab)return false;
            routes[index]=Instantiate(prefab,transform,false);
            foreach(var gate in routes[index].GetComponentsInChildren<CourierRouteGate>(true))gate.Owner=this;
        }
        active=routes[index];laneX=((sequence/6)%2==0?-1:1)*laneDistance;
        active.transform.localPosition=new Vector3(laneX,0,0);active.SetActive(true);
        var surface=active.GetComponent<RailRideSurface>();
        manager=GameManager.Instance;
        for(int i=0;i<Mathf.Min(count,packages.Length);i++)
        {
            var package=packages[i];if(!package)continue;
            float z=(roof?RoofPackages:TunnelPackages)[Mathf.Min(i,4)];
            package.transform.localPosition=new Vector3(laneX,Height(z)+packageHeight,z);
            package.transform.localRotation=Quaternion.identity;package.transform.localScale=Vector3.one;package.SetActive(true);
            if(surface)surface.RegisterContent(package);
        }
        if(!roof && obstacle)
        {
            obstacle.transform.localPosition=new Vector3(laneX,0,12.8f);obstacle.gameObject.SetActive(true);obstacle.Configure(RunnerObstacleType.Slide);
            if(surface)surface.RegisterContent(obstacle.gameObject);
        }
        return true;
    }
    public float GetRideHeightAt(float x,float z)=>Active && Mathf.Abs(x-laneX)<.96f?Height(z):0f;
    private float Height(float z)
    {
        if(!roof)return 0;
        if(z>=2.5f && z<7f)return (z-2.5f)/4.5f*2.4f;
        if(z>=7f && z<=12f || z>=16f && z<=20f)return 2.4f;
        if(z>20f && z<=24.5f)return (24.5f-z)/4.5f*2.4f;
        return 0f;
    }
    public void Pass(bool exit,RunnerController runner)
    {
        if(!manager)manager=GameManager.Instance;
        if(!manager || !manager.IsRunActive || manager.IsPaused || manager.IsGameOver || !runner)return;
        int currentHits=CourierCargoManifest.Instance?CourierCargoManifest.Instance.HitVersion:0;
        if(!exit){entered=true;hitVersion=currentHits;return;}
        if(!entered || rewarded || currentHits!=hitVersion)return;
        rewarded=true;CourierCargoManifest.Instance?.GrantRouteBoost();
        CourierExpansionUI.ShowRouteNotice();
    }
}

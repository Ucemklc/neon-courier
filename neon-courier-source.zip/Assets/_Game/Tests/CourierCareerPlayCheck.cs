#if UNITY_EDITOR
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using TMPro;
using UnityEditor;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;
using Object=UnityEngine.Object;

public sealed class CourierCareerPlayCheck : MonoBehaviour
{
    private const BindingFlags Hidden=BindingFlags.Instance|BindingFlags.NonPublic;
    private readonly List<string> report=new List<string>();
    private GameManager gm;private RunnerController runner;private CharacterSelectionManager selection;
    private float oldDelta,oldScale;private int oldRate;
    [MenuItem("Neon Courier/Run Career Checks")]
    public static void Run()
    {
        if(EditorApplication.isPlayingOrWillChangePlaymode)return;
        CourierPolishPreferences.Capture();
        foreach(string key in CourierCareerProgress.SavedKeys)PlayerPrefs.DeleteKey(key);
        for(int i=1;i<=4;i++)PlayerPrefs.SetInt("NeonCourier.CharacterUnlocked.courier_0"+i,1);
        PlayerPrefs.SetInt("NeonCourier.SelectedCharacter",0);PlayerPrefs.SetInt("NeonCourier.Language",0);
        PlayerPrefs.SetInt("NeonCourier_StoryIntro_Seen_v1",1);PlayerPrefs.SetInt("NeonCourier.TutorialCompleted",1);
        SessionState.SetBool("CourierCareer.QA",true);EditorApplication.EnterPlaymode();
    }
    [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
    private static void Boot()
    {
        if(!SessionState.GetBool("CourierCareer.QA",false))return;SessionState.SetBool("CourierCareer.QA",false);
        foreach(var intro in Object.FindObjectsByType<StoryIntroController>(FindObjectsSortMode.None))intro.enabled=false;
        foreach(var tutorial in Object.FindObjectsByType<TutorialController>(FindObjectsSortMode.None))tutorial.enabled=false;
        var story=GameObject.Find("StoryIntroCanvas");if(story)story.SetActive(false);
        new GameObject("Career checks").AddComponent<CourierCareerPlayCheck>();
    }
    private IEnumerator Start()
    {
        oldScale=Time.timeScale;oldDelta=Time.captureDeltaTime;oldRate=Application.targetFrameRate;
        Time.timeScale=1;Time.captureDeltaTime=1f/60;Application.targetFrameRate=120;
        Directory.CreateDirectory("Logs");Application.logMessageReceived+=Log;
        var stack=new Stack<IEnumerator>();stack.Push(Checks());double deadline=EditorApplication.timeSinceStartup+180;
        while(stack.Count>0)
        {
            bool moved=false;object next=null;Exception error=null;
            try{if(EditorApplication.timeSinceStartup>deadline)throw new TimeoutException("Career QA deadline");moved=stack.Peek().MoveNext();if(moved)next=stack.Peek().Current;}catch(Exception e){error=e;}
            if(error!=null){Check(false,error.ToString());break;}
            if(!moved){(stack.Pop() as IDisposable)?.Dispose();continue;}
            if(next is IEnumerator nested)stack.Push(nested);else yield return next;
        }
        while(stack.Count>0)(stack.Pop() as IDisposable)?.Dispose();
        Application.logMessageReceived-=Log;Time.timeScale=oldScale;Time.captureDeltaTime=oldDelta;Application.targetFrameRate=oldRate;
        File.WriteAllLines("Logs/CourierCareerChecks.txt",report);Debug.Log("CAREER_CHECKS_COMPLETE failures="+report.Count(l=>l.StartsWith("FAIL")));EditorApplication.isPlaying=false;
    }
    private void Log(string message,string trace,LogType type){if(type==LogType.Error||type==LogType.Exception)Check(false,"Unity: "+message);}
    private void Check(bool value,string message){report.Add((value?"PASS ":"FAIL ")+message);File.WriteAllLines("Logs/CourierCareerChecks.txt",report);}
    private IEnumerator Checks()
    {
        for(int i=0;i<10;i++)yield return null;
        gm=GameManager.Instance;runner=Object.FindAnyObjectByType<RunnerController>();selection=Object.FindAnyObjectByType<CharacterSelectionManager>();
        gm.OpenMainMenu();yield return null;
        var garage=gm.GetComponent<CourierGarageUI>();
        Check(garage&&gm.GetComponent<CourierRouteContract>()&&gm.GetComponent<CourierCharacterAbilities>()&&gm.GetComponent<CourierCareerProgress>()&&gm.GetComponent<CourierDroneChallenge>(),"All career systems attach to the real game scene");
        Click(Button("MissionsButton"));yield return null;yield return null;
        Check(!Button("OpenGarage").gameObject.activeInHierarchy&&!Button("BagWorkshop").gameObject.activeInHierarchy,"Mission panel hides overlapping garage and workshop entries");
        Click(Button("CloseMissionButton"));yield return null;yield return null;
        var open=Button("OpenGarage");Canvas.ForceUpdateCanvases();Check(Hit(open)==open,"Garage entry receives its visible click");Click(open);yield return new WaitForSecondsRealtime(.8f);
        Check(garage.IsOpen,"Garage opens from the main menu");
        var view=Object.FindObjectsByType<RawImage>(FindObjectsSortMode.None).First(t=>t.name=="GaragePreview");
        Check(view.texture&&view.texture.width==1000,"Garage shows a rendered 3D preview");
        Check(!Button("CareerOutfit1").interactable&&!Button("CareerOutfit2").interactable,"Career outfits begin locked");
        ScreenCapture.CaptureScreenshot("Logs/Career-Garage-Rookie.png");for(int i=0;i<5;i++)yield return null;
        Click(Button("CloseGarage"));Check(!garage.IsOpen,"Garage closes cleanly");
        Click(Button("CharacterButton"));yield return null;
        Check(Object.FindObjectsByType<TMP_Text>(FindObjectsSortMode.None).Count(t=>t.name=="CourierAbility")==4,"Character menu explains all four abilities");
        ScreenCapture.CaptureScreenshot("Logs/Career-Characters.png");for(int i=0;i<5;i++)yield return null;
        Click(Button("CloseCharacterButton"));
        gm.StartGameFromMenu();float deadline=Time.realtimeSinceStartup+7;while(!gm.IsRunActive&&Time.realtimeSinceStartup<deadline)yield return null;
        Check(gm.IsRunActive,"Career run starts normally");runner.enabled=false;
        foreach(var track in Object.FindObjectsByType<TrackManager>(FindObjectsSortMode.None))track.gameObject.SetActive(false);
        var ground=GameObject.CreatePrimitive(PrimitiveType.Cube);ground.name="QA ground";ground.transform.position=new Vector3(0,-.25f,50);ground.transform.localScale=new Vector3(20,.5f,180);
        yield return Contracts();yield return Abilities();yield return Progression(garage);yield return PooledCourses();
        foreach(float speed in new[]{9.5f,15.5f,25f})yield return RoofPhysics(speed);
        foreach(float speed in new[]{9.5f,15.5f,25f})yield return DronePhysics(speed);
        yield return DroneFailures();
        runner.enabled=false;gm.OpenMainMenu();yield return null;garage.Open();yield return new WaitForSecondsRealtime(.7f);
        var stage=GameObject.Find("Garage render stage");
        Check(stage.GetComponentsInChildren<Transform>().Any(t=>t.name=="ContractTrophy")&&stage.GetComponentsInChildren<Transform>().Any(t=>t.name=="RoofTrophy")&&stage.GetComponentsInChildren<Transform>().Any(t=>t.name=="DroneTrophy"),"Earned contract, roof and pursuit cups appear on the garage shelf");
        foreach(string name in new[]{"CloseGarage","GarageWorkshop","GarageRun"})Check(Hit(Button(name))==Button(name),name+" has the correct pointer target");
        ScreenCapture.CaptureScreenshot("Logs/Career-Garage-Legend.png");for(int i=0;i<5;i++)yield return null;
        Click(Button("GarageWorkshop"));yield return null;Check(gm.GetComponent<CourierExpansionUI>().WardrobeOpen,"Garage opens the backpack workshop");
        gm.GetComponent<CourierExpansionUI>().CloseWardrobe();garage.Open();Click(Button("GarageRun"));Check(!garage.IsOpen&&!gm.IsMainMenuActive,"Garage delivery button starts the next run");
        Destroy(ground);
    }
    private IEnumerator Contracts()
    {
        var contract=CourierRouteContract.Instance;var zone=Instantiate(AssetDatabase.LoadAssetAtPath<GameObject>("Assets/_Game/Prefabs/PF_DeliveryZone.prefab"));
        var stop=zone.GetComponent<CourierDeliveryStop>();if(!stop)stop=zone.AddComponent<CourierDeliveryStop>();var delivery=zone.GetComponent<DeliveryZone>();
        int before=gm.TotalCoins;int xp=CourierCareerProgress.XP;
        for(int i=0;i<3;i++)
        {
            zone.transform.position=new Vector3(0,1.5f,100+i*120);stop.Configure(i*120);delivery.ResetZone();gm.CollectPackage();
            Call(delivery,"OnTriggerEnter",runner.GetComponent<CharacterController>());
            Check(contract.ContractsCompleted==i/2&&contract.StopsCompleted==(i+1)%3,"Actual delivery trigger advances ordered stop "+(i+1));
        }
        Check(contract.ContractsCompleted==1&&gm.TotalCoins>=before+50,"Three-stop route grants the Neon courier contract bonus");
        Check(CourierCareerProgress.XP>=xp+135&&PlayerPrefs.GetInt(CourierCareerProgress.ContractsKey)==1,"Real deliveries and contract completion award persistent XP");
        int after=gm.TotalCoins;Check(!contract.CompleteStop(2,340,1)&&gm.TotalCoins==after,"Same delivery cannot duplicate contract rewards");
        contract.CompleteStop(1,500,1);Check(contract.StopsCompleted==1&&contract.NextCustomer==2,"Skipping a customer starts a new ordered chain");
        gm.PauseGame();Check(!contract.CompleteStop(2,620,1),"Paused delivery cannot advance a contract");gm.ResumeGame();
        Check(contract.RouteText(false).Length>5&&contract.Review(true).Length>5,"Customer feedback is present in Turkish and English");Destroy(zone);yield return null;
    }
    private IEnumerator Abilities()
    {
        var abilities=CourierCharacterAbilities.Instance;var manifest=CourierCargoManifest.Instance;
        selection.SelectCharacter(1);gm.CollectPackage();gm.DeliverCarriedPackages();
        Check(abilities.TimeLeft>2.4f&&manifest.SpeedMultiplier>=1.11f,"Express courier gains a short delivery speed boost");
        gm.PauseGame();float left=abilities.TimeLeft;yield return new WaitForSecondsRealtime(.2f);Check(Mathf.Approximately(left,abilities.TimeLeft),"Pause freezes the express ability timer");gm.ResumeGame();
        for(int i=0;i<160;i++)yield return null;Check(abilities.TimeLeft==0,"Express boost expires without stacking");
        selection.SelectCharacter(2);gm.CollectPackage(CourierCargoKind.Heavy);gm.CollectPackage(CourierCargoKind.Heavy);
        Check(Mathf.Approximately(manifest.SpeedMultiplier,.94f),"Industrial courier limits two heavy parcels to six percent slowdown");
        selection.SelectCharacter(0);Check(Mathf.Approximately(manifest.SpeedMultiplier,.84f),"Other couriers retain the original heavy cargo penalty");gm.DeliverCarriedPackages();
        selection.SelectCharacter(3);var parcel=Instantiate(AssetDatabase.LoadAssetAtPath<GameObject>("Assets/_Game/Prefabs/PF_Package.prefab"));parcel.SetActive(false);parcel.transform.position=runner.transform.position+Vector3.forward*25;parcel.SetActive(true);
        yield return new WaitForSecondsRealtime(.5f);Check(abilities.VisibleBeacons>0,"Night courier marks a real distant parcel");
        selection.SelectCharacter(0);yield return null;Check(abilities.VisibleBeacons==0,"Changing courier removes scanner markers");Destroy(parcel);
    }
    private IEnumerator Progression(CourierGarageUI garage)
    {
        PlayerPrefs.SetInt(CourierCareerProgress.XPKey,399);Check(CourierCareerProgress.Level==2&&!CourierCareerProgress.SelectOutfit(1),"Master rewards remain locked before level three");
        CourierCareerProgress.AddXP(1);Check(CourierCareerProgress.Level==3&&CourierCareerProgress.DistrictCount==4&&CourierCareerProgress.SelectOutfit(1),"Level three unlocks master outfit and Canal Line");
        CourierBackpackStyle.Set(0,3,0);Check(CourierBackpackStyle.Patch==3,"Earned master badge can be equipped");
        Check(CourierWorldRules.DistrictAt(910)==CourierDistrict.Canal,"Unlocked canal joins procedural district rotation");
        PlayerPrefs.SetInt(CourierCareerProgress.XPKey,1399);CourierCareerProgress.AddXP(1);Check(CourierCareerProgress.DistrictCount==5&&CourierWorldRules.DistrictAt(1210)==CourierDistrict.Skyport,"Level five unlocks Sky Terminal");
        PlayerPrefs.SetInt(CourierCareerProgress.XPKey,2199);CourierCareerProgress.AddXP(1);Check(CourierCareerProgress.Level==6&&CourierCareerProgress.SelectOutfit(2),"Level six unlocks the Legend outfit");
        CourierBackpackStyle.Set(0,4,0);Check(CourierBackpackStyle.Patch==4&&PlayerPrefs.GetInt(CourierCareerProgress.OutfitKey)==2,"Legend outfit and badge selections persist in player preferences");
        foreach(int index in new[]{3,4})
        {
            var tile=new GameObject("Career district test");tile.transform.position=new Vector3(0,0,index*300);
            tile.AddComponent<CourierDistrictTile>().Refresh();Check(tile.transform.childCount==1,"Career district "+index+" instantiates its visual asset");Destroy(tile);
            var ob=new GameObject("Career obstacle test");ob.transform.position=new Vector3(0,0,index*300);
            Check(ob.AddComponent<CourierDistrictObstacle>().Apply(RunnerObstacleType.Jump),"Career district "+index+" uses valid obstacle variants");Destroy(ob);
        }
        yield return null;
    }
    private IEnumerator PooledCourses()
    {
        var tile=Instantiate(AssetDatabase.LoadAssetAtPath<GameObject>("Assets/_Game/Prefabs/TrackTile_Prototype.prefab"));tile.transform.position=new Vector3(0,0,2000);
        var content=tile.GetComponent<TrackTileContent>();int roofs=0,drones=0;bool clean=true;
        for(int i=0;i<36;i++)
        {
            content.RefreshPattern();if(tile.GetComponentInChildren<CourierRoofCourse>())roofs++;if(tile.GetComponentInChildren<CourierDroneCourse>())drones++;
            content.ClearPattern();clean&=!tile.GetComponentInChildren<CourierRoofCourse>()&&!tile.GetComponentInChildren<CourierDroneCourse>();
        }
        Check(roofs>=3&&drones>=2,"Procedural tiles schedule both new courses across 36 patterns");
        Check(clean&&tile.GetComponentsInChildren<CourierRoofCourse>(true).Length==1&&tile.GetComponentsInChildren<CourierDroneCourse>(true).Length==1,"Recycling clears each course and reuses one pooled instance");
        Destroy(tile);yield return null;
    }
    private IEnumerator RoofPhysics(float speed)
    {
        Call(PowerUpController.Instance,"ResetAllPowerUps");
        var root=Instantiate(Resources.Load<GameObject>("CourierCareer/SkybridgeRoute"));var roof=root.GetComponent<CourierRoofCourse>();
        Warp(new Vector3(-2.5f,1.08f,-3),0,speed);Property(gm,"CurrentLives",3);runner.enabled=true;
        bool jumped=false,captured=false;float highest=0;int frames=0;int before=gm.TotalCoins;
        while(runner.transform.position.z<29&&frames++<350)
        {
            float z=runner.transform.position.z;
            if(speed==9.5f&&!captured&&z>9){ScreenCapture.CaptureScreenshot("Logs/Career-Roof.png");captured=true;}
            if(!jumped&&z>=14.4f){Call(runner,"TryJump");Call(runner,"MoveRight");jumped=true;}
            highest=Mathf.Max(highest,runner.transform.position.y);yield return null;
        }
        Check(roof.Entered&&highest>3.4f,"Train ramp reaches the rooftop at speed "+speed);
        Check(jumped&&roof.Completed&&gm.CurrentLives==3,"Roof bridge jump finishes safely at speed "+speed);
        Check(gm.TotalCoins>=before+15,"Completed roof course pays its bonus at speed "+speed);
        Check(!root.transform.Find("GoldParcel").gameObject.activeSelf&&!roof.TakeGold(runner),"Gold parcel is collectible during the jump and rewards only once at speed "+speed);
        runner.enabled=false;Destroy(root);yield return null;
    }
    private IEnumerator DronePhysics(float speed)
    {
        var root=Instantiate(Resources.Load<GameObject>("CourierCareer/DroneCourse"));var challenge=CourierDroneChallenge.Instance;
        Warp(new Vector3(-2.5f,1.08f,-3),0,speed);Property(gm,"CurrentLives",3);runner.enabled=true;int shift=0,frames=0,before=challenge.EscapesThisRun;
        while(runner.transform.position.z<30&&frames++<350)
        {
            float z=runner.transform.position.z;
            if(shift==0&&z>9.3f){Call(runner,"MoveRight");shift=1;}
            if(shift==1&&z>16.3f){Call(runner,"MoveRight");shift=2;}
            yield return null;
        }
        Check(challenge.EscapesThisRun==before+1&&gm.CurrentLives==3,"Three pursuit gates are escapable at speed "+speed);
        Check(!challenge.Active,"Pursuit ends after the exit gate at speed "+speed);
        runner.enabled=false;Destroy(root);yield return null;
    }
    private IEnumerator DroneFailures()
    {
        var root=Instantiate(Resources.Load<GameObject>("CourierCareer/DroneCourse"));var course=root.GetComponent<CourierDroneCourse>();var challenge=CourierDroneChallenge.Instance;
        Check(challenge.Begin(course),"Pursuit starts from an eligible course");
        gm.PauseGame();Check(!challenge.Finish(course)&&challenge.Active,"Pause prevents premature pursuit completion");gm.ResumeGame();
        int coins=gm.TotalCoins;CourierCargoManifest.Instance.DamageFragileCargo();challenge.Finish(course);
        Check(gm.TotalCoins==coins&&!challenge.Active,"A collision forfeits only the pursuit bonus");
        Check(!challenge.Finish(course),"Pursuit exit cannot repeat its reward");
        challenge.Begin(course);bool soundWasOn=gm.IsSoundEnabled;if(soundWasOn)gm.ToggleSound();yield return null;Check(!challenge.AlarmPlaying,"Muted pursuit does not play its warning audio");if(soundWasOn)gm.ToggleSound();challenge.Finish(course);Destroy(root);yield return null;
    }
    private void Warp(Vector3 pos,int lane,float speed){runner.enabled=false;var cc=runner.GetComponent<CharacterController>();cc.enabled=false;runner.transform.position=pos;Set(runner,"currentLane",lane);Set(runner,"verticalVelocity",0f);Set(runner,"horizontalVelocity",0f);cc.enabled=true;runner.SetForwardSpeed(speed);Physics.SyncTransforms();}
    private static Button Button(string name)=>Object.FindObjectsByType<Button>(FindObjectsInactive.Include,FindObjectsSortMode.None).First(b=>b.name==name);
    private static Button Hit(Button b){var corners=new Vector3[4];((RectTransform)b.transform).GetWorldCorners(corners);var data=new PointerEventData(EventSystem.current){position=RectTransformUtility.WorldToScreenPoint(null,(corners[0]+corners[2])/2)};var hits=new List<RaycastResult>();EventSystem.current.RaycastAll(data,hits);return hits.Count>0?hits[0].gameObject.GetComponentInParent<Button>():null;}
    private static void Click(Button b)=>ExecuteEvents.Execute(b.gameObject,new PointerEventData(EventSystem.current){button=PointerEventData.InputButton.Left},ExecuteEvents.pointerClickHandler);
    private static object Call(object o,string method,params object[] values)=>o.GetType().GetMethod(method,Hidden).Invoke(o,values);
    private static void Set(object o,string field,object value)=>o.GetType().GetField(field,Hidden).SetValue(o,value);
    private static void Property(object o,string property,object value)=>o.GetType().GetProperty(property).GetSetMethod(true).Invoke(o,new[]{value});
}
#endif

#if UNITY_EDITOR
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using TMPro;
using UnityEditor;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;
using Object=UnityEngine.Object;

public sealed class CourierJourneyPlayCheck:MonoBehaviour
{
    private const BindingFlags Hidden=BindingFlags.Instance|BindingFlags.NonPublic;
    private readonly List<string> report=new List<string>();
    private GameManager gm;private RunnerController runner;private CourierTimedDelivery delivery;
    [MenuItem("Neon Courier/Run Journey Checks")]
    public static void Run()
    {
        if(EditorApplication.isPlayingOrWillChangePlaymode)return;CourierPolishPreferences.Capture();
        PlayerPrefs.SetInt("NeonCourier_StoryIntro_Seen_v1",1);PlayerPrefs.SetInt("NeonCourier.TutorialCompleted",1);PlayerPrefs.SetInt("NeonCourier.Language",0);
        SessionState.SetBool("CourierJourney.QA",true);EditorApplication.EnterPlaymode();
    }
    [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
    private static void Boot()
    {
        if(!SessionState.GetBool("CourierJourney.QA",false))return;SessionState.SetBool("CourierJourney.QA",false);
        foreach(var intro in Object.FindObjectsByType<StoryIntroController>(FindObjectsSortMode.None))intro.enabled=false;
        foreach(var tutorial in Object.FindObjectsByType<TutorialController>(FindObjectsSortMode.None))tutorial.enabled=false;
        var story=GameObject.Find("StoryIntroCanvas");if(story)story.SetActive(false);
        new GameObject("Journey checks").AddComponent<CourierJourneyPlayCheck>();
    }
    private IEnumerator Start()
    {
        float oldDelta=Time.captureDeltaTime;int oldRate=Application.targetFrameRate;
        Time.timeScale=1;Time.captureDeltaTime=1f/60;Application.targetFrameRate=120;
        Directory.CreateDirectory("Logs");Application.logMessageReceived+=Log;
        var stack=new Stack<IEnumerator>();stack.Push(Checks());double deadline=EditorApplication.timeSinceStartup+240;
        while(stack.Count>0)
        {
            bool moved=false;object next=null;Exception error=null;
            try{if(EditorApplication.timeSinceStartup>deadline)throw new TimeoutException("Journey QA deadline");moved=stack.Peek().MoveNext();if(moved)next=stack.Peek().Current;}catch(Exception e){error=e;}
            if(error!=null){Check(false,error.ToString());break;}if(!moved){(stack.Pop() as IDisposable)?.Dispose();continue;}
            if(next is IEnumerator nested)stack.Push(nested);else yield return next;
        }
        while(stack.Count>0)(stack.Pop() as IDisposable)?.Dispose();
        Application.logMessageReceived-=Log;Time.timeScale=1;Time.captureDeltaTime=oldDelta;Application.targetFrameRate=oldRate;
        report.Add("COMPLETE failures="+report.Count(s=>s.StartsWith("FAIL")));File.WriteAllLines("Logs/CourierJourneyChecks.txt",report);EditorApplication.isPlaying=false;
    }
    private void Log(string message,string trace,LogType type){if(type==LogType.Error||type==LogType.Exception)Check(false,"Unity: "+message);}
    private void Check(bool value,string message){report.Add((value?"PASS ":"FAIL ")+message);File.WriteAllLines("Logs/CourierJourneyChecks.txt",report);}
    private IEnumerator Frames(int count){for(int i=0;i<count;i++)yield return null;}
    private IEnumerator Capture(string name){yield return Frames(10);ScreenCapture.CaptureScreenshot("Logs/Journey-"+name+".png");yield return Frames(6);}
    private IEnumerator Checks()
    {
        yield return Frames(10);gm=GameManager.Instance;runner=Object.FindAnyObjectByType<RunnerController>();delivery=gm.GetComponent<CourierTimedDelivery>();gm.OpenMainMenu();yield return Frames(2);
        Check(delivery&&gm.GetComponent<CourierGhostRace>()&&gm.GetComponent<CourierScooterRide>()&&gm.GetComponent<CourierWeather>(),"Five journey systems attach to the real scene");
        var toggle=Button("GhostRaceToggle");Pointer(toggle,"Record ghost toggle");bool enabled=gm.GetComponent<CourierGhostRace>().RaceEnabled;Click(toggle);Check(gm.GetComponent<CourierGhostRace>().RaceEnabled!=enabled,"Ghost toggle changes the saved preference");Click(toggle);
        yield return Capture("Menu");Click(Button("MissionsButton"));yield return Frames(2);Check(!toggle.gameObject.activeInHierarchy,"Missions modal hides the ghost control");Click(Button("CloseMissionButton"));
        gm.StartGameFromMenu();float deadline=Time.realtimeSinceStartup+7;while(!gm.IsRunActive&&Time.realtimeSinceStartup<deadline)yield return null;Check(gm.IsRunActive,"Run starts with all five additions");
        runner.enabled=false;Set(gm,"speedGainPerSecond",0f);foreach(var track in Object.FindObjectsByType<TrackManager>(FindObjectsSortMode.None))track.gameObject.SetActive(false);
        var ground=GameObject.CreatePrimitive(PrimitiveType.Cube);ground.name="QA ground";ground.transform.position=new Vector3(0,-.25f,1500);ground.transform.localScale=new Vector3(20,.5f,3200);
        yield return Deliveries();yield return Ghost();yield return Weather();yield return Pooling();
        foreach(float speed in new[]{9.5f,15.5f,25f})yield return Scooter(speed);
        foreach(int kind in new[]{0,1,2})yield return Street(kind);
        Destroy(ground);yield return Frames(2);yield return Showcase();
        gm.OpenMainMenu();yield return Frames(2);Check(!CourierScooterRide.Instance.IsRiding&&!gm.GetComponent<CourierWeather>().Rain.isPlaying,"Menu clears scooter and rain emission");
    }
    private IEnumerator Deliveries()
    {
        var obj=Instantiate(AssetDatabase.LoadAssetAtPath<GameObject>("Assets/_Game/Prefabs/PF_DeliveryZone.prefab"));var zone=obj.GetComponent<DeliveryZone>();Property(gm,"CurrentSpeed",10f);runner.SetForwardSpeed(10);Warp(0,0);
        for(int i=0;i<3;i++)
        {
            zone.ResetZone();gm.CollectPackage();float seconds=i==0?1.9f:i==1?1.25f:.75f;zone.transform.position=new Vector3(0,1.5f,seconds*10);delivery.RefreshTarget();
            Check(delivery.CanThrow,"Timing window is offered for case "+i);yield return Frames(2);
            if(i==2){Pointer(Button("ThrowParcelButton"),"Timed throw");yield return Capture("Delivery");}
            int before=gm.DeliveredPackages;Check(delivery.TryThrow(),"Throw input accepted for case "+i);
            Check(delivery.LastResult==i,"Early / good / perfect throw classification "+i);
            Check(!delivery.TryThrow(),"Repeated tap cannot pay twice for case "+i);
            if(i==0){Check(gm.CarriedPackages>0&&!zone.IsDelivered,"Early throw retains carried cargo");Check(zone.TryDeliver()>0,"Early throw still permits normal delivery at stop");}
            else Check(gm.DeliveredPackages>before&&zone.IsDelivered,"Accurate throw completes actual delivery "+i);
            Check(zone.TryDeliver()==0,"Processed stop cannot deliver twice "+i);yield return Frames(40);
        }
        zone.ResetZone();gm.CollectPackage();zone.transform.position=new Vector3(0,1.5f,7.5f);gm.PauseGame();Check(!delivery.TryThrow()&&zone.TryDeliver()==0,"Pause prevents timed and normal deliveries");gm.ResumeGame();
        zone.ResetZone();gm.DeliverCarriedPackages();delivery.RefreshTarget();Check(!delivery.CanThrow,"Empty backpack hides throw action");
        zone.gameObject.SetActive(false);Check(!DeliveryZone.ActiveStops.Contains(zone),"Pooled stop unregisters on disable");zone.gameObject.SetActive(true);Check(!zone.ThrowAttempted&&!zone.IsDelivered,"Pooled stop resets both delivery and throw state");Destroy(obj);yield return null;
    }
    private IEnumerator Ghost()
    {
        var race=gm.GetComponent<CourierGhostRace>();float time=race.RunClock;gm.PauseGame();yield return Frames(10);Check(Mathf.Approximately(time,race.RunClock),"Paused time is excluded from ghost recording");gm.ResumeGame();
        var replay=new CourierGhostRace.Replay{score=200,distance=100,samples=new List<CourierGhostRace.Sample>{new CourierGhostRace.Sample{t=0,x=-2.5f,y=1,z=0},new CourierGhostRace.Sample{t=10,x=2.5f,y=4,z=100}}};
        int index=0;var halfway=CourierGhostRace.At(replay,5,ref index);Check(Mathf.Abs(halfway.x)<.01f&&halfway.z==50&&halfway.y==2.5f,"Ghost interpolates time, lanes and jumping height");
        string path=Path.GetFullPath("Temp/CourierJourney-QA-Replay.json");Check(CourierGhostRace.Save(path,replay),"Replay saves to an isolated test file");Check(CourierGhostRace.Load(path)?.score==200,"Replay survives disk reload");
        replay.score=400;Check(CourierGhostRace.Save(path,replay)&&CourierGhostRace.Load(path).score==400,"New best replay replaces previous file atomically");
        File.WriteAllText(path,"broken replay");Check(CourierGhostRace.Load(path)==null,"Corrupt replay falls back to normal play");replay.samples[1]=new CourierGhostRace.Sample{t=-2,z=float.NaN};Check(!CourierGhostRace.Valid(replay),"Invalid timing and positions are rejected");
        var ghost=Resources.Load<GameObject>("CourierJourney/RecordGhost");Check(ghost&&ghost.GetComponentsInChildren<Collider>(true).Length==0,"Ghost has no colliders or gameplay pickups");
        Check(ghost.GetComponentsInChildren<Renderer>(true).All(r=>r.sharedMaterial.GetColor("_BaseColor").a<.5f),"Replay courier is translucent");
        string before=File.Exists(race.SavePath)?File.ReadAllText(race.SavePath):null;race.SaveBest();Check(before==(File.Exists(race.SavePath)?File.ReadAllText(race.SavePath):null),"Automated tests preserve the player's real replay");
    }
    private IEnumerator Weather()
    {
        var weather=gm.GetComponent<CourierWeather>();
        for(int i=0;i<6;i++){Warp(0,i*600+20);yield return Frames(2);Check((int)weather.Current==i%3,"Weather rotates at 600m, phase "+i);}
        Warp(0,1220);yield return Frames(50);Check(weather.Rain.isPlaying&&weather.Rain.particleCount>0,"Rain emits particles only in rainy phase");
        gm.PauseGame();float time=weather.Rain.time;yield return Frames(10);Check(weather.Rain.isPaused&&Mathf.Approximately(time,weather.Rain.time),"Pause freezes rainfall");gm.ResumeGame();yield return Frames(2);Check(weather.Rain.isPlaying,"Rain resumes after pause");
        if(gm.IsSoundEnabled)gm.ToggleSound();yield return Frames(2);Check(gm.GetComponents<AudioSource>().All(a=>!a.isPlaying),"Sound toggle mutes weather ambience");gm.ToggleSound();
        var puddles=GameObject.Find("Puddles(Clone)");Check(puddles&&puddles.transform.childCount==96,"Rain reuses a fixed set of puddles and reflections");
        yield return Capture("Rain");Warp(0,620);yield return Frames(100);Check(weather.Rain.isStopped&&!puddles.activeSelf,"Dry phase clears rain and hides wet road");yield return Capture("Night");Warp(0,20);yield return Frames(100);yield return Capture("Sunset");
    }
    private IEnumerator Pooling()
    {
        var tile=Object.FindObjectsByType<TrackTileContent>(FindObjectsInactive.Include,FindObjectsSortMode.None).First();tile.gameObject.SetActive(true);
        for(int i=0;i<120;i++)tile.RefreshPattern();int count=JourneyNodes(tile);
        for(int i=0;i<120;i++)tile.RefreshPattern();Check(JourneyNodes(tile)==count,"240 tile refreshes reuse scooter and street-event objects");
        Check(tile.GetComponentsInChildren<CourierScooterSegment>(true).Length==1&&tile.GetComponentsInChildren<CourierStreetEvent>(true).Length==3,"Tile pool contains one scooter course and all three street-event variants");tile.gameObject.SetActive(false);yield return null;
    }
    private int JourneyNodes(TrackTileContent tile)=>tile.GetComponentsInChildren<CourierScooterSegment>(true).Sum(s=>s.GetComponentsInChildren<Transform>(true).Length)+tile.GetComponentsInChildren<CourierStreetEvent>(true).Sum(s=>s.GetComponentsInChildren<Transform>(true).Length);
    private IEnumerator Scooter(float speed)
    {
        var obj=Instantiate(Resources.Load<GameObject>("CourierJourney/ScooterRoad"));obj.SetActive(true);var course=obj.GetComponent<CourierScooterSegment>();var ride=CourierScooterRide.Instance;Property(gm,"CurrentSpeed",speed);
        for(int part=0;part<3;part++)
        {
            obj.transform.position=new Vector3(0,0,part*30);course.Configure(part,Array.Empty<GameObject>(),0,.7f);int lane=part==0?1:part==1?0:2;Warp((lane-1)*2.5f,part*30+.5f);runner.SetForwardSpeed(speed);Property(gm,"CurrentLives",3);runner.enabled=true;
            int frames=0;while(runner.transform.position.z<part*30+25&&frames++<250){runner.SetForwardSpeed(speed);yield return null;}
            Check(ride.IsRiding&&gm.CurrentLives==3,"Scooter section "+part+" has a safe lane at speed "+speed);runner.enabled=false;
            if(part==0&&speed==9.5f){Check(ride.SpeedFactor==1.1f,"Scooter applies ten percent speed increase");gm.PauseGame();float left=ride.Remaining;yield return Frames(10);Check(ride.Remaining==left&&ride.IsRiding,"Pause preserves scooter section progress");gm.ResumeGame();runner.enabled=false;yield return Capture("Scooter");}
        }
        Warp(0,90);Check(!ride.IsRiding&&ride.SpeedFactor==1,"End of scooter section restores running");Destroy(obj);yield return null;
    }
    private IEnumerator Street(int kind)
    {
        var obj=Instantiate(Resources.Load<GameObject>("CourierJourney/StreetEvent"+kind));obj.SetActive(true);var street=obj.GetComponent<CourierStreetEvent>();street.enabled=false;
        foreach(float speed in new[]{9.5f,15.5f,25f})
        {
            Property(gm,"CurrentSpeed",speed);
            street.ResetEvent();street.Step(.6f,60,speed);street.Step(.6f,40,speed);
            Check(!street.Moving&&obj.GetComponentsInChildren<Collider>().All(c=>!c.enabled),"No sudden hazard during warning: "+kind+" / "+speed);
            street.Step(.8f,40,speed);street.Step(.5f,30,speed);Check(street.Moving,"Telegraphed event animates after warning: "+kind+" / "+speed);
            gm.PauseGame();float time=street.WarningTime;street.Step(5,20,speed);Check(time==street.WarningTime,"Pause freezes street event "+kind);gm.ResumeGame();runner.enabled=false;
            Warp(0,0);runner.SetForwardSpeed(speed);Property(gm,"CurrentLives",3);runner.enabled=true;
            int frames=0;while(runner.transform.position.z<24&&frames++<250){runner.SetForwardSpeed(speed);yield return null;}runner.enabled=false;
            Check(gm.CurrentLives==3,"Centre lane stays safe for event "+kind+" at "+speed);
        }
        street.ResetEvent();street.Step(.1f,8,25);street.Step(3,3,25);Check(street.Skipped&&!street.Moving&&obj.GetComponentsInChildren<Collider>().All(c=>!c.enabled),"Late street event skips hazard instead of spawning on runner "+kind);
        street.ResetEvent();street.Step(2,40,10);street.Step(.5f,30,10);var collision=obj.GetComponentsInChildren<Collider>().First(c=>c.enabled);collision.gameObject.SetActive(false);street.ResetEvent();Check(collision.gameObject.activeInHierarchy&&!collision.enabled,"Hit obstacle returns correctly on pooled event "+kind);
        street.Step(2,40,10);street.Step(.5f,30,10);Warp(kind==1?2.5f:-2.5f,0);Property(gm,"CurrentLives",3);runner.enabled=true;
        int blockedFrames=0;while(runner.transform.position.z<24&&blockedFrames++<250&&gm.CurrentLives==3)yield return null;runner.enabled=false;
        Check(gm.CurrentLives==2,"Warned obstacle has real collision for event "+kind);Destroy(obj);yield return new WaitForSecondsRealtime(1.65f);
    }
    private IEnumerator Showcase()
    {
        var world=new GameObject("Journey presentation road");
        for(int i=0;i<5;i++)
        {
            var tile=Instantiate(AssetDatabase.LoadAssetAtPath<GameObject>("Assets/_Game/Prefabs/TrackTile_Prototype.prefab"),world.transform);tile.transform.localPosition=new Vector3(0,0,-10+i*30);
            tile.GetComponent<TrackTileContent>().ClearPattern();tile.GetComponent<CityTileDecorator>()?.RefreshLayout();
        }
        gm.OpenMainMenu();gm.StartGameFromMenu();float deadline=Time.realtimeSinceStartup+7;while(!gm.IsRunActive&&Time.realtimeSinceStartup<deadline)yield return null;runner.enabled=false;Property(gm,"CurrentLives",3);
        foreach(int phase in new[]{0,1,2})
        {world.transform.position=new Vector3(0,0,phase*600);Warp(0,phase*600+5);yield return Frames(170);yield return Capture(phase==0?"Sunset":phase==1?"Night":"Rain");}
        world.transform.position=Vector3.zero;Warp(0,4);var road=Instantiate(Resources.Load<GameObject>("CourierJourney/ScooterRoad"));road.SetActive(true);road.GetComponent<CourierScooterSegment>().Configure(0,Array.Empty<GameObject>(),0,.7f);CourierScooterRide.Instance.Begin(0,88);yield return Frames(40);yield return Capture("Scooter");
        var bike=runner.transform.Find("RideScooter(Clone)");var bounds=new Bounds(bike.position,Vector3.zero);foreach(var r in bike.GetComponentsInChildren<Renderer>())bounds.Encapsulate(r.bounds);Check(bounds.size.x<1.8f&&bounds.size.z<3,"Scooter visual keeps a consistent world scale on the player rig");Destroy(road);CourierScooterRide.Instance.Begin(200,288);
        var race=gm.GetComponent<CourierGhostRace>();var replay=new CourierGhostRace.Replay{score=400,distance=200,samples=new List<CourierGhostRace.Sample>{new CourierGhostRace.Sample{t=0,x=-2.5f,y=1.08f,z=12},new CourierGhostRace.Sample{t=60,x=-2.5f,y=1.08f,z=18}}};Set(race,"opponent",replay);Set(race,"clock",0f);Set(race,"cursor",0);PlayerPrefs.SetInt(CourierGhostRace.EnabledKey,1);yield return Frames(4);Check(GameObject.Find("RecordGhost(Clone)")&&race.LeadMetres<0,"Recorded opponent appears ahead during a live run");yield return Capture("Ghost");Set(race,"opponent",null);
        for(int kind=0;kind<3;kind++)
        {var street=Instantiate(Resources.Load<GameObject>("CourierJourney/StreetEvent"+kind));street.SetActive(true);var ev=street.GetComponent<CourierStreetEvent>();ev.enabled=false;ev.ResetEvent();ev.Step(2,40,10);ev.Step(.5f,30,10);Warp(0,4);yield return Capture("Street"+kind);Destroy(street);yield return null;}
        var destination=Instantiate(AssetDatabase.LoadAssetAtPath<GameObject>("Assets/_Game/Prefabs/PF_DeliveryZone.prefab"));gm.CollectPackage();runner.SetForwardSpeed(10);Property(gm,"CurrentSpeed",10f);destination.transform.position=new Vector3(0,1.5f,11.5f);Warp(0,4);yield return Frames(5);yield return Capture("Delivery");delivery.TryThrow();yield return Frames(15);yield return Capture("DeliverySuccess");Destroy(destination);Destroy(world);
    }
    private void Warp(float x,float z){runner.enabled=false;var cc=runner.GetComponent<CharacterController>();cc.enabled=false;runner.transform.position=new Vector3(x,1.08f,z);Set(runner,"currentLane",Mathf.Clamp(Mathf.RoundToInt(x/2.5f)+1,0,2));Set(runner,"verticalVelocity",-2f);Set(runner,"horizontalVelocity",0f);cc.enabled=true;Physics.SyncTransforms();var camera=Camera.main.GetComponent<CameraFollow>();Set(camera,"movementVelocity",Vector3.zero);camera.GetType().GetMethod("InitializeFollowPosition",Hidden).Invoke(camera,null);camera.transform.LookAt(runner.transform.position+new Vector3(0,1.35f,5.2f));}
    private static Button Button(string name)=>Object.FindObjectsByType<Button>(FindObjectsInactive.Include,FindObjectsSortMode.None).First(b=>b.name==name);
    private static void Click(Button button){ExecuteEvents.Execute(button.gameObject,new PointerEventData(EventSystem.current){button=PointerEventData.InputButton.Left},ExecuteEvents.pointerClickHandler);}
    private void Pointer(Button button,string label)
    {
        Canvas.ForceUpdateCanvases();var corners=new Vector3[4];((RectTransform)button.transform).GetWorldCorners(corners);
        foreach(float x in new[]{.1f,.5f,.9f})foreach(float y in new[]{.1f,.5f,.9f})
        {var p=Vector3.Lerp(Vector3.Lerp(corners[0],corners[3],x),Vector3.Lerp(corners[1],corners[2],x),y);var hits=new List<RaycastResult>();EventSystem.current.RaycastAll(new PointerEventData(EventSystem.current){position=p},hits);Check(hits.Count>0&&hits[0].gameObject.GetComponentInParent<Button>()==button,label+" hit area "+x+","+y);}
    }
    private static void Set(object obj,string field,object value)=>obj.GetType().GetField(field,Hidden).SetValue(obj,value);
    private static void Property(object obj,string name,object value)=>obj.GetType().GetProperty(name).GetSetMethod(true).Invoke(obj,new[]{value});
}
#endif

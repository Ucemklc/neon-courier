#if UNITY_EDITOR
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;
using Object = UnityEngine.Object;

/// <summary>Builds and installs the matching parcel, backpack and delivery android art.</summary>
public static class CourierVisualUpgrade
{
    private const string Folder = "Assets/_Game/Art/CourierSet";
    private const string PackagePath = "Assets/_Game/Prefabs/PF_Package.prefab";
    private const string DeliveryPath = "Assets/_Game/Prefabs/PF_DeliveryZone.prefab";
    private const string ScenePath = "Assets/ArtTest_Backup_BeforeIntro.unity";
    private static Material navy, panel, rubber, ivory, orange, cyan, glass;
    private static readonly List<Mesh> TemporaryMeshes = new List<Mesh>();
    private static readonly Dictionary<string, Mesh> BoxMeshes = new Dictionary<string, Mesh>();

    [MenuItem("Neon Courier/Apply Courier Visual Upgrade")]
    public static void Apply()
    {
        if (EditorApplication.isPlayingOrWillChangePlaymode)
            throw new InvalidOperationException("Stop Play Mode before applying the art update.");
        Scene scene = SceneManager.GetActiveScene();
        if (scene.path != ScenePath || scene.isDirty)
            throw new InvalidOperationException("Open the saved ArtTest_Backup_BeforeIntro scene before applying.");
        Backup(ScenePath); Backup(PackagePath); Backup(DeliveryPath);
        Generate();
        ReplacePackage();
        ReplaceReceiver();
        ReplaceBackpackAndHud(scene);
        AssetDatabase.SaveAssets();
        Validate();
        Capture();
        Debug.Log("COURIER_VISUAL_UPGRADE_OK: parcel, android, backpack and notification removal applied.");
    }

    [MenuItem("Neon Courier/Generate Courier Visual Assets")]
    public static void Generate()
    {
        EnsureFolder(Folder + "/Meshes"); EnsureFolder(Folder + "/Materials");
        navy = Mat("MidnightShell", new Color(.045f,.095f,.15f), .3f);
        panel = Mat("BlueSlate", new Color(.13f,.24f,.32f), .25f);
        rubber = Mat("SoftGraphite", new Color(.026f,.042f,.058f), 0f);
        ivory = Mat("Porcelain", new Color(.76f,.83f,.82f), .15f);
        orange = Mat("SafetyTangerine", new Color(1f,.31f,.055f), .12f);
        cyan = Mat("SignalCyan", new Color(.015f,.78f,.94f), .15f, 1.1f);
        glass = Mat("VisorGlass", new Color(.012f,.036f,.062f), .65f);
        Scene preview = EditorSceneManager.NewPreviewScene();
        var root = new GameObject("Courier art build");
        SceneManager.MoveGameObjectToScene(root, preview);
        try
        {
            Save(BuildParcel(root.transform), "CourierParcel");
            Save(BuildBackpack(root.transform), "CourierBackpack");
            Save(BuildReceiver(root.transform), "DeliveryAndroid");
        }
        finally
        {
            EditorSceneManager.ClosePreviewScene(preview);
            foreach (var mesh in TemporaryMeshes) if (mesh) Object.DestroyImmediate(mesh);
            TemporaryMeshes.Clear(); BoxMeshes.Clear();
        }
        AssetDatabase.SaveAssets();
    }

    private static GameObject BuildParcel(Transform parent)
    {
        var root = Node("CourierParcel", parent);
        Box(root,"Case",V(0,0,0),V(.62f,.43f,.56f),navy,.055f);
        Box(root,"Lid",V(0,.22f,0),V(.65f,.075f,.59f),panel,.024f);
        Box(root,"BaseBumper",V(0,-.218f,0),V(.65f,.065f,.59f),rubber,.025f);
        foreach(float x in new[]{-.225f,.225f})
        {
            Box(root,"OrangeLockBand",V(x,0,0),V(.052f,.5f,.599f),orange,.009f);
            Box(root,"Latch",V(x,.11f,-.309f),V(.086f,.085f,.03f),ivory,.01f);
        }
        Box(root,"LabelPlate",V(0,.015f,-.289f),V(.31f,.23f,.021f),ivory,.018f);
        Mail(root,V(-.065f,.033f,-.304f),.095f,navy,false);
        for(int i=0;i<7;i++)
            Box(root,"TrackingStripe",V(.047f+i*.014f,-.025f,-.304f),V(i%3==0?.008f:.004f,.095f,.009f),navy,.001f);
        Box(root,"StatusLight",V(0,-.153f,-.298f),V(.12f,.019f,.016f),cyan,.005f);
        Box(root,"HandleFootL",V(-.09f,.285f,0),V(.035f,.055f,.07f),rubber,.009f);
        Box(root,"HandleFootR",V(.09f,.285f,0),V(.035f,.055f,.07f),rubber,.009f);
        Box(root,"CarryHandle",V(0,.31f,0),V(.2f,.035f,.07f),rubber,.012f);
        return root.gameObject;
    }

    private static GameObject BuildBackpack(Transform parent)
    {
        var root = Node("CourierBackpack",parent);
        Box(root,"PaddedBack",V(0,0,.10f),V(.57f,.77f,.18f),rubber,.075f);
        Box(root,"MainShell",V(0,0,-.045f),V(.64f,.84f,.38f),navy,.095f);
        Box(root,"TopFlap",V(0,.32f,-.055f),V(.66f,.23f,.405f),orange,.06f);
        Box(root,"FrontPocket",V(0,-.055f,-.247f),V(.50f,.45f,.13f),panel,.044f);
        Box(root,"PocketSeam",V(0,.118f,-.317f),V(.39f,.018f,.015f),rubber,.004f);
        Box(root,"ZipPull",V(.17f,.10f,-.332f),V(.026f,.055f,.018f),ivory,.006f);
        Box(root,"LowerBumper",V(0,-.386f,-.03f),V(.66f,.10f,.405f),rubber,.034f);
        foreach(float x in new[]{-.245f,.245f})
        {
            Box(root,"FasteningStrap",V(x,.21f,-.276f),V(.055f,.32f,.026f),rubber,.01f);
            Box(root,"Buckle",V(x,.115f,-.299f),V(.075f,.095f,.022f),ivory,.012f);
            Box(root,"Reflector",V(x,-.26f,-.278f),V(.029f,.15f,.016f),cyan,.006f);
            Box(root,"ShoulderStrap",V(x,.02f,.209f),V(.075f,.68f,.075f),rubber,.028f, new Vector3(-8,0,x>0?-8:8));
            Box(root,"StrapPadding",V(x,.17f,.218f),V(.092f,.30f,.086f),panel,.028f);
        }
        Box(root,"SidePocketL",V(-.337f,-.09f,-.015f),V(.07f,.29f,.23f),panel,.025f);
        Box(root,"SidePocketR",V(.337f,-.09f,-.015f),V(.07f,.29f,.23f),panel,.025f);
        Box(root,"TopHandleL",V(-.10f,.475f,0),V(.038f,.10f,.06f),rubber,.012f);
        Box(root,"TopHandleR",V(.10f,.475f,0),V(.038f,.10f,.06f),rubber,.012f);
        Box(root,"TopHandle",V(0,.513f,0),V(.235f,.036f,.06f),rubber,.012f);
        Mail(root,V(0,-.02f,-.321f),.22f,ivory,false);
        Box(root,"LightRecess",V(0,-.226f,-.32f),V(.31f,.064f,.02f),rubber,.012f);
        for(int i=0;i<5;i++)
        {
            float x = (i-2)*.054f;
            Box(root,"EmptyCapacitySlot",V(x,-.226f,-.334f),V(.036f,.027f,.008f),panel,.004f);
            var lamp = Node("CapacityLight_0"+(i+1),root);
            Box(lamp,"LED",V(x,-.226f,-.341f),V(.036f,.027f,.008f),cyan,.004f);
        }
        var glow = Node("CoreGlow",root);
        Box(glow,"TopStatusLED",V(0,.367f,-.267f),V(.13f,.022f,.015f),cyan,.005f);
        Node("IntakePoint",root).localPosition=V(0,.05f,-.36f);
        var core = root.gameObject.AddComponent<CargoCoreController>();
        Set(core,"coreGlow",glow.gameObject); Set(core,"intakePoint",root.Find("IntakePoint"));
        for(int i=1;i<=5;i++) Set(core,"capacityLight0"+i,root.Find("CapacityLight_0"+i).gameObject);
        SetFloat(core,"fullPulseAmount",.025f);
        return root.gameObject;
    }

    private static GameObject BuildReceiver(Transform parent)
    {
        var root=Node("DeliveryAndroid",parent);
        foreach(float x in new[]{-.16f,.16f})
        {
            Box(root,"BootSole",V(x,.065f,.065f),V(.245f,.13f,.38f),rubber,.04f);
            Box(root,"BootShell",V(x,.15f,.055f),V(.22f,.17f,.34f),ivory,.04f);
            Box(root,"BootReflector",V(x,.16f,.232f),V(.115f,.025f,.015f),cyan,.005f);
            Box(root,"Shin",V(x,.37f,0),V(.18f,.33f,.20f),panel,.035f);
            Box(root,"Knee",V(x,.56f,.065f),V(.20f,.12f,.16f),orange,.035f);
            Box(root,"Thigh",V(x,.73f,0),V(.215f,.29f,.225f),navy,.035f);
        }
        Box(root,"Hip",V(0,.91f,0),V(.46f,.18f,.28f),rubber,.04f);
        Box(root,"Jacket",V(0,1.20f,0),V(.57f,.52f,.35f),navy,.07f);
        Box(root,"JacketYoke",V(0,1.393f,.014f),V(.59f,.135f,.355f),orange,.035f);
        Box(root,"FrontArmor",V(0,1.17f,.181f),V(.42f,.29f,.034f),panel,.032f);
        Mail(root,V(0,1.20f,.204f),.24f,ivory,true);
        Box(root,"ChestStatus",V(0,1.045f,.212f),V(.135f,.024f,.016f),cyan,.006f);
        Box(root,"Collar",V(0,1.50f,0),V(.235f,.13f,.23f),rubber,.03f);
        var head=Node("HeadPivot",root); head.localPosition=V(0,1.65f,0);
        Box(head,"Helmet",V(0,.055f,0),V(.55f,.41f,.445f),ivory,.083f);
        Box(head,"HelmetCrown",V(0,.222f,0),V(.47f,.078f,.36f),orange,.032f);
        Box(head,"FaceVisor",V(0,.045f,.219f),V(.465f,.238f,.047f),glass,.052f);
        foreach(float x in new[]{-.105f,.105f})
        {
            Box(head,"FriendlyEye",V(x,.070f,.250f),V(.06f,.069f,.013f),cyan,.018f);
            Box(head,"EarModule",V(Mathf.Sign(x)*.29f,.038f,0),V(.063f,.19f,.23f),orange,.025f);
        }
        Box(head,"Smile",V(0,-.02f,.249f),V(.10f,.019f,.012f),cyan,.005f);
        Box(head,"SmileL",V(-.055f,-.008f,.249f),V(.014f,.028f,.012f),cyan,.004f);
        Box(head,"SmileR",V(.055f,-.008f,.249f),V(.014f,.028f,.012f),cyan,.004f);
        Box(head,"Antenna",V(.18f,.315f,-.035f),V(.025f,.15f,.025f),rubber,.009f);
        Box(head,"AntennaTip",V(.18f,.394f,-.035f),V(.06f,.045f,.06f),cyan,.015f);
        var receiver=root.gameObject.AddComponent<DeliveryReceiverVisual>(); Set(receiver,"head",head);
        foreach(int side in new[]{-1,1})
        {
            string label=side<0?"left":"right";
            var arm=Node(label+"Arm",root); arm.localPosition=V(side*.365f,1.40f,0);
            arm.localRotation=Quaternion.Euler(0,0,side*8f);
            Box(arm,"Shoulder",V(0,-.05f,0),V(.20f,.22f,.25f),orange,.048f);
            Box(arm,"UpperArm",V(0,-.21f,0),V(.155f,.24f,.18f),navy,.03f);
            var fore=Node(label+"Forearm",arm); fore.localPosition=V(0,-.33f,0);
            Box(fore,"Elbow",V(0,0,0),V(.16f,.12f,.17f),rubber,.033f);
            Box(fore,"Forearm",V(0,-.135f,.014f),V(.175f,.24f,.21f),ivory,.037f);
            Box(fore,"WristBand",V(0,-.25f,.014f),V(.18f,.065f,.215f),orange,.015f);
            Box(fore,"Hand",V(0,-.331f,.018f),V(.16f,.115f,.175f),rubber,.027f);
            Set(receiver,label+"Arm",arm); Set(receiver,label+"Forearm",fore);
        }
        var anchor=Node("ReceivedPackageAnchor",root); anchor.localPosition=V(0,1.025f,.55f);
        var parcel=Object.Instantiate(AssetDatabase.LoadAssetAtPath<GameObject>(Folder+"/CourierParcel.prefab"),anchor);
        parcel.name="ReceivedParcel"; parcel.transform.localScale=Vector3.one*.76f; parcel.SetActive(false);
        return root.gameObject;
    }

    private static void ReplacePackage()
    {
        var root=PrefabUtility.LoadPrefabContents(PackagePath);
        try
        {
            foreach(Transform child in root.transform.Cast<Transform>().ToArray()) Object.DestroyImmediate(child.gameObject);
            Instance("CourierParcel",root.transform);
            // Runtime tile pools set scale to one; make the saved prefab use that same scale.
            root.transform.localScale=Vector3.one;
            var hit=root.GetComponent<BoxCollider>(); hit.center=Vector3.zero; hit.size=V(.70f,.63f,.70f);
            PrefabUtility.SaveAsPrefabAsset(root,PackagePath);
        }
        finally { PrefabUtility.UnloadPrefabContents(root); }
    }

    private static void ReplaceReceiver()
    {
        var root=PrefabUtility.LoadPrefabContents(DeliveryPath);
        try
        {
            var feedback=root.GetComponentInChildren<NPCDeliveryFeedback>(true);
            var anchor=feedback.transform.Find("NPCAnchor");
            foreach(Transform child in anchor.Cast<Transform>().ToArray()) Object.DestroyImmediate(child.gameObject);
            var npc=Instance("DeliveryAndroid",anchor); npc.name="DeliveryNPC";
            npc.transform.localPosition=V(3.95f,-1.5f,1.8f); npc.transform.localRotation=Quaternion.Euler(0,-110,0);
            var receiver=npc.GetComponent<DeliveryReceiverVisual>();
            Set(feedback,"npcAnimator",null); SetBool(feedback,"automaticallyFindAnimator",false);
            Set(feedback,"receiverVisual",receiver);
            Set(feedback,"receivedPackageVisual",npc.transform.Find("ReceivedPackageAnchor/ReceivedParcel").gameObject);
            Set(root.GetComponent<DeliveryZone>(),"npcCameraFocusTarget",npc.transform);
            PrefabUtility.SaveAsPrefabAsset(root,DeliveryPath);
        }
        finally { PrefabUtility.UnloadPrefabContents(root); }
    }

    private static void ReplaceBackpackAndHud(Scene scene)
    {
        var roots=scene.GetRootGameObjects();
        var runner=roots.SelectMany(r=>r.GetComponentsInChildren<RunnerController>(true)).Single();
        var visual=runner.transform.Find("PlayerVisual");
        var anchor=visual.Find("CargoCoreAnchor");
        // Keep the anchor identity for existing references, replace the visible attachment.
        foreach(Transform child in anchor.Cast<Transform>().ToArray()) Object.DestroyImmediate(child.gameObject);
        anchor.localPosition=V(0,.12f,-.26f); anchor.localRotation=Quaternion.identity; anchor.localScale=Vector3.one*.8f;
        if(!anchor.GetComponent<CourierBackpackMount>())anchor.gameObject.AddComponent<CourierBackpackMount>();
        var bag=Instance("CourierBackpack",anchor); bag.name="CargoCoreVisual";
        foreach(var root in roots)
            foreach(var transform in root.GetComponentsInChildren<Transform>(true))
                if(transform != null && transform.name=="NearMissHUD") Object.DestroyImmediate(transform.gameObject);
        EditorSceneManager.MarkSceneDirty(scene);
        if(!EditorSceneManager.SaveScene(scene)) throw new Exception("Could not save the updated scene.");
    }

    [MenuItem("Neon Courier/Validate Courier Visual Assets")]
    public static void Validate()
    {
        var report=new List<string>();
        foreach(string name in new[]{"CourierParcel","CourierBackpack","DeliveryAndroid"})
        {
            var prefab=AssetDatabase.LoadAssetAtPath<GameObject>(Folder+"/"+name+".prefab");
            Require(prefab!=null,"Saved prefab: "+name,report);
            Require(prefab.GetComponentsInChildren<Collider>(true).Length==0,"No decorative colliders: "+name,report);
            foreach(var filter in prefab.GetComponentsInChildren<MeshFilter>(true))
                if(!filter.sharedMesh || !EditorUtility.IsPersistent(filter.sharedMesh)) throw new Exception("Transient mesh: "+filter.name);
            foreach(var renderer in prefab.GetComponentsInChildren<Renderer>(true))
                if(renderer.sharedMaterials.Any(m=>!m || !EditorUtility.IsPersistent(m))) throw new Exception("Transient material: "+renderer.name);
            report.Add("PASS Persistent shared meshes and materials: "+name);
        }
        var package=AssetDatabase.LoadAssetAtPath<GameObject>(PackagePath);
        Require(package.GetComponent<PackagePickup>() && package.GetComponent<BoxCollider>().isTrigger &&
            package.GetComponent<Rigidbody>().isKinematic,"Package pickup physics retained",report);
        var delivery=AssetDatabase.LoadAssetAtPath<GameObject>(DeliveryPath);
        var feedback=delivery.GetComponentInChildren<NPCDeliveryFeedback>(true);
        var props=new SerializedObject(feedback);
        Require(props.FindProperty("receiverVisual").objectReferenceValue!=null && props.FindProperty("receivedPackageVisual").objectReferenceValue!=null,
            "Android receive pose and held parcel connected",report);
        Require(delivery.GetComponent<DeliveryZone>() && delivery.GetComponent<BoxCollider>().isTrigger,"Delivery trigger retained",report);
        var scene=SceneManager.GetActiveScene();
        Require(!scene.GetRootGameObjects().SelectMany(r=>r.GetComponentsInChildren<Transform>(true)).Any(t=>t.name=="NearMissHUD"||t.name=="NearMissText"),
            "Near-miss text and HUD removed from active scene",report);
        var core=scene.GetRootGameObjects().SelectMany(r=>r.GetComponentsInChildren<CargoCoreController>(true)).Single();
        var coreProps=new SerializedObject(core);
        Require(core.IntakePoint!=null,"Backpack intake connected",report);
        for(int i=1;i<=5;i++) Require(coreProps.FindProperty("capacityLight0"+i).objectReferenceValue!=null,"Backpack capacity light "+i,report);
        Directory.CreateDirectory("Logs"); File.WriteAllLines("Logs/CourierVisualValidation.txt",report);
        Debug.Log("COURIER_VISUAL_VALIDATION_OK: "+report.Count+" checks.");
    }

    [MenuItem("Neon Courier/Capture Courier Asset Preview")]
    public static void Capture()
    {
        var preview=new PreviewRenderUtility(); Texture2D image=null;
        try
        {
            var root=new GameObject("Courier set preview"); preview.AddSingleGO(root);
            var robot=Object.Instantiate(AssetDatabase.LoadAssetAtPath<GameObject>(Folder+"/DeliveryAndroid.prefab"),root.transform);
            robot.transform.localPosition=V(-.95f,0,0); robot.transform.localRotation=Quaternion.Euler(0,160,0);
            var bag=Object.Instantiate(AssetDatabase.LoadAssetAtPath<GameObject>(Folder+"/CourierBackpack.prefab"),root.transform);
            bag.transform.localPosition=V(.68f,.86f,0); bag.transform.localScale=Vector3.one*1.45f;
            bag.transform.localRotation=Quaternion.Euler(0,-15,0);
            var parcel=Object.Instantiate(AssetDatabase.LoadAssetAtPath<GameObject>(Folder+"/CourierParcel.prefab"),root.transform);
            parcel.transform.localPosition=V(.70f,.28f,-.80f); parcel.transform.localRotation=Quaternion.Euler(0,-15,0);
            preview.camera.transform.position=V(-3.2f,2.7f,-6.5f); preview.camera.transform.LookAt(V(0,.98f,0));
            preview.camera.fieldOfView=30f; preview.camera.nearClipPlane=.1f; preview.camera.farClipPlane=100f;
            preview.camera.clearFlags=CameraClearFlags.SolidColor; preview.camera.backgroundColor=new Color(.018f,.029f,.044f);
            preview.ambientColor=new Color(.55f,.58f,.62f);
            preview.lights[0].intensity=1.7f; preview.lights[0].transform.rotation=Quaternion.Euler(30,30,0);
            preview.lights[1].intensity=1.1f; preview.lights[1].color=new Color(.55f,.8f,1f); preview.lights[1].transform.rotation=Quaternion.Euler(30,-150,0);
            preview.BeginStaticPreview(new Rect(0,0,1500,1100)); preview.Render(true,false); image=preview.EndStaticPreview();
            Directory.CreateDirectory("Logs"); File.WriteAllBytes("Logs/CourierSetPreview.png",image.EncodeToPNG());
        }
        finally { if(image) Object.DestroyImmediate(image); preview.Cleanup(); }
    }

    private static Transform Node(string name,Transform parent)
    { var node=new GameObject(name).transform; node.SetParent(parent,false); return node; }

    [MenuItem("Neon Courier/Capture Worn Backpack Preview")]
    public static void CaptureWornBackpack()
    {
        if(EditorApplication.isPlaying) return;
        var player=SceneManager.GetActiveScene().GetRootGameObjects().SelectMany(r=>r.GetComponentsInChildren<RunnerController>(true)).Single();
        var preview=new PreviewRenderUtility(); Texture2D image=null;
        try
        {
            var root=new GameObject("Worn backpack preview");preview.AddSingleGO(root);
            var copy=Object.Instantiate(player.gameObject,root.transform);copy.transform.localPosition=Vector3.zero;
            var selection=copy.GetComponentInChildren<CharacterSelectionManager>(true);
            if(selection)
            {
                var characters=new SerializedObject(selection).FindProperty("characters");
                int selected=Mathf.Clamp(PlayerPrefs.GetInt("NeonCourier.SelectedCharacter",0),0,characters.arraySize-1);
                for(int i=0;i<characters.arraySize;i++)
                    ((GameObject)characters.GetArrayElementAtIndex(i).FindPropertyRelative("characterRoot").objectReferenceValue).SetActive(i==selected);
            }
            foreach(var t in copy.GetComponentsInChildren<Transform>(true))
                if(t.name=="HoverboardVisual" || t.name=="CharacterModelRoot")t.gameObject.SetActive(false);
            foreach(var animator in copy.GetComponentsInChildren<Animator>()) { animator.Rebind(); animator.Update(0f); }
            copy.GetComponentInChildren<CourierBackpackMount>(true)?.FitNow();
            preview.camera.transform.position=V(-2.1f,1.1f,-4.7f);preview.camera.transform.LookAt(V(0,.05f,0));
            preview.camera.fieldOfView=32;preview.camera.nearClipPlane=.1f;preview.camera.farClipPlane=50;
            preview.camera.clearFlags=CameraClearFlags.SolidColor;preview.camera.backgroundColor=new Color(.018f,.029f,.044f);
            preview.ambientColor=new Color(.55f,.58f,.62f);
            preview.lights[0].intensity=1.7f;preview.lights[0].transform.rotation=Quaternion.Euler(30,30,0);
            preview.lights[1].intensity=1.1f;preview.lights[1].transform.rotation=Quaternion.Euler(30,-150,0);
            preview.BeginStaticPreview(new Rect(0,0,1000,1200));preview.Render(true,false);image=preview.EndStaticPreview();
            Directory.CreateDirectory("Logs");File.WriteAllBytes("Logs/CourierWornBackpack.png",image.EncodeToPNG());
        }
        finally{if(image)Object.DestroyImmediate(image);preview.Cleanup();}
    }
    private static Vector3 V(float x,float y,float z)=>new Vector3(x,y,z);
    private static GameObject Instance(string name,Transform parent)=>
        (GameObject)PrefabUtility.InstantiatePrefab(AssetDatabase.LoadAssetAtPath<GameObject>(Folder+"/"+name+".prefab"),parent);
    private static void Box(Transform parent,string name,Vector3 position,Vector3 size,Material material,float bevel,Vector3 rotation=default)
    {
        var node=Node(name,parent); node.localPosition=position; node.localRotation=Quaternion.Euler(rotation);
        string key=size.ToString("F4")+bevel.ToString("F4");
        if(!BoxMeshes.TryGetValue(key,out var mesh)) { mesh=BeveledBox(size,bevel); BoxMeshes.Add(key,mesh); TemporaryMeshes.Add(mesh); }
        node.gameObject.AddComponent<MeshFilter>().sharedMesh=mesh;
        node.gameObject.AddComponent<MeshRenderer>().sharedMaterial=material;
    }
    private static void Mail(Transform parent,Vector3 center,float width,Material material,bool front)
    {
        float height=width*.62f, thick=width*.073f;
        Box(parent,"MailTop",center+V(0,height*.5f,0),V(width,thick,.011f),material,.002f);
        Box(parent,"MailBottom",center+V(0,-height*.5f,0),V(width,thick,.011f),material,.002f);
        Box(parent,"MailLeft",center+V(-width*.5f,0,0),V(thick,height,.011f),material,.002f);
        Box(parent,"MailRight",center+V(width*.5f,0,0),V(thick,height,.011f),material,.002f);
        Box(parent,"MailFoldL",center+V(-width*.25f,height*.10f,0),V(width*.58f,thick,.014f),material,.002f,V(0,0,-34));
        Box(parent,"MailFoldR",center+V(width*.25f,height*.10f,0),V(width*.58f,thick,.014f),material,.002f,V(0,0,34));
    }
    private static Mesh BeveledBox(Vector3 size,float bevel)
    {
        Vector3 h=size*.5f; float r=Mathf.Min(bevel,Mathf.Min(h.x,Mathf.Min(h.y,h.z))*.8f);
        var verts=new List<Vector3>(); var tris=new List<int>();
        Action<Vector3[]> face=points=>
        {
            Vector3 center=Vector3.zero; foreach(var p in points) center+=p;
            if(Vector3.Dot(Vector3.Cross(points[1]-points[0],points[2]-points[0]),center)<0) Array.Reverse(points);
            int start=verts.Count; verts.AddRange(points);
            for(int i=1;i<points.Length-1;i++){tris.Add(start);tris.Add(start+i);tris.Add(start+i+1);}
        };
        for(int axis=0;axis<3;axis++) for(int sign=-1;sign<=1;sign+=2)
        {
            int b=(axis+1)%3,c=(axis+2)%3; var q=new Vector3[4]; int k=0;
            foreach(var pair in new[]{new Vector2(-1,-1),new Vector2(1,-1),new Vector2(1,1),new Vector2(-1,1)})
            {var p=Vector3.zero;p[axis]=sign*h[axis];p[b]=pair.x*(h[b]-r);p[c]=pair.y*(h[c]-r);q[k++]=p;} face(q);
        }
        for(int axis=0;axis<3;axis++) for(int sb=-1;sb<=1;sb+=2) for(int sc=-1;sc<=1;sc+=2)
        {
            int b=(axis+1)%3,c=(axis+2)%3;var q=new Vector3[4];
            for(int i=0;i<4;i++){var p=Vector3.zero;p[axis]=(i<2?-1:1)*(h[axis]-r);bool outerB=i==0||i==3;p[b]=sb*(h[b]-(outerB?0:r));p[c]=sc*(h[c]-(outerB?r:0));q[i]=p;}face(q);
        }
        for(int sx=-1;sx<=1;sx+=2)for(int sy=-1;sy<=1;sy+=2)for(int sz=-1;sz<=1;sz+=2)
            face(new[]{V(sx*h.x,sy*(h.y-r),sz*(h.z-r)),V(sx*(h.x-r),sy*h.y,sz*(h.z-r)),V(sx*(h.x-r),sy*(h.y-r),sz*h.z)});
        var mesh=new Mesh{name="ChamferedShell"};mesh.SetVertices(verts);mesh.SetTriangles(tris,0);mesh.RecalculateNormals();mesh.RecalculateBounds();return mesh;
    }
    private static Material Mat(string name,Color color,float metal,float emission=0f)
    {
        string path=Folder+"/Materials/"+name+".mat";var material=AssetDatabase.LoadAssetAtPath<Material>(path);
        if(!material){material=new Material(Shader.Find("Universal Render Pipeline/Lit"));AssetDatabase.CreateAsset(material,path);}
        material.name=name;material.SetColor("_BaseColor",color);material.SetFloat("_Metallic",metal);material.SetFloat("_Smoothness",.37f);
        if(emission>0){material.EnableKeyword("_EMISSION");material.SetColor("_EmissionColor",color*emission);}
        EditorUtility.SetDirty(material);return material;
    }
    private static void Save(GameObject root,string name)
    {
        // Combine direct static parts per material. Animated pivots and capacity LEDs remain independent.
        foreach(var parent in root.GetComponentsInChildren<Transform>(true).Reverse().ToArray())
        {
            var parts=parent.Cast<Transform>().Where(t=>t.GetComponent<MeshFilter>()!=null).ToArray();
            foreach(var group in parts.GroupBy(t=>t.GetComponent<MeshRenderer>().sharedMaterial))
            {
                var mesh=new Mesh{name=name+"_"+parent.name+"_"+group.Key.name};
                mesh.CombineMeshes(group.Select(t=>new CombineInstance{mesh=t.GetComponent<MeshFilter>().sharedMesh,transform=Matrix4x4.TRS(t.localPosition,t.localRotation,t.localScale)}).ToArray(),true,true);
                string path=Folder+"/Meshes/"+mesh.name+".asset";var saved=AssetDatabase.LoadAssetAtPath<Mesh>(path);
                if(saved){EditorUtility.CopySerialized(mesh,saved);Object.DestroyImmediate(mesh);}else{saved=mesh;AssetDatabase.CreateAsset(saved,path);}
                foreach(var part in group) Object.DestroyImmediate(part.gameObject);
                var combined=Node(group.Key.name,parent);combined.gameObject.AddComponent<MeshFilter>().sharedMesh=saved;combined.gameObject.AddComponent<MeshRenderer>().sharedMaterial=group.Key;
            }
        }
        PrefabUtility.SaveAsPrefabAsset(root,Folder+"/"+name+".prefab",out bool ok);
        if(!ok)throw new Exception("Could not save "+name);
    }
    private static void Set(Object target,string name,Object value)
    {var so=new SerializedObject(target);var p=so.FindProperty(name);if(p==null)throw new Exception(name);p.objectReferenceValue=value;so.ApplyModifiedPropertiesWithoutUndo();}
    private static void SetFloat(Object target,string name,float value)
    {var so=new SerializedObject(target);so.FindProperty(name).floatValue=value;so.ApplyModifiedPropertiesWithoutUndo();}
    private static void SetBool(Object target,string name,bool value)
    {var so=new SerializedObject(target);so.FindProperty(name).boolValue=value;so.ApplyModifiedPropertiesWithoutUndo();}
    private static void Require(bool condition,string message,List<string> report)
    {if(!condition)throw new Exception(message);report.Add("PASS "+message);}
    private static void EnsureFolder(string path)
    {if(AssetDatabase.IsValidFolder(path))return;string parent=Path.GetDirectoryName(path).Replace('\\','/');EnsureFolder(parent);AssetDatabase.CreateFolder(parent,Path.GetFileName(path));}
    private static void Backup(string path)
    {string target="CodexBackups/CourierVisual-20260925/"+path;Directory.CreateDirectory(Path.GetDirectoryName(target));if(!File.Exists(target))File.Copy(path,target);}
}
#endif

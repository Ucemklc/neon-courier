using UnityEngine;

/// <summary>Train ramp, rooftop, bridge jump and a second rooftop, with an optional gold parcel.</summary>
public sealed class CourierRoofCourse : MonoBehaviour
{
    private bool entered,completed,goldTaken;
    private int entryHits;
    public bool Entered=>entered;
    public bool Completed=>completed;
    private void OnEnable(){entered=false;completed=false;goldTaken=false;var gold=transform.Find("GoldParcel");if(gold)gold.gameObject.SetActive(true);}
    public void Configure(GameObject[] parcels,int count,float height)
    {
        gameObject.SetActive(true);
        Vector3[] route={new Vector3(-2.5f,2.4f,7),new Vector3(-2.5f,2.4f,12),new Vector3(-1.25f,2.4f,16),new Vector3(0,2.4f,20),new Vector3(0,2.4f,21)};
        var surface=GetComponent<RailRideSurface>();
        for(int i=0;i<Mathf.Min(count,parcels.Length);i++)
        {if(!parcels[i])continue;parcels[i].transform.localPosition=route[Mathf.Min(i,route.Length-1)]+Vector3.up*height;parcels[i].SetActive(true);surface.RegisterContent(parcels[i]);}
    }
    public void Pass(bool exit,RunnerController runner)
    {
        var gm=GameManager.Instance;
        if(!gm||!gm.IsRunActive||gm.IsPaused||gm.IsGameOver||!runner||runner.transform.position.y<2.4f)return;
        int hits=CourierCargoManifest.Instance?CourierCargoManifest.Instance.HitVersion:0;
        if(!exit){if(!entered){entered=true;entryHits=hits;}return;}
        if(!entered||completed||hits!=entryHits)return;
        completed=true;gm.GrantRunBonus(15);CourierCareerProgress.RecordRoof();CourierExpansionUI.ShowRoofNotice();
    }
    public bool TakeGold(RunnerController runner)
    {
        var gm=GameManager.Instance;
        if(goldTaken||!entered||!runner||runner.transform.position.y<transform.position.y+2.4f||!gm||!gm.IsRunActive||gm.IsPaused||gm.IsGameOver)return false;
        goldTaken=true;gm.GrantRunBonus(15);return true;
    }
}

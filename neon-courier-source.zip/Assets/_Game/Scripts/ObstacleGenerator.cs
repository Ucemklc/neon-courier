using System.Collections.Generic;
using UnityEngine;

public class ObstacleGenerator : MonoBehaviour
{
    [Header("Prefab")]
    [SerializeField] private GameObject obstaclePrefab;

    [Header("Lane Settings")]
    [SerializeField] private float laneDistance = 2.5f;

    [Header("Row Settings")]
    [SerializeField, Min(1)] private int rowCount = 3;
    [SerializeField] private float firstRowZ = 8f;
    [SerializeField] private float rowSpacing = 7f;

    [Header("Difficulty")]
    [SerializeField, Range(0f, 1f)]
    private float twoObstacleChance = 0.55f;

    [SerializeField, Range(0f, 1f)]
    private float slideObstacleChance = 0.35f;

    private GameObject[,] obstacleSlots;
    private Transform generatedRoot;
    private bool slotsCreated;

    private void Awake()
    {
        CreateObstacleSlots();
    }

    public void ClearPattern()
    {
        CreateObstacleSlots();
        DisableAllObstacles();
    }

    public void RefreshPattern()
    {
        CreateObstacleSlots();
        DisableAllObstacles();

        int previousSafeLane = Random.Range(0, 3);

        for (int row = 0; row < rowCount; row++)
        {
            int safeLane;

            if (row == 0)
            {
                safeLane = previousSafeLane;
            }
            else
            {
                int laneChange = Random.Range(-1, 2);

                safeLane = Mathf.Clamp(
                    previousSafeLane + laneChange,
                    0,
                    2
                );
            }

            CreateRowPattern(row, safeLane);
            previousSafeLane = safeLane;
        }
    }

    private void CreateRowPattern(int row, int safeLane)
    {
        List<int> availableBlockedLanes = new();

        for (int lane = 0; lane < 3; lane++)
        {
            if (lane != safeLane)
            {
                availableBlockedLanes.Add(lane);
            }
        }

        bool shouldUseTwoObstacles =
            Random.value < twoObstacleChance;

        if (shouldUseTwoObstacles)
        {
            ActivateObstacle(
                row,
                availableBlockedLanes[0]
            );

            ActivateObstacle(
                row,
                availableBlockedLanes[1]
            );

            return;
        }

        int selectedIndex = Random.Range(
            0,
            availableBlockedLanes.Count
        );

        ActivateObstacle(
            row,
            availableBlockedLanes[selectedIndex]
        );
    }

    private void ActivateObstacle(int row, int lane)
    {
        GameObject obstacle = obstacleSlots[row, lane];

        bool isSlideObstacle =
            Random.value < slideObstacleChance;

        float laneX = (lane - 1) * laneDistance;
        float rowZ = firstRowZ + (row * rowSpacing);

        obstacle.SetActive(true);

        if (isSlideObstacle)
        {
            ConfigureSlideObstacle(
                obstacle,
                laneX,
                rowZ
            );
        }
        else
        {
            ConfigureJumpObstacle(
                obstacle,
                laneX,
                rowZ
            );
        }
    }

    private void ConfigureJumpObstacle(
        GameObject obstacle,
        float laneX,
        float rowZ
    )
    {
        obstacle.name = "JumpObstacle";

        obstacle.transform.localPosition =
            new Vector3(laneX, 0.55f, rowZ);

        obstacle.transform.localRotation =
            Quaternion.identity;

        obstacle.transform.localScale =
            new Vector3(1.5f, 1.1f, 1.4f);
    }

    private void ConfigureSlideObstacle(
        GameObject obstacle,
        float laneX,
        float rowZ
    )
    {
        obstacle.name = "SlideObstacle";

        obstacle.transform.localPosition =
            new Vector3(laneX, 1.75f, rowZ);

        obstacle.transform.localRotation =
            Quaternion.identity;

        obstacle.transform.localScale =
            new Vector3(1.5f, 0.5f, 1.4f);
    }

    private void CreateObstacleSlots()
    {
        if (slotsCreated)
        {
            return;
        }

        if (obstaclePrefab == null)
        {
            Debug.LogError(
                "ObstacleGenerator: Obstacle Prefab is missing.",
                this
            );

            return;
        }

        generatedRoot =
            new GameObject("GeneratedObstacles").transform;

        generatedRoot.SetParent(transform, false);

        obstacleSlots =
            new GameObject[rowCount, 3];

        for (int row = 0; row < rowCount; row++)
        {
            for (int lane = 0; lane < 3; lane++)
            {
                GameObject obstacle = Instantiate(
                    obstaclePrefab,
                    generatedRoot
                );

                obstacle.name =
                    $"ObstacleSlot_{row}_{lane}";

                obstacle.SetActive(false);

                obstacleSlots[row, lane] = obstacle;
            }
        }

        slotsCreated = true;
    }

    private void DisableAllObstacles()
    {
        if (!slotsCreated)
        {
            return;
        }

        for (int row = 0; row < rowCount; row++)
        {
            for (int lane = 0; lane < 3; lane++)
            {
                obstacleSlots[row, lane].SetActive(false);
            }
        }
    }
}
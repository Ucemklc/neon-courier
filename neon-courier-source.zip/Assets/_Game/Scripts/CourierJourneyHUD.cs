using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public sealed class CourierJourneyHUD : MonoBehaviour
{
    private GameManager manager;
    private CourierGhostRace ghost;
    private CourierWeather weather;
    private GameObject root,menu,throwCard;
    private TMP_Text menuLabel,status,throwLabel,hint;
    private Image cursor;
    private Button throwButton;
    private float nextRefresh;
    private readonly List<RaycastResult> pointerHits=new List<RaycastResult>();
    public bool IsControlAt(Vector2 point)
    {
        if(!EventSystem.current)return false;pointerHits.Clear();EventSystem.current.RaycastAll(new PointerEventData(EventSystem.current){position=point},pointerHits);
        return pointerHits.Count>0&&pointerHits[0].gameObject.GetComponentInParent<Button>();
    }
    private void Start()
    {
        manager=GetComponent<GameManager>();ghost=GetComponent<CourierGhostRace>();weather=GetComponent<CourierWeather>();
        root=new GameObject("CourierJourneyCanvas",typeof(RectTransform),typeof(Canvas),typeof(CanvasScaler),typeof(GraphicRaycaster));root.transform.SetParent(transform,false);
        var canvas=root.GetComponent<Canvas>();canvas.renderMode=RenderMode.ScreenSpaceOverlay;canvas.sortingOrder=203;
        var scaler=root.GetComponent<CanvasScaler>();scaler.uiScaleMode=CanvasScaler.ScaleMode.ScaleWithScreenSize;scaler.referenceResolution=new Vector2(1080,1920);scaler.matchWidthOrHeight=.5f;
        menu=MakeButton(root.transform,"GhostRaceToggle",new Vector2(0,-639),new Vector2(820,84),()=>ghost.Toggle(),false).gameObject;
        menuLabel=menu.GetComponentInChildren<TMP_Text>();
        status=CourierPanelSurface.Label(root.transform,"JourneyStatus",new Vector2(0,-531),new Vector2(940,55),24,new Color(.68f,.89f,1));
        throwCard=CourierPanelSurface.Card(root.transform,"DeliveryTimingCard",new Vector2(0,-653),new Vector2(920,156)).gameObject;
        throwButton=MakeButton(throwCard.transform,"ThrowParcelButton",new Vector2(270,-60),new Vector2(335,94),()=>CourierTimedDelivery.Instance?.TryThrow(),true);
        throwButton.GetComponentInChildren<TMP_Text>().text="FIRLAT [F]";
        throwLabel=CourierPanelSurface.Label(throwCard.transform,"DeliveryTimingTitle",new Vector2(-182,-36),new Vector2(478,48),28,Color.white);
        hint=CourierPanelSurface.Label(throwCard.transform,"DeliveryTimingHint",new Vector2(-182,-121),new Vector2(475,35),21,CourierPanelSurface.Muted);
        var bar=CourierPanelSurface.Card(throwCard.transform,"TimingTrack",new Vector2(-182,-80),new Vector2(460,20));bar.sprite=null;bar.color=new Color(.15f,.23f,.32f);
        var green=CourierPanelSurface.Card(bar.transform,"PerfectTimingBand",new Vector2(93,-10),new Vector2(96,20));green.sprite=null;green.color=new Color(.2f,.9f,.63f);
        cursor=CourierPanelSurface.Card(bar.transform,"TimingNeedle",new Vector2(-230,-10),new Vector2(8,30));cursor.sprite=null;cursor.color=Color.white;
        throwCard.SetActive(false);
    }
    private Button MakeButton(Transform parent,string name,Vector2 pos,Vector2 size,UnityEngine.Events.UnityAction action,bool primary)
    {
        var go=new GameObject(name,typeof(RectTransform),typeof(Image),typeof(Button));
        var label=CourierPanelSurface.Label(go.transform,"Label",Vector2.zero,size,28,Color.white,true);
        var button=go.GetComponent<Button>();CourierPanelSurface.Button(button,parent,pos,size,primary,label);button.onClick.AddListener(action);return button;
    }
    private void Update()
    {
        if(!root||!manager)return;bool en=PlayerPrefs.GetInt("NeonCourier.Language",0)==1;
        var garage=manager.GetComponent<CourierGarageUI>();var workshop=manager.GetComponent<CourierExpansionUI>();
        bool overlay=CourierGarageUI.MenuOverlayOpen||(garage&&garage.IsOpen)||(workshop&&workshop.WardrobeOpen)||FindAnyObjectByType<CourierCharacterMenu>();
        menu.SetActive(manager.IsMainMenuActive&&!overlay);
        var delivery=CourierTimedDelivery.Instance;bool run=CourierJourney.Active;
        status.gameObject.SetActive(run);throwCard.SetActive(run&&delivery&&(delivery.CanThrow||delivery.HasNotice));
        if(delivery&&delivery.CanThrow)
        {
            throwButton.gameObject.SetActive(true);cursor.transform.parent.gameObject.SetActive(true);
            throwLabel.rectTransform.anchoredPosition=new Vector2(-182,-36);throwLabel.rectTransform.sizeDelta=new Vector2(478,48);
            hint.rectTransform.anchoredPosition=new Vector2(-182,-121);
            cursor.rectTransform.anchoredPosition=new Vector2(Mathf.Lerp(-230,230,Mathf.InverseLerp(2.1f,.18f,delivery.SecondsToStop)),-10);
            throwLabel.text=delivery.PerfectWindow?(en?"THROW NOW!":"ŞİMDİ FIRLAT!"):(en?"CUSTOMER AHEAD":"MÜŞTERİ YAKLAŞIYOR");
            hint.text=en?"Tap when the marker turns green":"Çizgi yeşil alandayken bas";
            throwButton.interactable=true;throwButton.GetComponentInChildren<TMP_Text>().text=(en?"THROW":"FIRLAT")+(Application.isMobilePlatform?"":" [F]");
        }
        else if(throwCard.activeSelf)
        {
            throwButton.gameObject.SetActive(false);cursor.transform.parent.gameObject.SetActive(false);
            throwLabel.rectTransform.anchoredPosition=new Vector2(0,-52);throwLabel.rectTransform.sizeDelta=new Vector2(870,85);
            hint.rectTransform.anchoredPosition=new Vector2(0,-120);
            throwLabel.text=delivery.Notice(en);hint.text=en?"Keep running!":"Koşmaya devam!";throwButton.interactable=false;
        }
        if(Time.unscaledTime<nextRefresh)return;nextRefresh=Time.unscaledTime+.15f;
        menuLabel.text=(en?"RECORD GHOST: ":"REKOR HAYALETİ: ")+(ghost.RaceEnabled?(en?"ON":"AÇIK"):(en?"OFF":"KAPALI"))+(ghost.HasRecord?"":(en?" · Record your first run":" · İlk koşunu kaydet"));
        if(run)
        {
            string race=ghost.RaceEnabled&&ghost.HasRecord?(Mathf.Abs(ghost.LeadMetres).ToString("0")+" m "+(ghost.LeadMetres>=0?(en?"AHEAD":"ÖNDESİN"):(en?"BEHIND":"GERİDESİN"))):"";
            var scooter=CourierScooterRide.Instance;
            status.text=weather.Label(en)+(string.IsNullOrEmpty(race)?"":"  ·  "+race)+(scooter&&scooter.IsRiding?"  ·  SCOOTER "+scooter.Remaining.ToString("0")+" m":"");
        }
    }
}

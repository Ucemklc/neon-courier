using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering;

/// <summary>
/// Original, reusable neon freight-train geometry. Forward is +Z and the root is
/// at track height. Only the train shell and access ramps have colliders.
/// </summary>
public static class NeonRailFactory
{
    public const float RoofHeight = 2.4f;
    public const float BodyLength = 12f;
    public const float RampLength = 4.5f;

    private static Mesh boxMesh;
    private static Mesh wheelMesh;
    private static Mesh rampMesh;
    private static Mesh cabMesh;
    private static Mesh arrowMesh;
    private static Material hullMaterial;
    private static Material panelMaterial;
    private static Material deckMaterial;
    private static Material rubberMaterial;
    private static Material glassMaterial;
    private static Material cyanMaterial;
    private static Material pinkMaterial;
    private static Material lampMaterial;

    // Resource references survive Play Mode when domain reload is disabled.
    // Keep them if valid; never invalidate the meshes of a live train on entry.
    [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.SubsystemRegistration)]
    private static void RegisterResourceCleanup()
    {
        Application.quitting -= ReleaseSharedResources;
        Application.quitting += ReleaseSharedResources;
    }

#if UNITY_EDITOR
    static NeonRailFactory()
    {
        UnityEditor.AssemblyReloadEvents.beforeAssemblyReload += ReleaseSharedResources;
        UnityEditor.EditorApplication.quitting += ReleaseSharedResources;
    }
#endif

    public static GameObject CreateTrain(Transform parent, float laneWidth = 2.5f, bool withRamps = true)
    {
        if (float.IsNaN(laneWidth) || float.IsInfinity(laneWidth) || laneWidth <= 0.5f)
            throw new ArgumentOutOfRangeException(nameof(laneWidth), "Lane width must exceed 0.5 metres.");

        EnsureResources();
        float width = Mathf.Min(1.9f, laneWidth - 0.5f);
        GameObject train = Root("Neon Courier - Roof Route", parent);
        train.AddComponent<RailRideSurface>();

        // One continuous shell avoids seams between decorative carriage pieces.
        BoxCollider shell = train.AddComponent<BoxCollider>();
        shell.center = new Vector3(0f, RoofHeight * 0.5f, BodyLength * 0.5f);
        shell.size = new Vector3(width, RoofHeight, BodyLength);

        Transform body = Root("Train Visuals", train.transform).transform;
        Box("Underframe", body, new Vector3(0f, 0.49f, 6f), new Vector3(width * 0.81f, 0.28f, 11.7f), rubberMaterial);
        Box("Cargo Hull", body, new Vector3(0f, 1.39f, 5.27f), new Vector3(width * 0.97f, 1.72f, 10.34f), hullMaterial);
        Piece("Sloped Driver Cab", body, cabMesh, new Vector3(0f, 0.55f, 10f), new Vector3(width * 0.97f, 1.7f, 2f), hullMaterial);
        Box("Continuous Walkable Roof", body, new Vector3(0f, 2.32f, 6f), new Vector3(width, 0.16f, BodyLength), deckMaterial);

        // All roof decoration is flush or beneath the 2.4 m walking plane.
        for (int i = 0; i < 6; i++)
            Box("Roof Plate Seam", body, new Vector3(0f, 2.393f, 1f + i * 2f), new Vector3(width * 0.82f, 0.01f, 0.035f), panelMaterial);

        for (int side = -1; side <= 1; side += 2)
        {
            float x = side * width * 0.485f;
            Box("Cargo Side Panel", body, new Vector3(x, 1.37f, 5.12f), new Vector3(0.018f, 1.22f, 9.55f), panelMaterial);
            Box("Cyan Upper Running Light", body, new Vector3(side * width * 0.493f, 2.10f, 5.13f), new Vector3(0.018f, 0.065f, 9.78f), cyanMaterial);
            Box("Magenta Lower Running Light", body, new Vector3(side * width * 0.493f, 0.73f, 5.24f), new Vector3(0.018f, 0.052f, 10f), pinkMaterial);
            Box("Roof Edge Guide", body, new Vector3(side * width * 0.482f, 2.36f, 6f), new Vector3(0.025f, 0.03f, 11.92f), cyanMaterial);
            for (int rib = 0; rib < 6; rib++)
                Box("Cargo Reinforcement", body, new Vector3(side * width * 0.493f, 1.39f, 0.54f + rib * 1.79f), new Vector3(0.02f, 1.32f, 0.07f), hullMaterial);

            Box("Cab Side Window", body, new Vector3(side * width * 0.489f, 1.80f, 10.68f), new Vector3(0.018f, 0.51f, 1.17f), glassMaterial);
            Box("Cab Window Light", body, new Vector3(side * width * 0.494f, 1.49f, 10.65f), new Vector3(0.014f, 0.035f, 1.28f), cyanMaterial);
            Box("Cargo Status Light", body, new Vector3(side * width * 0.497f, 1.50f, 4.31f), new Vector3(0.008f, 0.22f, 0.11f), pinkMaterial);
            Box("Cargo Status Light", body, new Vector3(side * width * 0.497f, 1.50f, 4.50f), new Vector3(0.008f, 0.22f, 0.11f), cyanMaterial);

            for (int bogie = 0; bogie < 2; bogie++)
            {
                float z = bogie == 0 ? 1.72f : 9.12f;
                Box("Bogie", body, new Vector3(side * width * 0.35f, 0.40f, z), new Vector3(width * 0.20f, 0.26f, 1.40f), rubberMaterial);
                for (int axle = -1; axle <= 1; axle += 2)
                {
                    // Cylinder local Y is its axle; rotate to face the lane edge.
                    GameObject wheel = Piece("Wheel", body, wheelMesh,
                        new Vector3(side * width * 0.448f, 0.31f, z + axle * 0.43f),
                        new Vector3(0.58f, width * 0.07f, 0.58f), rubberMaterial);
                    wheel.transform.localRotation = Quaternion.Euler(0f, 0f, 90f);
                    GameObject hub = Piece("Wheel Hub", body, wheelMesh,
                        new Vector3(side * width * 0.487f, 0.31f, z + axle * 0.43f),
                        new Vector3(0.23f, width * 0.014f, 0.23f), panelMaterial);
                    hub.transform.localRotation = Quaternion.Euler(0f, 0f, 90f);
                }
            }
        }

        GameObject windshield = Box("Front Windshield", body, new Vector3(0f, 1.73f, 11.68f), new Vector3(width * 0.76f, 0.62f, 0.027f), glassMaterial);
        windshield.transform.localRotation = Quaternion.Euler(-16.39f, 0f, 0f);
        Box("Front Bumper", body, new Vector3(0f, 0.64f, 11.94f), new Vector3(width * 0.90f, 0.21f, 0.12f), panelMaterial);
        Box("Rear Bumper", body, new Vector3(0f, 0.64f, 0.07f), new Vector3(width * 0.90f, 0.21f, 0.12f), panelMaterial);
        for (int side = -1; side <= 1; side += 2)
        {
            Box("Headlight", body, new Vector3(side * width * 0.31f, 0.97f, 11.89f), new Vector3(width * 0.17f, 0.12f, 0.028f), lampMaterial);
            Box("Rear Signal", body, new Vector3(side * width * 0.32f, 1.37f, 0.02f), new Vector3(width * 0.12f, 0.15f, 0.028f), pinkMaterial);
        }

        if (withRamps)
        {
            CreateRamp(train.transform, width, true);
            CreateRamp(train.transform, width, false);
        }
        return train;
    }

    /// <summary>A small collider-free roadside sign; arrow faces approaching runners (-Z).</summary>
    public static GameObject CreateRouteSign(Transform parent)
    {
        EnsureResources();
        GameObject sign = Root("Neon Roof Route Sign", parent);
        for (int side = -1; side <= 1; side += 2)
            Box("Sign Post", sign.transform, new Vector3(side * 0.52f, 0.60f, 0.02f), new Vector3(0.06f, 1.20f, 0.06f), panelMaterial);
        Box("Sign Frame", sign.transform, new Vector3(0f, 1.40f, 0f), new Vector3(1.34f, 0.81f, 0.08f), cyanMaterial);
        Box("Sign Face", sign.transform, new Vector3(0f, 1.40f, -0.046f), new Vector3(1.25f, 0.72f, 0.022f), hullMaterial);
        GameObject arrow = Piece("Go Up Arrow", sign.transform, arrowMesh, new Vector3(0f, 1.40f, -0.062f), new Vector3(1.30f, 1f, 0.78f), cyanMaterial);
        arrow.transform.localRotation = Quaternion.Euler(-90f, 0f, 0f);
        return sign;
    }

    private static void CreateRamp(Transform parent, float width, bool entrance)
    {
        // Shared triangular prism is closed, with its upper plane rising toward +Z.
        GameObject ramp = Piece(entrance ? "Entry Ramp - 28 Degrees" : "Exit Ramp - 28 Degrees",
            parent, rampMesh, new Vector3(0f, 0f, entrance ? -RampLength : BodyLength + RampLength),
            new Vector3(width, RoofHeight, RampLength), deckMaterial);
        if (!entrance) ramp.transform.localRotation = Quaternion.Euler(0f, 180f, 0f);
        MeshCollider collider = ramp.AddComponent<MeshCollider>();
        collider.sharedMesh = rampMesh;
        collider.convex = false;

        // Decoration uses unscaled train coordinates, so geometry and colliders stay separate.
        float slope = Mathf.Atan2(RoofHeight, RampLength) * Mathf.Rad2Deg;
        float centerZ = entrance ? -RampLength * 0.5f : BodyLength + RampLength * 0.5f;
        float slopeLength = Mathf.Sqrt(RampLength * RampLength + RoofHeight * RoofHeight);
        for (int side = -1; side <= 1; side += 2)
        {
            GameObject guide = Box("Ramp Edge Light", parent,
                new Vector3(side * width * 0.44f, RoofHeight * 0.5f + 0.017f, centerZ),
                new Vector3(width * 0.027f, 0.015f, slopeLength), entrance ? cyanMaterial : pinkMaterial);
            guide.transform.localRotation = Quaternion.Euler(entrance ? -slope : slope, 0f, 0f);
        }
        for (int i = 0; i < 3; i++)
        {
            float t = 0.22f + i * 0.28f;
            float z = entrance ? -RampLength + RampLength * t : BodyLength + RampLength * t;
            float y = RoofHeight * (entrance ? t : 1f - t) + 0.025f;
            GameObject arrow = Piece("Ramp Direction Arrow", parent, arrowMesh, new Vector3(0f, y, z),
                new Vector3(width * 0.76f, 1f, 0.83f), entrance ? cyanMaterial : pinkMaterial);
            arrow.transform.localRotation = Quaternion.Euler(entrance ? -slope : slope, 0f, 0f);
        }
    }

    private static GameObject Root(string name, Transform parent)
    {
        GameObject obj = new GameObject(name);
        obj.transform.SetParent(parent, false);
        return obj;
    }

    private static GameObject Box(string name, Transform parent, Vector3 position, Vector3 scale, Material material)
    {
        return Piece(name, parent, boxMesh, position, scale, material);
    }

    private static GameObject Piece(string name, Transform parent, Mesh mesh, Vector3 position, Vector3 scale, Material material)
    {
        GameObject obj = Root(name, parent);
        obj.transform.localPosition = position;
        obj.transform.localScale = scale;
        obj.AddComponent<MeshFilter>().sharedMesh = mesh;
        MeshRenderer renderer = obj.AddComponent<MeshRenderer>();
        renderer.sharedMaterial = material;
        renderer.shadowCastingMode = material == cyanMaterial || material == pinkMaterial || material == lampMaterial
            ? ShadowCastingMode.Off : ShadowCastingMode.On;
        renderer.receiveShadows = true;
        return obj;
    }

    private static void EnsureResources()
    {
        RegisterResourceCleanup();
        if (!boxMesh) boxMesh = BuildBox();
        if (!wheelMesh) wheelMesh = BuildWheel();
        if (!rampMesh) rampMesh = BuildRamp();
        if (!cabMesh) cabMesh = BuildCab();
        if (!arrowMesh) arrowMesh = BuildArrow();
        if (!hullMaterial) hullMaterial = Material("Rail - Midnight Alloy", new Color(0.035f, 0.060f, 0.095f), 0.72f, 0.38f);
        if (!panelMaterial) panelMaterial = Material("Rail - Blue Steel", new Color(0.10f, 0.18f, 0.25f), 0.65f, 0.32f);
        if (!deckMaterial) deckMaterial = Material("Rail - Grippy Roof", new Color(0.12f, 0.21f, 0.26f), 0.38f, 0.25f);
        if (!rubberMaterial) rubberMaterial = Material("Rail - Rubber and Undercarriage", new Color(0.026f, 0.033f, 0.045f), 0.16f, 0.20f);
        if (!glassMaterial) glassMaterial = Material("Rail - Cyan Cab Glass", new Color(0.025f, 0.35f, 0.44f), 0.6f, 0.9f, new Color(0.025f, 0.36f, 0.46f), 0.6f);
        if (!cyanMaterial) cyanMaterial = Material("Rail - Cyan Guidance", new Color(0.04f, 0.88f, 1f), 0.15f, 0.6f, new Color(0.01f, 0.8f, 1f), 2.2f);
        if (!pinkMaterial) pinkMaterial = Material("Rail - Magenta Guidance", new Color(1f, 0.06f, 0.47f), 0.15f, 0.6f, new Color(1f, 0.025f, 0.34f), 1.8f);
        if (!lampMaterial) lampMaterial = Material("Rail - Headlamps", new Color(0.78f, 0.95f, 1f), 0.1f, 0.7f, new Color(0.65f, 0.9f, 1f), 3f);
    }

    private static Material Material(string name, Color color, float metallic, float smoothness, Color emission = default, float intensity = 0f)
    {
        Shader shader = Shader.Find("Universal Render Pipeline/Lit");
        if (!shader) shader = Shader.Find("Standard");
        if (!shader) shader = Shader.Find("Universal Render Pipeline/Unlit");
        if (!shader) shader = Shader.Find("Unlit/Color");
        if (!shader) throw new InvalidOperationException("No supported train shader is available.");
        Material material = new Material(shader) { name = name, hideFlags = HideFlags.DontSave };
        if (material.HasProperty("_BaseColor")) material.SetColor("_BaseColor", color);
        if (material.HasProperty("_Color")) material.SetColor("_Color", color);
        if (material.HasProperty("_Metallic")) material.SetFloat("_Metallic", metallic);
        if (material.HasProperty("_Smoothness")) material.SetFloat("_Smoothness", smoothness);
        if (material.HasProperty("_Glossiness")) material.SetFloat("_Glossiness", smoothness);
        if (intensity > 0f && material.HasProperty("_EmissionColor"))
        {
            material.EnableKeyword("_EMISSION");
            material.SetColor("_EmissionColor", emission * intensity);
            material.globalIlluminationFlags = MaterialGlobalIlluminationFlags.None;
        }
        return material;
    }

    private static Mesh BuildBox()
    {
        var b = new MeshBuilder();
        Vector3 a = new Vector3(-0.5f, -0.5f, -0.5f), c = new Vector3(0.5f, -0.5f, -0.5f);
        Vector3 d = new Vector3(0.5f, 0.5f, -0.5f), e = new Vector3(-0.5f, 0.5f, -0.5f);
        Vector3 f = new Vector3(-0.5f, -0.5f, 0.5f), g = new Vector3(0.5f, -0.5f, 0.5f);
        Vector3 h = new Vector3(0.5f, 0.5f, 0.5f), i = new Vector3(-0.5f, 0.5f, 0.5f);
        b.Quad(a, e, d, c); b.Quad(f, g, h, i); b.Quad(a, f, i, e);
        b.Quad(c, d, h, g); b.Quad(e, i, h, d); b.Quad(a, c, g, f);
        return b.Build("Rail Shared Box");
    }

    private static Mesh BuildRamp()
    {
        var b = new MeshBuilder();
        Vector3 a = new Vector3(-0.5f, 0f, 0f), c = new Vector3(0.5f, 0f, 0f);
        Vector3 d = new Vector3(-0.5f, 0f, 1f), e = new Vector3(0.5f, 0f, 1f);
        Vector3 f = new Vector3(-0.5f, 1f, 1f), g = new Vector3(0.5f, 1f, 1f);
        b.Quad(a, f, g, c); // Walkable upper slope: normal points up and back.
        b.Quad(a, c, e, d); // Base.
        b.Quad(d, e, g, f); // Tall end.
        b.Triangle(a, d, f); b.Triangle(c, g, e); // Closed sides.
        return b.Build("Rail Shared Closed Ramp");
    }

    private static Mesh BuildCab()
    {
        var b = new MeshBuilder();
        Vector3 a = new Vector3(-0.5f, 0f, 0f), c = new Vector3(0.5f, 0f, 0f);
        Vector3 d = new Vector3(0.5f, 1f, 0f), e = new Vector3(-0.5f, 1f, 0f);
        Vector3 f = new Vector3(-0.5f, 0f, 1f), g = new Vector3(0.5f, 0f, 1f);
        Vector3 h = new Vector3(0.5f, 1f, 0.75f), i = new Vector3(-0.5f, 1f, 0.75f);
        b.Quad(a, e, d, c); b.Quad(f, g, h, i); b.Quad(a, f, i, e);
        b.Quad(c, d, h, g); b.Quad(e, i, h, d); b.Quad(a, c, g, f);
        return b.Build("Rail Shared Sloped Cab");
    }

    private static Mesh BuildArrow()
    {
        var b = new MeshBuilder();
        b.Quad(new Vector3(-0.095f, 0f, -0.38f), new Vector3(-0.095f, 0f, 0f),
            new Vector3(0.095f, 0f, 0f), new Vector3(0.095f, 0f, -0.38f));
        b.Triangle(new Vector3(-0.30f, 0f, 0f), new Vector3(0f, 0f, 0.4f), new Vector3(0.30f, 0f, 0f));
        return b.Build("Rail Shared Direction Arrow");
    }

    private static Mesh BuildWheel()
    {
        var b = new MeshBuilder();
        const int segments = 12;
        for (int i = 0; i < segments; i++)
        {
            float a = i * Mathf.PI * 2f / segments, c = (i + 1) * Mathf.PI * 2f / segments;
            Vector3 lowA = new Vector3(Mathf.Cos(a) * 0.5f, -0.5f, Mathf.Sin(a) * 0.5f);
            Vector3 lowB = new Vector3(Mathf.Cos(c) * 0.5f, -0.5f, Mathf.Sin(c) * 0.5f);
            Vector3 highA = lowA + Vector3.up, highB = lowB + Vector3.up;
            b.Quad(lowA, highA, highB, lowB);
            b.Triangle(Vector3.up * 0.5f, highB, highA);
            b.Triangle(Vector3.down * 0.5f, lowA, lowB);
        }
        return b.Build("Rail Shared 12 Sided Wheel");
    }

    /// <summary>
    /// Frees transient meshes/materials at shutdown. For manual/editor calls,
    /// destroy generated instances or persist their referenced assets first.
    /// Assets already saved by an editor prefab builder are never destroyed.
    /// </summary>
    public static void ReleaseSharedResources()
    {
        Release(boxMesh); Release(wheelMesh); Release(rampMesh); Release(cabMesh); Release(arrowMesh);
        Release(hullMaterial); Release(panelMaterial); Release(deckMaterial); Release(rubberMaterial);
        Release(glassMaterial); Release(cyanMaterial); Release(pinkMaterial); Release(lampMaterial);
        boxMesh = wheelMesh = rampMesh = cabMesh = arrowMesh = null;
        hullMaterial = panelMaterial = deckMaterial = rubberMaterial = glassMaterial = cyanMaterial = pinkMaterial = lampMaterial = null;
    }

    private static void Release(UnityEngine.Object resource)
    {
        if (!resource) return;
#if UNITY_EDITOR
        if (UnityEditor.EditorUtility.IsPersistent(resource)) return;
#endif
        if (Application.isPlaying) UnityEngine.Object.Destroy(resource);
        else UnityEngine.Object.DestroyImmediate(resource);
    }

    private sealed class MeshBuilder
    {
        private readonly List<Vector3> vertices = new List<Vector3>();
        private readonly List<int> triangles = new List<int>();
        private readonly List<Vector2> uvs = new List<Vector2>();

        public void Triangle(Vector3 a, Vector3 b, Vector3 c)
        {
            int first = vertices.Count;
            vertices.Add(a); vertices.Add(b); vertices.Add(c);
            triangles.Add(first); triangles.Add(first + 1); triangles.Add(first + 2);
            uvs.Add(Vector2.zero); uvs.Add(Vector2.up); uvs.Add(Vector2.one);
        }

        public void Quad(Vector3 a, Vector3 b, Vector3 c, Vector3 d)
        {
            int first = vertices.Count;
            vertices.Add(a); vertices.Add(b); vertices.Add(c); vertices.Add(d);
            triangles.Add(first); triangles.Add(first + 1); triangles.Add(first + 2);
            triangles.Add(first); triangles.Add(first + 2); triangles.Add(first + 3);
            uvs.Add(Vector2.zero); uvs.Add(Vector2.up); uvs.Add(Vector2.one); uvs.Add(Vector2.right);
        }

        public Mesh Build(string name)
        {
            Mesh mesh = new Mesh { name = name, hideFlags = HideFlags.DontSave };
            mesh.SetVertices(vertices);
            mesh.SetTriangles(triangles, 0);
            mesh.SetUVs(0, uvs);
            mesh.RecalculateNormals();
            mesh.RecalculateBounds();
            return mesh;
        }
    }
}

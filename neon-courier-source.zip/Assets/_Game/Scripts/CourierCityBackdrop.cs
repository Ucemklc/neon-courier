using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.SceneManagement;

/// <summary>Fixed-size, recycled city layers fill the space behind the playable street.</summary>
public sealed class CourierCityBackdrop : MonoBehaviour
{
    public const int ChunkCount = 8;
    public const float ChunkLength = 90f;
    private readonly List<Mesh> meshes = new List<Mesh>();
    private readonly Transform[] chunks = new Transform[ChunkCount];
    private Material[] materials;
    private Transform runner, horizon;
    private Camera sceneCamera;
    private bool oldFog;
    private FogMode oldFogMode;
    private Color oldFogColor, oldBackground;
    private float oldStart, oldEnd, oldFar;
    private CameraClearFlags oldClear;
    public int RecycledChunkCount => chunks.Length;

    [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
    private static void Install()
    {
        SceneManager.sceneLoaded -= OnScene;
        SceneManager.sceneLoaded += OnScene;
        OnScene(SceneManager.GetActiveScene(), LoadSceneMode.Single);
    }
    private static void OnScene(Scene scene, LoadSceneMode mode)
    {
        var manager = FindAnyObjectByType<GameManager>();
        if (manager && !manager.GetComponent<CourierCityBackdrop>())
            manager.gameObject.AddComponent<CourierCityBackdrop>();
    }
    private void Start()
    {
        var player = FindAnyObjectByType<RunnerController>();
        if (!player) { enabled = false; return; }
        runner = player.transform;
        sceneCamera = Camera.main;
        oldFog = RenderSettings.fog; oldFogMode = RenderSettings.fogMode;
        oldFogColor = RenderSettings.fogColor; oldStart = RenderSettings.fogStartDistance; oldEnd = RenderSettings.fogEndDistance;
        RenderSettings.fog = true; RenderSettings.fogMode = FogMode.Linear;
        RenderSettings.fogColor = new Color(.18f, .28f, .38f);
        RenderSettings.fogStartDistance = 105f; RenderSettings.fogEndDistance = 510f;
        if (sceneCamera)
        {
            oldBackground = sceneCamera.backgroundColor; oldClear = sceneCamera.clearFlags; oldFar = sceneCamera.farClipPlane;
            sceneCamera.backgroundColor = RenderSettings.fogColor;
            sceneCamera.clearFlags = CameraClearFlags.SolidColor; sceneCamera.farClipPlane = Mathf.Max(650, oldFar);
        }
        materials = new[] {
            Material("Distant blue towers", new Color(.13f,.21f,.30f)),
            Material("Middle city", new Color(.18f,.29f,.38f)),
            Material("City window lights", new Color(.32f,.62f,.78f)),
            Material("City foundation", new Color(.09f,.12f,.16f))
        };
        for (int i = 0; i < ChunkCount; i++) chunks[i] = BuildChunk(i);
        horizon = BuildHorizon();
        LateUpdate();
    }
    private Material Material(string label, Color color)
    {
        var template=Resources.Load<Material>("CourierPolish/CityBackdrop");
        var m = template ? new Material(template) : new Material(Shader.Find("Universal Render Pipeline/Unlit"));
        m.name = label; m.SetColor("_BaseColor", color); return m;
    }
    private Transform BuildChunk(int seed)
    {
        var builder = new Blocks(); var rng = new System.Random(7919 + seed * 97);
        builder.Box(new Vector3(0,-.9f,45), new Vector3(500, .5f, 90), 3);
        for (int side = -1; side <= 1; side += 2)
        for (int row = 0; row < 2; row++)
        for (int b = 0; b < 6; b++)
        {
            float h = (row == 0 ? 17 : 33) + (float)rng.NextDouble() * 31;
            float w = 9 + (float)rng.NextDouble() * 7;
            float x = side * (row == 0 ? 24 : 56);
            float z = b * 15 + 7;
            builder.Box(new Vector3(x,h/2-.4f,z), new Vector3(w,h,12), row == 0 ? 1 : 0);
            builder.Box(new Vector3(x,h+1,z), new Vector3(w*.58f,2.5f,8), 0);
            if (b % 3 == 0) builder.Box(new Vector3(x,h+4,z),new Vector3(.4f,5,.4f),2);
            // Windows face both the road and the approach; every slab shares one mesh.
            for (int floor = 0; floor < 5; floor++)
            {
                float y = 3 + floor * (h-5)/5;
                builder.Box(new Vector3(x-side*(w/2+.025f),y,z),new Vector3(.06f,.35f,9),2);
                builder.Box(new Vector3(x,y,z-6.025f),new Vector3(w*.65f,.35f,.06f),2);
            }
        }
        return Finish("City backdrop chunk " + seed,builder);
    }
    private Transform BuildHorizon()
    {
        var builder = new Blocks(); var rng = new System.Random(281);
        for (int i = -15; i <= 15; i++)
        {
            float h = 24 + (float)rng.NextDouble()*68;
            builder.Box(new Vector3(i*19,h/2,0),new Vector3(17,h,30),0);
            builder.Box(new Vector3(i*19,h+2,0),new Vector3(9,4,18),1);
        }
        return Finish("Far city horizon",builder);
    }
    private Transform Finish(string label, Blocks builder)
    {
        var go = new GameObject(label,typeof(MeshFilter),typeof(MeshRenderer));
        go.transform.SetParent(transform,false);var mesh=builder.Create(); meshes.Add(mesh);
        go.GetComponent<MeshFilter>().sharedMesh=mesh;
        var renderer=go.GetComponent<MeshRenderer>();renderer.sharedMaterials=materials;
        renderer.shadowCastingMode=ShadowCastingMode.Off;renderer.receiveShadows=false;
        return go.transform;
    }
    private void LateUpdate()
    {
        if (!runner || !horizon) return;
        int segment=Mathf.FloorToInt(runner.position.z/ChunkLength);
        for(int i=0;i<ChunkCount;i++)
        {
            int slot=((segment-1)%ChunkCount+ChunkCount)%ChunkCount;
            int ahead=(i-slot+ChunkCount)%ChunkCount;
            chunks[i].position=new Vector3(0,0,(segment-1+ahead)*ChunkLength);
        }
        horizon.position=new Vector3(0,0,runner.position.z+430);
    }
    private void OnDestroy()
    {
        foreach(var mesh in meshes)if(mesh)Destroy(mesh);
        if(materials==null)return;
        foreach(var m in materials)if(m)Destroy(m);
        RenderSettings.fog=oldFog;RenderSettings.fogMode=oldFogMode;RenderSettings.fogColor=oldFogColor;
        RenderSettings.fogStartDistance=oldStart;RenderSettings.fogEndDistance=oldEnd;
        if(sceneCamera){sceneCamera.backgroundColor=oldBackground;sceneCamera.clearFlags=oldClear;sceneCamera.farClipPlane=oldFar;}
    }
    private sealed class Blocks
    {
        private readonly List<Vector3> vertices=new List<Vector3>();
        private readonly List<int>[] triangles={new List<int>(),new List<int>(),new List<int>(),new List<int>()};
        private static readonly Vector3[] Corners={new Vector3(-1,-1,-1),new Vector3(1,-1,-1),new Vector3(1,1,-1),new Vector3(-1,1,-1),new Vector3(-1,-1,1),new Vector3(1,-1,1),new Vector3(1,1,1),new Vector3(-1,1,1)};
        private static readonly int[] Faces={0,2,1,0,3,2,5,6,4,6,7,4,4,3,0,4,7,3,1,2,5,2,6,5,3,7,2,7,6,2,4,0,5,0,1,5};
        public void Box(Vector3 center,Vector3 size,int material)
        {
            int offset=vertices.Count;
            foreach(var corner in Corners)vertices.Add(center+Vector3.Scale(corner,size*.5f));
            foreach(int index in Faces)triangles[material].Add(offset+index);
        }
        public Mesh Create()
        {
            var mesh=new Mesh{name="Combined city layer"};mesh.SetVertices(vertices);mesh.subMeshCount=4;
            for(int i=0;i<4;i++)mesh.SetTriangles(triangles[i],i);
            mesh.RecalculateNormals();mesh.RecalculateBounds();return mesh;
        }
    }
}

using TMPro;
using UnityEngine;
using UnityEngine.UI;

public sealed class CourierReviveMenu : MonoBehaviour
{
    private TMP_Text title,subtitle,costCaption,hint,reviveLabel,giveUpLabel;
    public void Build(Button revive,Button giveUp,TMP_Text cost,TMP_Text wallet,TMP_Text information)
    {
        var content=CourierPanelSurface.Prepare(gameObject).Content;
        CourierPanelSurface.Card(content,"ReviveCard",new Vector2(0,-960),new Vector2(940,1230));
        title=CourierPanelSurface.Label(content,"ContinueTitle",new Vector2(0,-485),new Vector2(840,115),68,CourierPanelSurface.Cyan);
        subtitle=CourierPanelSurface.Label(content,"ContinueSubtitle",new Vector2(0,-605),new Vector2(800,85),30,CourierPanelSurface.Muted);
        costCaption=CourierPanelSurface.Label(content,"ContinueCostCaption",new Vector2(0,-735),new Vector2(800,60),26,CourierPanelSurface.Muted);
        CourierPanelSurface.Put(cost,content,new Vector2(0,-825),new Vector2(800,100),62);cost.color=new Color(1,.77f,.31f);
        CourierPanelSurface.Put(wallet,content,new Vector2(0,-925),new Vector2(800,65),31);
        CourierPanelSurface.Put(information,content,new Vector2(0,-1035),new Vector2(800,95),29);information.color=CourierPanelSurface.Muted;
        CourierPanelSurface.Button(revive,content,new Vector2(0,-1195),new Vector2(800,140),true);
        CourierPanelSurface.Button(giveUp,content,new Vector2(0,-1370),new Vector2(800,130),false);
        reviveLabel=revive.GetComponentInChildren<TMP_Text>();giveUpLabel=giveUp.GetComponentInChildren<TMP_Text>();
        hint=CourierPanelSurface.Label(content,"ContinueLimit",new Vector2(0,-1510),new Vector2(820,70),25,CourierPanelSurface.Muted);
    }
    public void Refresh(int cost,bool en)
    {
        title.text=en?"CONTINUE?":"DEVAM ET?";
        subtitle.text=en?"Your delivery route is waiting.":"Teslimat rotan seni bekliyor.";
        costCaption.text=en?"CONTINUE COST":"DEVAM BEDELİ";
        hint.text=en?"Available once per run.":"Her koşuda bir kez kullanılabilir.";
        reviveLabel.text=(en?"CONTINUE • ":"DEVAM ET • ")+cost+" COIN";
        giveUpLabel.text=en?"FINISH RUN":"KOŞUYU BİTİR";
    }
}

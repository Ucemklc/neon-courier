using System.Collections;
using UnityEngine;

[DisallowMultipleComponent]
public sealed class DroneGameOverSequence : MonoBehaviour
{
    [Header("References")]
    [SerializeField]
    private GameManager gameManager;

    [SerializeField]
    private SecurityDroneChase securityDroneChase;

    [Tooltip("Genellikle SecurityDroneRoot.")]
    [SerializeField]
    private Transform droneTransform;

    [Tooltip("Player root Transform.")]
    [SerializeField]
    private Transform player;

    [Tooltip("GameHUD/GameOverPanel.")]
    [SerializeField]
    private GameObject gameOverPanel;

    [Tooltip("Drone altındaki Spot Light.")]
    [SerializeField]
    private Light scanLight;

    [Header("Capture Position")]
    [SerializeField]
    private Vector3 captureOffset =
        new Vector3(
            0f,
            1.45f,
            -1.15f
        );

    [SerializeField]
    private float lookHeight = 1.15f;

    [Header("Timing")]
    [SerializeField, Min(0.1f)]
    private float approachDuration = 0.9f;

    [SerializeField, Min(0f)]
    private float captureHoldDuration = 0.55f;

    [Header("Scan Light")]
    [SerializeField]
    private bool useRedScanLight = true;

    [SerializeField, Min(0f)]
    private float scanIntensity = 30f;

    [SerializeField, Min(1f)]
    private float scanRange = 18f;

    [SerializeField, Range(1f, 179f)]
    private float scanSpotAngle = 55f;

    [SerializeField, Range(0f, 179f)]
    private float scanInnerSpotAngle = 30f;

    [SerializeField, Min(0.1f)]
    private float scanPulseSpeed = 9f;

    [SerializeField, Range(0f, 1f)]
    private float scanPulseAmount = 0.20f;

    [Header("Scan Target")]
    [Tooltip(
        "Işığın karakterin hangi yüksekliğine bakacağını belirler."
    )]
    [SerializeField]
    private float scanTargetHeight = 0.95f;

    private Coroutine sequenceCoroutine;

    private bool subscribed;

    private bool previousChaseEnabled;

    private bool originalLightEnabled;
    private Color originalLightColor;
    private float originalLightIntensity;
    private float originalLightRange;
    private float originalSpotAngle;
    private float originalInnerSpotAngle;
    private Quaternion originalLightLocalRotation;

    private bool lightStateStored;

    private void Awake()
    {
        ResolveReferences();
    }

    private void Start()
    {
        ResolveReferences();
        Subscribe();
    }

    private void OnEnable()
    {
        ResolveReferences();
        Subscribe();
    }

    private void OnDisable()
    {
        Unsubscribe();

        if (sequenceCoroutine != null)
        {
            StopCoroutine(sequenceCoroutine);
            sequenceCoroutine = null;
        }

        RestoreScanLight();
    }

    private void OnDestroy()
    {
        Unsubscribe();
    }

    private void ResolveReferences()
    {
        if (gameManager == null)
        {
            gameManager = GameManager.Instance;
        }

        if (gameManager == null)
        {
            gameManager =
                FindAnyObjectByType<GameManager>();
        }

        if (securityDroneChase == null)
        {
            securityDroneChase =
                GetComponent<SecurityDroneChase>();
        }

        if (securityDroneChase == null)
        {
            securityDroneChase =
                FindAnyObjectByType<SecurityDroneChase>();
        }

        if (droneTransform == null)
        {
            if (securityDroneChase != null)
            {
                droneTransform =
                    securityDroneChase.transform;
            }
            else
            {
                droneTransform = transform;
            }
        }

        if (player == null)
        {
            RunnerController runner =
                FindAnyObjectByType<RunnerController>();

            if (runner != null)
            {
                player = runner.transform;
            }
        }

        if (scanLight == null)
        {
            scanLight =
                GetComponentInChildren<Light>(true);
        }
    }

    private void Subscribe()
    {
        if (
            subscribed ||
            gameManager == null
        )
        {
            return;
        }

        gameManager.GameOverTriggered +=
            HandleGameOver;

        gameManager.ReviveTriggered +=
            HandleRevive;

        subscribed = true;
    }

    private void Unsubscribe()
    {
        if (
            !subscribed ||
            gameManager == null
        )
        {
            subscribed = false;
            return;
        }

        gameManager.GameOverTriggered -=
            HandleGameOver;

        gameManager.ReviveTriggered -=
            HandleRevive;

        subscribed = false;
    }

    private void HandleGameOver()
    {
        if (sequenceCoroutine != null)
        {
            return;
        }

        ResolveReferences();

        sequenceCoroutine =
            StartCoroutine(
                CaptureSequence()
            );
    }

    private IEnumerator CaptureSequence()
    {
        if (gameOverPanel != null)
        {
            gameOverPanel.SetActive(false);
        }

        if (securityDroneChase != null)
        {
            previousChaseEnabled =
                securityDroneChase.enabled;

            securityDroneChase.enabled = false;
        }

        PrepareScanLight();

        yield return null;

        if (gameOverPanel != null)
        {
            gameOverPanel.SetActive(false);
        }

        if (
            droneTransform == null ||
            player == null
        )
        {
            FinishSequence();
            yield break;
        }

        Vector3 startPosition =
            droneTransform.position;

        Quaternion startRotation =
            droneTransform.rotation;

        float elapsed = 0f;

        while (
            elapsed <
            approachDuration
        )
        {
            float normalizedTime =
                Mathf.Clamp01(
                    elapsed /
                    Mathf.Max(
                        0.01f,
                        approachDuration
                    )
                );

            float smoothTime =
                normalizedTime *
                normalizedTime *
                (
                    3f -
                    2f *
                    normalizedTime
                );

            Vector3 targetPosition =
                player.TransformPoint(
                    captureOffset
                );

            droneTransform.position =
                Vector3.Lerp(
                    startPosition,
                    targetPosition,
                    smoothTime
                );

            Vector3 lookTarget =
                player.position +
                Vector3.up *
                lookHeight;

            Vector3 lookDirection =
                lookTarget -
                droneTransform.position;

            if (
                lookDirection.sqrMagnitude >
                0.001f
            )
            {
                Quaternion targetRotation =
                    Quaternion.LookRotation(
                        lookDirection.normalized,
                        Vector3.up
                    );

                droneTransform.rotation =
                    Quaternion.Slerp(
                        startRotation,
                        targetRotation,
                        smoothTime
                    );
            }

            /*
             * KRİTİK:
             * Drone'un rotasyonundan bağımsız olarak
             * Spot Light doğrudan oyuncuya bakar.
             */
            PointScanLightAtPlayer();

            UpdateScanLight(
                smoothTime
            );

            elapsed +=
                Time.unscaledDeltaTime;

            yield return null;
        }

        droneTransform.position =
            player.TransformPoint(
                captureOffset
            );

        LookAtPlayerImmediately();
        PointScanLightAtPlayer();

        elapsed = 0f;

        while (
            elapsed <
            captureHoldDuration
        )
        {
            droneTransform.position =
                player.TransformPoint(
                    captureOffset
                );

            LookAtPlayerImmediately();

            PointScanLightAtPlayer();

            PulseScanLight();

            elapsed +=
                Time.unscaledDeltaTime;

            yield return null;
        }

        FinishSequence();
    }

    private void PrepareScanLight()
    {
        if (
            scanLight == null ||
            !useRedScanLight
        )
        {
            return;
        }

        if (!lightStateStored)
        {
            originalLightEnabled =
                scanLight.enabled;

            originalLightColor =
                scanLight.color;

            originalLightIntensity =
                scanLight.intensity;

            originalLightRange =
                scanLight.range;

            originalSpotAngle =
                scanLight.spotAngle;

            originalInnerSpotAngle =
                scanLight.innerSpotAngle;

            originalLightLocalRotation =
                scanLight.transform.localRotation;

            lightStateStored = true;
        }

        scanLight.enabled = true;

        scanLight.type =
            LightType.Spot;

        scanLight.color =
            Color.red;

        scanLight.intensity =
            scanIntensity;

        scanLight.range =
            scanRange;

        scanLight.spotAngle =
            scanSpotAngle;

        scanLight.innerSpotAngle =
            Mathf.Min(
                scanInnerSpotAngle,
                scanSpotAngle
            );

        PointScanLightAtPlayer();
    }

    private void PointScanLightAtPlayer()
    {
        if (
            scanLight == null ||
            player == null
        )
        {
            return;
        }

        Vector3 targetPosition =
            player.position +
            Vector3.up *
                scanTargetHeight;

        Vector3 direction =
            targetPosition -
            scanLight.transform.position;

        if (
            direction.sqrMagnitude <=
            0.001f
        )
        {
            return;
        }

        /*
         * Unity Spot Light +Z ekseni boyunca
         * ışık gönderir.
         */
        scanLight.transform.rotation =
            Quaternion.LookRotation(
                direction.normalized,
                Vector3.up
            );
    }

    private void UpdateScanLight(
        float progress
    )
    {
        if (
            scanLight == null ||
            !useRedScanLight
        )
        {
            return;
        }

        /*
         * Başlangıçta bile güçlü görünmesi için
         * minimum değer kullanıyoruz.
         */
        float minimumIntensity =
            scanIntensity * 0.35f;

        scanLight.intensity =
            Mathf.Lerp(
                minimumIntensity,
                scanIntensity,
                progress
            );
    }

    private void PulseScanLight()
    {
        if (
            scanLight == null ||
            !useRedScanLight
        )
        {
            return;
        }

        float pulse =
            (
                Mathf.Sin(
                    Time.unscaledTime *
                    scanPulseSpeed
                ) +
                1f
            ) * 0.5f;

        float multiplier =
            1f +
            pulse *
                scanPulseAmount;

        scanLight.intensity =
            scanIntensity *
            multiplier;
    }

    private void LookAtPlayerImmediately()
    {
        if (
            droneTransform == null ||
            player == null
        )
        {
            return;
        }

        Vector3 lookTarget =
            player.position +
            Vector3.up *
                lookHeight;

        Vector3 lookDirection =
            lookTarget -
            droneTransform.position;

        if (
            lookDirection.sqrMagnitude <=
            0.001f
        )
        {
            return;
        }

        droneTransform.rotation =
            Quaternion.LookRotation(
                lookDirection.normalized,
                Vector3.up
            );
    }

    private void FinishSequence()
    {
        /*
         * Game Over paneli açıldıktan sonra
         * kırmızı ışığı açık bırakıyoruz.
         * Böylece panel arkasında yakalama
         * atmosferi devam ediyor.
         */
        if (gameOverPanel != null)
        {
            gameOverPanel.SetActive(true);
        }

        sequenceCoroutine = null;
    }

    private void HandleRevive()
    {
        if (sequenceCoroutine != null)
        {
            StopCoroutine(
                sequenceCoroutine
            );

            sequenceCoroutine = null;
        }

        RestoreScanLight();

        if (securityDroneChase != null)
        {
            securityDroneChase.enabled =
                previousChaseEnabled;

            securityDroneChase
                .ResetChaseDistance();
        }
    }

    private void RestoreScanLight()
    {
        if (
            scanLight == null ||
            !lightStateStored
        )
        {
            return;
        }

        scanLight.color =
            originalLightColor;

        scanLight.intensity =
            originalLightIntensity;

        scanLight.range =
            originalLightRange;

        scanLight.spotAngle =
            originalSpotAngle;

        scanLight.innerSpotAngle =
            originalInnerSpotAngle;

        scanLight.enabled =
            originalLightEnabled;

        scanLight.transform.localRotation =
            originalLightLocalRotation;

        lightStateStored = false;
    }

    [ContextMenu(
        "Test / Play Capture Sequence"
    )]
    private void TestCaptureSequence()
    {
        if (!Application.isPlaying)
        {
            Debug.LogWarning(
                "Test yalnızca Play Mode'da çalışır.",
                this
            );

            return;
        }

        if (sequenceCoroutine != null)
        {
            return;
        }

        ResolveReferences();

        sequenceCoroutine =
            StartCoroutine(
                CaptureSequence()
            );
    }

    [ContextMenu(
        "Test / Aim Red Light At Player"
    )]
    private void TestAimRedLight()
    {
        if (!Application.isPlaying)
        {
            Debug.LogWarning(
                "Test yalnızca Play Mode'da çalışır.",
                this
            );

            return;
        }

        ResolveReferences();

        PrepareScanLight();
        PointScanLightAtPlayer();
    }

    [ContextMenu(
        "Test / Restore Light"
    )]
    private void TestRestoreLight()
    {
        RestoreScanLight();
    }

    private void OnValidate()
    {
        approachDuration =
            Mathf.Max(
                0.1f,
                approachDuration
            );

        captureHoldDuration =
            Mathf.Max(
                0f,
                captureHoldDuration
            );

        scanIntensity =
            Mathf.Max(
                0f,
                scanIntensity
            );

        scanRange =
            Mathf.Max(
                1f,
                scanRange
            );

        scanSpotAngle =
            Mathf.Clamp(
                scanSpotAngle,
                1f,
                179f
            );

        scanInnerSpotAngle =
            Mathf.Clamp(
                scanInnerSpotAngle,
                0f,
                scanSpotAngle
            );

        scanPulseSpeed =
            Mathf.Max(
                0.1f,
                scanPulseSpeed
            );

        scanPulseAmount =
            Mathf.Clamp01(
                scanPulseAmount
            );
    }
}
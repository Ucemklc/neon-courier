using UnityEngine;

[DisallowMultipleComponent]
public sealed class CargoCoreController :
    MonoBehaviour
{
    [Header("References")]
    [Tooltip(
        "Cargo Core'un ana enerji ışığı."
    )]
    [SerializeField]
    private GameObject coreGlow;

    [Tooltip(
        "Paketlerin ileride uçacağı hedef nokta."
    )]
    [SerializeField]
    private Transform intakePoint;

    [Header("Capacity Lights")]
    [SerializeField]
    private GameObject capacityLight01;

    [SerializeField]
    private GameObject capacityLight02;

    [SerializeField]
    private GameObject capacityLight03;

    [SerializeField]
    private GameObject capacityLight04;

    [SerializeField]
    private GameObject capacityLight05;

    [Header("Capacity")]
    [Tooltip(
        "Beş göstergenin tamamen dolu sayılacağı paket miktarı."
    )]
    [SerializeField, Min(1)]
    private int fullCapacityPackageCount = 10;

    [Header("Full Capacity Pulse")]
    [SerializeField]
    private bool pulseWhenFull = true;

    [SerializeField, Min(0.1f)]
    private float fullPulseSpeed = 4f;

    [SerializeField, Range(0f, 0.5f)]
    private float fullPulseAmount = 0.12f;

    public Transform IntakePoint =>
        intakePoint;

    private GameManager gameManager;

    private Vector3 originalScale;

    private bool isFull;

    private void Awake()
    {
        originalScale =
            transform.localScale;
    }

    private void Start()
    {
        ResolveGameManager();
        SubscribeToGameManager();

        RefreshVisuals();
    }

    private void Update()
    {
        UpdateFullPulse();
    }

    private void OnDestroy()
    {
        UnsubscribeFromGameManager();
    }

    private void ResolveGameManager()
    {
        if (gameManager != null)
        {
            return;
        }

        gameManager =
            GameManager.Instance;

        if (gameManager == null)
        {
            gameManager =
                FindAnyObjectByType
                    <GameManager>();
        }
    }

    private void SubscribeToGameManager()
    {
        if (gameManager == null)
        {
            return;
        }

        gameManager.StatsChanged +=
            RefreshVisuals;

        gameManager.GameOverTriggered +=
            RefreshVisuals;

        gameManager.MainMenuChanged +=
            HandleMainMenuChanged;

        gameManager.RunStateChanged +=
            HandleRunStateChanged;
    }

    private void UnsubscribeFromGameManager()
    {
        if (gameManager == null)
        {
            return;
        }

        gameManager.StatsChanged -=
            RefreshVisuals;

        gameManager.GameOverTriggered -=
            RefreshVisuals;

        gameManager.MainMenuChanged -=
            HandleMainMenuChanged;

        gameManager.RunStateChanged -=
            HandleRunStateChanged;
    }

    private void HandleMainMenuChanged(
        bool isMainMenuOpen
    )
    {
        RefreshVisuals();
    }

    private void HandleRunStateChanged(
        bool isRunActive
    )
    {
        RefreshVisuals();
    }

    private void RefreshVisuals()
    {
        ResolveGameManager();

        int packageCount =
            gameManager != null
                ? Mathf.Max(
                    0,
                    gameManager
                        .CarriedPackages
                )
                : 0;

        int activeLightCount =
            CalculateActiveLightCount(
                packageCount
            );

        SetLightState(
            capacityLight01,
            activeLightCount >= 1
        );

        SetLightState(
            capacityLight02,
            activeLightCount >= 2
        );

        SetLightState(
            capacityLight03,
            activeLightCount >= 3
        );

        SetLightState(
            capacityLight04,
            activeLightCount >= 4
        );

        SetLightState(
            capacityLight05,
            activeLightCount >= 5
        );

        if (coreGlow != null)
        {
            coreGlow.SetActive(
                packageCount > 0
            );
        }

        isFull =
            packageCount >=
            fullCapacityPackageCount;

        if (!isFull)
        {
            transform.localScale =
                originalScale;
        }
    }

    private int CalculateActiveLightCount(
        int packageCount
    )
    {
        if (packageCount <= 0)
        {
            return 0;
        }

        float normalizedCapacity =
            Mathf.Clamp01(
                packageCount /
                (float)
                fullCapacityPackageCount
            );

        return Mathf.Clamp(
            Mathf.CeilToInt(
                normalizedCapacity * 5f
            ),
            1,
            5
        );
    }

    private static void SetLightState(
        GameObject lightObject,
        bool active
    )
    {
        if (lightObject == null)
        {
            return;
        }

        lightObject.SetActive(
            active
        );
    }

    private void UpdateFullPulse()
    {
        if (
            !pulseWhenFull ||
            !isFull
        )
        {
            return;
        }

        float pulse =
            1f +
            Mathf.Sin(
                Time.unscaledTime *
                fullPulseSpeed
            ) *
            fullPulseAmount;

        transform.localScale =
            originalScale *
            pulse;
    }

    [ContextMenu(
        "Refresh Cargo Core"
    )]
    private void TestRefresh()
    {
        RefreshVisuals();
    }

    private void OnValidate()
    {
        fullCapacityPackageCount =
            Mathf.Max(
                1,
                fullCapacityPackageCount
            );

        fullPulseSpeed =
            Mathf.Max(
                0.1f,
                fullPulseSpeed
            );

        fullPulseAmount =
            Mathf.Clamp(
                fullPulseAmount,
                0f,
                0.5f
            );
    }
}
using UnityEngine;

/// <summary>Shop, apartment and locker façades share the original delivery trigger and rewards.</summary>
public sealed class CourierDeliveryStop : MonoBehaviour
{
    private readonly GameObject[] variants=new GameObject[3];
    private GameObject npc;
    private GameObject current;
    private Transform door;
    private Renderer signal;
    private MaterialPropertyBlock block;
    private float feedbackUntil;
    public int Variant { get; private set; }
    public void Configure(float worldZ)
    {
        if(!npc)
        {var receiver=GetComponentInChildren<DeliveryReceiverVisual>(true);if(receiver)npc=receiver.gameObject;}
        Variant=Mathf.Abs(Mathf.FloorToInt((worldZ+10f)/120f))%4;
        foreach(var variant in variants)if(variant)variant.SetActive(false);
        if(npc)npc.SetActive(Variant!=3);
        feedbackUntil=0;current=null;door=null;signal=null;
        if(Variant==0){GetComponent<DeliveryZone>().SetDestinationFocus(npc?npc.transform:null);return;}
        int index=Variant-1;
        if(!variants[index])
        {
            var prefab=Resources.Load<GameObject>("CourierExpansion/DeliveryStop"+Variant);
            if(!prefab)return;
            variants[index]=Instantiate(prefab,transform,false);
            variants[index].transform.localPosition=new Vector3(4.9f,-1.5f,2.2f);
            variants[index].transform.localRotation=Quaternion.Euler(0,-100,0);
        }
        current=variants[index];current.SetActive(true);door=current.transform.Find("DoorPivot");
        Transform light=current.transform.Find("ConfirmationLight");if(light)signal=light.GetComponent<Renderer>();
        if(door)door.localRotation=Quaternion.identity;
        GetComponent<DeliveryZone>().SetDestinationFocus(Variant==3?current.transform:(npc?npc.transform:current.transform));
        ApplySignal(false);
    }
    public void PlayFeedback(){feedbackUntil=Time.time+1.5f;ApplySignal(true);}
    private void Update()
    {
        if(!current)return;
        bool active=Time.time<feedbackUntil;
        if(door)door.localRotation=Quaternion.RotateTowards(door.localRotation,Quaternion.Euler(0,active?-65f:0f,0),Time.deltaTime*160f);
        ApplySignal(active);
    }
    private void ApplySignal(bool success)
    {
        if(!signal)return;if(block==null)block=new MaterialPropertyBlock();
        Color color=success?new Color(.2f,1,.45f):new Color(.08f,.6f,.85f);
        signal.GetPropertyBlock(block);block.SetColor("_BaseColor",color);block.SetColor("_EmissionColor",color*1.2f);signal.SetPropertyBlock(block);
    }
}

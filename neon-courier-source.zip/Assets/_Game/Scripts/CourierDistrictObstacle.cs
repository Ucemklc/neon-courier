using UnityEngine;

/// <summary>District-specific silhouettes share the original, tested obstacle colliders.</summary>
[DisallowMultipleComponent]
public sealed class CourierDistrictObstacle : MonoBehaviour
{
    private readonly GameObject[] variants=new GameObject[6];
    public bool Apply(RunnerObstacleType kind)
    {
        foreach(var variant in variants)if(variant)variant.SetActive(false);
        int district=(int)CourierWorldRules.DistrictAt(transform.position.z);
        if(district>=3)district=district==3?2:1;
        if(district==0)return false;
        int index=(district-1)*3+(int)kind;
        if(!variants[index])
        {
            var prefab=Resources.Load<GameObject>("CourierExpansion/Obstacle"+district+"_"+(int)kind);
            if(!prefab)return false;
            variants[index]=Instantiate(prefab,transform,false);
        }
        variants[index].SetActive(true);return true;
    }
}

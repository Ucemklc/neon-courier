using UnityEngine;

/// <summary>World-sized effects and a planted hoverboard stance on the courier's real skeleton.</summary>
[DefaultExecutionOrder(100)]
public sealed class CourierPowerEffects : MonoBehaviour
{
    public static CourierPowerEffects Instance{get;private set;}
    private RunnerController runner;
    private PowerUpController power;
    private CharacterController capsule;
    private Transform board,shield,magnet,coinAura,burst;
    private TrailRenderer[] trails;
    private Renderer[] boardPanels;
    private Vector3 previousPosition;
    private float clock,lean,stance,burstLeft;
    private int posedFrame=-1,lastSkin=-1;
    public float StanceWeight=>stance;
    public float BankAngle=>lean;
    public Transform Board=>board;
    public bool ShieldVisible=>shield&&shield.gameObject.activeSelf;
    public bool MagnetVisible=>magnet&&magnet.gameObject.activeSelf;
    public bool CoinAuraVisible=>coinAura&&coinAura.gameObject.activeSelf;
    public bool ShieldBurstVisible=>burst&&burst.gameObject.activeSelf;
    private Transform Make(string name)
    {var asset=Resources.Load<GameObject>("CourierPowers/"+name);if(!asset)return null;var go=Instantiate(asset);go.name="Courier "+name;go.SetActive(false);return go.transform;}
    private void Start()
    {
        Instance=this;runner=GetComponent<RunnerController>();power=GetComponent<PowerUpController>();capsule=GetComponent<CharacterController>();previousPosition=transform.position;
        board=Make("Hoverboard");shield=Make("ShieldField");magnet=Make("MagnetField");coinAura=Make("CoinField");burst=Make("ShieldBreak");
        if(board){trails=board.GetComponentsInChildren<TrailRenderer>(true);boardPanels=board.GetComponentsInChildren<Renderer>(true);}
        power.ShieldConsumed+=BreakShield;
    }
    private void OnDestroy()
    {if(power)power.ShieldConsumed-=BreakShield;foreach(var t in new[]{board,shield,magnet,coinAura,burst})if(t)Destroy(t.gameObject);if(Instance==this)Instance=null;}
    private bool InRun=>GameManager.Instance&&GameManager.Instance.IsRunActive&&!GameManager.Instance.IsGameOver&&!GameManager.Instance.IsMainMenuActive;
    private Vector3 BoardPosition=>new Vector3(transform.position.x,capsule.bounds.min.y+.015f+Mathf.Sin(clock*4)*.035f,transform.position.z);
    private Quaternion BoardRotation=>Quaternion.Euler(Mathf.Sin(clock*3.4f)*2,10,-lean);
    private void Update()
    {
        if(!power||!runner)return;
        if(CourierJourney.Active)
        {
            clock+=Time.deltaTime;
            float lateral=(transform.position.x-previousPosition.x)/Mathf.Max(.001f,Time.deltaTime);
            lean=Mathf.Lerp(lean,Mathf.Clamp(lateral*2,-17,17),1-Mathf.Exp(-Time.deltaTime*12));
            stance=Mathf.MoveTowards(stance,runner.IsHoverboardMovementActive?1:0,Time.deltaTime*5);
            burstLeft=Mathf.Max(0,burstLeft-Time.deltaTime);
        }
        else if(!InRun){stance=lean=burstLeft=0;}
        previousPosition=transform.position;
    }
    private void LateUpdate()
    {
        if(!power)return;
        bool ride=InRun&&runner.IsHoverboardMovementActive;
        if(board)
        {
            bool starting=ride&&!board.gameObject.activeSelf;board.gameObject.SetActive(ride);
            if(ride)
            {
                board.SetPositionAndRotation(BoardPosition,BoardRotation);
                foreach(var trail in trails){if(starting)trail.Clear();trail.emitting=CourierJourney.Active;}
                if(lastSkin!=CourierBackpackStyle.Skin)
                {
                    lastSkin=CourierBackpackStyle.Skin;var block=new MaterialPropertyBlock();block.SetColor("_BaseColor",CourierBackpackStyle.Accents[lastSkin]);
                    foreach(var panel in boardPanels)if(panel.sharedMaterial&&panel.sharedMaterial.name=="SafetyTangerine")panel.SetPropertyBlock(block);
                }
            }
        }
        Place(shield,InRun&&power.IsShieldActive,transform.position,Quaternion.Euler(0,clock*24,0));
        Place(magnet,InRun&&power.IsMagnetActive,transform.position,Quaternion.Euler(0,clock*65,0));
        Place(coinAura,InRun&&power.IsDoubleCoinActive,transform.position,Quaternion.Euler(0,-clock*45,0));
        if(magnet){float wave=1+Mathf.Sin(clock*6)*.12f;magnet.localScale=Vector3.one*wave;}
        if(shield)shield.localScale=Vector3.one*(1+Mathf.Sin(clock*3)*.025f);
        if(burst){burst.gameObject.SetActive(InRun&&burstLeft>0);burst.position=transform.position;burst.localScale=Vector3.one*Mathf.Lerp(1.8f,1,burstLeft/.45f);}
    }
    private static void Place(Transform t,bool visible,Vector3 position,Quaternion rotation){if(!t)return;t.gameObject.SetActive(visible);if(visible)t.SetPositionAndRotation(position,rotation);}
    private void BreakShield(){if(InRun)burstLeft=.45f;}
    public void ApplyPose(Animator rig)
    {
        if(!runner||rig!=runner.CurrentAnimator||!rig.isHuman||!CourierJourney.Active||stance<=0||posedFrame==Time.frameCount)return;
        posedFrame=Time.frameCount;var hips=rig.GetBoneTransform(HumanBodyBones.Hips);if(!hips)return;
        var left=rig.GetBoneTransform(HumanBodyBones.LeftUpperLeg);var knee=rig.GetBoneTransform(HumanBodyBones.LeftLowerLeg);var foot=rig.GetBoneTransform(HumanBodyBones.LeftFoot);
        if(!left||!knee||!foot)return;
        float leg=Vector3.Distance(left.position,knee.position)+Vector3.Distance(knee.position,foot.position);
        Vector3 origin=BoardPosition;var rotation=BoardRotation;
        hips.position=Vector3.Lerp(hips.position,new Vector3(transform.position.x,origin.y+leg*.86f+.16f,transform.position.z),stance);
        hips.rotation=Quaternion.Slerp(hips.rotation,Quaternion.Euler(7,20,-lean*.4f),stance);
        Leg(rig,true,origin+rotation*new Vector3(-.20f,.17f,.34f),rotation);
        Leg(rig,false,origin+rotation*new Vector3(.20f,.17f,-.34f),rotation);
        Arm(rig,HumanBodyBones.LeftUpperArm,HumanBodyBones.LeftLowerArm,new Vector3(-.65f,-.22f,.16f));
        Arm(rig,HumanBodyBones.LeftLowerArm,HumanBodyBones.LeftHand,new Vector3(-.3f,.06f,.18f));
        Arm(rig,HumanBodyBones.RightUpperArm,HumanBodyBones.RightLowerArm,new Vector3(.65f,-.2f,.1f));
        Arm(rig,HumanBodyBones.RightLowerArm,HumanBodyBones.RightHand,new Vector3(.28f,.10f,.18f));
    }
    private void Arm(Animator rig,HumanBodyBones a,HumanBodyBones b,Vector3 direction)
    {var start=rig.GetBoneTransform(a);var end=rig.GetBoneTransform(b);if(!start||!end)return;var target=Quaternion.FromToRotation(end.position-start.position,BoardRotation*direction)*start.rotation;start.rotation=Quaternion.Slerp(start.rotation,target,stance);}
    private void Leg(Animator rig,bool left,Vector3 target,Quaternion facing)
    {
        var upper=rig.GetBoneTransform(left?HumanBodyBones.LeftUpperLeg:HumanBodyBones.RightUpperLeg);var lower=rig.GetBoneTransform(left?HumanBodyBones.LeftLowerLeg:HumanBodyBones.RightLowerLeg);var foot=rig.GetBoneTransform(left?HumanBodyBones.LeftFoot:HumanBodyBones.RightFoot);if(!upper||!lower||!foot)return;
        float a=Vector3.Distance(upper.position,lower.position),b=Vector3.Distance(lower.position,foot.position);Vector3 delta=target-upper.position;
        float distance=Mathf.Clamp(delta.magnitude,Mathf.Abs(a-b)+.001f,a+b-.001f);Vector3 direction=delta.normalized;
        Vector3 bend=Vector3.ProjectOnPlane(facing*Vector3.forward,direction).normalized;
        float along=(a*a+distance*distance-b*b)/(2*distance);Vector3 desiredKnee=upper.position+direction*along+bend*Mathf.Sqrt(Mathf.Max(0,a*a-along*along));
        upper.rotation=Quaternion.Slerp(upper.rotation,Quaternion.FromToRotation(lower.position-upper.position,desiredKnee-upper.position)*upper.rotation,stance);
        lower.rotation=Quaternion.Slerp(lower.rotation,Quaternion.FromToRotation(foot.position-lower.position,target-lower.position)*lower.rotation,stance);
        foot.rotation=Quaternion.Slerp(foot.rotation,facing,stance);
    }
}

using UnityEngine;

[DisallowMultipleComponent]
public sealed class ObstacleTimingMotion : MonoBehaviour
{
    [Header("Activation Chance by Difficulty")]
    [SerializeField, Range(0f, 1f)] private float level0Chance = 0f;
    [SerializeField, Range(0f, 1f)] private float level1Chance = 0.18f;
    [SerializeField, Range(0f, 1f)] private float level2Chance = 0.35f;
    [SerializeField, Range(0f, 1f)] private float level3Chance = 0.55f;

    [Header("Level 1 Motion")]
    [SerializeField] private Vector2 level1DistanceRange = new Vector2(0.35f, 0.60f);
    [SerializeField] private Vector2 level1SpeedRange = new Vector2(1.0f, 1.35f);

    [Header("Level 2 Motion")]
    [SerializeField] private Vector2 level2DistanceRange = new Vector2(0.55f, 0.90f);
    [SerializeField] private Vector2 level2SpeedRange = new Vector2(1.20f, 1.65f);

    [Header("Level 3 Motion")]
    [SerializeField] private Vector2 level3DistanceRange = new Vector2(0.75f, 1.20f);
    [SerializeField] private Vector2 level3SpeedRange = new Vector2(1.45f, 2.00f);

    [Header("Direction")]
    [Tooltip("Parent uzayındaki hareket ekseni. Z ekseni zamanlamayı değiştirir fakat güvenli şeridi bozmaz.")]
    [SerializeField] private Vector3 localMovementAxis = Vector3.forward;

    [Header("Fairness")]
    [SerializeField, Min(0f)] private float maximumAllowedDistance = 1.20f;
    [SerializeField, Min(0f)] private float activationBlendDuration = 0.20f;

    [Header("Testing")]
    [SerializeField] private bool forceMovementForTesting = false;
    [SerializeField, Range(0, 3)] private int testDifficultyLevel = 3;
    [SerializeField] private bool debugLogs = false;

    public bool IsMoving { get; private set; }

    private Vector3 anchorLocalPosition;
    private Vector3 normalizedMovementAxis;

    private float movementDistance;
    private float movementSpeed;
    private float phaseOffset;
    private float enabledTime;

    private bool anchorCaptured;

    private void Awake()
    {
        NormalizeMovementAxis();
    }

    private void OnEnable()
    {
        NormalizeMovementAxis();
        CaptureAnchor();
        ConfigureForCurrentDifficulty();
    }

    private void FixedUpdate()
    {
        if (!anchorCaptured)
        {
            CaptureAnchor();
        }

        GameManager gameManager = GameManager.Instance;

        if (
            !IsMoving ||
            gameManager == null ||
            !gameManager.IsRunActive ||
            gameManager.IsPaused ||
            gameManager.IsGameOver ||
            gameManager.IsMainMenuActive
        )
        {
            transform.localPosition = anchorLocalPosition;
            return;
        }

        float elapsedTime = Time.time - enabledTime;

        float blend = activationBlendDuration <= 0f
            ? 1f
            : Mathf.Clamp01(elapsedTime / activationBlendDuration);

        float oscillation = Mathf.Sin(
            elapsedTime * movementSpeed + phaseOffset
        );

        float offset = oscillation * movementDistance * blend;

        transform.localPosition =
            anchorLocalPosition +
            normalizedMovementAxis * offset;
    }

    private void OnDisable()
    {
        if (anchorCaptured)
        {
            transform.localPosition = anchorLocalPosition;
        }

        IsMoving = false;
        anchorCaptured = false;
    }

    private void CaptureAnchor()
    {
        anchorLocalPosition = transform.localPosition;
        anchorCaptured = true;
        enabledTime = Time.time;
    }

    private void ConfigureForCurrentDifficulty()
    {
        int difficultyLevel = GetDifficultyLevel();
        float movementChance = GetMovementChance(difficultyLevel);

        IsMoving =
            forceMovementForTesting ||
            Random.value < movementChance;

        if (!IsMoving)
        {
            movementDistance = 0f;
            movementSpeed = 0f;
            transform.localPosition = anchorLocalPosition;
            return;
        }

        Vector2 distanceRange = GetDistanceRange(difficultyLevel);
        Vector2 speedRange = GetSpeedRange(difficultyLevel);

        movementDistance = Mathf.Min(
            maximumAllowedDistance,
            Random.Range(distanceRange.x, distanceRange.y)
        );

        movementSpeed = Random.Range(
            speedRange.x,
            speedRange.y
        );

        phaseOffset = Random.Range(
            0f,
            Mathf.PI * 2f
        );

        if (debugLogs)
        {
            Debug.Log(
                $"ObstacleTimingMotion: {name} hareketli. " +
                $"Seviye {difficultyLevel}, " +
                $"Mesafe {movementDistance:0.00}, " +
                $"Hız {movementSpeed:0.00}",
                this
            );
        }
    }

    private int GetDifficultyLevel()
    {
        if (forceMovementForTesting)
        {
            return Mathf.Clamp(testDifficultyLevel, 0, 3);
        }

        if (GameManager.Instance == null)
        {
            return 0;
        }

        return Mathf.Clamp(
            GameManager.Instance.DifficultyLevel,
            0,
            3
        );
    }

    private float GetMovementChance(int difficultyLevel)
    {
        switch (difficultyLevel)
        {
            case 1:
                return level1Chance;
            case 2:
                return level2Chance;
            case 3:
                return level3Chance;
            default:
                return level0Chance;
        }
    }

    private Vector2 GetDistanceRange(int difficultyLevel)
    {
        switch (difficultyLevel)
        {
            case 1:
                return level1DistanceRange;
            case 2:
                return level2DistanceRange;
            case 3:
                return level3DistanceRange;
            default:
                return Vector2.zero;
        }
    }

    private Vector2 GetSpeedRange(int difficultyLevel)
    {
        switch (difficultyLevel)
        {
            case 1:
                return level1SpeedRange;
            case 2:
                return level2SpeedRange;
            case 3:
                return level3SpeedRange;
            default:
                return Vector2.zero;
        }
    }

    private void NormalizeMovementAxis()
    {
        normalizedMovementAxis =
            localMovementAxis.sqrMagnitude > 0.0001f
                ? localMovementAxis.normalized
                : Vector3.forward;
    }

    private void OnValidate()
    {
        level1DistanceRange = ValidateRange(level1DistanceRange, 0f);
        level2DistanceRange = ValidateRange(level2DistanceRange, 0f);
        level3DistanceRange = ValidateRange(level3DistanceRange, 0f);

        level1SpeedRange = ValidateRange(level1SpeedRange, 0.01f);
        level2SpeedRange = ValidateRange(level2SpeedRange, 0.01f);
        level3SpeedRange = ValidateRange(level3SpeedRange, 0.01f);

        maximumAllowedDistance = Mathf.Max(0f, maximumAllowedDistance);
        activationBlendDuration = Mathf.Max(0f, activationBlendDuration);

        NormalizeMovementAxis();
    }

    private static Vector2 ValidateRange(
        Vector2 range,
        float minimumValue
    )
    {
        range.x = Mathf.Max(minimumValue, range.x);
        range.y = Mathf.Max(range.x, range.y);
        return range;
    }
}

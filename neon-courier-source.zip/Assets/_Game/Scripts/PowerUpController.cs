using System;
using System.Collections.Generic;
using UnityEngine;

public enum PowerUpType
{
    Magnet = 0,
    Shield = 1,
    DoubleCoin = 2,
    Hoverboard = 3,
    JumpShoes = 4
}

[DisallowMultipleComponent]
public class PowerUpController : MonoBehaviour
{
    public static PowerUpController Instance
    {
        get;
        private set;
    }

    [Header("Magnet")]
    [SerializeField, Min(0.1f)]
    private float magnetDuration = 8f;

    [SerializeField, Min(0.1f)]
    private float magnetRadius = 7f;

    [SerializeField, Min(0.1f)]
    private float magnetPullSpeed = 18f;

    [SerializeField]
    private Transform packageAttractionTarget;

    [Header("Shield")]
    [SerializeField, Min(0.1f)]
    private float shieldDuration = 12f;

    [Header("Double Coin")]
    [SerializeField, Min(0.1f)]
    private float doubleCoinDuration = 10f;

    [Header("Hoverboard")]
    [SerializeField, Min(0.1f)]
    private float hoverboardDuration = 7f;

    [Tooltip(
        "Player/HoverboardAnchor/HoverboardVisual nesnesini bağla."
    )]
    [SerializeField]
    private GameObject hoverboardVisualRoot;

    [Header("Security Drone")]
    [Tooltip(
        "SecurityDroneRoot üzerindeki SecurityDroneChase componentini bağla."
    )]
    [SerializeField]
    private SecurityDroneChase securityDroneChase;

    [SerializeField]
    private bool pushDroneBackOnHoverboardPickup = true;

    [Header("Optional Visual Effects")]
    [SerializeField]
    private GameObject magnetVisualRoot;

    [SerializeField]
    private GameObject shieldVisualRoot;

    [SerializeField]
    private GameObject doubleCoinVisualRoot;

    public event Action PowerUpStateChanged;
    public event Action ShieldConsumed;
    private readonly List<AirCoinPickup> coinBuffer = new List<AirCoinPickup>(64);
    private RunnerController runner;
    private CourierPowerEffects effects;

    public const float JumpShoesDuration = 10f;
    public bool IsJumpShoesActive => jumpShoesTimeRemaining > 0f;
    public float JumpShoesTimeRemaining => Mathf.Max(0f, jumpShoesTimeRemaining);
    private float jumpShoesTimeRemaining;
    private bool previousJumpShoesState;

    public bool IsMagnetActive =>
        magnetTimeRemaining > 0f;

    public bool IsShieldActive =>
        shieldTimeRemaining > 0f &&
        shieldChargeCount > 0;

    public bool IsDoubleCoinActive =>
        doubleCoinTimeRemaining > 0f;

    public bool IsHoverboardActive =>
        hoverboardTimeRemaining > 0f;

    public float MagnetTimeRemaining =>
        Mathf.Max(
            0f,
            magnetTimeRemaining
        );

    public float ShieldTimeRemaining =>
        Mathf.Max(
            0f,
            shieldTimeRemaining
        );

    public float DoubleCoinTimeRemaining =>
        Mathf.Max(
            0f,
            doubleCoinTimeRemaining
        );

    public float HoverboardTimeRemaining =>
        Mathf.Max(
            0f,
            hoverboardTimeRemaining
        );

    public float HoverboardDuration =>
        Mathf.Max(
            0.1f,
            hoverboardDuration
        );

    public int CoinMultiplier =>
        IsDoubleCoinActive ? 2 : 1;

    private readonly List<PackagePickup>
        packageBuffer =
            new List<PackagePickup>(64);

    private GameManager gameManager;

    private float magnetTimeRemaining;
    private float shieldTimeRemaining;
    private float doubleCoinTimeRemaining;
    private float hoverboardTimeRemaining;

    private int shieldChargeCount;

    private bool previousMagnetState;
    private bool previousShieldState;
    private bool previousDoubleCoinState;
    private bool previousHoverboardState;

    private void Awake()
    {
        if (
            Instance != null &&
            Instance != this
        )
        {
            Destroy(this);
            return;
        }

        Instance = this;

        if (packageAttractionTarget == null)
        {
            packageAttractionTarget =
                transform;
        }

        ResolveSecurityDrone();

        UpdateVisualStates(true);
    }

    private void Start()
    {
        runner = GetComponent<RunnerController>();
        if (Resources.Load<GameObject>("CourierPowers/Hoverboard"))
            effects = GetComponent<CourierPowerEffects>() ?? gameObject.AddComponent<CourierPowerEffects>();
        var anchor = new GameObject("PowerAttractionAnchor").transform;
        anchor.SetParent(transform, false);
        anchor.localPosition = new Vector3(0, .2f, -.1f);
        packageAttractionTarget = anchor;
        gameManager =
            GameManager.Instance;

        if (gameManager == null)
        {
            gameManager =
                FindAnyObjectByType<GameManager>();
        }

        ResolveSecurityDrone();

        if (gameManager != null)
        {
            gameManager.GameOverTriggered +=
                ResetAllPowerUps;

            gameManager.MainMenuChanged +=
                HandleMainMenuChanged;
        }
    }

    private void Update()
    {
        if (
            gameManager == null ||
            !gameManager.IsRunActive ||
            gameManager.IsPaused ||
            gameManager.IsGameOver
        )
        {
            return;
        }

        UpdateTimers();

        if (IsMagnetActive)
        {
            PullNearbyPackages();
        }

        UpdateVisualStates(false);
    }

    private void OnDestroy()
    {
        if (gameManager != null)
        {
            gameManager.GameOverTriggered -=
                ResetAllPowerUps;

            gameManager.MainMenuChanged -=
                HandleMainMenuChanged;
        }

        if (Instance == this)
        {
            Instance = null;
        }
    }

    public void ActivatePowerUp(
        PowerUpType powerUpType
    )
    {
        if (
            gameManager != null &&
            (
                !gameManager.IsRunActive ||
                gameManager.IsPaused ||
                gameManager.IsGameOver
            )
        )
        {
            return;
        }

        switch (powerUpType)
        {
            case PowerUpType.JumpShoes:
                jumpShoesTimeRemaining = JumpShoesDuration;
                break;

            case PowerUpType.Magnet:
                magnetTimeRemaining =
                    Mathf.Max(
                        magnetTimeRemaining,
                        magnetDuration
                    );
                break;

            case PowerUpType.Shield:
                shieldTimeRemaining =
                    Mathf.Max(
                        shieldTimeRemaining,
                        shieldDuration
                    );

                shieldChargeCount = 1;
                break;

            case PowerUpType.DoubleCoin:
                doubleCoinTimeRemaining =
                    Mathf.Max(
                        doubleCoinTimeRemaining,
                        doubleCoinDuration
                    );
                break;

            case PowerUpType.Hoverboard:
                hoverboardTimeRemaining =
                    Mathf.Max(
                        hoverboardTimeRemaining,
                        hoverboardDuration
                    );

                PushSecurityDroneBack();
                break;
        }

        UpdateVisualStates(true);
    }

    public bool TryConsumeShield()
    {
        if (!IsShieldActive)
        {
            return false;
        }

        shieldChargeCount = 0;
        shieldTimeRemaining = 0f;

        UpdateVisualStates(true);
        ShieldConsumed?.Invoke();

        return true;
    }

    public float GetDuration(PowerUpType type)
    {
        switch(type)
        {
            case PowerUpType.Magnet: return magnetDuration;
            case PowerUpType.Shield: return shieldDuration;
            case PowerUpType.DoubleCoin: return doubleCoinDuration;
            case PowerUpType.Hoverboard: return hoverboardDuration;
            case PowerUpType.JumpShoes: return JumpShoesDuration;
            default: return 1;
        }
    }

    public float GetRemainingTime(
        PowerUpType powerUpType
    )
    {
        switch (powerUpType)
        {
            case PowerUpType.JumpShoes:
                return JumpShoesTimeRemaining;

            case PowerUpType.Magnet:
                return MagnetTimeRemaining;

            case PowerUpType.Shield:
                return ShieldTimeRemaining;

            case PowerUpType.DoubleCoin:
                return DoubleCoinTimeRemaining;

            case PowerUpType.Hoverboard:
                return HoverboardTimeRemaining;

            default:
                return 0f;
        }
    }

    [ContextMenu(
        "Test / Activate Hoverboard"
    )]
    private void TestActivateHoverboard()
    {
        ActivatePowerUp(
            PowerUpType.Hoverboard
        );
    }

    [ContextMenu(
        "Test / Stop Hoverboard"
    )]
    private void TestStopHoverboard()
    {
        hoverboardTimeRemaining = 0f;

        UpdateVisualStates(true);
    }

    [ContextMenu(
        "Test / Push Drone Back"
    )]
    private void TestPushDroneBack()
    {
        PushSecurityDroneBack();
    }

    [ContextMenu(
        "Test / Reset Drone Distance"
    )]
    private void TestResetDroneDistance()
    {
        ResolveSecurityDrone();

        if (securityDroneChase != null)
        {
            securityDroneChase
                .ResetChaseDistance();
        }
    }

    private void ResolveSecurityDrone()
    {
        if (securityDroneChase != null)
        {
            return;
        }

        securityDroneChase =
            FindAnyObjectByType
                <SecurityDroneChase>();
    }

    private void PushSecurityDroneBack()
    {
        if (!pushDroneBackOnHoverboardPickup)
        {
            return;
        }

        ResolveSecurityDrone();

        if (securityDroneChase == null)
        {
            Debug.LogWarning(
                "PowerUpController: SecurityDroneChase bulunamadı.",
                this
            );

            return;
        }

        securityDroneChase.PushBack();
    }

    private void UpdateTimers()
    {
        jumpShoesTimeRemaining = Mathf.Max(0f, jumpShoesTimeRemaining - Time.deltaTime);
        float deltaTime =
            Time.deltaTime;

        if (magnetTimeRemaining > 0f)
        {
            magnetTimeRemaining -=
                deltaTime;

            if (magnetTimeRemaining < 0f)
            {
                magnetTimeRemaining = 0f;
            }
        }

        if (shieldTimeRemaining > 0f)
        {
            shieldTimeRemaining -=
                deltaTime;

            if (shieldTimeRemaining <= 0f)
            {
                shieldTimeRemaining = 0f;
                shieldChargeCount = 0;
            }
        }

        if (doubleCoinTimeRemaining > 0f)
        {
            doubleCoinTimeRemaining -=
                deltaTime;

            if (doubleCoinTimeRemaining < 0f)
            {
                doubleCoinTimeRemaining = 0f;
            }
        }

        if (hoverboardTimeRemaining > 0f)
        {
            hoverboardTimeRemaining -=
                deltaTime;

            if (hoverboardTimeRemaining < 0f)
            {
                hoverboardTimeRemaining = 0f;
            }
        }
    }

    private void PullNearbyPackages()
    {
        float speed = Mathf.Max(magnetPullSpeed, runner ? runner.CurrentForwardSpeed * (CourierCargoManifest.Instance ? CourierCargoManifest.Instance.SpeedMultiplier : 1) + 12f : magnetPullSpeed);
        if (packageAttractionTarget == null)
        {
            return;
        }

        packageBuffer.Clear();

        PackagePickup.CopyActivePickupsTo(
            packageBuffer
        );

        float radiusSquared =
            magnetRadius *
            magnetRadius;

        Vector3 targetPosition =
            packageAttractionTarget.position;

        foreach (
            PackagePickup packagePickup
            in packageBuffer
        )
        {
            if (
                packagePickup == null ||
                !packagePickup.gameObject
                    .activeInHierarchy
            )
            {
                continue;
            }

            float distanceSquared =
                (
                    packagePickup
                        .transform.position -
                    targetPosition
                ).sqrMagnitude;

            if (
                distanceSquared >
                radiusSquared
            )
            {
                continue;
            }

            packagePickup.AttractTowards(
                packageAttractionTarget,
                speed
            );
        }
        AirCoinPickup.CopyActiveCoinsTo(coinBuffer);
        foreach (var coin in coinBuffer)
            if (coin && coin.CanCollect && (coin.transform.position-targetPosition).sqrMagnitude <= radiusSquared)
                coin.AttractTowards(packageAttractionTarget, speed);
    }

    private void UpdateVisualStates(
        bool forceEvent
    )
    {
        bool magnetState =
            IsMagnetActive;

        bool shieldState =
            IsShieldActive;

        bool doubleCoinState =
            IsDoubleCoinActive;

        bool hoverboardState =
            IsHoverboardActive;

        if (magnetVisualRoot != null)
        {
            magnetVisualRoot.SetActive(
                magnetState
            );
        }

        if (shieldVisualRoot != null)
        {
            shieldVisualRoot.SetActive(
                shieldState
            );
        }

        if (doubleCoinVisualRoot != null)
        {
            doubleCoinVisualRoot.SetActive(
                doubleCoinState
            );
        }

        if (hoverboardVisualRoot != null)
        {
            hoverboardVisualRoot.SetActive(
                hoverboardState && !effects
            );
        }

        bool stateChanged = IsJumpShoesActive != previousJumpShoesState ||
            magnetState !=
                previousMagnetState ||
            shieldState !=
                previousShieldState ||
            doubleCoinState !=
                previousDoubleCoinState ||
            hoverboardState !=
                previousHoverboardState;

        previousJumpShoesState = IsJumpShoesActive;
        previousMagnetState =
            magnetState;

        previousShieldState =
            shieldState;

        previousDoubleCoinState =
            doubleCoinState;

        previousHoverboardState =
            hoverboardState;

        if (
            stateChanged ||
            forceEvent
        )
        {
            PowerUpStateChanged?.Invoke();
        }
    }

    private void HandleMainMenuChanged(
        bool isMainMenuOpen
    )
    {
        if (isMainMenuOpen)
        {
            ResetAllPowerUps();
        }
    }

    private void ResetAllPowerUps()
    {
        jumpShoesTimeRemaining = 0f;
        magnetTimeRemaining = 0f;
        shieldTimeRemaining = 0f;
        doubleCoinTimeRemaining = 0f;
        hoverboardTimeRemaining = 0f;

        shieldChargeCount = 0;

        ResolveSecurityDrone();

        if (securityDroneChase != null)
        {
            securityDroneChase
                .ResetChaseDistance();
        }

        UpdateVisualStates(true);
    }

    private void OnValidate()
    {
        magnetDuration =
            Mathf.Max(
                0.1f,
                magnetDuration
            );

        magnetRadius =
            Mathf.Max(
                0.1f,
                magnetRadius
            );

        magnetPullSpeed =
            Mathf.Max(
                0.1f,
                magnetPullSpeed
            );

        shieldDuration =
            Mathf.Max(
                0.1f,
                shieldDuration
            );

        doubleCoinDuration =
            Mathf.Max(
                0.1f,
                doubleCoinDuration
            );

        hoverboardDuration =
            Mathf.Max(
                0.1f,
                hoverboardDuration
            );
    }
}

using TMPro;
using UnityEngine;
using UnityEngine.UI;

/// <summary>A modal with one coordinate system for the visible graphics and pointer targets.</summary>
public sealed class CourierPanelSurface : MonoBehaviour
{
    public static readonly Color Cyan=new Color(.16f,.86f,1);
    public static readonly Color Muted=new Color(.63f,.75f,.83f);
    public RectTransform Content { get; private set; }
    private void OnEnable(){var modal=GetComponent<Canvas>();if(modal){modal.overrideSorting=true;modal.sortingOrder=240;}LateUpdate();}
    public static CourierPanelSurface Prepare(GameObject root)
    {
        var existing=root.GetComponent<CourierPanelSurface>();if(existing)return existing;
        var canvas=root.GetComponentInParent<Canvas>(true);
        if(canvas)root.transform.SetParent(canvas.rootCanvas.transform,false);
        foreach(Transform child in root.transform)child.gameObject.SetActive(false);
        var rect=(RectTransform)root.transform;rect.localScale=Vector3.one;rect.localRotation=Quaternion.identity;
        rect.anchorMin=Vector2.zero;rect.anchorMax=Vector2.one;rect.offsetMin=rect.offsetMax=Vector2.zero;
        var image=root.GetComponent<Image>();if(!image)image=root.AddComponent<Image>();
        image.sprite=null;image.color=new Color(.018f,.031f,.055f,1);image.raycastTarget=true;
        var modal=root.GetComponent<Canvas>();if(!modal)modal=root.AddComponent<Canvas>();modal.overrideSorting=true;modal.sortingOrder=240;
        if(!root.GetComponent<GraphicRaycaster>())root.AddComponent<GraphicRaycaster>();
        var surface=root.AddComponent<CourierPanelSurface>();
        var content=new GameObject("PanelContent",typeof(RectTransform));content.transform.SetParent(root.transform,false);
        surface.Content=(RectTransform)content.transform;surface.Content.sizeDelta=new Vector2(1080,1920);
        surface.Content.anchorMin=surface.Content.anchorMax=surface.Content.pivot=new Vector2(.5f,.5f);
        surface.LateUpdate();return surface;
    }
    private void LateUpdate()
    {
        if(!Content||Screen.width<=0||Screen.height<=0)return;
        var root=(RectTransform)transform;var safe=Screen.safeArea;
        if(safe.width<=0||safe.height<=0)safe=new Rect(0,0,Screen.width,Screen.height);
        float x=root.rect.width/Screen.width,y=root.rect.height/Screen.height;
        Content.anchoredPosition=new Vector2((safe.center.x-Screen.width*.5f)*x,(safe.center.y-Screen.height*.5f)*y);
        float scale=Mathf.Min(safe.width*x/1080f,safe.height*y/1920f);Content.localScale=Vector3.one*scale;
    }
    public static void Place(RectTransform rect,Transform parent,Vector2 position,Vector2 size,bool center=false)
    {
        rect.SetParent(parent,false);rect.gameObject.SetActive(true);
        CourierMenuLayout.Place(rect,center?new Vector2(.5f,.5f):new Vector2(.5f,1),position,size);
    }
    public static TMP_Text Label(Transform parent,string name,Vector2 pos,Vector2 size,float font,Color color,bool center=false)
    {
        var go=new GameObject(name,typeof(RectTransform),typeof(TextMeshProUGUI));var text=go.GetComponent<TMP_Text>();
        Put(text,parent,pos,size,font,center);text.color=color;return text;
    }
    public static void Put(TMP_Text text,Transform parent,Vector2 pos,Vector2 size,float font,bool center=false)
    {
        if(!text)return;Place(text.rectTransform,parent,pos,size,center);
        text.enabled=true;text.font=TMP_Settings.defaultFontAsset;text.fontSharedMaterial=text.font.material;
        text.fontSize=font;text.fontSizeMax=font;text.fontSizeMin=font*.82f;text.enableAutoSizing=true;
        text.color=Color.white;text.fontStyle=FontStyles.Bold;text.margin=Vector4.zero;text.outlineWidth=0;
        text.alignment=TextAlignmentOptions.Center;text.raycastTarget=false;text.textWrappingMode=TextWrappingModes.Normal;text.overflowMode=TextOverflowModes.Overflow;
    }
    public static void Button(Button button,Transform parent,Vector2 pos,Vector2 size,bool primary,TMP_Text label=null,bool center=false)
    {
        if(!button)return;Place((RectTransform)button.transform,parent,pos,size,center);
        if(label){label.transform.SetParent(button.transform,false);label.gameObject.SetActive(true);}
        var style=button.GetComponent<CourierMenuButton>();if(!style)style=button.gameObject.AddComponent<CourierMenuButton>();style.Style(primary);
        button.navigation=new Navigation{mode=Navigation.Mode.None};
        foreach(var t in button.GetComponentsInChildren<TMP_Text>(true)){t.fontSizeMax=36;t.fontSizeMin=28;t.fontSize=36;t.enableAutoSizing=true;}
    }
    public static Image Card(Transform parent,string name,Vector2 pos,Vector2 size)
    {
        var go=new GameObject(name,typeof(RectTransform),typeof(Image));Place((RectTransform)go.transform,parent,pos,size);
        var image=go.GetComponent<Image>();image.sprite=Resources.Load<Sprite>("CourierPolish/MenuCard");image.type=Image.Type.Sliced;
        image.color=new Color(.055f,.105f,.16f);image.raycastTarget=false;return image;
    }
}

using UnityEngine;

[DisallowMultipleComponent]
[RequireComponent(typeof(Collider))]
[RequireComponent(typeof(Rigidbody))]
public class PowerUpPickup : MonoBehaviour
{
    [Header("Power-up Type")]
    [SerializeField]
    private PowerUpType powerUpType =
        PowerUpType.Magnet;

    [Header("Visual Roots")]
    [SerializeField]
    private GameObject magnetVisualRoot;

    [SerializeField]
    private GameObject shieldVisualRoot;

    [SerializeField]
    private GameObject doubleCoinVisualRoot;

    [SerializeField]
    private GameObject hoverboardVisualRoot;

    [Header("Movement")]
    [SerializeField]
    private float rotationSpeed = 90f;

    [SerializeField]
    private float bobHeight = 0.15f;

    [SerializeField]
    private float bobSpeed = 2.5f;

    private Collider triggerCollider;
    private Rigidbody pickupRigidbody;

    private Vector3 initialLocalPosition;
    private float bobPhase;

    private bool collected;

    public PowerUpType PowerUpType =>
        powerUpType;

    private void Awake()
    {
        triggerCollider =
            GetComponent<Collider>();

        pickupRigidbody =
            GetComponent<Rigidbody>();

        ConfigurePhysics();
        RefreshVisuals();
    }

    private void OnEnable()
    {
        collected = false;

        initialLocalPosition =
            transform.localPosition;

        bobPhase =
            Random.Range(
                0f,
                Mathf.PI * 2f
            );

        ConfigurePhysics();
        RefreshVisuals();
    }

    private void Update()
    {
        if (collected)
        {
            return;
        }

        transform.Rotate(
            Vector3.up,
            rotationSpeed *
            Time.deltaTime,
            Space.Self
        );

        Vector3 localPosition =
            initialLocalPosition;

        localPosition.y +=
            Mathf.Sin(
                Time.time *
                bobSpeed +
                bobPhase
            ) * bobHeight;

        transform.localPosition =
            localPosition;
    }

    private void OnTriggerEnter(
        Collider other
    )
    {
        if (collected)
        {
            return;
        }

        RunnerController runner =
            other.GetComponentInParent
                <RunnerController>();

        if (runner == null)
        {
            return;
        }

        Collect();
    }

    public void Configure(
        PowerUpType newPowerUpType
    )
    {
        powerUpType =
            newPowerUpType;

        collected = false;

        RefreshVisuals();

        gameObject.name =
            $"PowerUp_{powerUpType}";
    }

    private void Collect()
    {
        var manager = GameManager.Instance;
        if (manager && (!manager.IsRunActive || manager.IsPaused || manager.IsGameOver)) return;
        if (collected)
        {
            return;
        }

        PowerUpController controller =
            PowerUpController.Instance;

        if (controller == null)
        {
            controller =
                FindAnyObjectByType
                    <PowerUpController>();
        }

        if (controller == null)
        {
            Debug.LogError(
                "PowerUpPickup: PowerUpController bulunamadı.",
                this
            );

            return;
        }

        collected = true;

        controller.ActivatePowerUp(
            powerUpType
        );

        gameObject.SetActive(false);
    }

    private void ConfigurePhysics()
    {
        if (triggerCollider == null)
        {
            triggerCollider =
                GetComponent<Collider>();
        }

        if (pickupRigidbody == null)
        {
            pickupRigidbody =
                GetComponent<Rigidbody>();
        }

        if (triggerCollider != null)
        {
            triggerCollider.isTrigger =
                true;
        }

        if (pickupRigidbody != null)
        {
            pickupRigidbody.isKinematic =
                true;

            pickupRigidbody.useGravity =
                false;

            pickupRigidbody.detectCollisions =
                true;
        }
    }

    private GameObject jumpShoesVisualRoot;
    private readonly GameObject[] polishedVisuals = new GameObject[4];

    private void RefreshVisuals()
    {
        int index=(int)powerUpType;
        if (index>=0 && index<polishedVisuals.Length && !polishedVisuals[index])
        {
            string[] names={"MagnetPickup","ShieldPickup","DoubleCoinPickup","HoverboardPickup"};
            var asset=Resources.Load<GameObject>("CourierPowers/"+names[index]);
            if(asset){polishedVisuals[index]=Instantiate(asset,transform,false);polishedVisuals[index].name="Courier"+names[index];}
        }
        for(int i=0;i<polishedVisuals.Length;i++)if(polishedVisuals[i])polishedVisuals[i].SetActive(i==index);
        bool polished=index>=0 && index<polishedVisuals.Length && polishedVisuals[index];
        if (powerUpType == PowerUpType.JumpShoes && !jumpShoesVisualRoot)
        {
            var asset = Resources.Load<GameObject>("CourierPolish/JumpShoesPickup");
            if (asset) jumpShoesVisualRoot = Instantiate(asset, transform, false);
        }
        if (jumpShoesVisualRoot) jumpShoesVisualRoot.SetActive(powerUpType == PowerUpType.JumpShoes);
        SetVisualActive(
            magnetVisualRoot,
            !polished && powerUpType ==
                PowerUpType.Magnet
        );

        SetVisualActive(
            shieldVisualRoot,
            !polished && powerUpType ==
                PowerUpType.Shield
        );

        SetVisualActive(
            doubleCoinVisualRoot,
            !polished && powerUpType ==
                PowerUpType.DoubleCoin
        );

        SetVisualActive(
            hoverboardVisualRoot,
            !polished && powerUpType ==
                PowerUpType.Hoverboard
        );
    }

    private static void SetVisualActive(
        GameObject visualRoot,
        bool active
    )
    {
        if (visualRoot == null)
        {
            return;
        }

        visualRoot.SetActive(active);
    }
}

using System.Collections;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

[DisallowMultipleComponent]
public class BoosterShopPanelController :
    MonoBehaviour
{
    [Header("Panel")]
    [SerializeField]
    private GameObject shopPanelRoot;

    [SerializeField]
    private Button openShopButton;

    [SerializeField]
    private Button closeShopButton;

    [Header("General Text")]
    [SerializeField]
    private TMP_Text totalCoinText;

    [SerializeField]
    private TMP_Text feedbackText;

    [Header("Magnet")]
    [SerializeField]
    private TMP_Text magnetCountText;

    [SerializeField]
    private TMP_Text magnetPriceText;

    [SerializeField]
    private Button magnetBuyButton;

    [SerializeField]
    private Button magnetEquipButton;

    [SerializeField]
    private TMP_Text magnetEquipButtonText;

    [Header("Shield")]
    [SerializeField]
    private TMP_Text shieldCountText;

    [SerializeField]
    private TMP_Text shieldPriceText;

    [SerializeField]
    private Button shieldBuyButton;

    [SerializeField]
    private Button shieldEquipButton;

    [SerializeField]
    private TMP_Text shieldEquipButtonText;

    [Header("Double Coin")]
    [SerializeField]
    private TMP_Text doubleCoinCountText;

    [SerializeField]
    private TMP_Text doubleCoinPriceText;

    [SerializeField]
    private Button doubleCoinBuyButton;

    [SerializeField]
    private Button doubleCoinEquipButton;

    [SerializeField]
    private TMP_Text doubleCoinEquipButtonText;

    [Header("Feedback")]
    [SerializeField, Min(0.1f)]
    private float feedbackDuration = 1.5f;

    private BoosterInventoryManager
        inventoryManager;

    private GameManager gameManager;

    private CanvasGroup shopCanvasGroup;
    private Coroutine feedbackCoroutine;

    private bool listenersBound;

    private void Awake()
    {
        PrepareShopPanel();

        if (feedbackText != null)
        {
            feedbackText.gameObject.SetActive(
                false
            );
        }

        if (shopPanelRoot != null)
        {
            shopPanelRoot.SetActive(false);
        }
    }

    private void Start()
    {
        ResolveReferences();
        BindButtonListeners();
        SubscribeToEvents();
        RefreshAll();
    }

    private void OnDestroy()
    {
        UnsubscribeFromEvents();
        RemoveButtonListeners();
    }

    public void OpenShop()
    {
        ResolveReferences();

        if (
            shopPanelRoot == null ||
            gameManager == null ||
            !gameManager.IsMainMenuActive ||
            gameManager.IsGameOver
        )
        {
            return;
        }

        shopPanelRoot.SetActive(true);

        if (shopCanvasGroup != null)
        {
            shopCanvasGroup.alpha = 1f;
            shopCanvasGroup.interactable = true;
            shopCanvasGroup.blocksRaycasts = true;
        }

        HideFeedback();
        RefreshAll();
    }

    public void CloseShop()
    {
        if (shopPanelRoot == null)
        {
            return;
        }

        HideFeedback();
        shopPanelRoot.SetActive(false);
    }

    private void BuyMagnet()
    {
        TryPurchase(
            PowerUpType.Magnet
        );
    }

    private void BuyShield()
    {
        TryPurchase(
            PowerUpType.Shield
        );
    }

    private void BuyDoubleCoin()
    {
        TryPurchase(
            PowerUpType.DoubleCoin
        );
    }

    private void ToggleMagnet()
    {
        TryToggle(
            PowerUpType.Magnet
        );
    }

    private void ToggleShield()
    {
        TryToggle(
            PowerUpType.Shield
        );
    }

    private void ToggleDoubleCoin()
    {
        TryToggle(
            PowerUpType.DoubleCoin
        );
    }

    private void TryPurchase(
        PowerUpType powerUpType
    )
    {
        ResolveReferences();

        if (
            inventoryManager == null ||
            gameManager == null
        )
        {
            ShowFeedback(
                "SİSTEM BULUNAMADI"
            );

            return;
        }

        int price =
            inventoryManager.GetPrice(
                powerUpType
            );

        if (
            gameManager.TotalCoins <
            price
        )
        {
            ShowFeedback(
                "YETERSİZ COIN"
            );

            return;
        }

        bool purchased =
            inventoryManager.TryPurchase(
                powerUpType
            );

        if (!purchased)
        {
            ShowFeedback(
                "SATIN ALINAMADI"
            );

            return;
        }

        ShowFeedback(
            "SATIN ALINDI"
        );

        RefreshAll();
    }

    private void TryToggle(
        PowerUpType powerUpType
    )
    {
        ResolveReferences();

        if (inventoryManager == null)
        {
            ShowFeedback(
                "SİSTEM BULUNAMADI"
            );

            return;
        }

        if (
            inventoryManager.GetCount(
                powerUpType
            ) <= 0
        )
        {
            ShowFeedback(
                "ÖNCE SATIN AL"
            );

            return;
        }

        bool toggled =
            inventoryManager.ToggleEquipped(
                powerUpType
            );

        if (!toggled)
        {
            ShowFeedback(
                "SEÇİM YAPILAMADI"
            );

            return;
        }

        bool isEquipped =
            inventoryManager.IsEquipped(
                powerUpType
            );

        ShowFeedback(
            isEquipped
                ? "KOŞU İÇİN SEÇİLDİ"
                : "SEÇİM KALDIRILDI"
        );

        RefreshAll();
    }

    private void ResolveReferences()
    {
        if (gameManager == null)
        {
            gameManager =
                GameManager.Instance;

            if (gameManager == null)
            {
                gameManager =
                    FindAnyObjectByType
                        <GameManager>();
            }
        }

        if (inventoryManager == null)
        {
            inventoryManager =
                BoosterInventoryManager
                    .Instance;

            if (inventoryManager == null)
            {
                inventoryManager =
                    FindAnyObjectByType
                        <BoosterInventoryManager>();
            }
        }
    }

    private void BindButtonListeners()
    {
        if (listenersBound)
        {
            return;
        }

        if (openShopButton != null)
        {
            openShopButton.onClick.AddListener(
                OpenShop
            );
        }

        if (closeShopButton != null)
        {
            closeShopButton.onClick.AddListener(
                CloseShop
            );
        }

        if (magnetBuyButton != null)
        {
            magnetBuyButton.onClick.AddListener(
                BuyMagnet
            );
        }

        if (magnetEquipButton != null)
        {
            magnetEquipButton.onClick.AddListener(
                ToggleMagnet
            );
        }

        if (shieldBuyButton != null)
        {
            shieldBuyButton.onClick.AddListener(
                BuyShield
            );
        }

        if (shieldEquipButton != null)
        {
            shieldEquipButton.onClick.AddListener(
                ToggleShield
            );
        }

        if (doubleCoinBuyButton != null)
        {
            doubleCoinBuyButton.onClick.AddListener(
                BuyDoubleCoin
            );
        }

        if (doubleCoinEquipButton != null)
        {
            doubleCoinEquipButton.onClick.AddListener(
                ToggleDoubleCoin
            );
        }

        listenersBound = true;
    }

    private void RemoveButtonListeners()
    {
        if (!listenersBound)
        {
            return;
        }

        if (openShopButton != null)
        {
            openShopButton.onClick.RemoveListener(
                OpenShop
            );
        }

        if (closeShopButton != null)
        {
            closeShopButton.onClick.RemoveListener(
                CloseShop
            );
        }

        if (magnetBuyButton != null)
        {
            magnetBuyButton.onClick.RemoveListener(
                BuyMagnet
            );
        }

        if (magnetEquipButton != null)
        {
            magnetEquipButton.onClick.RemoveListener(
                ToggleMagnet
            );
        }

        if (shieldBuyButton != null)
        {
            shieldBuyButton.onClick.RemoveListener(
                BuyShield
            );
        }

        if (shieldEquipButton != null)
        {
            shieldEquipButton.onClick.RemoveListener(
                ToggleShield
            );
        }

        if (doubleCoinBuyButton != null)
        {
            doubleCoinBuyButton.onClick.RemoveListener(
                BuyDoubleCoin
            );
        }

        if (doubleCoinEquipButton != null)
        {
            doubleCoinEquipButton.onClick.RemoveListener(
                ToggleDoubleCoin
            );
        }

        listenersBound = false;
    }

    private void SubscribeToEvents()
    {
        if (inventoryManager != null)
        {
            inventoryManager.InventoryChanged +=
                RefreshAll;
        }

        if (gameManager != null)
        {
            gameManager.StatsChanged +=
                RefreshAll;

            gameManager.MainMenuChanged +=
                HandleMainMenuChanged;
        }
    }

    private void UnsubscribeFromEvents()
    {
        if (inventoryManager != null)
        {
            inventoryManager.InventoryChanged -=
                RefreshAll;
        }

        if (gameManager != null)
        {
            gameManager.StatsChanged -=
                RefreshAll;

            gameManager.MainMenuChanged -=
                HandleMainMenuChanged;
        }
    }

    private void HandleMainMenuChanged(
        bool isMainMenuOpen
    )
    {
        if (!isMainMenuOpen)
        {
            CloseShop();
            return;
        }

        RefreshAll();
    }

    private void RefreshAll()
    {
        ResolveReferences();

        if (
            inventoryManager == null ||
            gameManager == null
        )
        {
            return;
        }

        if (totalCoinText != null)
        {
            totalCoinText.text =
                $"COIN: {gameManager.TotalCoins}";
        }

        bool shopUsable =
            inventoryManager.CanUseShop;

        UpdateBoosterSlot(
            PowerUpType.Magnet,
            magnetCountText,
            magnetPriceText,
            magnetBuyButton,
            magnetEquipButton,
            magnetEquipButtonText,
            shopUsable
        );

        UpdateBoosterSlot(
            PowerUpType.Shield,
            shieldCountText,
            shieldPriceText,
            shieldBuyButton,
            shieldEquipButton,
            shieldEquipButtonText,
            shopUsable
        );

        UpdateBoosterSlot(
            PowerUpType.DoubleCoin,
            doubleCoinCountText,
            doubleCoinPriceText,
            doubleCoinBuyButton,
            doubleCoinEquipButton,
            doubleCoinEquipButtonText,
            shopUsable
        );
    }

    private void UpdateBoosterSlot(
        PowerUpType powerUpType,
        TMP_Text countText,
        TMP_Text priceText,
        Button buyButton,
        Button equipButton,
        TMP_Text equipButtonText,
        bool shopUsable
    )
    {
        int count =
            inventoryManager.GetCount(
                powerUpType
            );

        int price =
            inventoryManager.GetPrice(
                powerUpType
            );

        bool equipped =
            inventoryManager.IsEquipped(
                powerUpType
            );

        if (countText != null)
        {
            countText.text =
                $"SAHİP: {count}";
        }

        if (priceText != null)
        {
            priceText.text =
                $"{price} COIN";
        }

        if (buyButton != null)
        {
            buyButton.interactable =
                shopUsable &&
                gameManager.TotalCoins >= price;
        }

        if (equipButton != null)
        {
            equipButton.interactable =
                shopUsable &&
                count > 0;
        }

        if (equipButtonText != null)
        {
            equipButtonText.text =
                equipped
                    ? "SEÇİMİ KALDIR"
                    : "KOŞUDA KULLAN";
        }
    }

    private void PrepareShopPanel()
    {
        if (shopPanelRoot == null)
        {
            return;
        }

        shopCanvasGroup =
            shopPanelRoot.GetComponent
                <CanvasGroup>();

        if (shopCanvasGroup == null)
        {
            shopCanvasGroup =
                shopPanelRoot.AddComponent
                    <CanvasGroup>();
        }

        shopCanvasGroup.alpha = 1f;
        shopCanvasGroup.interactable = true;
        shopCanvasGroup.blocksRaycasts = true;
    }

    private void ShowFeedback(
        string message
    )
    {
        if (feedbackText == null)
        {
            return;
        }

        if (feedbackCoroutine != null)
        {
            StopCoroutine(
                feedbackCoroutine
            );
        }

        feedbackCoroutine =
            StartCoroutine(
                FeedbackRoutine(message)
            );
    }

    private IEnumerator FeedbackRoutine(
        string message
    )
    {
        feedbackText.text = message;
        feedbackText.gameObject.SetActive(
            true
        );

        yield return
            new WaitForSecondsRealtime(
                feedbackDuration
            );

        feedbackText.gameObject.SetActive(
            false
        );

        feedbackCoroutine = null;
    }

    private void HideFeedback()
    {
        if (feedbackCoroutine != null)
        {
            StopCoroutine(
                feedbackCoroutine
            );

            feedbackCoroutine = null;
        }

        if (feedbackText != null)
        {
            feedbackText.gameObject.SetActive(
                false
            );
        }
    }
}
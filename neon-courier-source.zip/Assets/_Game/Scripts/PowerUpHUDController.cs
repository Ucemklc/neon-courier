using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class PowerUpHUDController :
    MonoBehaviour
{
    [Header("References")]
    [SerializeField]
    private GameObject powerUpHudRoot;

    [SerializeField]
    private TMP_Text magnetText;

    [SerializeField]
    private TMP_Text shieldText;

    [SerializeField]
    private TMP_Text doubleCoinText;

    [Header("Hoverboard Timer")]
    [SerializeField, Min(0f)]
    private float nearExpiryWarningTime = 2f;

    private TMP_Text hoverboardText;
    private Image hoverboardTimeFill;

    private PowerUpController
        powerUpController;

    private void Start()
    {
        powerUpController =
            PowerUpController.Instance;

        if (powerUpController == null)
        {
            powerUpController =
                FindAnyObjectByType
                    <PowerUpController>();
        }

        CreateHoverboardIndicator();
        RefreshHUD();
    }

    private void Update()
    {
        RefreshHUD();
    }

    public void HideForModernHud()
    {
        if(powerUpHudRoot)powerUpHudRoot.SetActive(false);
    }

    private void RefreshHUD()
    {
        if (CourierRunPolishHUD.Instance) { HideForModernHud(); return; }
        if (powerUpController == null)
        {
            if (powerUpHudRoot != null)
            {
                powerUpHudRoot.SetActive(
                    false
                );
            }

            return;
        }

        bool hasActivePowerUp =
            powerUpController
                .IsMagnetActive ||
            powerUpController
                .IsShieldActive ||
            powerUpController
                .IsDoubleCoinActive ||
            powerUpController
                .IsHoverboardActive;

        if (powerUpHudRoot != null)
        {
            powerUpHudRoot.SetActive(
                hasActivePowerUp
            );
        }

        UpdateStatusText(
            magnetText,
            powerUpController
                .IsMagnetActive,
            "MIKNATIS",
            powerUpController
                .MagnetTimeRemaining
        );

        UpdateStatusText(
            shieldText,
            powerUpController
                .IsShieldActive,
            "KALKAN",
            powerUpController
                .ShieldTimeRemaining
        );

        UpdateStatusText(
            doubleCoinText,
            powerUpController
                .IsDoubleCoinActive,
            "ÇİFT COIN",
            powerUpController
                .DoubleCoinTimeRemaining
        );

        UpdateHoverboardIndicator();
    }

    private void CreateHoverboardIndicator()
    {
        if (
            powerUpHudRoot == null ||
            hoverboardText != null
        )
        {
            return;
        }

        GameObject rowObject = new GameObject(
            "HoverboardTimerHUD",
            typeof(RectTransform)
        );

        rowObject.transform.SetParent(
            powerUpHudRoot.transform,
            false
        );

        RectTransform rowRect =
            rowObject.GetComponent<RectTransform>();

        rowRect.anchorMin = new Vector2(0.5f, 0.5f);
        rowRect.anchorMax = new Vector2(0.5f, 0.5f);
        rowRect.pivot = new Vector2(0.5f, 0.5f);
        rowRect.anchoredPosition = new Vector2(0f, -110f);
        rowRect.sizeDelta = new Vector2(300f, 42f);

        GameObject textObject = new GameObject(
            "HoverboardStatusText",
            typeof(RectTransform),
            typeof(CanvasRenderer),
            typeof(TextMeshProUGUI)
        );

        textObject.transform.SetParent(
            rowObject.transform,
            false
        );

        RectTransform textRect =
            textObject.GetComponent<RectTransform>();

        textRect.anchorMin = new Vector2(0.5f, 0.5f);
        textRect.anchorMax = new Vector2(0.5f, 0.5f);
        textRect.pivot = new Vector2(0.5f, 0.5f);
        textRect.anchoredPosition = new Vector2(0f, 7f);
        textRect.sizeDelta = new Vector2(300f, 30f);

        hoverboardText =
            textObject.GetComponent<TextMeshProUGUI>();

        hoverboardText.font = magnetText != null
            ? magnetText.font
            : TMP_Settings.defaultFontAsset;
        hoverboardText.fontSize = 26f;
        hoverboardText.alignment = TextAlignmentOptions.Center;
        hoverboardText.raycastTarget = false;
        hoverboardText.color = Color.white;

        GameObject trackObject = new GameObject(
            "HoverboardTimeTrack",
            typeof(RectTransform),
            typeof(CanvasRenderer),
            typeof(Image)
        );

        trackObject.transform.SetParent(
            rowObject.transform,
            false
        );

        RectTransform trackRect =
            trackObject.GetComponent<RectTransform>();

        trackRect.anchorMin = new Vector2(0.5f, 0.5f);
        trackRect.anchorMax = new Vector2(0.5f, 0.5f);
        trackRect.pivot = new Vector2(0.5f, 0.5f);
        trackRect.anchoredPosition = new Vector2(0f, -13f);
        trackRect.sizeDelta = new Vector2(250f, 8f);

        Image trackImage = trackObject.GetComponent<Image>();
        trackImage.color = new Color(0.05f, 0.09f, 0.13f, 0.9f);
        trackImage.raycastTarget = false;

        GameObject fillObject = new GameObject(
            "HoverboardTimeFill",
            typeof(RectTransform),
            typeof(CanvasRenderer),
            typeof(Image)
        );

        fillObject.transform.SetParent(
            trackObject.transform,
            false
        );

        RectTransform fillRect =
            fillObject.GetComponent<RectTransform>();

        fillRect.anchorMin = Vector2.zero;
        fillRect.anchorMax = Vector2.one;
        fillRect.offsetMin = Vector2.zero;
        fillRect.offsetMax = Vector2.zero;

        hoverboardTimeFill = fillObject.GetComponent<Image>();
        hoverboardTimeFill.type = Image.Type.Filled;
        hoverboardTimeFill.fillMethod = Image.FillMethod.Horizontal;
        hoverboardTimeFill.fillOrigin = (int)Image.OriginHorizontal.Left;
        hoverboardTimeFill.color = new Color(0.2f, 0.9f, 1f, 1f);
        hoverboardTimeFill.raycastTarget = false;

        rowObject.SetActive(false);
    }

    private void UpdateHoverboardIndicator()
    {
        if (
            hoverboardText == null ||
            powerUpController == null
        )
        {
            return;
        }

        bool isActive =
            powerUpController.IsHoverboardActive;

        hoverboardText.transform.parent.gameObject.SetActive(isActive);

        if (!isActive)
        {
            return;
        }

        float remaining =
            powerUpController.HoverboardTimeRemaining;

        hoverboardText.text =
            $"HOVERBOARD  {Mathf.Max(1, Mathf.CeilToInt(remaining))}s";

        bool warning = remaining <= nearExpiryWarningTime;
        Color warningColor = new Color(1f, 0.36f, 0.16f, 1f);

        hoverboardText.color = warning
            ? warningColor
            : Color.white;

        if (hoverboardTimeFill != null)
        {
            hoverboardTimeFill.fillAmount = Mathf.Clamp01(
                remaining / powerUpController.HoverboardDuration
            );

            hoverboardTimeFill.color = warning
                ? warningColor
                : new Color(0.2f, 0.9f, 1f, 1f);
        }

        if (warning)
        {
            float pulse = 0.72f + Mathf.PingPong(Time.unscaledTime * 1.8f, 0.28f);
            hoverboardText.color = new Color(
                warningColor.r,
                warningColor.g,
                warningColor.b,
                pulse
            );
        }
        else
        {
            hoverboardText.color = Color.white;
        }
    }

    private void UpdateStatusText(
        TMP_Text statusText,
        bool isActive,
        string label,
        float remainingTime
    )
    {
        if (statusText == null)
        {
            return;
        }

        statusText.gameObject.SetActive(
            isActive
        );

        if (!isActive)
        {
            return;
        }

        int displayedSeconds =
            Mathf.Max(
                1,
                Mathf.CeilToInt(
                    remainingTime
                )
            );

        statusText.text =
            $"{label}  {displayedSeconds}";
    }
}

#if UNITY_EDITOR
using System.IO;
using UnityEditor;
using UnityEngine;

public static class NeonRailPreview
{
    [MenuItem("Neon Courier/Capture Rail Asset Preview")]
    public static void Capture()
    {
        var preview = new PreviewRenderUtility();
        Texture2D image = null;
        try
        {
            var root = new GameObject("Rail assets preview");
            preview.AddSingleGO(root);
            var train = Object.Instantiate(Resources.Load<GameObject>("NeonRail/NeonCargoTrain"), root.transform);
            var car = Object.Instantiate(Resources.Load<GameObject>("NeonRail/NeonCargoCar"), root.transform);
            car.transform.localPosition = new Vector3(2.5f, 0f, 0f);
            var sign = Object.Instantiate(Resources.Load<GameObject>("NeonRail/RampRouteSign"), root.transform);
            sign.transform.localPosition = new Vector3(-2.6f, 0f, -3.5f);
            preview.camera.transform.position = new Vector3(-15f, 12.5f, -15f);
            preview.camera.transform.LookAt(new Vector3(.5f, 1f, 5.5f));
            preview.camera.fieldOfView = 42f;
            preview.camera.nearClipPlane = .1f;
            preview.camera.farClipPlane = 100f;
            preview.camera.clearFlags = CameraClearFlags.SolidColor;
            preview.camera.backgroundColor = new Color(.012f, .025f, .045f);
            preview.ambientColor = new Color(.38f, .42f, .5f);
            preview.lights[0].intensity = 1.7f;
            preview.lights[0].transform.rotation = Quaternion.Euler(35f, 30f, 0f);
            preview.lights[1].intensity = 1.2f;
            preview.lights[1].color = new Color(.4f, .8f, 1f);
            preview.lights[1].transform.rotation = Quaternion.Euler(55f, -130f, 0f);
            preview.BeginStaticPreview(new Rect(0f, 0f, 1400f, 1000f));
            preview.Render(true, false);
            image = preview.EndStaticPreview();
            Directory.CreateDirectory("Logs");
            File.WriteAllBytes("Logs/NeonRailPreview.png", image.EncodeToPNG());
            Debug.Log("NEON_RAIL_PREVIEW_OK Logs/NeonRailPreview.png");
        }
        finally
        {
            if (image != null) Object.DestroyImmediate(image);
            preview.Cleanup();
        }
    }
}
#endif

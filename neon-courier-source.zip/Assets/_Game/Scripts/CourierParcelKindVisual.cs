using UnityEngine;

/// <summary>Shared parcel geometry with a per-instance color and a clear cargo symbol.</summary>
public sealed class CourierParcelKindVisual : MonoBehaviour
{
    private Renderer[] renderers;
    private MaterialPropertyBlock block;
    private GameObject[] badges;
    public void Apply(CourierCargoKind kind)
    {
        if(renderers==null){renderers=GetComponentsInChildren<Renderer>(true);block=new MaterialPropertyBlock();}
        Color accent=CourierWorldRules.CargoColor(kind);
        foreach(var renderer in renderers)
        {
            if(!renderer || !renderer.sharedMaterial)continue;
            string material=renderer.sharedMaterial.name;
            if(!material.Contains("SafetyTangerine")&&!material.Contains("SignalCyan"))continue;
            renderer.GetPropertyBlock(block);block.SetColor("_BaseColor",accent);
            if(material.Contains("SignalCyan"))block.SetColor("_EmissionColor",accent*1.1f);
            renderer.SetPropertyBlock(block);
        }
        if(badges==null)badges=new GameObject[4];
        for(int i=0;i<badges.Length;i++)if(badges[i])badges[i].SetActive(false);
        int index=(int)kind;
        if(index==0)return;
        if(!badges[index])
        {
            var asset=Resources.Load<GameObject>("CourierExpansion/CargoBadge"+index);
            if(!asset)return;
            badges[index]=Instantiate(asset,transform,false);
            badges[index].transform.localPosition=new Vector3(0,.51f,0);
        }
        badges[index].SetActive(true);
    }
}

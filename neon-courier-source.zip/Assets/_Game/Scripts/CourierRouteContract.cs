using UnityEngine;

/// <summary>Three ordered customers make one contract; ordinary delivery payouts still apply.</summary>
public sealed class CourierRouteContract : MonoBehaviour
{
    public static CourierRouteContract Instance { get; private set; }
    private GameManager manager;
    private int firstCustomer;
    private float lastStopZ=float.NegativeInfinity,reviewUntil;
    private string reviewTr="",reviewEn="";
    public int StopsCompleted { get; private set; }
    public int ContractsCompleted { get; private set; }
    public int NextCustomer=>(firstCustomer+StopsCompleted)%4;
    public bool ShowingReview=>Time.unscaledTime<reviewUntil;
    public string Review(bool english)=>english?reviewEn:reviewTr;
    public static string CustomerName(int index,bool en=false)=>new[]{"MİNA",en?"EFE'S SHOP":"EFE BÜFE",en?"ADA APARTMENTS":"ADA APARTMANI",en?"SMART LOCKER":"AKILLI DOLAP"}[Mathf.Clamp(index,0,3)];
    private void Awake(){Instance=this;manager=GetComponent<GameManager>();}
    private void Start(){manager.MainMenuChanged+=MenuChanged;}
    private void OnDestroy(){if(manager)manager.MainMenuChanged-=MenuChanged;if(Instance==this)Instance=null;}
    private void MenuChanged(bool open){if(open){firstCustomer=0;StopsCompleted=0;ContractsCompleted=0;lastStopZ=float.NegativeInfinity;reviewUntil=0;}}
    public bool CompleteStop(int customer,float worldZ,int packages)
    {
        if(!manager||!manager.IsRunActive||manager.IsPaused||manager.IsGameOver||packages<=0||worldZ<=lastStopZ+.1f)return false;
        lastStopZ=worldZ;customer=Mathf.Clamp(customer,0,3);
        bool reset=customer!=NextCustomer;
        if(reset){firstCustomer=customer;StopsCompleted=0;}
        StopsCompleted++;
        reviewTr=reset?"Yeni rota başladı • Teslimat için teşekkürler!":"Müşteri: Paketim geldi, teşekkürler!";
        reviewEn=reset?"New route started • Thanks for the delivery!":"Customer: My parcel arrived. Thank you!";
        if(StopsCompleted==3)
        {
            int bonus=40+(CourierCharacterAbilities.ActiveIndex==0?10:0);
            manager.GrantRunBonus(bonus);ContractsCompleted++;
            CourierCareerProgress.RecordContract();
            reviewTr="3 DURAK TAMAM! +"+bonus+" COIN • Harika teslimat!";
            reviewEn="3 STOPS COMPLETE! +"+bonus+" COINS • Great service!";
            firstCustomer=(customer+1)%4;StopsCompleted=0;
        }
        reviewUntil=Time.unscaledTime+4;return true;
    }
    public string RouteText(bool en)
    {
        if(ShowingReview)return Review(en);
        int bonus=CourierCharacterAbilities.ActiveIndex==0?50:40;
        return (en?"STOP ":"DURAK ")+(StopsCompleted+1)+"/3  •  "+CustomerName(NextCustomer,en)+(en?"  •  3 stops: +":"  •  3 durak: +")+bonus+" coin";
    }
}

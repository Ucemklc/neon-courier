using UnityEngine;

[DefaultExecutionOrder(110)]
public sealed class CourierWeather : MonoBehaviour
{
    public static RunnerController Runner{get;private set;}
    public enum Weather{Sunset,Night,Rain}
    public Weather Current{get;private set;}
    public ParticleSystem Rain{get;private set;}
    private Camera cameraView;
    private Light sun;
    private Color oldLight,oldBackground,oldFog;
    private float oldIntensity;
    private Transform puddles;
    private AudioSource ambience;
    private readonly AudioClip[] clips=new AudioClip[3];
    private bool initialized;
    private void Start()
    {
        Runner=FindAnyObjectByType<RunnerController>();cameraView=Camera.main;
        foreach(var light in FindObjectsByType<Light>(FindObjectsSortMode.None))if(light.type==LightType.Directional){sun=light;break;}
        if(sun){oldLight=sun.color;oldIntensity=sun.intensity;}oldFog=RenderSettings.fogColor;if(cameraView)oldBackground=cameraView.backgroundColor;
        var rainPrefab=Resources.Load<GameObject>("CourierJourney/Rain");if(rainPrefab){Rain=Instantiate(rainPrefab).GetComponent<ParticleSystem>();Rain.Stop(true,ParticleSystemStopBehavior.StopEmittingAndClear);}
        var puddlePrefab=Resources.Load<GameObject>("CourierJourney/Puddles");if(puddlePrefab){puddles=Instantiate(puddlePrefab).transform;puddles.gameObject.SetActive(false);}
        ambience=gameObject.AddComponent<AudioSource>();ambience.loop=true;ambience.playOnAwake=false;ambience.spatialBlend=0;ambience.volume=.16f;
        clips[0]=Resources.Load<AudioClip>("CourierJourney/SunsetAmbience");clips[1]=Resources.Load<AudioClip>("CourierJourney/NightAmbience");clips[2]=Resources.Load<AudioClip>("CourierJourney/RainAmbience");initialized=true;
        GetComponent<GameManager>().PauseChanged+=PauseRain;
    }
    private void PauseRain(bool paused){if(paused&&Rain&&Rain.isPlaying)Rain.Pause();}
    public static Weather AtDistance(float distance)=>(Weather)(Mathf.FloorToInt(Mathf.Max(0,distance)/600)%3);
    public string Label(bool en)=>Current==Weather.Sunset?(en?"SUNSET":"GÜN BATIMI"):Current==Weather.Night?(en?"NEON NIGHT":"NEON GECE"):(en?"RAINY STREETS":"YAĞMURLU SOKAKLAR");
    private void LateUpdate()
    {
        if(!initialized||!Runner)return;var gm=GameManager.Instance;
        if(gm&&!gm.IsPaused&&!gm.IsGameOver)Current=AtDistance(Runner.transform.position.z);
        Color fog=Current==Weather.Sunset?new Color(.37f,.25f,.31f):Current==Weather.Night?new Color(.075f,.13f,.24f):new Color(.13f,.23f,.30f);
        Color light=Current==Weather.Sunset?new Color(1,.75f,.60f):Current==Weather.Night?new Color(.55f,.72f,1):new Color(.65f,.85f,1);
        float blend=1-Mathf.Exp(-Time.deltaTime*.8f);
        RenderSettings.fogColor=Color.Lerp(RenderSettings.fogColor,fog,blend);
        if(cameraView)cameraView.backgroundColor=RenderSettings.fogColor;
        if(sun){sun.color=Color.Lerp(sun.color,light,blend);sun.intensity=Mathf.Lerp(sun.intensity,oldIntensity*(Current==Weather.Sunset?1:Current==Weather.Night?.70f:.82f),blend);}
        bool wet=Current==Weather.Rain;
        if(Rain)
        {
            Rain.transform.position=Runner.transform.position+new Vector3(0,10,13);
            if(wet&&CourierJourney.Active){if(!Rain.isPlaying)Rain.Play();}
            else if(wet&&gm&&gm.IsPaused){if(Rain.isPlaying)Rain.Pause();}
            else if(!Rain.isStopped)Rain.Stop(true,ParticleSystemStopBehavior.StopEmittingAndClear);
        }
        if(puddles){puddles.gameObject.SetActive(wet);puddles.position=new Vector3(0,0,Mathf.Floor(Runner.transform.position.z/72)*72);}
        bool sound=CourierJourney.Active&&gm.IsSoundEnabled;
        var clip=clips[(int)Current];
        if(ambience.clip!=clip){ambience.Stop();ambience.clip=clip;}
        if(sound&&clip){if(!ambience.isPlaying)ambience.UnPause();if(!ambience.isPlaying)ambience.Play();}else if(ambience.isPlaying)ambience.Pause();
    }
    private void OnDestroy()
    {
        if(!initialized)return;
        GetComponent<GameManager>().PauseChanged-=PauseRain;
        if(sun){sun.color=oldLight;sun.intensity=oldIntensity;}if(cameraView)cameraView.backgroundColor=oldBackground;RenderSettings.fogColor=oldFog;
        if(Rain)Destroy(Rain.gameObject);if(puddles)Destroy(puddles.gameObject);Runner=null;
    }
}

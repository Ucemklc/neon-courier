using UnityEngine;

/// <summary>
/// Marks a train root whose upward-facing ramp and roof can be ridden.
/// Its child colliders still count as obstacles when struck from the side.
/// </summary>
[DisallowMultipleComponent]
public sealed class RailRideSurface : MonoBehaviour
{
    private readonly System.Collections.Generic.List<GameObject> rideContents =
        new System.Collections.Generic.List<GameObject>();

    public void RegisterContent(GameObject content)
    {
        if (content != null && !rideContents.Contains(content)) rideContents.Add(content);
    }

    private void OnDisable()
    {
        // The pickup pool remains on its tile; hide its elevated contents when
        // a side hit removes the supporting carriage.
        foreach (GameObject content in rideContents)
            if (content != null) content.SetActive(false);
        rideContents.Clear();
    }

    public bool IsSafeContact(Vector3 normal)
    {
        return normal.y >= 0.45f;
    }
}

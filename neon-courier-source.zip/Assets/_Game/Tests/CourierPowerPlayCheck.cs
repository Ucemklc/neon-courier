#if UNITY_EDITOR
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using TMPro;
using UnityEditor;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;
using Object=UnityEngine.Object;

public sealed class CourierPowerPlayCheck:MonoBehaviour
{
    private const BindingFlags Hidden=BindingFlags.Instance|BindingFlags.NonPublic;
    private readonly List<string> report=new List<string>();
    private GameManager gm;private RunnerController runner;private PowerUpController power;private CourierPowerEffects fx;
    [MenuItem("Neon Courier/Run Power Checks")]
    public static void Run()
    {
        if(EditorApplication.isPlayingOrWillChangePlaymode)return;CourierPolishPreferences.Capture();
        PlayerPrefs.SetInt("NeonCourier_StoryIntro_Seen_v1",1);PlayerPrefs.SetInt("NeonCourier.TutorialCompleted",1);PlayerPrefs.SetInt("NeonCourier.Language",0);
        for(int i=1;i<=4;i++)PlayerPrefs.SetInt("NeonCourier.CharacterUnlocked.courier_0"+i,1);
        SessionState.SetBool("CourierPower.QA",true);EditorApplication.EnterPlaymode();
    }
    [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
    private static void Boot()
    {
        if(!SessionState.GetBool("CourierPower.QA",false))return;SessionState.SetBool("CourierPower.QA",false);
        foreach(var intro in Object.FindObjectsByType<StoryIntroController>(FindObjectsSortMode.None))intro.enabled=false;
        foreach(var tutorial in Object.FindObjectsByType<TutorialController>(FindObjectsSortMode.None))tutorial.enabled=false;
        var story=GameObject.Find("StoryIntroCanvas");if(story)story.SetActive(false);
        new GameObject("Power checks").AddComponent<CourierPowerPlayCheck>();
    }
    private IEnumerator Start()
    {
        float oldDelta=Time.captureDeltaTime;int oldRate=Application.targetFrameRate;
        Time.timeScale=1;Time.captureDeltaTime=1f/60;Application.targetFrameRate=120;
        Directory.CreateDirectory("Logs");Application.logMessageReceived+=Log;
        var stack=new Stack<IEnumerator>();stack.Push(Checks());double deadline=EditorApplication.timeSinceStartup+240;
        while(stack.Count>0)
        {
            bool moved=false;object next=null;Exception error=null;
            try{if(EditorApplication.timeSinceStartup>deadline)throw new TimeoutException("Power QA deadline");moved=stack.Peek().MoveNext();if(moved)next=stack.Peek().Current;}catch(Exception e){error=e;}
            if(error!=null){Check(false,error.ToString());break;}if(!moved){(stack.Pop() as IDisposable)?.Dispose();continue;}
            if(next is IEnumerator nested)stack.Push(nested);else yield return next;
        }
        while(stack.Count>0)(stack.Pop() as IDisposable)?.Dispose();
        Application.logMessageReceived-=Log;Time.timeScale=1;Time.captureDeltaTime=oldDelta;Application.targetFrameRate=oldRate;
        report.Add("COMPLETE failures="+report.Count(s=>s.StartsWith("FAIL")));File.WriteAllLines("Logs/CourierPowerChecks.txt",report);EditorApplication.isPlaying=false;
    }
    private void Log(string message,string trace,LogType type){if(type==LogType.Error||type==LogType.Exception)Check(false,"Unity: "+message);}
    private void Check(bool value,string message){report.Add((value?"PASS ":"FAIL ")+message);File.WriteAllLines("Logs/CourierPowerChecks.txt",report);}
    private IEnumerator Frames(int count){for(int i=0;i<count;i++)yield return null;}
    private IEnumerator Capture(string name){yield return Frames(10);ScreenCapture.CaptureScreenshot("Logs/Power-"+name+".png");yield return Frames(6);}
    private IEnumerator Checks()
    {
        yield return Frames(15);gm=GameManager.Instance;runner=Object.FindAnyObjectByType<RunnerController>();power=PowerUpController.Instance;fx=runner.GetComponent<CourierPowerEffects>();
        Check(fx&&fx.Board,"Power visuals attach to the production runner");
        foreach(string name in new[]{"Coin","MagnetPickup","ShieldPickup","DoubleCoinPickup","HoverboardPickup","Hoverboard","ShieldField","MagnetField","CoinField","ShieldBreak"})
        {
            var asset=Resources.Load<GameObject>("CourierPowers/"+name);Check(asset&&asset.GetComponentsInChildren<Collider>(true).Length==0,name+" is a visual-only prefab");
            Check(asset.GetComponentsInChildren<Renderer>(true).All(r=>r.sharedMaterial&&r.sharedMaterial.shader.isSupported),name+" uses supported materials");
        }
        gm.OpenMainMenu();yield return Frames(2);Check(!fx.Board.gameObject.activeSelf&&!fx.ShieldVisible&&!fx.MagnetVisible,"Power effects stay hidden in the menu");
        gm.StartGameFromMenu();float deadline=Time.realtimeSinceStartup+7;while(!gm.IsRunActive&&Time.realtimeSinceStartup<deadline)yield return null;Check(gm.IsRunActive,"Run starts normally");
        runner.enabled=false;Set(gm,"speedGainPerSecond",0f);Property(gm,"CurrentSpeed",0f);runner.SetForwardSpeed(0);
        foreach(var track in Object.FindObjectsByType<TrackManager>(FindObjectsSortMode.None))track.gameObject.SetActive(false);
        var ground=GameObject.CreatePrimitive(PrimitiveType.Cube);ground.transform.position=new Vector3(0,-.25f,100);ground.transform.localScale=new Vector3(20,.5f,400);
        Warp(0,4);yield return Pickups();yield return Board();yield return Shield();yield return Magnet();yield return Hud();
        Destroy(ground);yield return Showcase();
        for(int i=0;i<5;i++)power.ActivatePowerUp((PowerUpType)i);yield return Frames(2);gm.TriggerGameOver();yield return Frames(3);Check(!fx.ShieldVisible&&!fx.MagnetVisible&&!fx.CoinAuraVisible&&!fx.Board.gameObject.activeSelf,"Game over clears all active effects");
        gm.OpenMainMenu();yield return Frames(2);Check(!power.IsShieldActive&&!power.IsMagnetActive&&!power.IsHoverboardActive,"Return to menu clears power timers");
    }
    private IEnumerator Pickups()
    {
        var obj=Instantiate(AssetDatabase.LoadAssetAtPath<GameObject>("Assets/_Game/Prefabs/PF_PowerUp.prefab"));obj.transform.position=new Vector3(0,2,12);var pickup=obj.GetComponent<PowerUpPickup>();
        for(int i=0;i<4;i++)
        {
            pickup.Configure((PowerUpType)i);yield return null;
            var visuals=obj.GetComponentsInChildren<Transform>().Where(t=>t.name.StartsWith("Courier")&&t.parent==obj.transform).ToArray();
            Check(visuals.Length==1,"Pickup "+i+" displays exactly one replacement model");
            Check(obj.GetComponentsInChildren<Renderer>().All(r=>!r.name.Contains("Visual")),"Pickup "+i+" hides old model roots");
            Call(pickup,"Collect");Check(!obj.activeSelf&&power.GetRemainingTime((PowerUpType)i)>0,"New model "+i+" retains pickup behavior");obj.SetActive(true);Call(power,"ResetAllPowerUps");
        }
        for(int cycle=0;cycle<30;cycle++)pickup.Configure((PowerUpType)(cycle%4));
        Check(obj.transform.Cast<Transform>().Count(t=>t.name.StartsWith("Courier"))==4,"Changing pooled power types reuses four visual instances");Destroy(obj);yield return null;
        var coin=NewCoin(new Vector3(0,1.2f,12),false);var visual=coin.transform.Find("CourierCoinVisual");
        var bounds=new Bounds(visual.position,Vector3.zero);foreach(var r in visual.GetComponentsInChildren<MeshRenderer>())bounds.Encapsulate(r.bounds);
        Check(bounds.size.x>.5f&&bounds.size.x<.7f&&bounds.size.y>.5f&&bounds.size.y<.7f,"Coin keeps consistent world dimensions on the imported prefab");
        power.ActivatePowerUp(PowerUpType.DoubleCoin);int total=gm.TotalCoins,earned=gm.EarnedCoinsThisRun,mult=gm.CurrentCoinMultiplier;
        Call(coin,"OnTriggerEnter",runner.GetComponent<CharacterController>());Call(coin,"OnTriggerEnter",runner.GetComponent<CharacterController>());
        Check(gm.TotalCoins==total+mult&&gm.EarnedCoinsThisRun==earned+mult,"Coin pays once with multiplier and appears in run earnings");
        var sparkle=GameObject.Find("CoinPickupSparkle");Check(sparkle&&sparkle.GetComponent<ParticleSystem>().colorOverLifetime.enabled,"Coin collection emits a fading gold burst");
        coin.ResetCoin();Check(coin.CanCollect&&coin.GetComponent<Collider>().enabled,"Recycled coin restores model and collider");
        gm.PauseGame();total=gm.TotalCoins;Call(coin,"OnTriggerEnter",runner.GetComponent<CharacterController>());Check(gm.TotalCoins==total&&coin.CanCollect,"Pause cannot consume a coin");gm.ResumeGame();runner.enabled=false;
        Destroy(coin.gameObject);Call(power,"ResetAllPowerUps");yield return null;
    }
    private IEnumerator Board()
    {
        var selection=Object.FindAnyObjectByType<CharacterSelectionManager>();
        for(int skin=0;skin<4;skin++)
        {
            selection.SelectCharacter(skin);Warp(0,4);power.ActivatePowerUp(PowerUpType.Hoverboard);runner.enabled=true;yield return Frames(38);
            Check(fx.Board.gameObject.activeSelf&&fx.StanceWeight>.99f,"Courier "+skin+" enters the board stance");
            foreach(var bone in new[]{HumanBodyBones.LeftFoot,HumanBodyBones.RightFoot})
            {var foot=runner.CurrentAnimator.GetBoneTransform(bone);var local=fx.Board.InverseTransformPoint(foot.position);Check(Mathf.Abs(local.x)<.38f&&Mathf.Abs(local.z)<.65f&&local.y>.08f&&local.y<.28f,"Courier "+skin+" "+bone+" stays on deck ("+local+")");}
            Set(runner,"currentLane",2);yield return Frames(7);Check(Mathf.Abs(fx.BankAngle)>2,"Courier "+skin+" banks while changing lanes");
            yield return Frames(24);float y=runner.transform.position.y,left=power.HoverboardTimeRemaining;gm.PauseGame();var boardPosition=fx.Board.position;yield return Frames(10);
            Check(Mathf.Abs(runner.transform.position.y-y)<.005f&&Mathf.Approximately(left,power.HoverboardTimeRemaining)&&Vector3.Distance(boardPosition,fx.Board.position)<.005f,"Pause preserves hover height, timer and board for courier "+skin);
            gm.ResumeGame();yield return Frames(2);Check(runner.transform.position.y>6,"Resuming does not restart takeoff");
            Set(power,"hoverboardTimeRemaining",0f);yield return Frames(3);Check(fx.Board.gameObject.activeSelf&&runner.IsHoverboardMovementActive,"Board remains visible during descent for courier "+skin);
            yield return Frames(60);Check(!fx.Board.gameObject.activeSelf&&fx.StanceWeight==0&&runner.transform.position.y<1.2f,"Landing restores running for courier "+skin);
        }
        runner.enabled=false;selection.SelectCharacter(0);yield return null;
    }
    private IEnumerator Shield()
    {
        Warp(0,4);power.ActivatePowerUp(PowerUpType.Shield);yield return Frames(3);Check(fx.ShieldVisible,"Armor surrounds the courier when active");
        int lives=gm.CurrentLives;gm.HandlePlayerHit();yield return null;Check(gm.CurrentLives==lives&&!power.IsShieldActive&&!fx.ShieldVisible&&fx.ShieldBurstVisible,"Absorbed hit breaks the field without losing health");
        gm.PauseGame();yield return Frames(35);Check(fx.ShieldBurstVisible,"Pause freezes the armor break effect");gm.ResumeGame();runner.enabled=false;yield return Frames(35);Check(!fx.ShieldBurstVisible,"Armor fragments clean up after the burst");
        power.ActivatePowerUp(PowerUpType.Shield);Set(power,"shieldTimeRemaining",.02f);yield return Frames(4);Check(!fx.ShieldVisible&&!fx.ShieldBurstVisible,"Natural armor expiry hides without a false hit burst");
    }
    private IEnumerator Magnet()
    {
        foreach(float speed in new[]{9.5f,15.5f,25f})
        {
            Warp(0,4);Property(gm,"CurrentSpeed",speed);runner.SetForwardSpeed(speed);power.ActivatePowerUp(PowerUpType.Magnet);runner.enabled=true;
            var coin=NewCoin(runner.transform.position+new Vector3(2.5f,0,4),false);int before=gm.TotalCoins;
            var package=Instantiate(AssetDatabase.LoadAssetAtPath<GameObject>("Assets/_Game/Prefabs/PF_Package.prefab"));package.SetActive(false);package.transform.position=runner.transform.position+new Vector3(-2.5f,0,4);package.SetActive(true);int cargo=gm.CarriedPackages;
            yield return Frames(55);Check(gm.TotalCoins>before&&gm.CarriedPackages>cargo,"Magnet collects across lanes at speed "+speed);Check(fx.MagnetVisible,"Magnet rings are visible at speed "+speed);
            Destroy(coin.gameObject);Destroy(package);runner.enabled=false;Call(power,"ResetAllPowerUps");
        }
        Property(gm,"CurrentSpeed",0f);runner.SetForwardSpeed(0);Warp(0,4);power.ActivatePowerUp(PowerUpType.Magnet);
        var restricted=NewCoin(runner.transform.position+new Vector3(0,0,3),true);yield return Frames(8);Check(!restricted.CanCollect&&(restricted.transform.position-runner.transform.position).magnitude>2,"Air coin still requires the hoverboard");Destroy(restricted.gameObject);
        var loose=NewCoin(runner.transform.position+new Vector3(2.5f,0,4),false);yield return Frames(2);var trail=loose.GetComponentInChildren<TrailRenderer>();Check(trail&&trail.emitting,"Attracted coin emits a short light trail");
        gm.PauseGame();var pos=loose.transform.position;float left=power.MagnetTimeRemaining;yield return Frames(10);Check(Vector3.Distance(pos,loose.transform.position)<.005f&&left==power.MagnetTimeRemaining,"Pause freezes attraction and power time");gm.ResumeGame();runner.enabled=false;
        Set(power,"magnetTimeRemaining",0f);pos=loose.transform.position;yield return Frames(3);Check(Vector3.Distance(pos,loose.transform.position)<.25f&&!trail.emitting&&!fx.MagnetVisible,"Magnet expiry releases coin in place and ends the trail");
        loose.gameObject.SetActive(false);loose.transform.position+=Vector3.forward*20;loose.ResetCoin();Check(trail.positionCount==0&&!trail.emitting,"Pooled coins do not draw a trail across the level");Destroy(loose.gameObject);yield return null;
    }
    private IEnumerator Hud()
    {
        for(int i=0;i<5;i++)power.ActivatePowerUp((PowerUpType)i);yield return Frames(3);Canvas.ForceUpdateCanvases();
        var hud=CourierRunPolishHUD.Instance;var cards=hud.transform.Cast<Transform>().Where(t=>t.name.StartsWith("PowerTimer")||t.name=="JumpShoesTimer").ToArray();
        Check(cards.Length==5&&cards.All(t=>t.gameObject.activeSelf),"All five powers have a visible countdown");
        bool separate=true;for(int i=0;i<cards.Length;i++)for(int j=i+1;j<cards.Length;j++)separate&=!Rect(cards[i]).Overlaps(Rect(cards[j]));Check(separate,"Five timer cards do not overlap");
        foreach(var b in Object.FindObjectsByType<Button>(FindObjectsSortMode.None).Where(b=>b.name.Contains("Pause")))Check(cards.All(t=>!Rect(t).Overlaps(Rect(b.transform))),"Power cards leave pause button unobstructed");
        foreach(var text in cards.SelectMany(t=>t.GetComponentsInChildren<TMP_Text>())){text.ForceMeshUpdate();Check(text.textInfo.lineCount==2,"Timer label fits two lines: "+text.text);}
        Check(cards.SelectMany(t=>t.GetComponentsInChildren<Graphic>()).All(g=>!g.raycastTarget),"Power cards do not intercept gameplay input");
        PlayerPrefs.SetInt("NeonCourier.Language",1);yield return null;Check(cards.SelectMany(t=>t.GetComponentsInChildren<TMP_Text>()).Any(t=>t.text.Contains("ARMOR")),"Power cards support English labels");PlayerPrefs.SetInt("NeonCourier.Language",0);Call(power,"ResetAllPowerUps");
    }
    private IEnumerator Showcase()
    {
        var world=new GameObject("Power presentation road");for(int i=0;i<5;i++){var tile=Instantiate(AssetDatabase.LoadAssetAtPath<GameObject>("Assets/_Game/Prefabs/TrackTile_Prototype.prefab"),world.transform);tile.transform.localPosition=new Vector3(0,0,-10+i*30);tile.GetComponent<TrackTileContent>().ClearPattern();tile.GetComponent<CityTileDecorator>()?.RefreshLayout();}
        Warp(0,4);Property(gm,"CurrentSpeed",0f);runner.SetForwardSpeed(0);yield return Frames(80);
        foreach(var type in new[]{PowerUpType.Shield,PowerUpType.Magnet,PowerUpType.DoubleCoin}){Call(power,"ResetAllPowerUps");power.ActivatePowerUp(type);yield return Capture(type.ToString());}
        Call(power,"ResetAllPowerUps");power.ActivatePowerUp(PowerUpType.Hoverboard);Property(gm,"CurrentSpeed",9.5f);runner.SetForwardSpeed(9.5f);runner.enabled=true;yield return Frames(40);yield return Capture("Hoverboard");
        var boardScreen=Camera.main.WorldToViewportPoint(fx.Board.position);Check(boardScreen.y>.22f,"Hoverboard camera keeps the deck above the bottom HUD");
        for(int i=0;i<5;i++)power.ActivatePowerUp((PowerUpType)i);yield return Capture("AllPowers");
        Call(power,"ResetAllPowerUps");yield return Frames(65);runner.enabled=false;Warp(0,4);
        for(int i=0;i<4;i++){var pickup=Instantiate(AssetDatabase.LoadAssetAtPath<GameObject>("Assets/_Game/Prefabs/PF_PowerUp.prefab"),world.transform);pickup.transform.position=new Vector3((i%2==0?-1:1)*2,1.3f,9+(i/2)*3);pickup.GetComponent<PowerUpPickup>().Configure((PowerUpType)i);Set(pickup.GetComponent<PowerUpPickup>(),"rotationSpeed",0f);pickup.transform.rotation=Quaternion.identity;pickup.SetActive(false);pickup.GetComponent<TrackPowerUpTypeRandomizer>().enabled=false;pickup.SetActive(true);}
        for(int i=0;i<6;i++){var coin=NewCoin(new Vector3(0,1.2f,9+i*1.7f),false);coin.transform.SetParent(world.transform,true);}
        yield return Capture("Pickups");Destroy(world);
    }
    private AirCoinPickup NewCoin(Vector3 position,bool restricted)
    {var coin=Instantiate(AssetDatabase.LoadAssetAtPath<GameObject>("Assets/_Game/Prefabs/PF_AirCoin.prefab")).GetComponent<AirCoinPickup>();coin.transform.position=position;Set(coin,"requireHoverboard",restricted);coin.ResetCoin();return coin;}
    private void Warp(float x,float z){runner.enabled=false;var cc=runner.GetComponent<CharacterController>();cc.enabled=false;runner.transform.position=new Vector3(x,1.08f,z);Set(runner,"currentLane",Mathf.Clamp(Mathf.RoundToInt(x/2.5f)+1,0,2));Set(runner,"verticalVelocity",-2f);Set(runner,"horizontalVelocity",0f);cc.enabled=true;Physics.SyncTransforms();var camera=Camera.main.GetComponent<CameraFollow>();Set(camera,"movementVelocity",Vector3.zero);Call(camera,"InitializeFollowPosition");camera.transform.LookAt(runner.transform.position+new Vector3(0,1.35f,5.2f));}
    private static Rect Rect(Transform t){var v=new Vector3[4];((RectTransform)t).GetWorldCorners(v);return new Rect(v[0],v[2]-v[0]);}
    private static void Set(object obj,string field,object value)=>obj.GetType().GetField(field,Hidden).SetValue(obj,value);
    private static void Property(object obj,string name,object value)=>obj.GetType().GetProperty(name).SetValue(obj,value);
    private static object Call(object obj,string name,params object[] args)=>obj.GetType().GetMethod(name,Hidden).Invoke(obj,args);
}
#endif

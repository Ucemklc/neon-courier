#if UNITY_EDITOR
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using Object=UnityEngine.Object;

public static class CourierPolishAssets
{
    private const string Folder="Assets/Resources/CourierPolish";
    private static Material navy,panel,rubber,ivory,orange,cyan,glass;
    private static readonly List<Mesh> TemporaryMeshes=new List<Mesh>();
    private static readonly Dictionary<string,Mesh> BoxMeshes=new Dictionary<string,Mesh>();
    [MenuItem("Neon Courier/Apply Courier Polish")]
    public static void Apply()
    {
        if(EditorApplication.isPlayingOrWillChangePlaymode)throw new InvalidOperationException("Stop Play before applying courier polish.");
        var scene=SceneManager.GetActiveScene();
        if(scene.path!="Assets/ArtTest_Backup_BeforeIntro.unity" || scene.isDirty)throw new InvalidOperationException("Open the saved game scene first.");
        Directory.CreateDirectory("CodexBackups/CourierPolish-20260925");
        string backup="CodexBackups/CourierPolish-20260925/ArtTest_Backup_BeforeIntro.unity";
        if(!File.Exists(backup))File.Copy(scene.path,backup);
        Generate();
        CourierMenuLayout.Apply();
        var camera=Object.FindAnyObjectByType<CameraFollow>();
        if(camera)
        {
            var framing=new SerializedObject(camera);
            framing.FindProperty("offset").vector3Value=new Vector3(0,4.4f,-8f);
            framing.FindProperty("lookOffset").vector3Value=new Vector3(0,1.35f,2.5f);
            framing.ApplyModifiedPropertiesWithoutUndo();
        }
        var selection=Object.FindAnyObjectByType<CharacterSelectionManager>();
        var so=new SerializedObject(selection);var entries=so.FindProperty("characters");
        for(int i=0;i<entries.arraySize;i++)
        {
            var entry=entries.GetArrayElementAtIndex(i);entry.FindPropertyRelative("displayName").stringValue=new[]{"NEON KURYE","EKSPRES KURYE","SANAYİ KURYESİ","GECE KURYESİ"}[i];
        }
        so.ApplyModifiedPropertiesWithoutUndo();
        var feedback=Object.FindAnyObjectByType<GameFeedbackController>();
        var music=AssetDatabase.FindAssets("0130_Intrusion-Detected_Full t:AudioClip").Select(AssetDatabase.GUIDToAssetPath).First(p=>p.Contains("/Loops/"));
        var f=new SerializedObject(feedback);f.FindProperty("gameplayMusicClip").objectReferenceValue=AssetDatabase.LoadAssetAtPath<AudioClip>(music);f.FindProperty("backgroundMusicVolume").floatValue=.34f;f.ApplyModifiedPropertiesWithoutUndo();
        var importer=(AudioImporter)AssetImporter.GetAtPath(music);var settings=importer.defaultSampleSettings;settings.loadType=AudioClipLoadType.Streaming;settings.compressionFormat=AudioCompressionFormat.Vorbis;settings.quality=.7f;importer.defaultSampleSettings=settings;importer.SaveAndReimport();
        EditorSceneManager.MarkSceneDirty(scene);EditorSceneManager.SaveScene(scene);
        AssetDatabase.SaveAssets();Directory.CreateDirectory("Logs");
        File.WriteAllText("Logs/CourierPolishAssets.txt","PASS Courier uniforms: 4 helmets + shared courier outfit\nPASS Jump shoes pickup + worn boosters\nPASS Menu card sprite and unified button layout\nPASS Character names; original IDs/prices retained\nPASS Run music: "+music+"\n");
        Debug.Log("COURIER_POLISH_ASSETS_READY");
    }
    [MenuItem("Neon Courier/Generate Courier Polish Assets")]
    public static void Generate()
    {
        EnsureFolder(Folder+"/Meshes");
        // A Resources material keeps the unlit shader available in Android builds.
        if(!AssetDatabase.LoadAssetAtPath<Material>(Folder+"/CityBackdrop.mat"))
            AssetDatabase.CreateAsset(new Material(Shader.Find("Universal Render Pipeline/Unlit")),Folder+"/CityBackdrop.mat");
        Material Load(string name)=>AssetDatabase.LoadAssetAtPath<Material>("Assets/_Game/Art/CourierSet/Materials/"+name+".mat");
        navy=Load("MidnightShell");panel=Load("BlueSlate");rubber=Load("SoftGraphite");ivory=Load("Porcelain");orange=Load("SafetyTangerine");cyan=Load("SignalCyan");glass=Load("VisorGlass");
        var scene=EditorSceneManager.NewPreviewScene();var root=new GameObject("CourierPolishBuild");SceneManager.MoveGameObjectToScene(root,scene);
        try
        {
            for(int i=0;i<4;i++)Save(Helmet(root.transform,i),"Helmet"+i);
            var jacket=Node("Jacket",root.transform);
            Box(jacket,"SoftSuit",V(0,0,0),V(.55f,.50f,.34f),navy,.075f);
            Box(jacket,"Yoke",V(0,.18f,.005f),V(.57f,.135f,.35f),orange,.035f);
            Box(jacket,"ChestPanel",V(0,-.015f,.18f),V(.39f,.285f,.042f),panel,.026f);
            foreach(float x in new[]{-.205f,.205f})
            {
                Box(jacket,"BagHarness",V(x,0,.187f),V(.057f,.47f,.056f),rubber,.012f);
                Box(jacket,"HarnessReflector",V(x,.085f,.22f),V(.036f,.13f,.012f),cyan,.004f);
                Box(jacket,"HarnessBuckle",V(x,-.14f,.22f),V(.078f,.068f,.022f),ivory,.009f);
            }
            Mail(jacket,V(0,.015f,.207f),.19f,ivory,false);
            Box(jacket,"WaistBand",V(0,-.238f,0),V(.55f,.065f,.35f),rubber,.012f);
            Save(jacket.gameObject,"Jacket");
            var hip=Node("Hips",root.transform);Box(hip,"UtilityBelt",Vector3.zero,V(.43f,.18f,.28f),navy,.035f);Box(hip,"Buckle",V(0,0,.15f),V(.12f,.085f,.025f),orange,.014f);Save(hip.gameObject,"Hips");
            var limb=Node("Limb",root.transform);Box(limb,"Suit",Vector3.zero,V(.85f,.91f,.85f),navy,.12f);Box(limb,"Joint",V(0,-.44f,0),V(.97f,.11f,.97f),rubber,.075f);Box(limb,"Armor",V(0,.05f,.43f),V(.78f,.60f,.13f),panel,.035f);Box(limb,"Stripe",V(0,.26f,.51f),V(.68f,.09f,.022f),orange,.01f);Save(limb.gameObject,"Limb");
            var glove=Node("Glove",root.transform);Box(glove,"GloveBody",V(0,-.018f,0),V(.16f,.145f,.17f),rubber,.038f);Box(glove,"Knuckles",V(0,0,.079f),V(.12f,.09f,.037f),ivory,.014f);Save(glove.gameObject,"Glove");
            var boot=Boot(root.transform,"Boot");Save(boot.gameObject,"Boot");
            var boost=Boost(root.transform);Save(boost.gameObject,"JumpBoost");
            var pickup=Node("JumpShoesPickup",root.transform);
            foreach(float x in new[]{-.19f,.19f})
            {
                var shoe=Boot(pickup,"JumpShoe");shoe.localPosition=V(x,0,0);shoe.localScale=Vector3.one*1.3f;
                var fx=Boost(pickup);fx.localPosition=V(x,0,0);fx.localScale=Vector3.one*1.3f;
            }
            for(int i=0;i<2;i++)
            {
                Box(pickup,"UpArrowL",V(-.085f,.34f+i*.15f,0),V(.24f,.045f,.07f),cyan,.01f,V(0,0,40));
                Box(pickup,"UpArrowR",V(.085f,.34f+i*.15f,0),V(.24f,.045f,.07f),cyan,.01f,V(0,0,-40));
            }
            Save(pickup.gameObject,"JumpShoesPickup");
            MenuSprite();
            for(int i=0;i<4;i++)Portrait(i);
        }
        finally{EditorSceneManager.ClosePreviewScene(scene);foreach(var m in TemporaryMeshes)if(m)Object.DestroyImmediate(m);TemporaryMeshes.Clear();BoxMeshes.Clear();}
        AssetDatabase.SaveAssets();
    }
    private static GameObject Helmet(Transform parent,int style)
    {
        var h=Node("Helmet"+style,parent);
        Box(h,"HelmetShell",Vector3.zero,V(.48f,.38f,.415f),style==0||style==2?ivory:navy,.075f);
        Box(h,"Visor",V(0,.01f,.206f),V(.407f,.205f,.047f),glass,.045f);
        foreach(float x in new[]{-.10f,.10f})Box(h,"Eyes",V(x,.032f,.237f),V(style==3?.094f:.048f,.051f,.017f),cyan,.012f);
        Box(h,"LowerLight",V(0,-.066f,.235f),V(.10f,.013f,.016f),cyan,.004f);
        foreach(float x in new[]{-.26f,.26f})Box(h,"Headset",V(x,.008f,-.02f),V(.065f,.17f,.20f),orange,.025f);
        if(style==0)Box(h,"CenterStripe",V(0,.19f,-.015f),V(.11f,.031f,.32f),orange,.012f);
        if(style==1){Box(h,"SpeedPeak",V(0,.155f,.14f),V(.47f,.046f,.27f),orange,.018f);Box(h,"Radio",V(-.265f,.18f,-.04f),V(.023f,.22f,.023f),cyan,.006f);}
        if(style==2){Box(h,"HardHat",V(0,.185f,0),V(.56f,.075f,.48f),orange,.025f);Box(h,"Lamp",V(0,.18f,.26f),V(.12f,.075f,.035f),cyan,.01f);}
        if(style==3)foreach(float x in new[]{-.15f,.15f})Box(h,"NightStripe",V(x,.19f,0),V(.044f,.025f,.30f),cyan,.008f);
        return h.gameObject;
    }
    private static Transform Boot(Transform parent,string name)
    {
        var b=Node(name,parent);Box(b,"Sole",V(0,-.06f,.06f),V(.24f,.09f,.36f),rubber,.027f);
        Box(b,"Upper",V(0,.015f,.05f),V(.22f,.13f,.32f),ivory,.032f);
        Box(b,"Toe",V(0,-.002f,.18f),V(.225f,.10f,.075f),orange,.018f);
        Box(b,"Heel",V(0,.04f,-.07f),V(.20f,.15f,.10f),navy,.025f);
        for(int i=0;i<3;i++)Box(b,"Lace",V(0,.087f,.02f+i*.035f),V(.13f,.014f,.012f),navy,.003f);
        return b;
    }
    private static Transform Boost(Transform parent)
    {
        var b=Node("JumpBoost",parent);
        Box(b,"EnergySole",V(0,-.104f,.065f),V(.255f,.025f,.375f),cyan,.009f);
        foreach(float x in new[]{-.143f,.143f})
        {
            Box(b,"JetPod",V(x,-.015f,-.01f),V(.075f,.11f,.21f),orange,.018f);
            Box(b,"JetGlow",V(x,-.08f,-.06f),V(.045f,.055f,.09f),cyan,.012f);
        }
        return b;
    }
    private static void MenuSprite()
    {
        const int n=96;var t=new Texture2D(n,n,TextureFormat.RGBA32,false);
        for(int y=0;y<n;y++)for(int x=0;x<n;x++)
        {float dx=Mathf.Max(18-x,Mathf.Max(0,x-(n-19))),dy=Mathf.Max(18-y,Mathf.Max(0,y-(n-19)));float a=Mathf.Clamp01(18.5f-Mathf.Sqrt(dx*dx+dy*dy));t.SetPixel(x,y,new Color(1,1,1,a));}
        t.Apply();string path=Folder+"/MenuCard.png";File.WriteAllBytes(path,t.EncodeToPNG());Object.DestroyImmediate(t);AssetDatabase.ImportAsset(path);
        var importer=(TextureImporter)AssetImporter.GetAtPath(path);importer.textureType=TextureImporterType.Sprite;importer.spriteImportMode=SpriteImportMode.Single;importer.spriteBorder=new Vector4(22,22,22,22);importer.alphaIsTransparency=true;importer.mipmapEnabled=false;importer.SaveAndReimport();
    }
    private static void Portrait(int index)
    {
        var preview=new PreviewRenderUtility();Texture2D image=null;
        try
        {
            var head=Object.Instantiate(AssetDatabase.LoadAssetAtPath<GameObject>(Folder+"/Helmet"+index+".prefab"));preview.AddSingleGO(head);head.transform.rotation=Quaternion.Euler(0,-18,0);
            preview.camera.transform.position=new Vector3(0,.12f,1.65f);preview.camera.transform.LookAt(new Vector3(0,.015f,0));preview.camera.fieldOfView=28;preview.camera.nearClipPlane=.01f;preview.camera.farClipPlane=10;
            preview.camera.clearFlags=CameraClearFlags.SolidColor;preview.camera.backgroundColor=new Color(.065f,.13f,.19f,1);
            preview.ambientColor=Color.gray;preview.lights[0].intensity=1.7f;preview.lights[0].transform.rotation=Quaternion.Euler(30,150,0);preview.lights[1].intensity=1;
            preview.BeginStaticPreview(new Rect(0,0,320,320));preview.Render(true,false);image=preview.EndStaticPreview();
            string path=Folder+"/Portrait"+index+".png";File.WriteAllBytes(path,image.EncodeToPNG());AssetDatabase.ImportAsset(path);
            var importer=(TextureImporter)AssetImporter.GetAtPath(path);importer.textureType=TextureImporterType.Sprite;importer.spriteImportMode=SpriteImportMode.Single;importer.mipmapEnabled=false;importer.SaveAndReimport();
        }
        finally{if(image)Object.DestroyImmediate(image);preview.Cleanup();}
    }
    private static Vector3 V(float x,float y,float z)=>new Vector3(x,y,z);
    private static Transform Node(string name,Transform parent){var go=new GameObject(name);go.transform.SetParent(parent,false);return go.transform;}
    // Geometry helpers are shared in form with CourierVisualUpgrade to match the existing courier kit.
    private static void Box(Transform parent,string name,Vector3 position,Vector3 size,Material material,float bevel,Vector3 rotation=default)
    {
        var node=Node(name,parent); node.localPosition=position; node.localRotation=Quaternion.Euler(rotation);
        string key=size.ToString("F4")+bevel.ToString("F4");
        if(!BoxMeshes.TryGetValue(key,out var mesh)) { mesh=BeveledBox(size,bevel); BoxMeshes.Add(key,mesh); TemporaryMeshes.Add(mesh); }
        node.gameObject.AddComponent<MeshFilter>().sharedMesh=mesh;
        node.gameObject.AddComponent<MeshRenderer>().sharedMaterial=material;
    }
    private static void Mail(Transform parent,Vector3 center,float width,Material material,bool front)
    {
        float height=width*.62f, thick=width*.073f;
        Box(parent,"MailTop",center+V(0,height*.5f,0),V(width,thick,.011f),material,.002f);
        Box(parent,"MailBottom",center+V(0,-height*.5f,0),V(width,thick,.011f),material,.002f);
        Box(parent,"MailLeft",center+V(-width*.5f,0,0),V(thick,height,.011f),material,.002f);
        Box(parent,"MailRight",center+V(width*.5f,0,0),V(thick,height,.011f),material,.002f);
        Box(parent,"MailFoldL",center+V(-width*.25f,height*.10f,0),V(width*.58f,thick,.014f),material,.002f,V(0,0,-34));
        Box(parent,"MailFoldR",center+V(width*.25f,height*.10f,0),V(width*.58f,thick,.014f),material,.002f,V(0,0,34));
    }
    private static Mesh BeveledBox(Vector3 size,float bevel)
    {
        Vector3 h=size*.5f; float r=Mathf.Min(bevel,Mathf.Min(h.x,Mathf.Min(h.y,h.z))*.8f);
        var verts=new List<Vector3>(); var tris=new List<int>();
        Action<Vector3[]> face=points=>
        {
            Vector3 center=Vector3.zero; foreach(var p in points) center+=p;
            if(Vector3.Dot(Vector3.Cross(points[1]-points[0],points[2]-points[0]),center)<0) Array.Reverse(points);
            int start=verts.Count; verts.AddRange(points);
            for(int i=1;i<points.Length-1;i++){tris.Add(start);tris.Add(start+i);tris.Add(start+i+1);}
        };
        for(int axis=0;axis<3;axis++) for(int sign=-1;sign<=1;sign+=2)
        {
            int b=(axis+1)%3,c=(axis+2)%3; var q=new Vector3[4]; int k=0;
            foreach(var pair in new[]{new Vector2(-1,-1),new Vector2(1,-1),new Vector2(1,1),new Vector2(-1,1)})
            {var p=Vector3.zero;p[axis]=sign*h[axis];p[b]=pair.x*(h[b]-r);p[c]=pair.y*(h[c]-r);q[k++]=p;} face(q);
        }
        for(int axis=0;axis<3;axis++) for(int sb=-1;sb<=1;sb+=2) for(int sc=-1;sc<=1;sc+=2)
        {
            int b=(axis+1)%3,c=(axis+2)%3;var q=new Vector3[4];
            for(int i=0;i<4;i++){var p=Vector3.zero;p[axis]=(i<2?-1:1)*(h[axis]-r);bool outerB=i==0||i==3;p[b]=sb*(h[b]-(outerB?0:r));p[c]=sc*(h[c]-(outerB?r:0));q[i]=p;}face(q);
        }
        for(int sx=-1;sx<=1;sx+=2)for(int sy=-1;sy<=1;sy+=2)for(int sz=-1;sz<=1;sz+=2)
            face(new[]{V(sx*h.x,sy*(h.y-r),sz*(h.z-r)),V(sx*(h.x-r),sy*h.y,sz*(h.z-r)),V(sx*(h.x-r),sy*(h.y-r),sz*h.z)});
        var mesh=new Mesh{name="ChamferedShell"};mesh.SetVertices(verts);mesh.SetTriangles(tris,0);mesh.RecalculateNormals();mesh.RecalculateBounds();return mesh;
    }
    private static void Save(GameObject root,string name)
    {
        // Combine direct static parts per material. Animated pivots and capacity LEDs remain independent.
        foreach(var parent in root.GetComponentsInChildren<Transform>(true).Reverse().ToArray())
        {
            var parts=parent.Cast<Transform>().Where(t=>t.GetComponent<MeshFilter>()!=null).ToArray();
            foreach(var group in parts.GroupBy(t=>t.GetComponent<MeshRenderer>().sharedMaterial))
            {
                var mesh=new Mesh{name=name+"_"+parent.name+"_"+group.Key.name};
                mesh.CombineMeshes(group.Select(t=>new CombineInstance{mesh=t.GetComponent<MeshFilter>().sharedMesh,transform=Matrix4x4.TRS(t.localPosition,t.localRotation,t.localScale)}).ToArray(),true,true);
                string path=Folder+"/Meshes/"+mesh.name+".asset";var saved=AssetDatabase.LoadAssetAtPath<Mesh>(path);
                if(saved){EditorUtility.CopySerialized(mesh,saved);Object.DestroyImmediate(mesh);}else{saved=mesh;AssetDatabase.CreateAsset(saved,path);}
                foreach(var part in group) Object.DestroyImmediate(part.gameObject);
                var combined=Node(group.Key.name,parent);combined.gameObject.AddComponent<MeshFilter>().sharedMesh=saved;combined.gameObject.AddComponent<MeshRenderer>().sharedMaterial=group.Key;
            }
        }
        PrefabUtility.SaveAsPrefabAsset(root,Folder+"/"+name+".prefab",out bool ok);
        if(!ok)throw new Exception("Could not save "+name);
    }
    private static void EnsureFolder(string path)
    {if(AssetDatabase.IsValidFolder(path))return;string parent=Path.GetDirectoryName(path).Replace('\\','/');EnsureFolder(parent);AssetDatabase.CreateFolder(parent,Path.GetFileName(path));}

}
#endif

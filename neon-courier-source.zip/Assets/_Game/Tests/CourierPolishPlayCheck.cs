#if UNITY_EDITOR
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using TMPro;
using UnityEditor;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;
using Object=UnityEngine.Object;

/// <summary>Opt-in checks against the real menu, player, audio, pickup and obstacle physics.</summary>
public sealed class CourierPolishPlayCheck : MonoBehaviour
{
    private const BindingFlags Hidden=BindingFlags.Instance|BindingFlags.NonPublic;
    private readonly List<string> report=new List<string>();
    private GameManager manager;private RunnerController runner;private PowerUpController power;
    private float oldScale,oldDelta;private int oldFrameRate;
    [MenuItem("Neon Courier/Run Courier Polish Checks")]
    public static void Run()
    {
        if(EditorApplication.isPlayingOrWillChangePlaymode)return;
        CourierPolishPreferences.Capture();
        for(int i=1;i<=4;i++)PlayerPrefs.SetInt("NeonCourier.CharacterUnlocked.courier_0"+i,1);
        PlayerPrefs.SetInt("NeonCourier_StoryIntro_Seen_v1",1);PlayerPrefs.SetInt("NeonCourier.TutorialCompleted",1);PlayerPrefs.SetInt("NeonCourier.Language",0);
        SessionState.SetBool("CourierPolish.QA",true);EditorApplication.EnterPlaymode();
    }
    [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
    private static void Boot()
    {
        if(!SessionState.GetBool("CourierPolish.QA",false))return;SessionState.SetBool("CourierPolish.QA",false);
        foreach(var intro in Object.FindObjectsByType<StoryIntroController>(FindObjectsSortMode.None))intro.enabled=false;
        foreach(var tutorial in Object.FindObjectsByType<TutorialController>(FindObjectsSortMode.None))tutorial.enabled=false;
        var story=GameObject.Find("StoryIntroCanvas");if(story)story.SetActive(false);
        new GameObject("Courier polish checks").AddComponent<CourierPolishPlayCheck>();
    }
    private IEnumerator Start()
    {
        oldScale=Time.timeScale;oldDelta=Time.captureDeltaTime;oldFrameRate=Application.targetFrameRate;
        Time.timeScale=1;Time.captureDeltaTime=1f/60;Application.targetFrameRate=-1;
        Application.logMessageReceived+=Log;Directory.CreateDirectory("Logs");
        var pending=new Stack<IEnumerator>();pending.Push(Checks());double deadline=EditorApplication.timeSinceStartup+180;
        while(pending.Count>0)
        {
            bool moved=false;object next=null;Exception error=null;
            try{if(EditorApplication.timeSinceStartup>deadline)throw new TimeoutException("Polish checks exceeded 180 seconds");moved=pending.Peek().MoveNext();if(moved)next=pending.Peek().Current;}catch(Exception e){error=e;}
            if(error!=null){Check(false,error.ToString());break;}
            if(!moved){(pending.Pop() as IDisposable)?.Dispose();continue;}
            if(next is IEnumerator nested)pending.Push(nested);else yield return next;
        }
        while(pending.Count>0)(pending.Pop() as IDisposable)?.Dispose();
        Application.logMessageReceived-=Log;Time.timeScale=oldScale;Time.captureDeltaTime=oldDelta;Application.targetFrameRate=oldFrameRate;
        File.WriteAllLines("Logs/CourierPolishChecks.txt",report);Debug.Log("COURIER_POLISH_CHECKS_COMPLETE failures="+report.Count(x=>x.StartsWith("FAIL")));
        EditorApplication.isPlaying=false;
    }
    private void Log(string message,string trace,LogType type){if(type==LogType.Error||type==LogType.Exception)report.Add("FAIL Unity: "+message);}
    private void Check(bool value,string message){report.Add((value?"PASS ":"FAIL ")+message);File.WriteAllLines("Logs/CourierPolishChecks.txt",report);}
    private IEnumerator Checks()
    {
        for(int i=0;i<10;i++)yield return null;
        manager=GameManager.Instance;runner=Object.FindAnyObjectByType<RunnerController>();power=PowerUpController.Instance;
        manager.OpenMainMenu();yield return null;yield return null;
        var selection=Object.FindAnyObjectByType<CharacterSelectionManager>();
        Check(selection.CharacterCount==4,"Four original character slots preserved");
        var entries=new SerializedObject(selection).FindProperty("characters");
        for(int i=0;i<4;i++)
        {
            var entry=entries.GetArrayElementAtIndex(i);var root=(GameObject)entry.FindPropertyRelative("characterRoot").objectReferenceValue;
            Check(entry.FindPropertyRelative("characterId").stringValue=="courier_0"+(i+1),"Character "+i+" retains its saved unlock ID");
            Check(selection.GetDisplayName(i)==new[]{"AKI · NEON KURYE","TANAKA · ZIRHLI KURYE","REN · DOĞA KURYESİ","LYRA · GÖLGE KURYE"}[i],"Character "+i+" has its courier menu name");
            var uniform=root.GetComponent<CourierUniform>();uniform.Configure(i);
            var visual=root.transform.Find("CourierUniformVisual");
            Check(visual&&visual.GetComponentsInChildren<Renderer>(true).Length>15,"Character "+i+" has a complete courier uniform");
        }
        foreach(string name in new[]{"PlayButton","MissionsButton","CharacterButton"})
        {
            var b=FindButton(name);Canvas.ForceUpdateCanvases();bool all=true;
            foreach(float x in new[]{.08f,.5f,.92f})foreach(float y in new[]{.12f,.5f,.88f})
            {var result=Hit(b,x,y);all &= result==b;if(result!=b)report.Add("INFO "+name+" hit "+(result?result.name:"no button")+" at "+x+","+y);}
            Check(all,name+" hit area matches all nine visible test points");
            var label=b.GetComponentInChildren<TMP_Text>();label.ForceMeshUpdate();
            Vector3 world=label.transform.TransformPoint(label.textBounds.center);
            var point=RectTransformUtility.WorldToScreenPoint(null,world);
            var buttonBounds=ScreenRect((RectTransform)b.transform);
            Check(buttonBounds.Contains(point)&&Mathf.Abs(point.y-buttonBounds.center.y)<12,name+" visible lettering is centered within its hit target");
            Check(b.GetComponent<Image>().sprite!=null,name+" uses the rounded menu card sprite");
        }
        ScreenCapture.CaptureScreenshot("Logs/Polish-Menu.png");for(int i=0;i<5;i++)yield return null;
        Click(FindButton("MissionsButton"));yield return null;
        var missions=Object.FindAnyObjectByType<DailyMissionPanelController>();var missionPanel=(GameObject)Get(missions,"missionPanel");
        Check(missionPanel.activeInHierarchy,"Mission button opens the mission panel");Click(FindButton("CloseMissionButton"));yield return null;
        Click(FindButton("CharacterButton"));yield return null;
        yield return new WaitForSecondsRealtime(.6f);
        var characterPanel=(GameObject)Get(Object.FindAnyObjectByType<CharacterSelectionPanelController>(),"characterPanel");
        Check(characterPanel.activeInHierarchy,"Character button opens the character panel");
        Check(characterPanel.GetComponent<Image>().color.a==1,"Character menu has an opaque, readable background");
        Check(characterPanel.GetComponentsInChildren<Image>().Count(i=>i.name=="CourierPortrait"&&i.sprite)!=0,"Character menu displays the updated courier portraits");
        var cards=new SerializedObject(Object.FindAnyObjectByType<CharacterSelectionPanelController>()).FindProperty("cards");
        for(int i=0;i<cards.arraySize;i++)
        {
            var action=(Button)cards.GetArrayElementAtIndex(i).FindPropertyRelative("actionButton").objectReferenceValue;
            Check(action.gameObject.activeInHierarchy&&action.GetComponent<Image>().enabled,"Character "+i+" selection button remains visible");
            Check(Hit(action,.5f,.5f)==action,"Character "+i+" selection has the correct pointer target");
            Click(action);Check(selection.SelectedIndex==i,"Selecting courier "+i+" changes the active character");
            Check(action.GetComponentInChildren<TMP_Text>().color.grayscale>.9f,"Character "+i+" button label has readable white contrast");
        }
        ScreenCapture.CaptureScreenshot("Logs/Polish-Characters.png");for(int i=0;i<4;i++)yield return null;
        Click(FindButton("CloseCharacterButton"));yield return null;
        // Disable equipped consumables only in the disposable Play session.
        var boosters=Object.FindAnyObjectByType<BoosterInventoryManager>();
        if(boosters){Property(boosters,"IsMagnetEquipped",false);Property(boosters,"IsShieldEquipped",false);Property(boosters,"IsDoubleCoinEquipped",false);}
        if(!manager.IsSoundEnabled)manager.ToggleSound();
        Click(FindButton("PlayButton"));Check(!manager.IsMainMenuActive,"Play button starts the countdown");
        float until=Time.realtimeSinceStartup+8;while(!manager.IsRunActive&&Time.realtimeSinceStartup<until)yield return null;
        Check(manager.IsRunActive,"Countdown enters the running state");runner.enabled=false;
        yield return new WaitForSeconds(.8f);
        var feedback=Object.FindAnyObjectByType<GameFeedbackController>();
        Check(feedback.RunMusicLength>30 && feedback.IsRunMusicPlaying,"Long looping music plays when running starts");
        var backdrop=Object.FindAnyObjectByType<CourierCityBackdrop>();
        Check(backdrop&&backdrop.RecycledChunkCount==8,"City background has eight recycled layers");
        var cityLayers=backdrop.GetComponentsInChildren<MeshFilter>().Where(m=>m.sharedMesh&&m.sharedMesh.name=="Combined city layer").ToArray();
        Check(cityLayers.Length==9&&cityLayers.All(m=>!m.GetComponent<Collider>()),"City backdrop uses nine combined meshes and does not obstruct gameplay");
        yield return new WaitForSecondsRealtime(1.1f);
        ScreenCapture.CaptureScreenshot("Logs/Polish-City.png");for(int i=0;i<5;i++)yield return null;
        // Keep the real UI, isolate movement from procedural route pickups for reproducible checks.
        foreach(var track in Object.FindObjectsByType<TrackManager>(FindObjectsSortMode.None))track.gameObject.SetActive(false);
        foreach(var package in Object.FindObjectsByType<PackagePickup>(FindObjectsSortMode.None))package.gameObject.SetActive(false);
        foreach(var obstacle in Object.FindObjectsByType<ObstacleVisualController>(FindObjectsSortMode.None))obstacle.gameObject.SetActive(false);
        var cc=runner.GetComponent<CharacterController>();cc.enabled=false;runner.transform.position=new Vector3(0,1.08f,320);cc.enabled=true;
        power.ActivatePowerUp(PowerUpType.JumpShoes);yield return null;
        Check(power.IsJumpShoesActive&&power.JumpShoesTimeRemaining>9.9f&&runner.JumpHeight>=6,"Shoes activate a 10 second high jump");
        manager.PauseGame();float paused=power.JumpShoesTimeRemaining;yield return new WaitForSecondsRealtime(.35f);
        Check(Mathf.Approximately(paused,power.JumpShoesTimeRemaining)&&AudioListener.pause,"Pause freezes shoes and audio");manager.ResumeGame();
        power.ActivatePowerUp(PowerUpType.JumpShoes);Check(Mathf.Approximately(power.JumpShoesTimeRemaining,10),"Repickup refreshes to ten seconds without stacking");
        var pickup=Instantiate(AssetDatabase.LoadAssetAtPath<GameObject>("Assets/_Game/Prefabs/PF_PowerUp.prefab"));pickup.GetComponent<TrackPowerUpTypeRandomizer>().enabled=false;
        var p=pickup.GetComponent<PowerUpPickup>();p.Configure(PowerUpType.JumpShoes);
        Check(pickup.GetComponentsInChildren<Transform>().Any(t=>t.name.StartsWith("JumpShoesPickup")),"Shoes pickup displays the two shoes and upward arrows");
        manager.PauseGame();Call(p,"Collect");Check(pickup.activeSelf,"Paused pickup is preserved");manager.ResumeGame();Call(p,"Collect");Check(!pickup.activeSelf&&power.IsJumpShoesActive,"Collecting the actual pickup activates shoes");Destroy(pickup);
        yield return new WaitForSeconds(.35f);Canvas.ForceUpdateCanvases();
        var cargo=Object.FindObjectsByType<RectTransform>(FindObjectsSortMode.None).First(t=>t.name=="CargoLedger");
        var mission=Object.FindObjectsByType<RectTransform>(FindObjectsSortMode.None).First(t=>t.name=="InRunMissionHUD");
        Check(!ScreenRect(cargo).Overlaps(ScreenRect(mission)),"Industrial district/cargo card does not overlap the daily mission card");
        Check(Object.FindObjectsByType<TMP_Text>(FindObjectsSortMode.None).Any(t=>t.name=="JumpShoesLabel"&&t.text.Contains("AYAKKABI")),"Shoes countdown is visible during the run");
        ScreenCapture.CaptureScreenshot("Logs/Polish-RunHUD.png");for(int i=0;i<5;i++)yield return null;
        float time=power.JumpShoesTimeRemaining;int frames=0;while(power.IsJumpShoesActive&&frames++<620)yield return null;
        Check(!power.IsJumpShoesActive&&Mathf.Abs(frames/60f-time)<.08f&&runner.JumpHeight<3,"Shoes expire after ten active seconds and restore the normal jump");
        var randomizer=Instantiate(AssetDatabase.LoadAssetAtPath<GameObject>("Assets/_Game/Prefabs/PF_PowerUp.prefab")).GetComponent<TrackPowerUpTypeRandomizer>();
        bool seen=false;for(int i=0;i<100;i++)seen|=(PowerUpType)Call(randomizer,"SelectRandomPowerUpType")==PowerUpType.JumpShoes;
        Check(seen,"Regular track pickup selection includes jump shoes");Destroy(randomizer.gameObject);
        foreach(float speed in new[]{9.5f,15.5f,25f})yield return JumpObstacle(speed,false);
        yield return JumpObstacle(15.5f,true);
        yield return CheckRunGoals();
        power.ActivatePowerUp(PowerUpType.JumpShoes);manager.OpenMainMenu();yield return null;
        Check(!power.IsJumpShoesActive,"Returning to the menu clears the shoes power");
        manager.ToggleSound();yield return null;Check(!feedback.IsRunMusicPlaying,"Muted sound stops run music");
    }
    private IEnumerator CheckRunGoals()
    {
        var goals=manager.GetComponent<CourierRunGoals>();
        // Reinitialise the run-local tracker; all preferences are restored on exiting Play.
        Call(goals,"MenuChanged",true);Call(goals,"RunChanged",true);
        int coins=manager.TotalCoins,earned=manager.EarnedCoinsThisRun;
        Property(manager,"DistanceMeters",249);Call(goals,"Update");
        Check(goals.MilestonesReached==0,"Distance reward waits until the threshold");
        Property(manager,"DistanceMeters",250);Call(goals,"Update");
        Check(goals.MilestonesReached==1&&manager.TotalCoins==coins+15&&manager.EarnedCoinsThisRun==earned+15,"250m reward adds 15 coins to the wallet and run earnings");
        Call(goals,"Update");Check(manager.TotalCoins==coins+15,"Distance reward cannot be claimed twice");
        manager.PauseGame();Property(manager,"DistanceMeters",500);Call(goals,"Update");
        Check(goals.MilestonesReached==1,"Pause prevents new distance rewards");manager.ResumeGame();
        Call(goals,"RunChanged",false);Call(goals,"RunChanged",true);Call(goals,"Update");
        Check(goals.MilestonesReached==2&&goals.BonusCoins==40,"Resuming a run preserves previous milestones");
        Property(manager,"DistanceMeters",2000);Call(goals,"Update");
        Check(goals.MilestonesReached==4&&goals.BonusCoins==190&&goals.NextDistance==0,"All four distance goals total 190 coins and finish cleanly");
        var cc=runner.GetComponent<CharacterController>();cc.enabled=false;runner.transform.position=new Vector3(0,7.2f,2000);cc.enabled=true;
        yield return null;
        Check(backdropInRange(),"City backdrop follows long runs without adding objects");
        manager.TriggerGameOver();yield return new WaitForSecondsRealtime(2);
        var revive=Object.FindAnyObjectByType<RevivePanelController>();if(revive)Call(revive,"GiveUp");yield return null;
        var results=Object.FindAnyObjectByType<CourierResultsMenu>();
        Check(results&&results.GetComponentsInChildren<TMP_Text>(true).Any(t=>t.name=="RunRecap"&&t.text.Contains("190")),"Results screen includes earned milestone coins and the run summary");
        if(results){Check(results.gameObject.activeInHierarchy,"Declining revive opens the results screen");Canvas.ForceUpdateCanvases();foreach(var b in results.GetComponentsInChildren<Button>())Check(Hit(b,.5f,.5f)==b,"Result button "+b.name+" has a correct pointer target");ScreenCapture.CaptureScreenshot("Logs/Polish-Results.png");for(int i=0;i<5;i++)yield return null;results.gameObject.SetActive(false);}
        Property(manager,"IsGameOver",false);Property(manager,"IsRunActive",true);Time.timeScale=1;
    }
    private bool backdropInRange()
    {
        var backdrop=Object.FindAnyObjectByType<CourierCityBackdrop>();var chunks=backdrop.GetComponentsInChildren<MeshRenderer>().Where(r=>r.name.StartsWith("City backdrop chunk")).ToArray();
        return chunks.Length==8&&chunks.All(r=>r.transform.position.z>=runner.transform.position.z-180&&r.transform.position.z<runner.transform.position.z+720);
    }
    private IEnumerator JumpObstacle(float speed,bool train)
    {
        var root=new GameObject("Jump physics check");root.transform.position=Vector3.zero;
        var ground=GameObject.CreatePrimitive(PrimitiveType.Cube);ground.transform.SetParent(root.transform);ground.transform.position=new Vector3(0,-.25f,40);ground.transform.localScale=new Vector3(18,.5f,150);
        var obstacle=train?NeonRailFactory.CreateTrain(root.transform,2.5f,false):GameObject.CreatePrimitive(PrimitiveType.Cube);
        obstacle.transform.SetParent(root.transform);obstacle.transform.position=new Vector3(0,train?0:1.5f,12);
        if(!train){obstacle.transform.localScale=new Vector3(2.4f,3,2);obstacle.tag="Obstacle";}
        var cc=runner.GetComponent<CharacterController>();runner.enabled=false;cc.enabled=false;runner.transform.position=new Vector3(0,1.08f,0);cc.enabled=true;
        Set(runner,"currentLane",1);runner.SetForwardSpeed(speed);Property(manager,"CurrentLives",3);power.ActivatePowerUp(PowerUpType.JumpShoes);runner.enabled=true;Physics.SyncTransforms();
        bool jumped=false;float highest=0;int frame=0;
        while(runner.transform.position.z<35&&frame++<300)
        {
            // Launch far enough ahead to clear the three-metre full-width obstacle at each speed.
            if(!jumped&&runner.transform.position.z>=Mathf.Max(1,12-speed*.47f)){Call(runner,"TryJump");jumped=true;}
            highest=Mathf.Max(highest,runner.transform.position.y);yield return null;
        }
        Check(jumped&&highest>6.8f&&manager.CurrentLives==3,(train?"Train":"3m obstacle")+" clears safely at speed "+speed);
        runner.enabled=false;Destroy(root);yield return null;
    }
    private static Rect ScreenRect(RectTransform t){var corners=new Vector3[4];t.GetWorldCorners(corners);Vector2 a=RectTransformUtility.WorldToScreenPoint(null,corners[0]),b=RectTransformUtility.WorldToScreenPoint(null,corners[2]);return Rect.MinMaxRect(a.x,a.y,b.x,b.y);}
    private static Button Hit(Button button,float x,float y)
    {
        Rect r=ScreenRect((RectTransform)button.transform);var data=new PointerEventData(EventSystem.current){position=new Vector2(Mathf.Lerp(r.xMin,r.xMax,x),Mathf.Lerp(r.yMin,r.yMax,y))};
        var hits=new List<RaycastResult>();EventSystem.current.RaycastAll(data,hits);return hits.Count>0?hits[0].gameObject.GetComponentInParent<Button>():null;
    }
    private static void Click(Button button){var data=new PointerEventData(EventSystem.current){button=PointerEventData.InputButton.Left};ExecuteEvents.Execute(button.gameObject,data,ExecuteEvents.pointerClickHandler);}
    private static Button FindButton(string name)=>Object.FindObjectsByType<Button>(FindObjectsInactive.Include,FindObjectsSortMode.None).First(b=>b.name==name);
    private static object Get(object target,string field)=>target.GetType().GetField(field,Hidden).GetValue(target);
    private static void Set(object target,string field,object value)=>target.GetType().GetField(field,Hidden).SetValue(target,value);
    private static object Call(object target,string method,params object[] args)=>target.GetType().GetMethod(method,Hidden).Invoke(target,args);
    private static void Property(object target,string name,object value)=>target.GetType().GetProperty(name).GetSetMethod(true).Invoke(target,new[]{value});
}

[InitializeOnLoad]
public static class CourierPolishPreferences
{
    [Serializable] private class Entry{public string key;public bool exists;public int number;public string text;public bool isText;}
    [Serializable] private class Snapshot{public List<Entry> entries=new List<Entry>();}
    static CourierPolishPreferences(){EditorApplication.playModeStateChanged+=state=>{if(state==PlayModeStateChange.EnteredEditMode)Restore();};}
    public static void Capture()
    {
        var keys=new HashSet<string>{"NeonCourier_StoryIntro_Seen_v1","NeonCourier.SelectedCharacter","NeonCourier.GhostEnabled","NeonCourier.BagSkin","NeonCourier.BagPatch","NeonCourier.BagGlow","NeonCourier.Language"};
        foreach(string key in CourierCareerProgress.SavedKeys)keys.Add(key);
        foreach(var type in new[]{typeof(GameManager),typeof(DailyMissionManager),typeof(BoosterInventoryManager),typeof(TutorialController),typeof(CharacterSelectionManager)})
            foreach(var field in type.GetFields(BindingFlags.NonPublic|BindingFlags.Static))if(field.IsLiteral&&field.FieldType==typeof(string)){string key=(string)field.GetRawConstantValue();if(key.StartsWith("NeonCourier"))keys.Add(key);}
        for(int i=1;i<=4;i++)keys.Add("NeonCourier.CharacterUnlocked.courier_0"+i);
        var snapshot=new Snapshot();foreach(string key in keys)snapshot.entries.Add(new Entry{key=key,exists=PlayerPrefs.HasKey(key),number=PlayerPrefs.GetInt(key),text=key.EndsWith("Date")?PlayerPrefs.GetString(key):"",isText=key.EndsWith("Date")});
        SessionState.SetString("CourierPolish.Prefs",JsonUtility.ToJson(snapshot));
    }
    private static void Restore()
    {
        string json=SessionState.GetString("CourierPolish.Prefs","");if(string.IsNullOrEmpty(json))return;
        foreach(var e in JsonUtility.FromJson<Snapshot>(json).entries){if(!e.exists)PlayerPrefs.DeleteKey(e.key);else if(e.isText)PlayerPrefs.SetString(e.key,e.text);else PlayerPrefs.SetInt(e.key,e.number);}PlayerPrefs.Save();SessionState.EraseString("CourierPolish.Prefs");
    }
}
#endif

#if UNITY_EDITOR
using System.IO;
using UnityEditor;
using UnityEngine;
using Object=UnityEngine.Object;

public static class CourierUniformPreview
{
    [MenuItem("Neon Courier/Capture Courier Uniforms")]
    public static void Capture()
    {
        var selection=Object.FindAnyObjectByType<CharacterSelectionManager>();
        if(!selection)return;
        var entries=new SerializedObject(selection).FindProperty("characters");
        var preview=new PreviewRenderUtility();Texture2D image=null;
        try
        {
            var root=new GameObject("Uniform lineup preview");preview.AddSingleGO(root);
            for(int i=0;i<entries.arraySize;i++)
            {
                var source=(GameObject)entries.GetArrayElementAtIndex(i).FindPropertyRelative("characterRoot").objectReferenceValue;
                var model=(GameObject)PrefabUtility.GetCorrespondingObjectFromSource(source);
                var clone=Object.Instantiate(model?model:source,root.transform,false);
                clone.transform.localPosition=new Vector3((i-1.5f)*1.7f,0,0);
                clone.transform.localRotation=Quaternion.Euler(0,i==3?155:-15,0);
                clone.transform.localScale=source.transform.localScale;clone.SetActive(true);
                foreach(var behavior in clone.GetComponentsInChildren<MonoBehaviour>(true))behavior.enabled=false;
                var rig=clone.GetComponent<Animator>();if(!rig)rig=clone.GetComponentInChildren<Animator>();
                var srcRig=source.GetComponent<Animator>();if(rig&&srcRig)rig.runtimeAnimatorController=srcRig.runtimeAnimatorController;
                if(rig){rig.Rebind();rig.Update(0);rig.enabled=false;}
                var uniform=clone.GetComponent<CourierUniform>();if(!uniform)uniform=clone.AddComponent<CourierUniform>();uniform.Configure(i);uniform.FitNow();uniform.enabled=false;
                var hip=rig.GetBoneTransform(HumanBodyBones.Hips);var head=rig.GetBoneTransform(HumanBodyBones.Head);var chest=rig.GetBoneTransform(HumanBodyBones.Chest);if(!chest)chest=rig.GetBoneTransform(HumanBodyBones.Spine);
                var bag=Object.Instantiate(Resources.Load<GameObject>("CourierExpansion/BackpackPreview"),root.transform,false);
                foreach(var b in bag.GetComponentsInChildren<MonoBehaviour>(true))b.enabled=false;
                Vector3 up=(head.position-hip.position).normalized,forward=Vector3.ProjectOnPlane(rig.transform.forward,up).normalized;
                float size=Mathf.Clamp(Vector3.Distance(head.position,hip.position)*1.3f,.7f,1.05f);
                bag.transform.SetPositionAndRotation(chest.position-up*.06f*size-forward*.31f*size,Quaternion.LookRotation(forward,up));bag.transform.localScale=Vector3.one*size;
            }
            preview.camera.transform.position=new Vector3(0,2.7f,11);preview.camera.transform.LookAt(new Vector3(0,1.1f,0));
            preview.camera.orthographic=true;preview.camera.orthographicSize=1.55f;preview.camera.nearClipPlane=.1f;preview.camera.farClipPlane=100;
            preview.camera.clearFlags=CameraClearFlags.SolidColor;preview.camera.backgroundColor=new Color(.02f,.035f,.06f);
            preview.ambientColor=new Color(.6f,.64f,.7f);preview.lights[0].intensity=1.7f;preview.lights[0].transform.rotation=Quaternion.Euler(35,150,0);
            preview.lights[1].intensity=1.1f;preview.lights[1].color=new Color(.55f,.85f,1);preview.lights[1].transform.rotation=Quaternion.Euler(30,-30,0);
            preview.BeginStaticPreview(new Rect(0,0,1600,700));preview.Render(true,false);image=preview.EndStaticPreview();
            Directory.CreateDirectory("Logs");File.WriteAllBytes("Logs/Polish-Uniforms.png",image.EncodeToPNG());
        }
        finally{if(image)Object.DestroyImmediate(image);preview.Cleanup();}
    }
}
#endif

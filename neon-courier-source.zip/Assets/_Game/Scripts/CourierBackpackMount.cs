using UnityEngine;

/// <summary>Keeps the shared backpack on the selected character's animated upper back.</summary>
[DefaultExecutionOrder(100)]
[DisallowMultipleComponent]
public sealed class CourierBackpackMount : MonoBehaviour
{
    private Animator[] candidates;
    private Renderer[] originalRenderers;
    private readonly GameObject[] themedBags=new GameObject[4];
    public int ActiveStyle {get;private set;}=-1;
    public GameObject ActiveBag=>ActiveStyle>=0?themedBags[ActiveStyle]:null;
    private void UseBag(int style)
    {
        if(ActiveStyle==style)return;
        var prefab=Resources.Load<GameObject>("CourierReference/Bag"+style);if(!prefab)return;
        if(originalRenderers==null)
        {
            var oldAppearance=GetComponent<CourierBackpackAppearance>();if(oldAppearance)oldAppearance.enabled=false;
            originalRenderers=GetComponentsInChildren<Renderer>(true);
            foreach(var renderer in originalRenderers)renderer.forceRenderingOff=true;
        }
        if(!themedBags[style])
        {
            themedBags[style]=Instantiate(prefab,transform,false);themedBags[style].name="CharacterBackpack"+style;
            themedBags[style].AddComponent<CourierBackpackAppearance>().UseCompactPatch();
        }
        for(int i=0;i<4;i++)if(themedBags[i])themedBags[i].SetActive(i==style);
        ActiveStyle=style;
    }
    private void LateUpdate() { FitNow(); }

    public void FitNow()
    {
        if(GameManager.Instance&&GameManager.Instance.IsPaused)return;
        if(candidates==null)
        {
            var runner=GetComponentInParent<RunnerController>();
            if(!runner)return;
            candidates=runner.GetComponentsInChildren<Animator>(true);
        }
        foreach(var animator in candidates)
        {
            if(!animator || !animator.isActiveAndEnabled || !animator.isHuman)continue;
            var outfit=animator.GetComponent<CourierUniform>();
            if(outfit&&outfit.HasReferenceOutfit)UseBag(outfit.StyleIndex);
            Transform hips=animator.GetBoneTransform(HumanBodyBones.Hips);
            Transform head=animator.GetBoneTransform(HumanBodyBones.Head);
            Transform chest=animator.GetBoneTransform(HumanBodyBones.UpperChest);
            if(!chest)chest=animator.GetBoneTransform(HumanBodyBones.Chest);
            if(!chest)chest=animator.GetBoneTransform(HumanBodyBones.Spine);
            if(!hips || !head || !chest)continue;
            Vector3 up=(head.position-hips.position).normalized;
            Vector3 forward=Vector3.ProjectOnPlane(animator.transform.forward,up).normalized;
            if(up.sqrMagnitude<.5f || forward.sqrMagnitude<.5f)continue;
            float size=Mathf.Clamp(Vector3.Distance(head.position,hips.position)*1.3f,.7f,1.05f);
            transform.SetPositionAndRotation(chest.position-up*(.06f*size)-forward*(.31f*size),Quaternion.LookRotation(forward,up));
            Vector3 parentScale=transform.parent ? transform.parent.lossyScale : Vector3.one;
            transform.localScale=new Vector3(size/Mathf.Max(.001f,Mathf.Abs(parentScale.x)),size/Mathf.Max(.001f,Mathf.Abs(parentScale.y)),size/Mathf.Max(.001f,Mathf.Abs(parentScale.z)));
            break;
        }
    }
}

using System;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEditor.Android;
using UnityEditor.Build;
using UnityEditor.Build.Reporting;
using UnityEngine;
using UnityEngine.Rendering;

public static class PlayStoreReleaseSetup
{
    private const string PackageId = "com.cemkilic.neoncourier";
    private const string IconForegroundPath =
        "Assets/_Game/Branding/NeonCourier-Android-Icon-Foreground-432.png";
    private const string IconBackgroundPath =
        "Assets/_Game/Branding/NeonCourier-Android-Icon-Background-432.png";
    private const string SetupSessionKey = "NeonCourier.PlayStoreSetup.1.0";
    private const string SparkTexturePath =
        "Assets/Resources/KenneyParticlePack/spark_01.png";
    private const string SparkMaterialPath =
        "Assets/Resources/KenneyParticlePack/CoinSparkle.mat";

    static PlayStoreReleaseSetup()
    {
        EditorApplication.delayCall += ApplyAutomaticallyOnce;
    }

    [MenuItem("Neon Courier/Apply Google Play Settings")]
    private static void ApplyGooglePlaySettings()
    {
        ApplySettings();
        SessionState.SetBool(SetupSessionKey, true);

        EditorUtility.DisplayDialog(
            "Neon Courier",
            "Google Play Android settings, app icons, and coin sparkle material are ready.\n\n" +
            "The package ID is provisional: " + PackageId + "\n" +
            "Use this ID only if this is a new Play listing.",
            "OK"
        );
    }

    private static void ApplyAutomaticallyOnce()
    {
        if (SessionState.GetBool(SetupSessionKey, false))
        {
            return;
        }

        try
        {
            ApplySettings();
            SessionState.SetBool(SetupSessionKey, true);
        }
        catch (Exception exception)
        {
            Debug.LogError("Neon Courier Play setup failed: " + exception);
        }
    }

    private static void ApplySettings()
    {
        PlayerSettings.companyName = "Cem Kılıç";
        PlayerSettings.productName = "Neon Courier";
        PlayerSettings.bundleVersion = "1.0.0";
        PlayerSettings.SetApplicationIdentifier(
            NamedBuildTarget.Android,
            PackageId
        );
        PlayerSettings.Android.bundleVersionCode = 1;
        PlayerSettings.Android.minSdkVersion = AndroidSdkVersions.AndroidApiLevel26;
        PlayerSettings.Android.targetSdkVersion = AndroidSdkVersions.AndroidApiLevel36;
        PlayerSettings.Android.targetArchitectures = AndroidArchitecture.ARM64;
        PlayerSettings.SetScriptingBackend(
            NamedBuildTarget.Android,
            ScriptingImplementation.IL2CPP
        );
        PlayerSettings.defaultInterfaceOrientation = UIOrientation.Portrait;
        PlayerSettings.allowedAutorotateToPortrait = true;
        PlayerSettings.allowedAutorotateToPortraitUpsideDown = false;
        PlayerSettings.allowedAutorotateToLandscapeLeft = false;
        PlayerSettings.allowedAutorotateToLandscapeRight = false;
        EditorUserBuildSettings.buildAppBundle = true;

        ApplyAdaptiveIcons();
        CreateCoinSparkleMaterial();

        AssetDatabase.SaveAssets();
        Debug.Log(
            "Neon Courier Play settings applied: Android 36, ARM64/IL2CPP, portrait, App Bundle, package " +
            PackageId + ". Add the final hosted privacy policy URL and upload key in Play Console before release."
        );
    }

    [MenuItem("Neon Courier/Build Google Play AAB")]
    public static void BuildGooglePlayAab()
    {
        ApplySettings();
        EditorUserBuildSettings.development = false;
        EditorUserBuildSettings.connectProfiler = false;
        EditorUserBuildSettings.buildAppBundle = true;

        string[] scenes = EditorBuildSettings.scenes
            .Where(scene => scene.enabled)
            .Select(scene => scene.path)
            .ToArray();
        if (scenes.Length == 0)
        {
            throw new BuildFailedException("No enabled scenes are configured in Build Settings.");
        }

        string outputDirectory = Path.GetFullPath(
            Path.Combine(Application.dataPath, "..", "Release", "Build")
        );
        Directory.CreateDirectory(outputDirectory);
        string outputPath = Path.Combine(outputDirectory, "NeonCourier-1.0.0.aab");

        BuildReport report = BuildPipeline.BuildPlayer(
            new BuildPlayerOptions
            {
                scenes = scenes,
                locationPathName = outputPath,
                target = BuildTarget.Android,
                options = BuildOptions.None
            }
        );

        if (report.summary.result != BuildResult.Succeeded)
        {
            throw new BuildFailedException(
                "Android App Bundle build finished with " + report.summary.result + "."
            );
        }

        Debug.Log("Google Play AAB built at " + outputPath);
    }

    private static void ApplyAdaptiveIcons()
    {
        Texture2D foreground = LoadTexture(IconForegroundPath);
        Texture2D background = LoadTexture(IconBackgroundPath);
        PlatformIcon[] icons = PlayerSettings.GetPlatformIcons(
            NamedBuildTarget.Android,
            AndroidPlatformIconKind.Adaptive
        );

        foreach (PlatformIcon icon in icons)
        {
            if (icon.maxLayerCount != 2)
            {
                throw new InvalidOperationException(
                    "Unexpected Android adaptive icon layer count: " + icon.maxLayerCount
                );
            }

            icon.SetTextures(foreground, background);
        }

        PlayerSettings.SetPlatformIcons(
            NamedBuildTarget.Android,
            AndroidPlatformIconKind.Adaptive,
            icons
        );
    }

    private static Texture2D LoadTexture(string assetPath)
    {
        Texture2D texture = AssetDatabase.LoadAssetAtPath<Texture2D>(assetPath);
        if (texture == null)
        {
            throw new FileNotFoundException("Required Play asset is missing: " + assetPath);
        }

        return texture;
    }

    private static void CreateCoinSparkleMaterial()
    {
        Texture2D sparkTexture = LoadTexture(SparkTexturePath);
        Shader shader = Shader.Find("Universal Render Pipeline/Particles/Unlit");
        if (shader == null)
        {
            throw new InvalidOperationException(
                "Could not find the URP particle shader for the coin pickup effect."
            );
        }

        Material material = AssetDatabase.LoadAssetAtPath<Material>(SparkMaterialPath);
        if (material == null)
        {
            material = new Material(shader);
            AssetDatabase.CreateAsset(material, SparkMaterialPath);
        }

        material.shader = shader;
        material.SetTexture("_BaseMap", sparkTexture);
        material.SetColor("_BaseColor", Color.white);
        material.SetFloat("_Surface", 1f);
        material.SetFloat("_Blend", 0f);
        material.SetFloat("_SrcBlend", (float)BlendMode.SrcAlpha);
        material.SetFloat("_DstBlend", (float)BlendMode.OneMinusSrcAlpha);
        material.SetFloat("_SrcBlendAlpha", (float)BlendMode.One);
        material.SetFloat("_DstBlendAlpha", (float)BlendMode.OneMinusSrcAlpha);
        material.SetFloat("_ZWrite", 0f);
        material.renderQueue = (int)RenderQueue.Transparent;
        material.EnableKeyword("_SURFACE_TYPE_TRANSPARENT");
        EditorUtility.SetDirty(material);
    }
}

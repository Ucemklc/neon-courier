using System.Collections;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

[DisallowMultipleComponent]
public sealed class RevivePanelController : MonoBehaviour
{
    [Header("Panels")]
    [SerializeField]
    private GameObject revivePanelRoot;

    [SerializeField]
    private GameObject gameOverPanelRoot;

    [Header("Buttons")]
    [SerializeField]
    private Button reviveButton;

    [SerializeField]
    private Button giveUpButton;

    [Header("Texts")]
    [SerializeField]
    private TMP_Text reviveCostText;

    [SerializeField]
    private TMP_Text totalCoinText;

    [SerializeField]
    private TMP_Text informationText;

    [Header("Settings")]
    [SerializeField, Min(0)]
    private int reviveCost = 50;

    private GameManager gameManager;
    private Coroutine openPanelCoroutine;

    private bool listenersBound;
    private bool eventsSubscribed;
    private CourierReviveMenu menu;
    private bool English => PlayerPrefs.GetInt("NeonCourier.Language",0)==1;

    private void Awake()
    {
        if (revivePanelRoot != null)
        {
            revivePanelRoot.SetActive(false);
        }
    }

    private void Start()
    {
        ResolveGameManager();
        if(revivePanelRoot)
        {
            menu=revivePanelRoot.GetComponent<CourierReviveMenu>();
            if(!menu){menu=revivePanelRoot.AddComponent<CourierReviveMenu>();menu.Build(reviveButton,giveUpButton,reviveCostText,totalCoinText,informationText);}
        }
        BindButtonListeners();
        SubscribeToEvents();
        RefreshPanel();
    }

    private void OnDestroy()
    {
        RemoveButtonListeners();
        UnsubscribeFromEvents();
    }

    private void ResolveGameManager()
    {
        if (gameManager != null)
        {
            return;
        }

        gameManager =
            GameManager.Instance;

        if (gameManager == null)
        {
            gameManager =
                FindAnyObjectByType
                    <GameManager>();
        }
    }

    private void BindButtonListeners()
    {
        if (listenersBound)
        {
            return;
        }

        if (reviveButton != null)
        {
            reviveButton.onClick.AddListener(
                TryRevive
            );
        }

        if (giveUpButton != null)
        {
            giveUpButton.onClick.AddListener(
                GiveUp
            );
        }

        listenersBound = true;
    }

    private void RemoveButtonListeners()
    {
        if (!listenersBound)
        {
            return;
        }

        if (reviveButton != null)
        {
            reviveButton.onClick.RemoveListener(
                TryRevive
            );
        }

        if (giveUpButton != null)
        {
            giveUpButton.onClick.RemoveListener(
                GiveUp
            );
        }

        listenersBound = false;
    }

    private void SubscribeToEvents()
    {
        if (
            eventsSubscribed ||
            gameManager == null
        )
        {
            return;
        }

        gameManager.GameOverTriggered +=
            HandleGameOver;

        gameManager.StatsChanged +=
            RefreshPanel;

        gameManager.ReviveTriggered +=
            HandleReviveTriggered;

        eventsSubscribed = true;
    }

    private void UnsubscribeFromEvents()
    {
        if (
            !eventsSubscribed ||
            gameManager == null
        )
        {
            return;
        }

        gameManager.GameOverTriggered -=
            HandleGameOver;

        gameManager.StatsChanged -=
            RefreshPanel;

        gameManager.ReviveTriggered -=
            HandleReviveTriggered;

        eventsSubscribed = false;
    }

    private void HandleGameOver()
    {
        if (openPanelCoroutine != null)
        {
            StopCoroutine(
                openPanelCoroutine
            );
        }

        /*
         * HUDController GameOverPanel'i açıyorsa
         * onun işlemini tamamlaması için bir frame bekler.
         */
        openPanelCoroutine =
            StartCoroutine(
                OpenPanelNextFrame()
            );
    }

    private IEnumerator OpenPanelNextFrame()
    {
        yield return null;

        ResolveGameManager();
        RefreshPanel();

        bool canRevive = gameManager != null && gameManager.IsGameOver && !gameManager.ReviveUsedThisRun;

        if (!canRevive)
        {
            HideRevivePanel();

            if (gameOverPanelRoot != null)
            {
                gameOverPanelRoot.SetActive(
                    true
                );
            }

            openPanelCoroutine = null;
            yield break;
        }

        if (gameOverPanelRoot != null)
        {
            gameOverPanelRoot.SetActive(
                false
            );
        }

        if (revivePanelRoot != null)
        {
            revivePanelRoot.SetActive(
                true
            );
        }

        openPanelCoroutine = null;
    }

    private void TryRevive()
    {
        if(!revivePanelRoot||!revivePanelRoot.activeInHierarchy)return;
        ResolveGameManager();

        if (gameManager == null)
        {
            SetInformation(
                "OYUN SİSTEMİ BULUNAMADI"
            );

            return;
        }

        bool revived =
            gameManager.TryRevive(
                reviveCost
            );

        if (!revived)
        {
            RefreshPanel();

            if (
                gameManager.TotalCoins <
                reviveCost
            )
            {
                SetInformation(
                    "YETERSİZ COIN"
                );
            }
            else
            {
                SetInformation(
                    "DEVAM EDİLEMİYOR"
                );
            }

            return;
        }

        HideRevivePanel();

        if (gameOverPanelRoot != null)
        {
            gameOverPanelRoot.SetActive(
                false
            );
        }
    }

    private void GiveUp()
    {
        if(!gameManager||!gameManager.IsGameOver)return;
        HideRevivePanel();

        if (gameOverPanelRoot != null)
        {
            gameOverPanelRoot.SetActive(
                true
            );
        }
    }

    private void HandleReviveTriggered()
    {
        HideRevivePanel();

        if (gameOverPanelRoot != null)
        {
            gameOverPanelRoot.SetActive(
                false
            );
        }
    }

    private void RefreshPanel()
    {
        ResolveGameManager();

        if (reviveCostText != null)
        {
            reviveCostText.text =
                $"{reviveCost} COIN";
        }

        int totalCoins =
            gameManager != null
                ? gameManager.TotalCoins
                : 0;

        if (totalCoinText != null)
        {
            totalCoinText.text =
                (English ? "YOUR BALANCE: " : "BAKİYEN: ")+totalCoins.ToString("N0")+" COIN";
        }
        if(menu)menu.Refresh(reviveCost,English);

        bool canRevive =
            gameManager != null &&
            gameManager.CanRevive(
                reviveCost
            );

        if (reviveButton != null)
        {
            reviveButton.interactable =
                canRevive;
        }

        if (informationText == null)
        {
            return;
        }

        if (
            gameManager != null &&
            gameManager.ReviveUsedThisRun
        )
        {
            informationText.text =
                English ? "CONTINUE ALREADY USED" : "DEVAM HAKKI KULLANILDI";
        }
        else if (totalCoins < reviveCost)
        {
            informationText.text =
                English ? "You need "+(reviveCost-totalCoins)+" more coins." : "Devam etmek için "+(reviveCost-totalCoins)+" coin daha gerekiyor.";
        }
        else
        {
            informationText.text =
                English ? "Continue this run with 1 life.\nYour score and distance are preserved." : "Aynı koşuya 1 canla devam et.\nSkorun ve mesafen korunur.";
        }
    }

    private void SetInformation(
        string message
    )
    {
        if (informationText != null)
        {
            informationText.text =
                message;
        }
    }

    private void HideRevivePanel()
    {
        if (revivePanelRoot != null)
        {
            revivePanelRoot.SetActive(
                false
            );
        }
    }
}

using UnityEngine;

/// <summary>An adjacent wagon warns before a short forward departure, wholly inside its reserved tile.</summary>
[DefaultExecutionOrder(-80)]
public sealed class CourierMovingTrain : MonoBehaviour
{
    private Vector3 start;
    private bool movingEnabled;
    private bool triggered;
    private float elapsed;
    private Transform runner;
    private GameObject beacon;
    public float FrameDeltaZ { get; private set; }
    public bool IsWarning=>triggered && elapsed<2.2f;
    public void Configure(bool enabledForRoute)
    {
        movingEnabled=enabledForRoute;start=transform.localPosition;triggered=false;elapsed=0;FrameDeltaZ=0;
        if(!beacon)
        {
            var asset=Resources.Load<GameObject>("CourierExpansion/TrainWarningBeacon");
            if(asset){beacon=Instantiate(asset,transform,false);beacon.transform.localPosition=new Vector3(0,2.65f,.2f);}
        }
        if(beacon)beacon.SetActive(false);
    }
    private void OnDisable(){FrameDeltaZ=0;triggered=false;if(beacon)beacon.SetActive(false);}
    private void Update()
    {
        FrameDeltaZ=0;var manager=GameManager.Instance;
        if(!movingEnabled || !manager || !manager.IsRunActive || manager.IsPaused || manager.IsGameOver)return;
        if(!runner){var controller=FindAnyObjectByType<RunnerController>();if(controller)runner=controller.transform;}
        if(!runner)return;
        if(!triggered && transform.position.z-runner.position.z<32f && runner.position.z<transform.position.z+12f)
        {triggered=true;CourierExpansionUI.ShowTrainNotice();}
        if(!triggered)return;
        elapsed+=Time.deltaTime;
        if(beacon)beacon.SetActive(elapsed<2.2f && Mathf.FloorToInt(elapsed*6)%2==0);
        float delta=Mathf.Clamp(elapsed-2.2f,0,1.5f)*1.8f;
        float previous=transform.position.z;transform.localPosition=start+Vector3.forward*delta;FrameDeltaZ=transform.position.z-previous;
        if(Mathf.Abs(FrameDeltaZ)>.00001f)Physics.SyncTransforms();
    }
}

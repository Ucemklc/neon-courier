using TMPro;
using UnityEngine;
using UnityEngine.UI;

public sealed class CourierResultsMenu : MonoBehaviour
{
    private TMP_Text recap;
    public void Apply(GameManager manager,TMP_Text[] stats,Button retry,Button menu)
    {
        var rect=(RectTransform)transform;rect.localScale=Vector3.one;
        rect.anchorMin=Vector2.zero;rect.anchorMax=Vector2.one;rect.offsetMin=rect.offsetMax=Vector2.zero;
        var bg=GetComponent<Image>();if(bg){bg.sprite=null;bg.color=new Color(.02f,.04f,.07f,.98f);bg.raycastTarget=true;}
        foreach(var t in GetComponentsInChildren<TMP_Text>(true))
        {
            if((t.text??"").Contains("OYUN BİTTİ")||(t.text??"").Contains("GAME OVER"))
            {CourierMenuLayout.Place(t.rectTransform,new Vector2(.5f,1),new Vector2(0,-170),new Vector2(900,100));TextStyle(t,55);}
        }
        for(int i=0;i<stats.Length;i++)
        {
            if(!stats[i])continue;stats[i].transform.SetParent(transform,false);
            CourierMenuLayout.Place(stats[i].rectTransform,new Vector2(.5f,1),new Vector2(i%2==0?-235:235,-510-(i/2)*260),new Vector2(430,190));
            TextStyle(stats[i],39);
        }
        if(!recap)
        {
            var go=new GameObject("RunRecap",typeof(RectTransform),typeof(TextMeshProUGUI));go.transform.SetParent(transform,false);recap=go.GetComponent<TMP_Text>();
            CourierMenuLayout.Place(recap.rectTransform,new Vector2(.5f,1),new Vector2(0,-310),new Vector2(940,135));TextStyle(recap,30);recap.color=new Color(.2f,.85f,1);
        }
        var goals=manager.GetComponent<CourierRunGoals>();bool en=PlayerPrefs.GetInt("NeonCourier.Language",0)==1;
        if(goals)recap.text=(manager.Score>goals.StartingRecord?(en?"NEW RECORD!":"YENİ REKOR!"):(en?"TO RECORD ":"REKORA KALAN ")+Mathf.Max(0,goals.StartingRecord-manager.Score))+
            "\n"+(en?"GOALS ":"HEDEFLER ")+goals.MilestonesReached+"/4  •  +"+goals.BonusCoins+" COIN  •  "+(en?"BEST COMBO x":"EN İYİ SERİ x")+goals.PeakCombo;
        StyleButton(retry,430,true);StyleButton(menu,240,false);
    }
    private void StyleButton(Button button,float y,bool primary)
    {
        if(!button)return;button.transform.SetParent(transform,false);button.gameObject.SetActive(true);
        CourierMenuLayout.Place((RectTransform)button.transform,new Vector2(.5f,0),new Vector2(0,y),new Vector2(820,140));
        var style=button.GetComponent<CourierMenuButton>();if(!style)style=button.gameObject.AddComponent<CourierMenuButton>();style.Style(primary);
    }
    private static void TextStyle(TMP_Text t,float size)
    {
        t.font=TMP_Settings.defaultFontAsset;t.fontSharedMaterial=t.font.material;t.fontSize=size;t.color=Color.white;
        t.fontStyle=FontStyles.Bold;t.margin=Vector4.zero;t.outlineWidth=0;t.alignment=TextAlignmentOptions.Center;t.raycastTarget=false;
        t.enableAutoSizing=true;t.fontSizeMin=size*.75f;t.fontSizeMax=size;
    }
}

using System;
using System.Collections;
using TMPro;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

public class CharacterSelectionPanelController :
    MonoBehaviour
{
    [Serializable]
    private class CharacterCardUI
    {
        public GameObject cardRoot;
        public TMP_Text nameText;
        public TMP_Text priceText;
        public TMP_Text statusText;
        public Button actionButton;
        public TMP_Text actionButtonText;
    }

    [Header("References")]
    [SerializeField]
    private CharacterSelectionManager
        selectionManager;

    [SerializeField]
    private GameObject characterPanel;

    [SerializeField]
    private Button openCharacterButton;

    [SerializeField]
    private Button closeCharacterButton;

    [SerializeField]
    private TMP_Text totalCoinText;

    [Header("Character Cards")]
    [SerializeField]
    private CharacterCardUI[] cards;

    private GameManager gameManager;

    private UnityAction[]
        characterButtonActions;

    private IEnumerator Start()
    {
        yield return null;

        if (selectionManager == null)
        {
            selectionManager =
                FindFirstObjectByType
                    <CharacterSelectionManager>();
        }

        gameManager =
            GameManager.Instance;

        if (
            selectionManager == null ||
            gameManager == null
        )
        {
            Debug.LogError(
                "CharacterSelectionPanelController: Gerekli yöneticiler bulunamadı.",
                this
            );

            enabled = false;
            yield break;
        }

        if (characterPanel != null)
        {
            characterPanel.SetActive(false);
        }

        if (characterPanel)
        {
            var design = characterPanel.AddComponent<CourierCharacterMenu>();
            design.Initialize(closeCharacterButton, totalCoinText);
            for (int i=0; i<cards.Length; i++)
            {
                var card=cards[i];
                // Rebuild the tiny status label to discard old per-card masks/materials.
                if (card.statusText) card.statusText.gameObject.SetActive(false);
                {
                    var status = new GameObject("CourierStatus", typeof(RectTransform), typeof(TextMeshProUGUI));
                    status.transform.SetParent(card.cardRoot.transform,false);
                    card.statusText=status.GetComponent<TMP_Text>();
                }
                design.Card(i,card.cardRoot,card.nameText,card.priceText,card.statusText,card.actionButton,card.actionButtonText);
                if (!card.actionButtonText) card.actionButtonText=card.actionButton.GetComponentInChildren<TMP_Text>(true);
            }
        }

        AddButtonListeners();

        selectionManager.SelectionChanged +=
            RefreshPanel;

        gameManager.StatsChanged +=
            RefreshPanel;

        gameManager.MainMenuChanged +=
            HandleMainMenuChanged;

        RefreshPanel();
    }

    private void OnDestroy()
    {
        RemoveButtonListeners();

        if (selectionManager != null)
        {
            selectionManager.SelectionChanged -=
                RefreshPanel;
        }

        if (gameManager != null)
        {
            gameManager.StatsChanged -=
                RefreshPanel;

            gameManager.MainMenuChanged -=
                HandleMainMenuChanged;
        }
    }

    private void AddButtonListeners()
    {
        if (openCharacterButton != null)
        {
            openCharacterButton.onClick
                .AddListener(OpenCharacterPanel);
        }

        if (closeCharacterButton != null)
        {
            closeCharacterButton.onClick
                .AddListener(CloseCharacterPanel);
        }

        if (cards == null)
        {
            return;
        }

        characterButtonActions =
            new UnityAction[cards.Length];

        for (
            int index = 0;
            index < cards.Length;
            index++
        )
        {
            int capturedIndex = index;

            characterButtonActions[index] =
                () =>
                    HandleCharacterButton(
                        capturedIndex
                    );

            if (
                cards[index] != null &&
                cards[index].actionButton != null
            )
            {
                cards[index]
                    .actionButton
                    .onClick
                    .AddListener(
                        characterButtonActions[
                            index
                        ]
                    );
            }
        }
    }

    private void RemoveButtonListeners()
    {
        if (openCharacterButton != null)
        {
            openCharacterButton.onClick
                .RemoveListener(
                    OpenCharacterPanel
                );
        }

        if (closeCharacterButton != null)
        {
            closeCharacterButton.onClick
                .RemoveListener(
                    CloseCharacterPanel
                );
        }

        if (
            cards == null ||
            characterButtonActions == null
        )
        {
            return;
        }

        int count =
            Mathf.Min(
                cards.Length,
                characterButtonActions.Length
            );

        for (
            int index = 0;
            index < count;
            index++
        )
        {
            if (
                cards[index] != null &&
                cards[index].actionButton != null &&
                characterButtonActions[index] != null
            )
            {
                cards[index]
                    .actionButton
                    .onClick
                    .RemoveListener(
                        characterButtonActions[
                            index
                        ]
                    );
            }
        }
    }

    public void OpenCharacterPanel()
    {
        if (
            characterPanel == null ||
            gameManager == null ||
            !gameManager.IsMainMenuActive
        )
        {
            return;
        }

        RefreshPanel();

        characterPanel.SetActive(true);

        characterPanel.transform
            .SetAsLastSibling();
    }

    public void CloseCharacterPanel()
    {
        if (characterPanel != null)
        {
            characterPanel.SetActive(false);
        }
    }

    private void HandleCharacterButton(
        int index
    )
    {
        if (selectionManager == null)
        {
            return;
        }

        selectionManager.TryUnlockOrSelect(
            index
        );

        RefreshPanel();
    }

    private void HandleMainMenuChanged(
        bool isMainMenuOpen
    )
    {
        if (!isMainMenuOpen)
        {
            CloseCharacterPanel();
        }
    }

    private void RefreshPanel()
    {
        if (
            selectionManager == null ||
            gameManager == null
        )
        {
            return;
        }

        if (totalCoinText != null)
        {
            totalCoinText.text =
                $"COIN: " +
                $"{gameManager.TotalCoins:N0}";
        }

        if (cards == null)
        {
            return;
        }

        for (
            int index = 0;
            index < cards.Length;
            index++
        )
        {
            CharacterCardUI card =
                cards[index];

            if (card == null)
            {
                continue;
            }

            bool hasCharacter =
                index <
                selectionManager.CharacterCount;

            if (card.cardRoot != null)
            {
                card.cardRoot.SetActive(
                    hasCharacter
                );
            }

            if (!hasCharacter)
            {
                continue;
            }

            RefreshCard(
                index,
                card
            );
        }
    }

    private void RefreshCard(
        int index,
        CharacterCardUI card
    )
    {
        string displayName =
            selectionManager.GetDisplayName(
                index
            );

        int price =
            selectionManager.GetPrice(
                index
            );

        bool unlocked =
            selectionManager.IsUnlocked(
                index
            );

        bool selected =
            selectionManager.IsSelected(
                index
            );

        bool canAfford =
            gameManager.TotalCoins >= price;

        if (card.nameText != null)
        {
            card.nameText.text =
                displayName;
        }

        if (card.priceText != null)
        {
            if (price <= 0)
            {
                card.priceText.text =
                    "ÜCRETSİZ";
            }
            else
            {
                card.priceText.text =
                    $"{price:N0} COIN";
            }
        }

        if (selected)
        {
            if (card.statusText != null)
            {
                card.statusText.text =
                    "SEÇİLİ";
            }

            if (card.actionButtonText != null)
            {
                card.actionButtonText.text =
                    "SEÇİLİ";
            }

            if (card.actionButton != null)
            {
                card.actionButton.interactable =
                    false;
            }

            return;
        }

        if (unlocked)
        {
            if (card.statusText != null)
            {
                card.statusText.text =
                    "AÇIK";
            }

            if (card.actionButtonText != null)
            {
                card.actionButtonText.text =
                    "SEÇ";
            }

            if (card.actionButton != null)
            {
                card.actionButton.interactable =
                    true;
            }

            return;
        }

        if (card.statusText != null)
        {
            card.statusText.text =
                "KİLİTLİ";
        }

        if (card.actionButtonText != null)
        {
            card.actionButtonText.text =
                canAfford
                    ? "AÇ"
                    : "COIN YETERSİZ";
        }

        if (card.actionButton != null)
        {
            card.actionButton.interactable =
                canAfford;
        }
    }
}

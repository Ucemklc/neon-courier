using System;
using System.Collections;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

[DisallowMultipleComponent]
public sealed class StoryIntroController : MonoBehaviour
{
    [Serializable]
    private sealed class StoryFrame
    {
        [Header("Visual")]
        public Sprite image;

        [Header("Text")]
        public string location;

        public string speaker;

        [TextArea(3, 7)]
        public string dialogue;

        [Header("Speaker Color")]
        public Color speakerColor =
            new Color(
                0.25f,
                0.9f,
                1f,
                1f
            );
    }

    [Header("Story Frames")]
    [SerializeField]
    private StoryFrame[] frames;

    [Header("Intro Canvas")]
    [SerializeField]
    private GameObject introCanvasRoot;

    [SerializeField]
    private CanvasGroup introCanvasGroup;

    [Header("Main Image")]
    [SerializeField]
    private Image backgroundImage;

    [SerializeField]
    private RectTransform backgroundRect;

    [Header("Texts")]
    [SerializeField]
    private TMP_Text locationText;

    [SerializeField]
    private TMP_Text speakerNameText;

    [SerializeField]
    private TMP_Text dialogueText;

    [SerializeField]
    private GameObject continueIndicator;

    [Header("Buttons")]
    [SerializeField]
    private Button tapAreaButton;

    [SerializeField]
    private Button skipButton;

    [Header("Frame Fade")]
    [SerializeField]
    private CanvasGroup fadeCanvasGroup;

    [SerializeField, Min(0f)]
    private float frameFadeDuration =
        0.18f;

    [Header("Typewriter")]
    [SerializeField, Min(1f)]
    private float charactersPerSecond =
        42f;

    [Header("Image Movement")]
    [SerializeField, Range(1f, 1.12f)]
    private float imageZoomScale =
        1.035f;

    [SerializeField, Min(0.1f)]
    private float imageZoomDuration =
        7f;

    [Header("Finish Transition")]
    [SerializeField, Min(0f)]
    private float finishFadeDuration =
        0.25f;

    [Header("Main Menu")]
    [Tooltip(
        "GameHUD altındaki MainMenuPanel bağlanmalıdır."
    )]
    [SerializeField]
    private GameObject mainMenuRoot;

    [Header("Playback")]
    [SerializeField]
    private bool playAutomatically =
        true;

    [SerializeField]
    private bool playOnlyOnce =
        true;

    [SerializeField]
    private string introSeenKey =
        "NeonCourier_StoryIntro_Seen_v1";

    [Header("Debug")]
    [SerializeField]
    private bool debugLogs =
        false;

    private int currentFrameIndex =
        -1;

    private bool introRunning;
    private bool isTyping;
    private bool isTransitioning;
    private bool isFinishing;
    private bool completeTypingRequested;

    private Coroutine transitionCoroutine;
    private Coroutine typingCoroutine;
    private Coroutine zoomCoroutine;

    private void Awake()
    {
        RegisterButtonEvents();

        SetContinueIndicator(false);
    }

    private void Start()
    {
        if (!playAutomatically)
        {
            ShowMainMenuWithoutIntro();
            return;
        }

        bool introWasSeen =
            playOnlyOnce &&
            PlayerPrefs.GetInt(
                introSeenKey,
                0
            ) == 1;

        if (introWasSeen)
        {
            ShowMainMenuWithoutIntro();
            return;
        }

        BeginIntro();
    }

    private void OnDestroy()
    {
        UnregisterButtonEvents();
    }

    public void BeginIntro()
    {
        if (introRunning)
        {
            return;
        }

        if (!ValidateReferences())
        {
            ShowMainMenuWithoutIntro();
            return;
        }

        StopAllCoroutines();

        transitionCoroutine = null;
        typingCoroutine = null;
        zoomCoroutine = null;

        currentFrameIndex = 0;

        introRunning = true;
        isTyping = false;
        isTransitioning = true;
        isFinishing = false;
        completeTypingRequested = false;

        SetMainMenuVisible(false);
        SetIntroVisible(true);

        introCanvasGroup.alpha = 1f;
        fadeCanvasGroup.alpha = 1f;

        SetContinueIndicator(false);

        transitionCoroutine =
            StartCoroutine(
                ShowFirstFrameRoutine()
            );

        if (debugLogs)
        {
            Debug.Log(
                "Story intro başlatıldı.",
                this
            );
        }
    }

    public void ReplayIntro()
    {
        if (introRunning)
        {
            return;
        }

        BeginIntro();
    }

    public void HandleTap()
    {
        if (
            !introRunning ||
            isTransitioning ||
            isFinishing
        )
        {
            return;
        }

        if (isTyping)
        {
            completeTypingRequested = true;
            return;
        }

        if (
            currentFrameIndex >=
            frames.Length - 1
        )
        {
            FinishIntro();
            return;
        }

        transitionCoroutine =
            StartCoroutine(
                ChangeFrameRoutine(
                    currentFrameIndex + 1
                )
            );
    }

    public void SkipIntro()
    {
        if (!introRunning)
        {
            ShowMainMenuWithoutIntro();
            return;
        }

        FinishIntro();
    }

    [ContextMenu("Test / Reset Intro Seen")]
    public void ResetIntroSeen()
    {
        PlayerPrefs.DeleteKey(
            introSeenKey
        );

        PlayerPrefs.Save();

        Debug.Log(
            "Intro izlendi kaydı silindi.",
            this
        );
    }

    private IEnumerator ShowFirstFrameRoutine()
    {
        ApplyFrame(currentFrameIndex);
        StartImageZoom();

        yield return FadeCanvasGroup(
            fadeCanvasGroup,
            0f,
            frameFadeDuration
        );

        isTransitioning = false;

        StartTypewriter();
    }

    private IEnumerator ChangeFrameRoutine(
        int nextFrameIndex
    )
    {
        isTransitioning = true;

        SetContinueIndicator(false);

        yield return FadeCanvasGroup(
            fadeCanvasGroup,
            1f,
            frameFadeDuration
        );

        StopFrameEffects();

        currentFrameIndex =
            nextFrameIndex;

        ApplyFrame(currentFrameIndex);
        StartImageZoom();

        yield return FadeCanvasGroup(
            fadeCanvasGroup,
            0f,
            frameFadeDuration
        );

        isTransitioning = false;

        StartTypewriter();
    }

    private void ApplyFrame(
        int frameIndex
    )
    {
        if (
            frames == null ||
            frameIndex < 0 ||
            frameIndex >= frames.Length
        )
        {
            return;
        }

        StoryFrame frame =
            frames[frameIndex];

        backgroundImage.sprite =
            frame.image;

        backgroundImage.enabled =
            frame.image != null;

        if (backgroundRect != null)
        {
            backgroundRect.localScale =
                Vector3.one;
        }

        locationText.text =
            frame.location;

        speakerNameText.text =
            frame.speaker;

        speakerNameText.color =
            frame.speakerColor;

        dialogueText.text =
            frame.dialogue;

        dialogueText.maxVisibleCharacters =
            0;

        SetContinueIndicator(false);
    }

    private void StartTypewriter()
    {
        if (typingCoroutine != null)
        {
            StopCoroutine(
                typingCoroutine
            );
        }

        typingCoroutine =
            StartCoroutine(
                TypewriterRoutine()
            );
    }

    private IEnumerator TypewriterRoutine()
    {
        isTyping = true;
        completeTypingRequested = false;

        SetContinueIndicator(false);

        dialogueText.ForceMeshUpdate();

        int totalCharacters =
            dialogueText.textInfo
                .characterCount;

        dialogueText.maxVisibleCharacters =
            0;

        float visibleCharacters = 0f;

        while (
            dialogueText
                .maxVisibleCharacters <
            totalCharacters
        )
        {
            if (completeTypingRequested)
            {
                break;
            }

            visibleCharacters +=
                charactersPerSecond *
                Time.unscaledDeltaTime;

            dialogueText
                .maxVisibleCharacters =
                Mathf.Clamp(
                    Mathf.FloorToInt(
                        visibleCharacters
                    ),
                    0,
                    totalCharacters
                );

            yield return null;
        }

        dialogueText.maxVisibleCharacters =
            totalCharacters;

        isTyping = false;
        completeTypingRequested = false;
        typingCoroutine = null;

        SetContinueIndicator(true);
    }

    private void StartImageZoom()
    {
        if (backgroundRect == null)
        {
            return;
        }

        if (zoomCoroutine != null)
        {
            StopCoroutine(
                zoomCoroutine
            );
        }

        zoomCoroutine =
            StartCoroutine(
                ImageZoomRoutine()
            );
    }

    private IEnumerator ImageZoomRoutine()
    {
        backgroundRect.localScale =
            Vector3.one;

        Vector3 targetScale =
            Vector3.one *
            imageZoomScale;

        float elapsedTime = 0f;

        while (
            elapsedTime <
            imageZoomDuration
        )
        {
            elapsedTime +=
                Time.unscaledDeltaTime;

            float progress =
                Mathf.Clamp01(
                    elapsedTime /
                    imageZoomDuration
                );

            float smoothProgress =
                progress *
                progress *
                (3f - 2f * progress);

            backgroundRect.localScale =
                Vector3.Lerp(
                    Vector3.one,
                    targetScale,
                    smoothProgress
                );

            yield return null;
        }

        backgroundRect.localScale =
            targetScale;

        zoomCoroutine = null;
    }

    private void FinishIntro()
    {
        if (isFinishing)
        {
            return;
        }

        isFinishing = true;
        isTransitioning = true;

        StopFrameEffects();

        transitionCoroutine =
            StartCoroutine(
                FinishIntroRoutine()
            );
    }

    private IEnumerator FinishIntroRoutine()
    {
        SetContinueIndicator(false);

        PlayerPrefs.SetInt(
            introSeenKey,
            1
        );

        PlayerPrefs.Save();

        SetMainMenuVisible(true);

        yield return FadeCanvasGroup(
            introCanvasGroup,
            0f,
            finishFadeDuration
        );

        introRunning = false;
        isTyping = false;
        isTransitioning = false;
        isFinishing = false;

        SetIntroVisible(false);

        introCanvasGroup.alpha = 1f;
        fadeCanvasGroup.alpha = 1f;

        transitionCoroutine = null;

        if (debugLogs)
        {
            Debug.Log(
                "Story intro tamamlandı.",
                this
            );
        }
    }

    private IEnumerator FadeCanvasGroup(
        CanvasGroup canvasGroup,
        float targetAlpha,
        float duration
    )
    {
        if (canvasGroup == null)
        {
            yield break;
        }

        float startAlpha =
            canvasGroup.alpha;

        if (duration <= 0f)
        {
            canvasGroup.alpha =
                targetAlpha;

            yield break;
        }

        float elapsedTime = 0f;

        while (elapsedTime < duration)
        {
            elapsedTime +=
                Time.unscaledDeltaTime;

            float progress =
                Mathf.Clamp01(
                    elapsedTime /
                    duration
                );

            canvasGroup.alpha =
                Mathf.Lerp(
                    startAlpha,
                    targetAlpha,
                    progress
                );

            yield return null;
        }

        canvasGroup.alpha =
            targetAlpha;
    }

    private void StopFrameEffects()
    {
        if (typingCoroutine != null)
        {
            StopCoroutine(
                typingCoroutine
            );

            typingCoroutine = null;
        }

        if (zoomCoroutine != null)
        {
            StopCoroutine(
                zoomCoroutine
            );

            zoomCoroutine = null;
        }

        isTyping = false;
        completeTypingRequested = false;
    }

    private void ShowMainMenuWithoutIntro()
    {
        introRunning = false;
        isTyping = false;
        isTransitioning = false;
        isFinishing = false;

        SetIntroVisible(false);
        SetMainMenuVisible(true);
    }

    private void SetIntroVisible(
        bool visible
    )
    {
        if (introCanvasRoot != null)
        {
            if (visible)
            {
                RectTransform canvasRect =
                    introCanvasRoot.transform as RectTransform;

                if (canvasRect != null)
                {
                    canvasRect.localScale = Vector3.one;
                }
            }

            introCanvasRoot.SetActive(
                visible
            );
        }

        if (introCanvasGroup != null)
        {
            introCanvasGroup.alpha =
                visible ? 1f : 0f;

            introCanvasGroup.interactable =
                visible;

            introCanvasGroup.blocksRaycasts =
                visible;
        }
    }

    private void SetMainMenuVisible(
        bool visible
    )
    {
        if (mainMenuRoot == null)
        {
            return;
        }

        mainMenuRoot.SetActive(
            visible
        );
    }

    private void SetContinueIndicator(
        bool visible
    )
    {
        if (continueIndicator == null)
        {
            return;
        }

        continueIndicator.SetActive(
            visible
        );
    }

    private void RegisterButtonEvents()
    {
        if (tapAreaButton != null)
        {
            tapAreaButton.onClick.AddListener(
                HandleTap
            );
        }

        if (skipButton != null)
        {
            skipButton.onClick.AddListener(
                SkipIntro
            );
        }
    }

    private void UnregisterButtonEvents()
    {
        if (tapAreaButton != null)
        {
            tapAreaButton.onClick.RemoveListener(
                HandleTap
            );
        }

        if (skipButton != null)
        {
            skipButton.onClick.RemoveListener(
                SkipIntro
            );
        }
    }

    private bool ValidateReferences()
    {
        bool valid =
            introCanvasRoot != null &&
            introCanvasGroup != null &&
            backgroundImage != null &&
            backgroundRect != null &&
            locationText != null &&
            speakerNameText != null &&
            dialogueText != null &&
            continueIndicator != null &&
            tapAreaButton != null &&
            skipButton != null &&
            fadeCanvasGroup != null &&
            mainMenuRoot != null &&
            frames != null &&
            frames.Length > 0;

        if (valid)
        {
            return true;
        }

        Debug.LogError(
            "StoryIntroController: " +
            "Inspector bağlantılarından biri eksik.",
            this
        );

        return false;
    }

    private void OnValidate()
    {
        frameFadeDuration =
            Mathf.Max(
                0f,
                frameFadeDuration
            );

        charactersPerSecond =
            Mathf.Max(
                1f,
                charactersPerSecond
            );

        imageZoomScale =
            Mathf.Clamp(
                imageZoomScale,
                1f,
                1.12f
            );

        imageZoomDuration =
            Mathf.Max(
                0.1f,
                imageZoomDuration
            );

        finishFadeDuration =
            Mathf.Max(
                0f,
                finishFadeDuration
            );

        if (
            string.IsNullOrWhiteSpace(
                introSeenKey
            )
        )
        {
            introSeenKey =
                "NeonCourier_StoryIntro_Seen_v1";
        }
    }
}

using TMPro;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.UI;

/// <summary>Mobile-friendly wardrobe, a live 3D backpack preview, and a compact cargo ledger.</summary>
public sealed class CourierExpansionUI : MonoBehaviour
{
    private GameManager manager;
    private RunnerController runner;
    private GameObject menuButton,wardrobe,hud;
    private TMP_Text cargoText,noticeText;
    private Image districtProgress;
    private Button[] skins=new Button[6],patches=new Button[5],effects=new Button[3];
    private Camera previewCamera;
    private RenderTexture previewTexture;
    private GameObject previewRoot;
    private Transform previewBag;
    private int previewStyle=-1;
    private float nextRefresh,nextRender;
    private static float trainNoticeUntil,routeNoticeUntil,roofNoticeUntil;
    private CourierDistrict lastDistrict=(CourierDistrict)(-1);
    private float districtNoticeUntil;
    private static readonly Color Background=new Color(.022f,.035f,.065f,1f);
    private static readonly Color Cyan=new Color(.15f,.89f,1);
    public bool WardrobeOpen=>wardrobe && wardrobe.activeSelf;
    private bool English=>PlayerPrefs.GetInt("NeonCourier.Language",0)==1;
    public static void ShowTrainNotice(){trainNoticeUntil=Time.unscaledTime+2.2f;}
    public static void ShowRouteNotice(){routeNoticeUntil=Time.unscaledTime+2.5f;}
    public static void ShowRoofNotice(){roofNoticeUntil=Time.unscaledTime+3f;}

    private void Start(){manager=GetComponent<GameManager>();Build();}
    private void OnDestroy()
    {
        if(previewRoot)Destroy(previewRoot);
        if(previewTexture){previewTexture.Release();Destroy(previewTexture);}
    }
    private void Update()
    {
        if(!manager || !menuButton)return;
        var characterMenu=FindAnyObjectByType<CourierCharacterMenu>();
        var garage=manager.GetComponent<CourierGarageUI>();
        menuButton.SetActive(manager.IsMainMenuActive&&!WardrobeOpen&&!characterMenu&&!(garage&&garage.IsOpen)&&!CourierGarageUI.MenuOverlayOpen);
        if(!manager.IsMainMenuActive && WardrobeOpen)CloseWardrobe();
        bool playing=manager.IsRunActive&&!manager.IsGameOver&&!manager.IsPaused&&!manager.IsMainMenuActive;
        hud.SetActive(playing);
        if(Time.unscaledTime>=nextRefresh){RefreshText();nextRefresh=Time.unscaledTime+.15f;}
        if(WardrobeOpen && previewCamera && Time.unscaledTime>=nextRender)
        {
            previewBag.localRotation=Quaternion.Euler(0,-18f+Mathf.Sin(Time.unscaledTime*.5f)*13f,0);
            var request=new RenderPipeline.StandardRequest{destination=previewTexture};
            if(RenderPipeline.SupportsRenderRequest(previewCamera,request))RenderPipeline.SubmitRenderRequest(previewCamera,request);
            nextRender=Time.unscaledTime+.10f;
        }
    }
    public void OpenWardrobe()
    {if(!manager || !manager.IsMainMenuActive)return;EnsurePreview();wardrobe.SetActive(true);if(previewRoot)previewRoot.SetActive(true);RefreshWorkshopLabels();RefreshSelections();}
    public void CloseWardrobe(){if(wardrobe)wardrobe.SetActive(false);if(previewRoot)previewRoot.SetActive(false);}
    public void SelectSkin(int index){CourierBackpackStyle.Set(index,CourierBackpackStyle.Patch,CourierBackpackStyle.Glow);RefreshSelections();}
    public void SelectPatch(int index){if(!CourierCareerProgress.PatchUnlocked(index))return;CourierBackpackStyle.Set(CourierBackpackStyle.Skin,index,CourierBackpackStyle.Glow);RefreshSelections();}
    public void SelectGlow(int index){CourierBackpackStyle.Set(CourierBackpackStyle.Skin,CourierBackpackStyle.Patch,index);RefreshSelections();}

    private void Build()
    {
        var canvasRoot=new GameObject("CourierExpansionCanvas",typeof(RectTransform),typeof(Canvas),typeof(CanvasScaler),typeof(GraphicRaycaster));
        canvasRoot.transform.SetParent(transform,false);var canvas=canvasRoot.GetComponent<Canvas>();canvas.renderMode=RenderMode.ScreenSpaceOverlay;canvas.sortingOrder=180;
        var scale=canvasRoot.GetComponent<CanvasScaler>();scale.uiScaleMode=CanvasScaler.ScaleMode.ScaleWithScreenSize;scale.referenceResolution=new Vector2(1080,1920);scale.matchWidthOrHeight=.5f;
        canvasRoot.AddComponent<CourierRunPolishHUD>();
        canvasRoot.AddComponent<CourierRunGoalsHUD>();
        var menu=ButtonAt(canvasRoot.transform,"BagWorkshop",new Vector2(.5f,0),new Vector2(0,350),new Vector2(820,104),"ÇANTA ATÖLYESİ",OpenWardrobe);menuButton=menu.gameObject;
        wardrobe=Panel(canvasRoot.transform,"BackpackWorkshop",Background);wardrobe.SetActive(false);
        TextAt(wardrobe.transform,"Title",new Vector2(.5f,1),new Vector2(0,-125),new Vector2(850,90),English?"COURIER WORKSHOP":"KURYE ATÖLYESİ",55,Cyan);
        TextAt(wardrobe.transform,"Subtitle",new Vector2(.5f,1),new Vector2(0,-217),new Vector2(900,70),English?"Your route. Your colors.":"Senin rotan, senin renklerin.",30,Color.white);
        ButtonAt(wardrobe.transform,"Close",Vector2.one,new Vector2(-85,-82),new Vector2(90,78),"X",CloseWardrobe);
        var view=new GameObject("BackpackPreview",typeof(RectTransform),typeof(RawImage));view.transform.SetParent(wardrobe.transform,false);
        Rect(view.GetComponent<RectTransform>(),new Vector2(.5f,1),new Vector2(0,-510),new Vector2(600,560));view.GetComponent<RawImage>().raycastTarget=false;
        TextAt(wardrobe.transform,"ColorLabel",new Vector2(.5f,1),new Vector2(0,-835),new Vector2(850,55),English?"COLORS":"RENKLER",31,Cyan);
        for(int i=0;i<6;i++){int choice=i;skins[i]=ButtonAt(wardrobe.transform,"Skin"+i,new Vector2(.5f,1),new Vector2((i-2.5f)*145,-925),new Vector2(132,94),"",()=>SelectSkin(choice));}
        TextAt(wardrobe.transform,"PatchLabel",new Vector2(.5f,1),new Vector2(0,-1070),new Vector2(850,55),English?"PATCH":"ARMA",31,Cyan);
        for(int i=0;i<5;i++){int choice=i;patches[i]=ButtonAt(wardrobe.transform,"Patch"+i,new Vector2(.5f,1),new Vector2((i-2)*180,-1160),new Vector2(170,90),"",()=>SelectPatch(choice));}
        TextAt(wardrobe.transform,"GlowLabel",new Vector2(.5f,1),new Vector2(0,-1305),new Vector2(850,55),English?"LIGHT EFFECT":"IŞIK EFEKTİ",31,Cyan);
        for(int i=0;i<3;i++){int choice=i;effects[i]=ButtonAt(wardrobe.transform,"Glow"+i,new Vector2(.5f,1),new Vector2((i-1)*292,-1395),new Vector2(274,90),"",()=>SelectGlow(choice));}
        TextAt(wardrobe.transform,"SaveHint",new Vector2(.5f,1),new Vector2(0,-1535),new Vector2(900,80),English?"Career badges unlock at levels 3 and 6. Saved automatically.":"Kariyer armaları seviye 3 ve 6'da açılır. Seçimin kaydedilir.",28,new Color(.68f,.76f,.85f));
        ButtonAt(wardrobe.transform,"Done",new Vector2(.5f,1),new Vector2(0,-1660),new Vector2(550,104),English?"READY TO DELIVER":"TESLİMATA HAZIRIM",CloseWardrobe);
        hud=Panel(canvasRoot.transform,"CargoLedger",new Color(.025f,.04f,.075f,.80f),false);
        Rect(hud.GetComponent<RectTransform>(),new Vector2(.5f,0),new Vector2(0,278),new Vector2(940,154));
        cargoText=TextAt(hud.transform,"CargoStatus",new Vector2(.5f,.5f),Vector2.zero,new Vector2(902,144),"",27,Color.white);
        noticeText=TextAt(hud.transform,"RouteNotice",new Vector2(.5f,1),new Vector2(0,96),new Vector2(940,96),"",36,Cyan);
        var bar=new GameObject("DistrictProgress",typeof(RectTransform),typeof(Image));bar.transform.SetParent(hud.transform,false);
        var barRect=(RectTransform)bar.transform;barRect.anchorMin=barRect.anchorMax=Vector2.zero;barRect.pivot=Vector2.zero;barRect.anchoredPosition=new Vector2(12,4);barRect.sizeDelta=new Vector2(916,5);
        districtProgress=bar.GetComponent<Image>();districtProgress.color=Cyan;districtProgress.raycastTarget=false;
    }
    private void RefreshText()
    {
        bool en=English;
        menuButton.GetComponentInChildren<TMP_Text>().text=en?"BACKPACK WORKSHOP":"ÇANTA ATÖLYESİ";
        var ledger=CourierCargoManifest.Instance;if(!runner)runner=FindAnyObjectByType<RunnerController>();
        CourierDistrict district=CourierWorldRules.DistrictAt(runner?runner.transform.position.z:0);
        if(district!=lastDistrict){lastDistrict=district;districtNoticeUntil=Time.unscaledTime+3;}
        if(!ledger)return;
        string express=en?"EXPRESS":"SÜRELİ",fragile=en?"FRAGILE":"KIRILGAN",heavy=en?"HEAVY":"AĞIR";
        float districtFraction=Mathf.Repeat(Mathf.Max(0,(runner?runner.transform.position.z:0)+10),CourierWorldRules.DistrictLength)/CourierWorldRules.DistrictLength;
        districtProgress.rectTransform.sizeDelta=new Vector2(916*districtFraction,5);
        cargoText.text=CourierWorldRules.DistrictName(district,en)+"  •  "+Mathf.CeilToInt((1-districtFraction)*CourierWorldRules.DistrictLength)+(en?" m to next":" m kaldı")+"\n"+
            $"<color=#32D5FF>{express} {ledger.Count(CourierCargoKind.Express)} • {Mathf.CeilToInt(ledger.EarliestDeadline)}s</color>   "+
            $"<color=#FF61AA>{fragile} {ledger.Count(CourierCargoKind.Fragile)}</color>   <color=#FFC64A>{heavy} {ledger.Count(CourierCargoKind.Heavy)}</color>\n"+
            (CourierCharacterAbilities.Instance&&CourierCharacterAbilities.Instance.TimeLeft>0?(en?"EXPRESS BOOST • ":"EKSPRES HIZI • ")+CourierCharacterAbilities.Instance.TimeLeft.ToString("0.0")+(en?" s":" sn"):
            ledger.Items.Count==0?(en?"Blue: 18s +6  •  Pink: no hits +5  •  Gold: slower +4":"Mavi: 18 sn +6  •  Pembe: hasarsız +5  •  Sarı: yavaş +4"):
            ledger.Count(CourierCargoKind.Express)>0 && ledger.EarliestDeadline<=0?(en?"Express deadline missed: base reward only":"Süresi dolan kargo: standart teslimat ödülü"):
            ledger.DamagedFragileCount>0?(en?"Damaged fragile cargo: base reward only":"Hasarlı kırılgan kargo: standart teslimat ödülü"):
            ledger.Count(CourierCargoKind.Heavy)>0?(CourierCharacterAbilities.ActiveIndex==2?(en?"Industrial ability: -3% each (max -6%)":"Sanayi yeteneği: paket başına -%3 (en fazla -%6)"):(en?"Heavy cargo: speed -8% each (max -16%)":"Ağır yük: paket başına hız -%8 (en fazla -%16)")):
            (en?"Deliver special cargo for extra coins":"Özel kargoları teslim et, ek coin kazan"));
        if(CourierDroneChallenge.Instance&&CourierDroneChallenge.Instance.ShowMessage)noticeText.text=CourierDroneChallenge.Instance.Message(en);
        else if(Time.unscaledTime<roofNoticeUntil)noticeText.text=en?"ROOFTOP ROUTE COMPLETE • +15 COINS":"ÇATI PARKURU TAMAM • +15 COIN";
        else if(Time.unscaledTime<trainNoticeUntil)noticeText.text=en?"TRAIN DEPARTING • KEEP A CLEAR LANE":"TREN HAREKET EDİYOR • ŞERİDİ KONTROL ET";
        else if(Time.unscaledTime<routeNoticeUntil)noticeText.text=en?"SHORTCUT COMPLETE • SPEED BOOST":"KESTİRME TAMAMLANDI • HIZ BONUSU";
        else if(Time.unscaledTime<ledger.BonusMessageUntil && ledger.LastDeliveryBonus>0)noticeText.text=(en?"SPECIAL DELIVERY +":"ÖZEL TESLİMAT +")+ledger.LastDeliveryBonus+" COIN";
        else if(Time.unscaledTime<districtNoticeUntil)noticeText.text=CourierWorldRules.DistrictName(district,en);
        else noticeText.text="";
    }
    private void RefreshWorkshopLabels()
    {
        bool en=English;
        Label("Title",en?"COURIER WORKSHOP":"KURYE ATÖLYESİ");
        Label("Subtitle",en?"Your route. Your colors.":"Senin rotan, senin renklerin.");
        Label("ColorLabel",en?"COLORS":"RENKLER");Label("PatchLabel",en?"PATCH":"ARMA");
        Label("GlowLabel",en?"LIGHT EFFECT":"IŞIK EFEKTİ");
        Label("SaveHint",en?"Career badges unlock at levels 3 and 6. Saved automatically.":"Kariyer armaları seviye 3 ve 6'da açılır. Seçimin kaydedilir.");
        Label("Done/Label",en?"READY TO DELIVER":"TESLİMATA HAZIRIM");
    }
    private void Label(string path,string value){wardrobe.transform.Find(path).GetComponent<TMP_Text>().text=value;}
    private void RefreshSelections()
    {
        string[] names=English?new[]{"NEON","ICE","VIOLET","FOREST","SUNSET","NIGHT"}:new[]{"NEON","BUZ","MOR","ORMAN","GÜNBATIMI","GECE"};
        string[] patchNames=English?new[]{"MAIL","LIGHTNING","STAR","MASTER","LEGEND"}:new[]{"ZARF","ŞİMŞEK","YILDIZ","USTA","EFSANE"};
        string[] glowNames=English?new[]{"STEADY","PULSE","SPECTRUM"}:new[]{"SABİT","NABIZ","RENK AKIŞI"};
        for(int i=0;i<6;i++)StyleChoice(skins[i],names[i],i==CourierBackpackStyle.Skin,CourierBackpackStyle.Accents[i]);
        for(int i=0;i<5;i++){bool unlocked=CourierCareerProgress.PatchUnlocked(i);patches[i].interactable=unlocked;StyleChoice(patches[i],unlocked?patchNames[i]:(English?"LV ":"SV ")+(i==3?3:6),i==CourierBackpackStyle.Patch,new Color(.11f,.20f,.29f));}
        for(int i=0;i<3;i++)StyleChoice(effects[i],glowNames[i],i==CourierBackpackStyle.Glow,new Color(.11f,.20f,.29f));
    }
    private static void StyleChoice(Button button,string label,bool selected,Color color)
    {
        button.GetComponent<Image>().color=color;var outline=button.GetComponent<Outline>();outline.effectColor=selected?Cyan:Color.clear;
        button.GetComponentInChildren<TMP_Text>().text=(selected?"• ":"")+label;
    }
    private void EnsurePreview()
    {
        int style=Mathf.Clamp(PlayerPrefs.GetInt("NeonCourier.SelectedCharacter",0),0,3);
        if(previewRoot&&previewStyle==style)return;
        if(previewRoot)Destroy(previewRoot);
        if(previewTexture){previewTexture.Release();Destroy(previewTexture);}
        previewStyle=style;
        previewRoot=new GameObject("Backpack wardrobe preview");previewRoot.transform.SetParent(transform,false);previewRoot.transform.position=new Vector3(0,-1000,0);
        var asset=Resources.Load<GameObject>("CourierReference/Bag"+style) ?? Resources.Load<GameObject>("CourierExpansion/BackpackPreview");if(!asset)return;
        var model=Instantiate(asset,previewRoot.transform,false);previewBag=model.transform;
        foreach(var behavior in model.GetComponentsInChildren<MonoBehaviour>(true))behavior.enabled=false;
        var appearance=model.GetComponent<CourierBackpackAppearance>();if(!appearance)appearance=model.AddComponent<CourierBackpackAppearance>();appearance.enabled=true;
        if(model.name.StartsWith("Bag"))appearance.UseCompactPatch();
        foreach(var t in model.GetComponentsInChildren<Transform>(true))t.gameObject.layer=31;
        var cameraObject=new GameObject("Backpack preview camera",typeof(Camera));cameraObject.transform.SetParent(previewRoot.transform,false);previewCamera=cameraObject.GetComponent<Camera>();
        cameraObject.transform.localPosition=new Vector3(-1.15f,.65f,-2.5f);cameraObject.transform.LookAt(previewRoot.transform.position+new Vector3(0,.045f,0));
        previewCamera.enabled=false;previewCamera.cullingMask=1<<31;previewCamera.fieldOfView=29;previewCamera.nearClipPlane=.1f;previewCamera.farClipPlane=10;
        previewCamera.clearFlags=CameraClearFlags.SolidColor;previewCamera.backgroundColor=new Color(.022f,.035f,.065f,0);
        var lamp=new GameObject("Wardrobe light",typeof(Light));lamp.transform.SetParent(previewRoot.transform,false);lamp.transform.localPosition=new Vector3(-1,1.5f,-1.8f);
        var light=lamp.GetComponent<Light>();light.type=LightType.Point;light.intensity=4;light.range=6;light.cullingMask=1<<31;
        previewTexture=new RenderTexture(600,560,24,RenderTextureFormat.ARGB32);previewTexture.Create();
        wardrobe.transform.Find("BackpackPreview").GetComponent<RawImage>().texture=previewTexture;
    }
    private static GameObject Panel(Transform parent,string name,Color color,bool stretch=true)
    {
        var go=new GameObject(name,typeof(RectTransform),typeof(Image));go.transform.SetParent(parent,false);go.GetComponent<Image>().color=color;go.GetComponent<Image>().raycastTarget=stretch;
        if(stretch){var rect=go.GetComponent<RectTransform>();rect.anchorMin=Vector2.zero;rect.anchorMax=Vector2.one;rect.offsetMin=rect.offsetMax=Vector2.zero;}
        return go;
    }
    private static void Rect(RectTransform rect,Vector2 anchor,Vector2 position,Vector2 size)
    {rect.anchorMin=rect.anchorMax=anchor;rect.pivot=new Vector2(.5f,.5f);rect.anchoredPosition=position;rect.sizeDelta=size;}
    private static TMP_Text TextAt(Transform parent,string name,Vector2 anchor,Vector2 position,Vector2 size,string value,float font,Color color)
    {
        var go=new GameObject(name,typeof(RectTransform),typeof(TextMeshProUGUI));go.transform.SetParent(parent,false);Rect(go.GetComponent<RectTransform>(),anchor,position,size);
        var text=go.GetComponent<TextMeshProUGUI>();text.text=value;text.font=TMP_Settings.defaultFontAsset;text.fontSize=font;text.color=color;text.alignment=TextAlignmentOptions.Center;text.raycastTarget=false;text.enableAutoSizing=true;text.fontSizeMin=font*.74f;text.fontSizeMax=font;return text;
    }
    private static Button ButtonAt(Transform parent,string name,Vector2 anchor,Vector2 position,Vector2 size,string label,UnityEngine.Events.UnityAction action)
    {
        var go=Panel(parent,name,new Color(.06f,.15f,.24f),false);Rect(go.GetComponent<RectTransform>(),anchor,position,size);go.GetComponent<Image>().raycastTarget=true;
        var outline=go.AddComponent<Outline>();outline.effectColor=Cyan;outline.effectDistance=new Vector2(2,-2);
        var button=go.AddComponent<Button>();button.targetGraphic=go.GetComponent<Image>();button.onClick.AddListener(action);
        TextAt(go.transform,"Label",new Vector2(.5f,.5f),Vector2.zero,size-new Vector2(18,12),label,28,Color.white);return button;
    }
}

#if UNITY_EDITOR
using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;
using Object = UnityEngine.Object;

/// <summary>Creates durable rail prefabs from the same geometry used by the runtime fallback.</summary>
public static class NeonRailUpgrade
{
    private const string AssetFolder = "Assets/Resources/NeonRail";
    private const string TrainPath = AssetFolder + "/NeonCargoTrain.prefab";
    private const string CarPath = AssetFolder + "/NeonCargoCar.prefab";
    private const string SignPath = AssetFolder + "/RampRouteSign.prefab";

    [MenuItem("Neon Courier/Generate Rail Assets")]
    public static void GenerateAssets()
    {
        EnsureFolder(AssetFolder + "/Meshes");
        EnsureFolder(AssetFolder + "/Materials");
        WithTemporaryRoot(parent =>
        {
            var assets = new AssetWriter();
            SavePrefab(NeonRailFactory.CreateTrain(parent, 2.5f, true), TrainPath, "NeonCargoTrain", assets);
            SavePrefab(NeonRailFactory.CreateTrain(parent, 2.5f, false), CarPath, "NeonCargoCar", assets);
            SavePrefab(NeonRailFactory.CreateRouteSign(parent), SignPath, "RampRouteSign", assets);
        });
        AssetDatabase.SaveAssets();
        Debug.Log("NEON_RAIL_ASSETS_OK: 3 prefabs with persistent shared meshes and materials in " + AssetFolder);
    }

    [MenuItem("Neon Courier/Validate Rail Assets")]
    public static void ValidateAndGenerate()
    {
        GenerateAssets();
        Dictionary<string, string> originalGuids = CaptureAssetGuids();
        GenerateAssets();
        foreach (KeyValuePair<string, string> entry in originalGuids)
            Require(AssetDatabase.AssetPathToGUID(entry.Key) == entry.Value,
                "Regeneration changed asset GUID: " + entry.Key);

        WithTemporaryRoot(parent =>
        {
            ValidateTrain(InstantiateSaved(TrainPath, parent), true);
            ValidateTrain(InstantiateSaved(CarPath, parent), false);
            GameObject sign = InstantiateSaved(SignPath, parent);
            Require(sign.GetComponentsInChildren<Collider>(true).Length == 0,
                "Route sign decoration must not block the runner.");
            ValidatePersistentReferences(sign);
        });
        Debug.Log("NEON_RAIL_VALIDATION_OK: stable GUIDs; entry ramp -4.5..0 m, roof 0..12 m, " +
            "exit ramp 12..16.5 m; 2.4 m roof; persistent resources; no decoration colliders.");
    }

    private static void SavePrefab(GameObject root, string path, string name, AssetWriter writer)
    {
        root.name = name;
        root.transform.localPosition = Vector3.zero;
        root.transform.localRotation = Quaternion.identity;
        root.transform.localScale = Vector3.one;
        foreach (Transform child in root.GetComponentsInChildren<Transform>(true))
            child.gameObject.hideFlags = HideFlags.None;
        writer.PersistReferences(root);
        GameObject saved = PrefabUtility.SaveAsPrefabAsset(root, path, out bool success);
        Require(success && saved != null, "Failed to save rail prefab: " + path);
        ValidatePersistentReferences(saved);
    }

    private static GameObject InstantiateSaved(string path, Transform parent)
    {
        GameObject prefab = AssetDatabase.LoadAssetAtPath<GameObject>(path);
        Require(prefab != null, "Missing generated prefab: " + path);
        return Object.Instantiate(prefab, parent, false);
    }

    private static void ValidateTrain(GameObject train, bool ramps)
    {
        Require(train.GetComponent<RailRideSurface>() != null, "Train root needs RailRideSurface.");
        Collider[] colliders = train.GetComponentsInChildren<Collider>(true);
        Require(colliders.Length == (ramps ? 3 : 1), "Only shell and access ramps may have colliders.");
        BoxCollider shell = train.GetComponent<BoxCollider>();
        Require(shell != null && !shell.isTrigger, "Train root needs its solid shell collider.");
        Require(Mathf.Abs(shell.bounds.max.y - NeonRailFactory.RoofHeight) < 0.1f,
            "Shell roof is not at the expected 2.4 m height.");
        foreach (Collider collider in colliders)
        {
            Require(!collider.isTrigger, "Walkable rail colliders cannot be triggers.");
            if (collider != shell)
                Require(collider is MeshCollider && collider.transform.parent == train.transform &&
                    collider.name.IndexOf("Ramp", StringComparison.Ordinal) >= 0,
                    "A decorative train part has a collider: " + collider.name);
        }

        Physics.SyncTransforms();
        float[] bodySamples = { 0.03f, 3f, 6f, 9f, 11.97f };
        foreach (float z in bodySamples) CheckHeight(colliders, z, NeonRailFactory.RoofHeight);
        if (ramps)
        {
            // Stay just inside terminal edges so a ray never depends on triangle-edge tolerance.
            float[] rampFractions = { 0.01f, 0.25f, 0.5f, 0.75f, 0.99f };
            foreach (float t in rampFractions)
            {
                CheckHeight(colliders, Mathf.Lerp(-NeonRailFactory.RampLength, 0f, t),
                    t * NeonRailFactory.RoofHeight);
                CheckHeight(colliders, NeonRailFactory.BodyLength + t * NeonRailFactory.RampLength,
                    (1f - t) * NeonRailFactory.RoofHeight);
            }
        }
        ValidatePersistentReferences(train);
    }

    private static void CheckHeight(Collider[] colliders, float z, float expectedHeight)
    {
        float[] laneSamples = { -0.7f, 0f, 0.7f };
        foreach (float x in laneSamples)
        {
            Ray ray = new Ray(new Vector3(x, NeonRailFactory.RoofHeight + 5f, z), Vector3.down);
            bool found = false;
            RaycastHit closest = default;
            foreach (Collider collider in colliders)
                if (collider.Raycast(ray, out RaycastHit hit, 12f) &&
                    (!found || hit.distance < closest.distance))
                {
                    found = true;
                    closest = hit;
                }
            Require(found, "Missing ride surface at x=" + x + ", z=" + z);
            Require(Mathf.Abs(closest.point.y - expectedHeight) <= 0.1f,
                "Ride height mismatch at z=" + z + ": expected " + expectedHeight + ", got " + closest.point.y);
            Require(closest.normal.y >= 0.8f, "Ramp or roof faces away from the runner at z=" + z);
        }
    }

    private static void ValidatePersistentReferences(GameObject root)
    {
        foreach (MeshFilter filter in root.GetComponentsInChildren<MeshFilter>(true))
            RequirePersistent(filter.sharedMesh, "mesh on " + filter.name);
        foreach (SkinnedMeshRenderer renderer in root.GetComponentsInChildren<SkinnedMeshRenderer>(true))
            RequirePersistent(renderer.sharedMesh, "skinned mesh on " + renderer.name);
        foreach (MeshCollider collider in root.GetComponentsInChildren<MeshCollider>(true))
            RequirePersistent(collider.sharedMesh, "collision mesh on " + collider.name);
        foreach (Renderer renderer in root.GetComponentsInChildren<Renderer>(true))
            foreach (Material material in renderer.sharedMaterials)
                RequirePersistent(material, "material on " + renderer.name);
    }

    private static void RequirePersistent(Object resource, string description)
    {
        Require(resource != null && !string.IsNullOrEmpty(AssetDatabase.GetAssetPath(resource)),
            "Prefab has a transient or missing " + description);
        if (AssetDatabase.GetAssetPath(resource).StartsWith(AssetFolder, StringComparison.Ordinal))
            Require(resource.hideFlags == HideFlags.None, "Generated asset has temporary hide flags: " + description);
    }

    private static Dictionary<string, string> CaptureAssetGuids()
    {
        var result = new Dictionary<string, string>(StringComparer.Ordinal);
        foreach (string guid in AssetDatabase.FindAssets(string.Empty, new[] { AssetFolder }))
        {
            string path = AssetDatabase.GUIDToAssetPath(guid);
            if (!AssetDatabase.IsValidFolder(path)) result[path] = guid;
        }
        return result;
    }

    private static void WithTemporaryRoot(Action<Transform> action)
    {
        Scene scene = EditorSceneManager.NewPreviewScene();
        GameObject root = null;
        try
        {
            root = new GameObject("Neon Rail Asset Workspace");
            SceneManager.MoveGameObjectToScene(root, scene);
            action(root.transform);
        }
        finally
        {
            if (root != null) Object.DestroyImmediate(root);
            EditorSceneManager.ClosePreviewScene(scene);
        }
    }

    private static void EnsureFolder(string folder)
    {
        if (AssetDatabase.IsValidFolder(folder)) return;
        int split = folder.LastIndexOf('/');
        string parent = folder.Substring(0, split);
        EnsureFolder(parent);
        Require(!string.IsNullOrEmpty(AssetDatabase.CreateFolder(parent, folder.Substring(split + 1))),
            "Cannot create asset folder: " + folder);
    }

    private static void Require(bool condition, string message)
    {
        if (!condition) throw new InvalidOperationException("Neon rail validation: " + message);
    }

    private sealed class AssetWriter
    {
        private readonly Dictionary<Object, Object> saved = new Dictionary<Object, Object>();
        private readonly Dictionary<string, Object> claimedPaths = new Dictionary<string, Object>(StringComparer.Ordinal);

        public void PersistReferences(GameObject root)
        {
            foreach (MeshFilter filter in root.GetComponentsInChildren<MeshFilter>(true))
                filter.sharedMesh = Persist(filter.sharedMesh, "Meshes", ".asset");
            foreach (SkinnedMeshRenderer renderer in root.GetComponentsInChildren<SkinnedMeshRenderer>(true))
                renderer.sharedMesh = Persist(renderer.sharedMesh, "Meshes", ".asset");
            foreach (MeshCollider collider in root.GetComponentsInChildren<MeshCollider>(true))
                collider.sharedMesh = Persist(collider.sharedMesh, "Meshes", ".asset");
            foreach (Renderer renderer in root.GetComponentsInChildren<Renderer>(true))
            {
                Material[] materials = renderer.sharedMaterials;
                for (int i = 0; i < materials.Length; i++) materials[i] = Persist(materials[i], "Materials", ".mat");
                renderer.sharedMaterials = materials;
            }
        }

        private T Persist<T>(T source, string folder, string extension) where T : Object
        {
            Require(source != null, "Cannot persist a null mesh or material.");
            // Keep Unity built-ins and already persistent project assets intact.
            if (!string.IsNullOrEmpty(AssetDatabase.GetAssetPath(source))) return source;
            if (saved.TryGetValue(source, out Object previous)) return (T)previous;

            string stem = Regex.Replace(source.name, "[^A-Za-z0-9_-]+", "_").Trim('_');
            if (stem.Length == 0) stem = typeof(T).Name;
            string path = AssetFolder + "/" + folder + "/" + stem + extension;
            int suffix = 2;
            while (claimedPaths.TryGetValue(path, out Object owner) && owner != source)
                path = AssetFolder + "/" + folder + "/" + stem + "_" + suffix++ + extension;
            claimedPaths[path] = source;

            Object existing = AssetDatabase.LoadMainAssetAtPath(path);
            Require(existing == null || existing is T, "Asset type mismatch at " + path);
            T asset = existing as T;
            if (asset == null)
            {
                asset = Object.Instantiate(source);
                asset.name = source.name;
                asset.hideFlags = HideFlags.None;
                AssetDatabase.CreateAsset(asset, path);
            }
            else
            {
                // Update the object in place; deleting/recreating it would break GUID references.
                EditorUtility.CopySerialized(source, asset);
                asset.name = source.name;
                asset.hideFlags = HideFlags.None;
                EditorUtility.SetDirty(asset);
            }
            saved[source] = asset;
            return asset;
        }
    }
}
#endif

using System.Collections.Generic;
using UnityEngine;

public class PackageStackVisual : MonoBehaviour
{
    [Header("References")]
    [SerializeField]
    private Transform stackRoot;

    [SerializeField]
    private GameObject packageVisualPrefab;

    [Header("Stack Settings")]
    [SerializeField, Min(1)]
    private int maximumVisiblePackages = 6;

    [SerializeField]
    private Vector3 packageScale =
        new Vector3(
            0.45f,
            0.35f,
            0.45f
        );

    [SerializeField, Min(0f)]
    private float horizontalSpacing = 0.5f;

    [SerializeField, Min(0f)]
    private float verticalSpacing = 0.38f;

    [SerializeField]
    private float rotationAmount = 7f;

    private readonly List<GameObject>
        packageVisuals =
            new List<GameObject>();

    private GameManager gameManager;

    private int lastDisplayedCount = -1;

    private void Start()
    {
        if (
            stackRoot == null ||
            packageVisualPrefab == null
        )
        {
            Debug.LogError(
                "PackageStackVisual: Stack Root veya Package Visual Prefab eksik.",
                this
            );

            enabled = false;
            return;
        }

        CreateVisualPool();

        gameManager =
            GameManager.Instance;

        if (gameManager == null)
        {
            Debug.LogError(
                "PackageStackVisual: GameManager bulunamad�.",
                this
            );

            enabled = false;
            return;
        }

        gameManager.StatsChanged +=
            RefreshVisual;

        RefreshVisual();
    }

    private void OnDestroy()
    {
        if (gameManager != null)
        {
            gameManager.StatsChanged -=
                RefreshVisual;
        }
    }

    private void CreateVisualPool()
    {
        for (
            int index = 0;
            index < maximumVisiblePackages;
            index++
        )
        {
            GameObject packageVisual =
                Instantiate(
                    packageVisualPrefab,
                    stackRoot
                );

            packageVisual.name =
                $"CarriedPackage_{index:00}";

            ConfigureVisualObject(
                packageVisual
            );

            PositionVisualObject(
                packageVisual.transform,
                index
            );

            packageVisual.SetActive(false);

            packageVisuals.Add(
                packageVisual
            );
        }
    }

    private void ConfigureVisualObject(
        GameObject packageVisual
    )
    {
        packageVisual.tag =
            "Untagged";

        PackagePickup packagePickup =
            packageVisual
                .GetComponent<PackagePickup>();

        if (packagePickup != null)
        {
            packagePickup.enabled = false;
        }

        Collider packageCollider =
            packageVisual
                .GetComponent<Collider>();

        if (packageCollider != null)
        {
            packageCollider.enabled = false;
        }

        Rigidbody packageRigidbody =
            packageVisual
                .GetComponent<Rigidbody>();

        if (packageRigidbody != null)
        {
            packageRigidbody.useGravity =
                false;

            packageRigidbody.isKinematic =
                true;

            packageRigidbody.detectCollisions =
                false;
        }
    }

    private void PositionVisualObject(
        Transform packageTransform,
        int index
    )
    {
        int column =
            index % 2;

        int row =
            index / 2;

        float xPosition =
            column == 0
                ? -horizontalSpacing * 0.5f
                : horizontalSpacing * 0.5f;

        float yPosition =
            row * verticalSpacing;

        float zRotation =
            column == 0
                ? rotationAmount
                : -rotationAmount;

        packageTransform.localPosition =
            new Vector3(
                xPosition,
                yPosition,
                0f
            );

        packageTransform.localRotation =
            Quaternion.Euler(
                0f,
                0f,
                zRotation
            );

        packageTransform.localScale =
            packageScale;
    }

    private void RefreshVisual()
    {
        if (gameManager == null)
        {
            return;
        }

        int visibleCount =
            Mathf.Min(
                gameManager.CarriedPackages,
                maximumVisiblePackages
            );

        if (
            visibleCount ==
            lastDisplayedCount
        )
        {
            return;
        }

        lastDisplayedCount =
            visibleCount;

        for (
            int index = 0;
            index < packageVisuals.Count;
            index++
        )
        {
            bool shouldBeVisible =
                index < visibleCount;

            packageVisuals[index]
                .SetActive(
                    shouldBeVisible
                );
        }
    }
}
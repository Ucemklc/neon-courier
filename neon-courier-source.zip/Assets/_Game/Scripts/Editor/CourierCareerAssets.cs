#if UNITY_EDITOR
using System.IO;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;
using Object=UnityEngine.Object;

public static class CourierCareerAssets
{
    private const string Folder="Assets/Resources/CourierCareer";
    private static Material navy,slate,cyan,orange,ivory,gold,water;
    [MenuItem("Neon Courier/Generate Career Assets")]
    public static void Generate()
    {
        if(EditorApplication.isPlayingOrWillChangePlaymode)throw new System.InvalidOperationException("Stop Play before generating assets.");
        Directory.CreateDirectory(Folder);AssetDatabase.Refresh();
        navy=Load("MidnightShell");slate=Load("BlueSlate");cyan=Load("SignalCyan");orange=Load("SafetyTangerine");ivory=Load("Porcelain");
        gold=NewMaterial("CareerGold",new Color(1,.62f,.10f),.5f);water=NewMaterial("CanalWater",new Color(.015f,.26f,.38f),.1f);
        var scene=EditorSceneManager.NewPreviewScene();var build=new GameObject("Career asset build");SceneManager.MoveGameObjectToScene(build,scene);
        try
        {
            var marker=Root("PackageBeacon",build.transform);
            Box(marker,"Arrow left",new Vector3(-.19f,.15f,0),new Vector3(.48f,.08f,.10f),cyan).transform.localRotation=Quaternion.Euler(0,0,-35);
            Box(marker,"Arrow right",new Vector3(.19f,.15f,0),new Vector3(.48f,.08f,.10f),cyan).transform.localRotation=Quaternion.Euler(0,0,35);
            Save(marker,"PackageBeacon");
            for(int i=3;i<=4;i++)
            {
                var patch=Root("BagPatch"+i,build.transform);
                Box(patch,"Badge plate",Vector3.zero,new Vector3(.34f,.27f,.035f),navy);
                for(int k=0;k<i-1;k++)Box(patch,"Rank stripe",new Vector3((k-(i-2)/2f)*.085f,0,-.025f),new Vector3(.047f,.17f,.02f),i==3?cyan:gold).transform.localRotation=Quaternion.Euler(0,0,-20);
                Save(patch,"BagPatch"+i);
            }
            BuildDistrict(build.transform,3);BuildDistrict(build.transform,4);
            BuildRoof(build.transform);BuildDrone(build.transform);BuildGarage(build.transform);BuildCouriers(build.transform);
            AssetDatabase.SaveAssets();Directory.CreateDirectory("Logs");File.WriteAllText("Logs/CourierCareerAssets.txt","PASS Scanner marker, career badges, canal and sky terminal\nPASS Train-roof-bridge route with gold parcel\nPASS Three-gate drone course\nPASS Garage, parked courier bike, trophy shelf and upgrades\n");
        }
        finally{EditorSceneManager.ClosePreviewScene(scene);}
    }
    private static Material Load(string name)=>AssetDatabase.LoadAssetAtPath<Material>("Assets/_Game/Art/CourierSet/Materials/"+name+".mat");
    private static Material NewMaterial(string name,Color color,float metal)
    {
        string path=Folder+"/"+name+".mat";var m=AssetDatabase.LoadAssetAtPath<Material>(path);
        if(!m){m=new Material(Shader.Find("Universal Render Pipeline/Lit"));AssetDatabase.CreateAsset(m,path);}
        m.SetColor("_BaseColor",color);m.SetFloat("_Metallic",metal);m.SetFloat("_Smoothness",.5f);EditorUtility.SetDirty(m);return m;
    }
    private static GameObject Root(string name,Transform parent){var go=new GameObject(name);go.transform.SetParent(parent,false);return go;}
    private static GameObject Box(GameObject root,string name,Vector3 pos,Vector3 size,Material material,bool solid=false)
    {
        var go=GameObject.CreatePrimitive(PrimitiveType.Cube);go.name=name;go.transform.SetParent(root.transform,false);go.transform.localPosition=pos;go.transform.localScale=size;go.GetComponent<Renderer>().sharedMaterial=material;
        if(!solid)Object.DestroyImmediate(go.GetComponent<Collider>());else go.tag="Obstacle";
        return go;
    }
    private static void Save(GameObject root,string name){PrefabUtility.SaveAsPrefabAsset(root,Folder+"/"+name+".prefab");root.SetActive(false);}
    private static void Gate(GameObject root,string name,Vector3 pos,Vector3 size,CourierGateKind kind)
    {var go=Root(name,root.transform);go.transform.localPosition=pos;var trigger=go.AddComponent<BoxCollider>();trigger.size=size;trigger.isTrigger=true;go.AddComponent<CourierCareerGate>().Kind=kind;}
    private static void Ramp(GameObject root,string name,float x,float z,float length,float from,float to)
    {
        float w=.95f,bottom=Mathf.Min(from,to)-.15f;
        var mesh=new Mesh{name=name};mesh.vertices=new[]{new Vector3(-w,bottom,0),new Vector3(w,bottom,0),new Vector3(w,from,0),new Vector3(-w,from,0),new Vector3(-w,bottom,length),new Vector3(w,bottom,length),new Vector3(w,to,length),new Vector3(-w,to,length)};
        mesh.triangles=new[]{0,2,1,0,3,2,5,6,4,6,7,4,4,3,0,4,7,3,1,2,5,2,6,5,3,7,2,7,6,2,4,0,5,0,1,5};mesh.RecalculateNormals();mesh.RecalculateBounds();
        string path=Folder+"/"+name+".asset";var existing=AssetDatabase.LoadAssetAtPath<Mesh>(path);
        if(existing){EditorUtility.CopySerialized(mesh,existing);Object.DestroyImmediate(mesh);mesh=existing;}else AssetDatabase.CreateAsset(mesh,path);
        var go=Root(name,root.transform);go.tag="Obstacle";go.transform.localPosition=new Vector3(x,0,z);go.AddComponent<MeshFilter>().sharedMesh=mesh;go.AddComponent<MeshRenderer>().sharedMaterial=slate;go.AddComponent<MeshCollider>().sharedMesh=mesh;
    }
    private static void BuildRoof(Transform parent)
    {
        var root=Root("SkybridgeRoute",parent);root.AddComponent<CourierRoofCourse>();root.AddComponent<RailRideSurface>();
        Ramp(root,"RoofEntryRamp",-2.5f,0,4.5f,0,2.4f);
        Box(root,"Short cargo train",new Vector3(-2.5f,1.2f,7.3f),new Vector3(1.9f,2.4f,5.6f),navy,true);
        Box(root,"Train cargo panel",new Vector3(-1.535f,1.35f,7.3f),new Vector3(.035f,1.35f,4.8f),orange);
        for(int j=0;j<3;j++)Box(root,"Train ribs",new Vector3(-1.50f,1.35f,5.4f+j*1.7f),new Vector3(.07f,1.55f,.10f),slate);
        Box(root,"First rooftop",new Vector3(-2.5f,2.27f,12.8f),new Vector3(1.9f,.26f,5.6f),slate,true);
        Box(root,"First roof building",new Vector3(-2.5f,1.05f,12.8f),new Vector3(1.75f,2.1f,5.6f),navy,true);
        for(int j=0;j<3;j++)Box(root,"Rooftop building window",new Vector3(-1.61f,1.2f,10.8f+j*1.9f),new Vector3(.03f,.65f,1.1f),cyan);
        Box(root,"Cross bridge",new Vector3(-1.25f,2.27f,16),new Vector3(4.4f,.26f,2),navy,true);
        Box(root,"Second rooftop",new Vector3(0,2.27f,20.5f),new Vector3(1.9f,.26f,3),slate,true);
        Ramp(root,"RoofExitRamp",0,22,4.5f,2.4f,0);
        foreach(float x in new[]{-3.42f,-1.58f})Box(root,"Roof light",new Vector3(x,2.405f,10),new Vector3(.04f,.025f,9),cyan);
        Box(root,"Bridge direction",new Vector3(-1.25f,2.41f,16),new Vector3(3.8f,.025f,.12f),gold);
        for(int j=0;j<3;j++)Box(root,"Jump guide",new Vector3(0,2.41f,17.2f+j*.3f),new Vector3(.6f,.025f,.1f),cyan);
        var parcel=Root("GoldParcel",root.transform);parcel.transform.localPosition=new Vector3(0,3.9f,20.4f);
        Box(parcel,"VIP shell",Vector3.zero,new Vector3(.55f,.48f,.4f),gold);Box(parcel,"VIP strap",new Vector3(0,0,-.21f),new Vector3(.1f,.50f,.04f),ivory);
        var pc=parcel.AddComponent<BoxCollider>();pc.isTrigger=true;pc.size=new Vector3(.9f,4,.8f);parcel.AddComponent<CourierCareerGate>().Kind=CourierGateKind.GoldParcel;
        Gate(root,"Rooftop entry",new Vector3(-2.5f,4.5f,5.1f),new Vector3(2.2f,7,.55f),CourierGateKind.RoofEntry);
        Gate(root,"Rooftop finish",new Vector3(0,5,21.6f),new Vector3(2.2f,9,.55f),CourierGateKind.RoofExit);
        Save(root,"SkybridgeRoute");
    }
    private static void BuildDrone(Transform parent)
    {
        var root=Root("DroneCourse",parent);root.AddComponent<CourierDroneCourse>();
        for(int row=0;row<3;row++)
        {
            float z=8+row*7;
            for(int lane=0;lane<3;lane++)if(lane!=row)
            {
                float x=(lane-1)*2.5f;
                Box(root,"Drone checkpoint barrier",new Vector3(x,.7f,z),new Vector3(1.9f,1.4f,.7f),navy,true);
                Box(root,"Warning stripe",new Vector3(x,1.25f,z-.37f),new Vector3(1.75f,.17f,.06f),orange);
                Box(root,"Warning light",new Vector3(x,1.45f,z),new Vector3(1.75f,.08f,.45f),gold);
            }
            Box(root,"Safe gate guide",new Vector3((row-1)*2.5f,.025f,z),new Vector3(1.5f,.025f,3),cyan);
            foreach(float x in new[]{-4.1f,4.1f}){Box(root,"Patrol post",new Vector3(x,1.6f,z),new Vector3(.20f,3.2f,.20f),slate);Box(root,"Patrol beacon",new Vector3(x,3.3f,z),new Vector3(.42f,.3f,.42f),orange);}
        }
        Gate(root,"Drone entry",new Vector3(0,4,1),new Vector3(9,10,.6f),CourierGateKind.DroneEntry);
        Gate(root,"Drone exit",new Vector3(0,4,26.5f),new Vector3(9,10,.6f),CourierGateKind.DroneExit);
        Save(root,"DroneCourse");
    }
    private static void BuildDistrict(Transform parent,int index)
    {
        var root=Root("District"+index,parent);bool canal=index==3;
        for(int side=-1;side<=1;side+=2)
        {
            Box(root,canal?"Canal water":"Terminal platform",new Vector3(side*10,-.08f,15),new Vector3(9,.12f,30),canal?water:navy);
            for(int i=0;i<4;i++)
            {
                float z=3+i*7.4f,h=canal?8+i%2*4:13+i%2*6;
                Box(root,canal?"Canal apartments":"Terminal tower",new Vector3(side*9,h/2,z),new Vector3(4,h,5),slate);
                for(int floor=0;floor<4;floor++)Box(root,"Window belt",new Vector3(side*6.98f,2+floor*(h-2)/4,z),new Vector3(.045f,.45f,4.6f),canal?cyan:gold);
                Box(root,"Rooftop",new Vector3(side*9,h+.12f,z),new Vector3(4.8f,.24f,5.6f),navy);
                if(!canal){Box(root,"Landing light",new Vector3(side*9,h+.26f,z),new Vector3(3,.04f,3),cyan);Box(root,"Terminal fin",new Vector3(side*11.2f,h*.6f,z),new Vector3(.25f,h,1.5f),ivory);}
                else Box(root,"Water crossing",new Vector3(side*7.6f,.15f,z),new Vector3(4.5f,.3f,1.6f),ivory);
            }
        }
        Save(root,"District"+index);
    }
    private static void Trophy(GameObject root,string name,Vector3 position)
    {
        var trophy=Root(name,root.transform);trophy.transform.localPosition=position;
        Box(trophy,"Base",Vector3.zero,new Vector3(.42f,.10f,.34f),navy);Box(trophy,"Stem",new Vector3(0,.2f,0),new Vector3(.10f,.30f,.10f),gold);
        Box(trophy,"Cup",new Vector3(0,.40f,0),new Vector3(.40f,.20f,.28f),gold);
        foreach(float side in new[]{-.24f,.24f})Box(trophy,"Handle",new Vector3(side,.38f,0),new Vector3(.08f,.16f,.08f),gold);
    }
    private static void BuildGarage(Transform parent)
    {
        var root=Root("CourierGarage",parent);
        Box(root,"Garage floor",new Vector3(0,-.16f,0),new Vector3(7.5f,.3f,5.8f),slate);
        Box(root,"Back wall",new Vector3(0,1.7f,2.75f),new Vector3(7.5f,3.7f,.25f),navy);
        foreach(float x in new[]{-3.5f,3.5f})Box(root,"Support",new Vector3(x,1.8f,1),new Vector3(.25f,3.8f,3.7f),slate);
        Box(root,"Neon sign",new Vector3(-1.7f,2.5f,2.55f),new Vector3(2.4f,.09f,.08f),cyan);
        Box(root,"Service mat",new Vector3(1.4f,.012f,-.3f),new Vector3(2.1f,.025f,3.7f),navy);
        var bike=Root("Courier hover bike",root.transform);bike.transform.localPosition=new Vector3(1.25f,.5f,-.2f);bike.transform.localRotation=Quaternion.Euler(0,-22,0);
        Box(bike,"Bike chassis",new Vector3(0,0,0),new Vector3(.7f,.3f,2.1f),slate);
        Box(bike,"Delivery case",new Vector3(0,.6f,.65f),new Vector3(.85f,.85f,.65f),orange);
        Box(bike,"Seat",new Vector3(0,.35f,-.1f),new Vector3(.55f,.15f,.7f),navy);
        Box(bike,"Steering column",new Vector3(0,.6f,-.8f),new Vector3(.10f,.85f,.10f),ivory);
        Box(bike,"Handlebar",new Vector3(0,1,-.8f),new Vector3(.85f,.08f,.10f),navy);
        Box(bike,"Nose fairing",new Vector3(0,.3f,-.92f),new Vector3(.68f,.5f,.5f),orange).transform.localRotation=Quaternion.Euler(18,0,0);
        Box(bike,"Headlight",new Vector3(0,.34f,-1.18f),new Vector3(.43f,.13f,.06f),ivory);
        Box(bike,"Case band",new Vector3(0,.6f,.30f),new Vector3(.14f,.86f,.05f),ivory);
        foreach(float side in new[]{-.48f,.48f})
        {
            Box(bike,"Foot plate",new Vector3(side,-.02f,-.05f),new Vector3(.24f,.08f,.8f),navy);
            Box(bike,"Cargo handle",new Vector3(side,.6f,.65f),new Vector3(.10f,.12f,.36f),navy);
        }
        foreach(float z in new[]{-.8f,.8f})Box(bike,"Hover engine",new Vector3(0,-.17f,z),new Vector3(.8f,.17f,.5f),cyan);
        Box(root,"Trophy shelf",new Vector3(1.7f,1.45f,2.35f),new Vector3(3.2f,.12f,.65f),slate);
        Trophy(root,"ContractTrophy",new Vector3(.7f,1.56f,2.22f));Trophy(root,"RoofTrophy",new Vector3(1.7f,1.56f,2.22f));Trophy(root,"DroneTrophy",new Vector3(2.7f,1.56f,2.22f));
        var upgrade=Root("UpgradeLevel3",root.transform);
        for(int i=0;i<3;i++)Box(upgrade,"Cargo locker",new Vector3(-2.7f,.35f+i*.62f,2.05f),new Vector3(.95f,.55f,.70f),i==1?orange:slate);
        var elite=Root("UpgradeLevel5",root.transform);
        foreach(float x in new[]{-3.3f,3.3f})Box(elite,"Elite workshop trim",new Vector3(x,2.1f,2.45f),new Vector3(.07f,2.7f,.06f),gold);
        Save(root,"CourierGarage");
    }
    private static void BuildCouriers(Transform parent)
    {
        var selection=Object.FindAnyObjectByType<CharacterSelectionManager>();
        var entries=new SerializedObject(selection).FindProperty("characters");
        for(int i=0;i<entries.arraySize;i++)
        {
            var source=(GameObject)entries.GetArrayElementAtIndex(i).FindPropertyRelative("characterRoot").objectReferenceValue;
            var model=(GameObject)PrefabUtility.GetCorrespondingObjectFromSource(source);
            var root=Root("GarageCourier"+i,parent);
            var clone=Object.Instantiate(model?model:source,root.transform,false);clone.SetActive(true);clone.transform.localPosition=Vector3.zero;clone.transform.localRotation=Quaternion.identity;clone.transform.localScale=source.transform.localScale;
            var rig=clone.GetComponentInChildren<Animator>();var srcRig=source.GetComponentInChildren<Animator>(true);
            if(rig&&srcRig)rig.runtimeAnimatorController=srcRig.runtimeAnimatorController;
            if(rig){rig.Rebind();rig.Update(0);rig.enabled=false;RelaxArms(rig);}
            var uniform=clone.GetComponent<CourierUniform>();if(!uniform)uniform=clone.AddComponent<CourierUniform>();uniform.Configure(i);uniform.FitNow();
            var hip=rig.GetBoneTransform(HumanBodyBones.Hips);var head=rig.GetBoneTransform(HumanBodyBones.Head);var chest=rig.GetBoneTransform(HumanBodyBones.Chest);if(!chest)chest=rig.GetBoneTransform(HumanBodyBones.Spine);
            Vector3 up=(head.position-hip.position).normalized,forward=Vector3.ProjectOnPlane(rig.transform.forward,up).normalized;
            float size=Mathf.Clamp(Vector3.Distance(head.position,hip.position)*1.3f,.7f,1.05f);
            var bag=Object.Instantiate(Resources.Load<GameObject>("CourierExpansion/BackpackPreview"),root.transform,false);
            bag.transform.SetPositionAndRotation(chest.position-up*.06f*size-forward*.31f*size,Quaternion.LookRotation(forward,up));bag.transform.localScale=Vector3.one*size;
            foreach(var behaviour in clone.GetComponentsInChildren<MonoBehaviour>(true))Object.DestroyImmediate(behaviour);
            foreach(var animator in clone.GetComponentsInChildren<Animator>(true))Object.DestroyImmediate(animator);
            Save(root,"GarageCourier"+i);
        }
    }
    private static void RelaxArms(Animator rig)
    {
        var hip=rig.GetBoneTransform(HumanBodyBones.Hips);var head=rig.GetBoneTransform(HumanBodyBones.Head);
        if(!hip||!head)return;Vector3 up=(head.position-hip.position).normalized;
        foreach(bool left in new[]{true,false})
        {
            var arm=rig.GetBoneTransform(left?HumanBodyBones.LeftUpperArm:HumanBodyBones.RightUpperArm);
            var elbow=rig.GetBoneTransform(left?HumanBodyBones.LeftLowerArm:HumanBodyBones.RightLowerArm);
            var hand=rig.GetBoneTransform(left?HumanBodyBones.LeftHand:HumanBodyBones.RightHand);
            if(!arm||!elbow||!hand)continue;
            Vector3 outwards=Vector3.ProjectOnPlane(arm.position-hip.position,up).normalized;
            arm.rotation=Quaternion.FromToRotation(elbow.position-arm.position,-up+outwards*.2f)*arm.rotation;
            elbow.rotation=Quaternion.FromToRotation(hand.position-elbow.position,-up+rig.transform.forward*.12f)*elbow.rotation;
        }
    }
}
#endif

using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public enum CourierCargoKind { Standard, Express, Fragile, Heavy }
public enum CourierDistrict { Neon, Industrial, Harbor, Canal, Skyport }

public static class CourierWorldRules
{
    public const float DistrictLength = 300f;
    public static CourierDistrict DistrictAt(float z) => (CourierDistrict)(Mathf.FloorToInt(Mathf.Max(0,z+10f)/DistrictLength)%CourierCareerProgress.DistrictCount);
    public static CourierCargoKind CargoAt(Vector3 position)
    {
        if(position.z<90f)return CourierCargoKind.Standard;
        int slot=Mathf.Abs(Mathf.FloorToInt(position.z/5f)+Mathf.RoundToInt(position.x*2f));
        return slot%5<2 ? CourierCargoKind.Standard : (CourierCargoKind)(1+slot%3);
    }
    public static Color CargoColor(CourierCargoKind kind)
    {
        switch(kind){case CourierCargoKind.Express:return new Color(.05f,.8f,1);case CourierCargoKind.Fragile:return new Color(1,.28f,.65f);case CourierCargoKind.Heavy:return new Color(1,.69f,.08f);default:return new Color(1,.31f,.055f);}
    }
    public static string DistrictName(CourierDistrict district,bool en)
    {return district==CourierDistrict.Neon?(en?"NEON CENTER":"NEON MERKEZ") : district==CourierDistrict.Industrial?(en?"INDUSTRIAL YARD":"SANAYİ BÖLGESİ"):district==CourierDistrict.Harbor?(en?"CARGO HARBOR":"KARGO LİMANI"):district==CourierDistrict.Canal?(en?"CANAL LINE":"KANAL HATTI"):(en?"SKY TERMINAL":"GÖKYÜZÜ TERMİNALİ");}
}

/// <summary>One ledger per run. Timers use active play time and rewards join the existing delivery payout.</summary>
[DisallowMultipleComponent]
public sealed class CourierCargoManifest : MonoBehaviour
{
    public sealed class Item
    {
        public CourierCargoKind Kind;
        public float Deadline;
        public bool Intact=true;
    }
    public static CourierCargoManifest Instance { get; private set; }
    private readonly List<Item> items=new List<Item>();
    private GameManager manager;
    private float boostUntil;
    public float RunClock { get; private set; }
    public int HitVersion { get; private set; }
    public IReadOnlyList<Item> Items=>items;
    public int LastDeliveryBonus { get; private set; }
    public int LastDeliveredSpecials { get; private set; }
    public float BonusMessageUntil { get; private set; }
    public float SpeedMultiplier=>Mathf.Max(CourierCharacterAbilities.MinimumHeavySpeed,1f-CourierCharacterAbilities.HeavyPenalty*Count(CourierCargoKind.Heavy))*Mathf.Max(RunClock<boostUntil?1.18f:1f,Mathf.Max(CourierCharacterAbilities.Instance?CourierCharacterAbilities.Instance.SpeedFactor:1,CourierScooterRide.Instance?CourierScooterRide.Instance.SpeedFactor:1));
    public bool HasRouteBoost=>RunClock<boostUntil;

    [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
    private static void Install()
    {
        SceneManager.sceneLoaded-=SceneLoaded;SceneManager.sceneLoaded+=SceneLoaded;
        SceneLoaded(SceneManager.GetActiveScene(),LoadSceneMode.Single);
    }
    private static void SceneLoaded(Scene scene,LoadSceneMode mode)
    {
        var manager=FindAnyObjectByType<GameManager>();
        if(!manager)return;
        if(!manager.GetComponent<CourierCargoManifest>())manager.gameObject.AddComponent<CourierCargoManifest>();
        if(!manager.GetComponent<CourierExpansionUI>())manager.gameObject.AddComponent<CourierExpansionUI>();
        if(!manager.GetComponent<CourierRunGoals>())manager.gameObject.AddComponent<CourierRunGoals>();
        if(!manager.GetComponent<CourierRouteContract>())manager.gameObject.AddComponent<CourierRouteContract>();
        if(!manager.GetComponent<CourierCharacterAbilities>())manager.gameObject.AddComponent<CourierCharacterAbilities>();
        if(!manager.GetComponent<CourierCareerProgress>())manager.gameObject.AddComponent<CourierCareerProgress>();
        if(!manager.GetComponent<CourierDroneChallenge>())manager.gameObject.AddComponent<CourierDroneChallenge>();
        if(!manager.GetComponent<CourierGarageUI>())manager.gameObject.AddComponent<CourierGarageUI>();
        foreach(var core in FindObjectsByType<CargoCoreController>(FindObjectsInactive.Include,FindObjectsSortMode.None))
            if(core.GetComponentInParent<RunnerController>() && !core.GetComponent<CourierBackpackAppearance>())core.gameObject.AddComponent<CourierBackpackAppearance>();
    }
    private void Awake(){Instance=this;manager=GetComponent<GameManager>();}
    private void Start(){if(manager){manager.StatsChanged+=SyncCount;manager.MainMenuChanged+=MenuChanged;SyncCount();}}
    private void OnDestroy(){if(manager){manager.StatsChanged-=SyncCount;manager.MainMenuChanged-=MenuChanged;}if(Instance==this)Instance=null;}
    private void Update(){if(manager && manager.IsRunActive && !manager.IsPaused && !manager.IsGameOver)RunClock+=Time.deltaTime;}
    public void RecordPickup(CourierCargoKind kind)
    {items.Add(new Item{Kind=kind,Deadline=RunClock+18f});}
    public void DamageFragileCargo(){HitVersion++;foreach(var item in items)if(item.Kind==CourierCargoKind.Fragile)item.Intact=false;}
    public int Count(CourierCargoKind kind){int count=0;foreach(var item in items)if(item.Kind==kind)count++;return count;}
    public float EarliestDeadline
    {get{float left=float.PositiveInfinity;foreach(var item in items)if(item.Kind==CourierCargoKind.Express)left=Mathf.Min(left,item.Deadline-RunClock);return float.IsPositiveInfinity(left)?0f:Mathf.Max(0,left);}}
    public int DamagedFragileCount
    {get{int count=0;foreach(var item in items)if(item.Kind==CourierCargoKind.Fragile&&!item.Intact)count++;return count;}}
    public int CompleteDelivery(int deliveredCount,int coinMultiplier=1)
    {
        int bonus=0,specials=0;
        for(int i=0;i<Mathf.Min(deliveredCount,items.Count);i++)
        {
            var item=items[i];int reward=0;
            if(item.Kind==CourierCargoKind.Express && RunClock<=item.Deadline)reward=6;
            if(item.Kind==CourierCargoKind.Fragile && item.Intact)reward=5;
            if(item.Kind==CourierCargoKind.Heavy)reward=4;
            if(reward>0){bonus+=reward;specials++;}
        }
        items.Clear();LastDeliveryBonus=bonus*coinMultiplier;LastDeliveredSpecials=specials;BonusMessageUntil=Time.unscaledTime+3f;
        return bonus;
    }
    public void GrantRouteBoost(){boostUntil=RunClock+2.5f;}
    private void SyncCount()
    {
        if(!manager)return;
        while(items.Count>manager.CarriedPackages)items.RemoveAt(items.Count-1);
        while(items.Count<manager.CarriedPackages)items.Add(new Item{Kind=CourierCargoKind.Standard});
    }
    private void MenuChanged(bool open)
    {if(open){items.Clear();RunClock=0;HitVersion=0;boostUntil=0;LastDeliveryBonus=0;BonusMessageUntil=0;}}
}

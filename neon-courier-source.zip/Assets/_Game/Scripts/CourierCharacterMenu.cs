using TMPro;
using UnityEngine;
using UnityEngine.UI;

public sealed class CourierCharacterMenu : MonoBehaviour
{
    public void Initialize(Button close,TMP_Text coins)
    {
        var r=(RectTransform)transform;r.localScale=Vector3.one;r.anchorMin=Vector2.zero;r.anchorMax=Vector2.one;r.offsetMin=r.offsetMax=Vector2.zero;
        var bg=GetComponent<Image>();if(!bg)bg=gameObject.AddComponent<Image>();bg.sprite=null;bg.color=new Color(.025f,.04f,.068f,1);bg.raycastTarget=true;
        foreach(var image in GetComponentsInChildren<Image>(true))
            if(!image.GetComponentInParent<Button>(true)){image.sprite=null;image.material=null;image.color=bg.color;image.raycastTarget=image==bg;}
        foreach(var t in GetComponentsInChildren<TMP_Text>(true))
        {
            Clean(t,30);
            if((t.text??"").Contains("KARAKTERLER")||t.name.Contains("Title")){Clean(t,54);CourierMenuLayout.Place(t.rectTransform,new Vector2(.5f,1),new Vector2(0,-150),new Vector2(780,90));}
        }
        if(close){close.transform.SetParent(transform,false);CourierMenuLayout.Place((RectTransform)close.transform,Vector2.one,new Vector2(-90,-100),new Vector2(100,90));var style=close.gameObject.AddComponent<CourierMenuButton>();style.Style(false);}
        if(coins){coins.transform.SetParent(transform,false);CourierMenuLayout.Place(coins.rectTransform,new Vector2(.5f,1),new Vector2(0,-245),new Vector2(820,65));Clean(coins,34);}
    }
    public void Card(int index,GameObject root,TMP_Text name,TMP_Text price,TMP_Text status,Button action,TMP_Text actionLabel)
    {
        root.transform.SetParent(transform,false);CourierMenuLayout.Place((RectTransform)root.transform,new Vector2(.5f,1),new Vector2(0,-475-index*335),new Vector2(940,300));
        // The panel starts inactive. Keep the serialized controls by hierarchy,
        // since active-only parent lookups miss buttons under a closed panel.
        action.transform.SetParent(root.transform,false);
        if(actionLabel)actionLabel.transform.SetParent(action.transform,false);
        Put(name,root.transform,new Vector2(150,91),new Vector2(580,60),33);
        Put(price,root.transform,new Vector2(150,-4),new Vector2(580,40),25);
        Put(status,root.transform,new Vector2(7,-70),new Vector2(260,60),26);
        foreach(var graphic in root.GetComponentsInChildren<Graphic>(true))
            if(graphic.gameObject!=root&&graphic!=name&&graphic!=price&&graphic!=status&&!graphic.transform.IsChildOf(action.transform))graphic.enabled=false;
        var img=root.GetComponent<Image>();if(img){img.sprite=Resources.Load<Sprite>("CourierPolish/MenuCard");img.type=Image.Type.Sliced;img.color=new Color(.065f,.13f,.19f);img.raycastTarget=false;}
        var portrait=new GameObject("CourierPortrait",typeof(RectTransform),typeof(Image));portrait.transform.SetParent(root.transform,false);
        CourierMenuLayout.Place((RectTransform)portrait.transform,new Vector2(0,.5f),new Vector2(140,0),new Vector2(230,230));
        var icon=portrait.GetComponent<Image>();icon.sprite=Resources.Load<Sprite>("CourierReference/Portrait"+index) ?? Resources.Load<Sprite>("CourierPolish/Portrait"+index);icon.preserveAspect=true;icon.raycastTarget=false;
        var abilityObject=new GameObject("CourierAbility",typeof(RectTransform),typeof(TextMeshProUGUI));abilityObject.transform.SetParent(root.transform,false);
        var ability=abilityObject.GetComponent<TMP_Text>();ability.text=CourierCharacterAbilities.Description(index,PlayerPrefs.GetInt("NeonCourier.Language",0)==1);
        Put(ability,root.transform,new Vector2(150,44),new Vector2(600,42),23);ability.color=new Color(.3f,.85f,1);
        action.gameObject.SetActive(true);
        action.transform.SetParent(root.transform,false);CourierMenuLayout.Place((RectTransform)action.transform,new Vector2(.5f,.5f),new Vector2(280,-78),new Vector2(270,88));
        var style=action.GetComponent<CourierMenuButton>();if(!style)style=action.gameObject.AddComponent<CourierMenuButton>();style.Style(false);
        foreach(var t in action.GetComponentsInChildren<TMP_Text>(true))t.fontSize=31;
    }
    private static void Put(TMP_Text text,Transform parent,Vector2 pos,Vector2 size,float font){if(!text)return;text.gameObject.SetActive(true);text.transform.SetParent(parent,false);CourierMenuLayout.Place(text.rectTransform,new Vector2(.5f,.5f),pos,size);Clean(text,font);}
    private static void Clean(TMP_Text text,float font){text.enabled=true;text.font=TMP_Settings.defaultFontAsset;text.fontSharedMaterial=text.font.material;text.fontSize=font;text.margin=Vector4.zero;text.outlineWidth=0;text.color=Color.white;text.fontStyle=FontStyles.Bold;text.enableAutoSizing=false;text.alignment=TextAlignmentOptions.Center;text.raycastTarget=false;}
}

using System;
using UnityEngine;

[DisallowMultipleComponent]
public class BoosterInventoryManager : MonoBehaviour
{
    public static BoosterInventoryManager Instance
    {
        get;
        private set;
    }

    [Header("Booster Prices")]
    [SerializeField, Min(1)]
    private int magnetPrice = 100;

    [SerializeField, Min(1)]
    private int shieldPrice = 150;

    [SerializeField, Min(1)]
    private int doubleCoinPrice = 200;

    public event Action InventoryChanged;

    public int MagnetCount
    {
        get;
        private set;
    }

    public int ShieldCount
    {
        get;
        private set;
    }

    public int DoubleCoinCount
    {
        get;
        private set;
    }

    public bool IsMagnetEquipped
    {
        get;
        private set;
    }

    public bool IsShieldEquipped
    {
        get;
        private set;
    }

    public bool IsDoubleCoinEquipped
    {
        get;
        private set;
    }

    public bool CanUseShop
    {
        get
        {
            ResolveReferences();

            return
                gameManager != null &&
                gameManager.IsMainMenuActive &&
                !gameManager.IsGameOver;
        }
    }

    private const string MagnetCountKey =
        "NeonCourier.Booster.Magnet.Count";

    private const string ShieldCountKey =
        "NeonCourier.Booster.Shield.Count";

    private const string DoubleCoinCountKey =
        "NeonCourier.Booster.DoubleCoin.Count";

    private const string MagnetEquippedKey =
        "NeonCourier.Booster.Magnet.Equipped";

    private const string ShieldEquippedKey =
        "NeonCourier.Booster.Shield.Equipped";

    private const string DoubleCoinEquippedKey =
        "NeonCourier.Booster.DoubleCoin.Equipped";

    private GameManager gameManager;
    private PowerUpController powerUpController;

    private void Awake()
    {
        if (
            Instance != null &&
            Instance != this
        )
        {
            Destroy(this);
            return;
        }

        Instance = this;

        LoadState();
    }

    private void Start()
    {
        ResolveReferences();

        if (gameManager != null)
        {
            gameManager.RunStateChanged +=
                HandleRunStateChanged;

            gameManager.MainMenuChanged +=
                HandleMainMenuChanged;
        }
    }

    private void OnDestroy()
    {
        if (gameManager != null)
        {
            gameManager.RunStateChanged -=
                HandleRunStateChanged;

            gameManager.MainMenuChanged -=
                HandleMainMenuChanged;
        }

        if (Instance == this)
        {
            Instance = null;
        }
    }

    public int GetPrice(
        PowerUpType powerUpType
    )
    {
        switch (powerUpType)
        {
            case PowerUpType.Magnet:
                return magnetPrice;

            case PowerUpType.Shield:
                return shieldPrice;

            case PowerUpType.DoubleCoin:
                return doubleCoinPrice;

            default:
                return 0;
        }
    }

    public int GetCount(
        PowerUpType powerUpType
    )
    {
        switch (powerUpType)
        {
            case PowerUpType.Magnet:
                return MagnetCount;

            case PowerUpType.Shield:
                return ShieldCount;

            case PowerUpType.DoubleCoin:
                return DoubleCoinCount;

            default:
                return 0;
        }
    }

    public bool IsEquipped(
        PowerUpType powerUpType
    )
    {
        switch (powerUpType)
        {
            case PowerUpType.Magnet:
                return IsMagnetEquipped;

            case PowerUpType.Shield:
                return IsShieldEquipped;

            case PowerUpType.DoubleCoin:
                return IsDoubleCoinEquipped;

            default:
                return false;
        }
    }

    public bool TryPurchase(
        PowerUpType powerUpType
    )
    {
        ResolveReferences();

        if (
            !CanUseShop ||
            gameManager == null
        )
        {
            return false;
        }

        int price =
            GetPrice(powerUpType);

        if (
            price <= 0 ||
            !gameManager.TrySpendCoins(price)
        )
        {
            return false;
        }

        switch (powerUpType)
        {
            case PowerUpType.Magnet:
                MagnetCount++;
                break;

            case PowerUpType.Shield:
                ShieldCount++;
                break;

            case PowerUpType.DoubleCoin:
                DoubleCoinCount++;
                break;

            default:
                return false;
        }

        SaveState();
        InventoryChanged?.Invoke();

        return true;
    }

    public bool ToggleEquipped(
        PowerUpType powerUpType
    )
    {
        if (!CanUseShop)
        {
            return false;
        }

        if (GetCount(powerUpType) <= 0)
        {
            return false;
        }

        switch (powerUpType)
        {
            case PowerUpType.Magnet:
                IsMagnetEquipped =
                    !IsMagnetEquipped;
                break;

            case PowerUpType.Shield:
                IsShieldEquipped =
                    !IsShieldEquipped;
                break;

            case PowerUpType.DoubleCoin:
                IsDoubleCoinEquipped =
                    !IsDoubleCoinEquipped;
                break;

            default:
                return false;
        }

        SaveState();
        InventoryChanged?.Invoke();

        return true;
    }

    private void HandleRunStateChanged(
        bool isRunActive
    )
    {
        if (!isRunActive)
        {
            return;
        }

        ActivateEquippedBoosters();
    }

    private void HandleMainMenuChanged(
        bool isMainMenuOpen
    )
    {
        if (!isMainMenuOpen)
        {
            return;
        }

        ValidateEquippedBoosters();
        InventoryChanged?.Invoke();
    }

    private void ActivateEquippedBoosters()
    {
        ResolveReferences();

        if (powerUpController == null)
        {
            Debug.LogError(
                "BoosterInventoryManager: PowerUpController bulunamadı.",
                this
            );

            return;
        }

        bool stateChanged = false;

        if (
            IsMagnetEquipped &&
            MagnetCount > 0
        )
        {
            powerUpController.ActivatePowerUp(
                PowerUpType.Magnet
            );

            MagnetCount--;
            IsMagnetEquipped = false;
            stateChanged = true;
        }

        if (
            IsShieldEquipped &&
            ShieldCount > 0
        )
        {
            powerUpController.ActivatePowerUp(
                PowerUpType.Shield
            );

            ShieldCount--;
            IsShieldEquipped = false;
            stateChanged = true;
        }

        if (
            IsDoubleCoinEquipped &&
            DoubleCoinCount > 0
        )
        {
            powerUpController.ActivatePowerUp(
                PowerUpType.DoubleCoin
            );

            DoubleCoinCount--;
            IsDoubleCoinEquipped = false;
            stateChanged = true;
        }

        if (!stateChanged)
        {
            return;
        }

        SaveState();
        InventoryChanged?.Invoke();
    }

    private void ResolveReferences()
    {
        if (gameManager == null)
        {
            gameManager =
                GameManager.Instance;

            if (gameManager == null)
            {
                gameManager =
                    FindAnyObjectByType
                        <GameManager>();
            }
        }

        if (powerUpController == null)
        {
            powerUpController =
                PowerUpController.Instance;

            if (powerUpController == null)
            {
                powerUpController =
                    FindAnyObjectByType
                        <PowerUpController>();
            }
        }
    }

    private void LoadState()
    {
        MagnetCount =
            Mathf.Max(
                0,
                PlayerPrefs.GetInt(
                    MagnetCountKey,
                    0
                )
            );

        ShieldCount =
            Mathf.Max(
                0,
                PlayerPrefs.GetInt(
                    ShieldCountKey,
                    0
                )
            );

        DoubleCoinCount =
            Mathf.Max(
                0,
                PlayerPrefs.GetInt(
                    DoubleCoinCountKey,
                    0
                )
            );

        IsMagnetEquipped =
            PlayerPrefs.GetInt(
                MagnetEquippedKey,
                0
            ) == 1;

        IsShieldEquipped =
            PlayerPrefs.GetInt(
                ShieldEquippedKey,
                0
            ) == 1;

        IsDoubleCoinEquipped =
            PlayerPrefs.GetInt(
                DoubleCoinEquippedKey,
                0
            ) == 1;

        ValidateEquippedBoosters();
    }

    private void ValidateEquippedBoosters()
    {
        if (MagnetCount <= 0)
        {
            IsMagnetEquipped = false;
        }

        if (ShieldCount <= 0)
        {
            IsShieldEquipped = false;
        }

        if (DoubleCoinCount <= 0)
        {
            IsDoubleCoinEquipped = false;
        }
    }

    private void SaveState()
    {
        ValidateEquippedBoosters();

        PlayerPrefs.SetInt(
            MagnetCountKey,
            MagnetCount
        );

        PlayerPrefs.SetInt(
            ShieldCountKey,
            ShieldCount
        );

        PlayerPrefs.SetInt(
            DoubleCoinCountKey,
            DoubleCoinCount
        );

        PlayerPrefs.SetInt(
            MagnetEquippedKey,
            IsMagnetEquipped ? 1 : 0
        );

        PlayerPrefs.SetInt(
            ShieldEquippedKey,
            IsShieldEquipped ? 1 : 0
        );

        PlayerPrefs.SetInt(
            DoubleCoinEquippedKey,
            IsDoubleCoinEquipped ? 1 : 0
        );

        PlayerPrefs.Save();
    }
}
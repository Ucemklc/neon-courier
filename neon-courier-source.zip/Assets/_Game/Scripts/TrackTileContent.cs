using System;
using System.Collections.Generic;
using UnityEngine;

[DisallowMultipleComponent]
public sealed class TrackTileContent : MonoBehaviour
{
    [Serializable]
    private sealed class DifficultyPreset
    {
        [Min(1)]
        public int activeRowCount = 3;

        [Min(0.5f)]
        public float rowSpacing = 6.2f;

        [Range(0f, 1f)]
        public float twoObstacleChance = 0.55f;

        [Range(0f, 1f)]
        public float slideObstacleChance = 0.30f;

        [Range(0f, 1f)]
        public float fullLaneClosureChance = 0.12f;

        [Range(0f, 1f)]
        public float safeLaneChangeChance = 0.30f;

        [Min(1)]
        public int maximumSameLaneStreak = 2;

        [Range(0f, 2f)]
        public float powerUpChanceMultiplier = 1f;
    }

    [Header("Prefabs")]
    [SerializeField]
    private GameObject obstaclePrefab;

    [SerializeField]
    private GameObject packagePrefab;

    [SerializeField]
    private GameObject deliveryZonePrefab;

    [SerializeField]
    private GameObject powerUpPrefab;

    [Header("Lane Settings")]
    [SerializeField, Min(0.1f)]
    private float laneDistance = 2.5f;

    [Header("Row Limits")]
    [SerializeField, Min(1)]
    private int maximumSupportedRows = 5;

    [SerializeField]
    private float firstRowZ = 4.5f;

    [SerializeField, Min(0f)]
    private float minimumDistanceBeforeDelivery = 3.5f;

    [Header("Delivery Route")]
    [Tooltip("Bir teslimat noktasından önce üretilecek toplam paket sayısı.")]
    [SerializeField, Min(1)]
    private int targetPackagesPerDelivery = 10;

    [Tooltip("Teslimat noktalarının kaç Track Tile aralıkla çıkacağını belirler.")]
    [SerializeField, Min(1)]
    private int tilesPerDelivery = 4;

    [Header("Difficulty Level 0 - 0 to 149 m")]
    [SerializeField]
    private DifficultyPreset level0 = new DifficultyPreset
    {
        activeRowCount = 3,
        rowSpacing = 6.2f,
        twoObstacleChance = 0.52f,
        slideObstacleChance = 0.30f,
        fullLaneClosureChance = 0.12f,
        safeLaneChangeChance = 0.30f,
        maximumSameLaneStreak = 2,
        powerUpChanceMultiplier = 1f
    };

    [Header("Difficulty Level 1 - 150 to 399 m")]
    [SerializeField]
    private DifficultyPreset level1 = new DifficultyPreset
    {
        activeRowCount = 4,
        rowSpacing = 5.7f,
        twoObstacleChance = 0.64f,
        slideObstacleChance = 0.38f,
        fullLaneClosureChance = 0.16f,
        safeLaneChangeChance = 0.48f,
        maximumSameLaneStreak = 2,
        powerUpChanceMultiplier = 0.85f
    };

    [Header("Difficulty Level 2 - 400 to 799 m")]
    [SerializeField]
    private DifficultyPreset level2 = new DifficultyPreset
    {
        activeRowCount = 4,
        rowSpacing = 5.2f,
        twoObstacleChance = 0.74f,
        slideObstacleChance = 0.44f,
        fullLaneClosureChance = 0.20f,
        safeLaneChangeChance = 0.65f,
        maximumSameLaneStreak = 1,
        powerUpChanceMultiplier = 0.70f
    };

    [Header("Difficulty Level 3 - 800 m and above")]
    [SerializeField]
    private DifficultyPreset level3 = new DifficultyPreset
    {
        activeRowCount = 5,
        rowSpacing = 4.8f,
        twoObstacleChance = 0.84f,
        slideObstacleChance = 0.50f,
        fullLaneClosureChance = 0.24f,
        safeLaneChangeChance = 0.78f,
        maximumSameLaneStreak = 1,
        powerUpChanceMultiplier = 0.55f
    };

    [Header("Package Settings")]
    [SerializeField, Min(0f)]
    private float packageLeadDistance = 2.8f;

    [SerializeField]
    private float packageHeight = 0.7f;

    [Header("Power-up Settings")]
    [SerializeField, Range(0f, 1f)]
    private float basePowerUpSpawnChance = 0.16f;

    [SerializeField]
    private float powerUpHeight = 1.1f;

    [SerializeField, Min(0f)]
    private float powerUpDistanceBeforeObstacle = 2.1f;

    [Header("Delivery")]
    [SerializeField]
    private float deliveryZoneZ = 27.5f;

    [SerializeField]
    private float deliveryZoneY = 1.5f;

    [Header("Debug")]
    [SerializeField]
    private bool logGeneratedDifficulty = false;

    [SerializeField]
    private bool overrideDifficultyForTesting = false;

    [SerializeField, Range(0, 3)]
    private int testDifficultyLevel = 0;

    private static int generatedTilesInCurrentRoute;
    private static int scheduledPackagesInCurrentRoute;

    private Transform generatedRoot;

    private ObstacleVisualController[,] obstacleSlots;
    private GameObject[] packageSlots;

    private PowerUpPickup powerUpSlot;
    private DeliveryZone deliveryZone;

    private bool contentCreated;

    [Header("Neon Rail Routes")]
    [SerializeField] private bool enableRailRoutes = true;
    [SerializeField, Min(2)] private int railRouteInterval = 3;
    private static int generatedTileSequence;
    private NeonRailSection railSection;
    private CourierAlternateRoute alternateRoute;
    private CourierRoofCourse roofCourse;
    private CourierDroneCourse droneCourse;
    private CourierScooterSegment scooterCourse;
    private CourierStreetEvent[] streetEvents=new CourierStreetEvent[3];

    [RuntimeInitializeOnLoadMethod(
        RuntimeInitializeLoadType.SubsystemRegistration
    )]
    private static void ResetStaticRouteState()
    {
        generatedTilesInCurrentRoute = 0;
        scheduledPackagesInCurrentRoute = 0;
        generatedTileSequence = 0;
    }

    private void Awake()
    {
        CreateContentSlots();
    }

    public void ClearPattern()
    {
        CreateContentSlots();

        if (!contentCreated)
        {
            return;
        }

        DisableAllContent();
        RefreshAirCoinRoute();
    }

    public void RefreshPattern()
    {
        CreateContentSlots();

        if (!contentCreated)
        {
            return;
        }

        DisableAllContent();

        generatedTilesInCurrentRoute++;
        generatedTileSequence++;

        int difficultyLevel =
            GetDifficultyLevel();

        DifficultyPreset preset =
            GetDifficultyPreset(
                difficultyLevel
            );

        int activeRowCount =
            CalculateFittingRowCount(
                preset
            );

        if (activeRowCount <= 0)
        {
            TryActivateDeliveryZone();
            RefreshAirCoinRoute();
            return;
        }

        int packageQuota =
            CalculatePackageQuotaForCurrentTile(
                activeRowCount
            );

        int scooterPhase=generatedTileSequence%36;
        if(scooterPhase>=15&&scooterPhase<=17)
        {
            if(!scooterCourse){var prefab=Resources.Load<GameObject>("CourierJourney/ScooterRoad");if(prefab)scooterCourse=Instantiate(prefab,transform,false).GetComponent<CourierScooterSegment>();}
            if(scooterCourse){scooterCourse.Configure(scooterPhase-15,packageSlots,packageQuota,packageHeight);scheduledPackagesInCurrentRoute+=packageQuota;TryActivateDeliveryZone();RefreshAirCoinRoute();return;}
        }
        if(generatedTileSequence>=6&&generatedTileSequence%18==6)
        {
            int kind=(generatedTileSequence/18)%3;
            if(!streetEvents[kind]){var prefab=Resources.Load<GameObject>("CourierJourney/StreetEvent"+kind);if(prefab)streetEvents[kind]=Instantiate(prefab,transform,false).GetComponent<CourierStreetEvent>();}
            if(streetEvents[kind]){streetEvents[kind].Configure(packageSlots,packageQuota,packageHeight);scheduledPackagesInCurrentRoute+=packageQuota;TryActivateDeliveryZone();RefreshAirCoinRoute();return;}
        }
        if (generatedTileSequence >= 8 && generatedTileSequence % 12 == 8)
        {
            if(!roofCourse){var prefab=Resources.Load<GameObject>("CourierCareer/SkybridgeRoute");if(prefab)roofCourse=Instantiate(prefab,transform,false).GetComponent<CourierRoofCourse>();}
            if(roofCourse){roofCourse.Configure(packageSlots,packageQuota,packageHeight);scheduledPackagesInCurrentRoute+=packageQuota;TryActivateDeliveryZone();RefreshAirCoinRoute();return;}
        }
        if (generatedTileSequence >= 12 && generatedTileSequence % 18 == 12)
        {
            if(!droneCourse){var prefab=Resources.Load<GameObject>("CourierCareer/DroneCourse");if(prefab)droneCourse=Instantiate(prefab,transform,false).GetComponent<CourierDroneCourse>();}
            if(droneCourse){droneCourse.Configure(packageSlots,packageQuota,packageHeight);scheduledPackagesInCurrentRoute+=packageQuota;TryActivateDeliveryZone();RefreshAirCoinRoute();return;}
        }
        if (generatedTileSequence >= 4 && generatedTileSequence % 6 == 4 &&
            deliveryZoneZ >= 27f)
        {
            if (!alternateRoute) alternateRoute = gameObject.AddComponent<CourierAlternateRoute>();
            if (alternateRoute.Configure(laneDistance, generatedTileSequence, packageSlots,
                packageQuota, packageHeight, obstacleSlots[0, 0]))
            {
                scheduledPackagesInCurrentRoute += packageQuota;
                TryActivateDeliveryZone();
                RefreshAirCoinRoute();
                return;
            }
        }

        // Reserve the full section so street obstacles never block either ramp.
        if (enableRailRoutes && generatedTileSequence >= 2 &&
            (generatedTileSequence - 2) % Mathf.Max(2, railRouteInterval) == 0 &&
            deliveryZoneZ - minimumDistanceBeforeDelivery >= 24f)
        {
            if (railSection == null) railSection = gameObject.AddComponent<NeonRailSection>();
            railSection.Configure(laneDistance, difficultyLevel, generatedTileSequence,
                packageSlots, packageQuota, packageHeight, powerUpSlot,
                obstacleSlots[0, 0], basePowerUpSpawnChance);
            scheduledPackagesInCurrentRoute += packageQuota;
            TryActivateDeliveryZone();
            RefreshAirCoinRoute();
            return;
        }

        HashSet<int> selectedPackageRows =
            SelectPackageRows(
                activeRowCount,
                packageQuota
            );

        int[] safeLanes =
            new int[activeRowCount];

        bool[] packageWasActivated =
            new bool[activeRowCount];

        int previousSafeLane =
            UnityEngine.Random.Range(
                0,
                3
            );

        int sameLaneStreak = 1;

        for (
            int row = 0;
            row < activeRowCount;
            row++
        )
        {
            int safeLane;

            if (row == 0)
            {
                safeLane =
                    previousSafeLane;
            }
            else
            {
                safeLane =
                    SelectNextSafeLane(
                        previousSafeLane,
                        sameLaneStreak,
                        preset
                    );

                if (
                    safeLane ==
                    previousSafeLane
                )
                {
                    sameLaneStreak++;
                }
                else
                {
                    sameLaneStreak = 1;
                }
            }

            safeLanes[row] =
                safeLane;

            CreateObstacleRow(
                row,
                safeLane,
                preset
            );

            if (
                selectedPackageRows.Contains(
                    row
                )
            )
            {
                bool packageActivated =
                    ActivatePackage(
                        row,
                        safeLane,
                        preset
                    );

                packageWasActivated[row] =
                    packageActivated;

                if (packageActivated)
                {
                    scheduledPackagesInCurrentRoute++;
                }
            }

            previousSafeLane =
                safeLane;
        }

        ActivatePowerUp(
            safeLanes,
            packageWasActivated,
            preset
        );

        bool deliveryActivated =
            TryActivateDeliveryZone();

        RefreshAirCoinRoute();

        if (logGeneratedDifficulty)
        {
            Debug.Log(
                $"TrackTileContent | " +
                $"Difficulty: {difficultyLevel} | " +
                $"Tile In Route: {generatedTilesInCurrentRoute} | " +
                $"Packages Scheduled: {scheduledPackagesInCurrentRoute} | " +
                $"Packages On Tile: {packageQuota} | " +
                $"Delivery: {deliveryActivated}",
                this
            );
        }
    }

    private int CalculatePackageQuotaForCurrentTile(
        int activeRowCount
    )
    {
        int remainingPackages =
            Mathf.Max(
                0,
                targetPackagesPerDelivery -
                scheduledPackagesInCurrentRoute
            );

        if (remainingPackages <= 0)
        {
            return 0;
        }

        int remainingTilesIncludingCurrent =
            Mathf.Max(
                1,
                tilesPerDelivery -
                generatedTilesInCurrentRoute +
                1
            );

        int requiredOnThisTile =
            Mathf.CeilToInt(
                remainingPackages /
                (float)remainingTilesIncludingCurrent
            );

        return Mathf.Clamp(
            requiredOnThisTile,
            0,
            activeRowCount
        );
    }

    private HashSet<int> SelectPackageRows(
        int activeRowCount,
        int packageQuota
    )
    {
        HashSet<int> selectedRows =
            new HashSet<int>();

        int clampedQuota =
            Mathf.Clamp(
                packageQuota,
                0,
                activeRowCount
            );

        if (clampedQuota <= 0)
        {
            return selectedRows;
        }

        List<int> availableRows =
            new List<int>();

        for (
            int row = 0;
            row < activeRowCount;
            row++
        )
        {
            availableRows.Add(row);
        }

        for (
            int packageIndex = 0;
            packageIndex < clampedQuota;
            packageIndex++
        )
        {
            int selectedListIndex =
                UnityEngine.Random.Range(
                    0,
                    availableRows.Count
                );

            int selectedRow =
                availableRows[
                    selectedListIndex
                ];

            selectedRows.Add(
                selectedRow
            );

            availableRows.RemoveAt(
                selectedListIndex
            );
        }

        return selectedRows;
    }

    private bool TryActivateDeliveryZone()
    {
        bool enoughTilesPassed =
            generatedTilesInCurrentRoute >=
            tilesPerDelivery;

        bool enoughPackagesScheduled =
            scheduledPackagesInCurrentRoute >=
            targetPackagesPerDelivery;

        if (
            !enoughTilesPassed ||
            !enoughPackagesScheduled
        )
        {
            return false;
        }

        ActivateDeliveryZone();

        generatedTilesInCurrentRoute = 0;
        scheduledPackagesInCurrentRoute = 0;

        return true;
    }

    private int SelectNextSafeLane(
        int previousSafeLane,
        int sameLaneStreak,
        DifficultyPreset preset
    )
    {
        bool mustChangeLane =
            sameLaneStreak >=
            Mathf.Max(
                1,
                preset.maximumSameLaneStreak
            );

        bool changeLane =
            mustChangeLane ||
            UnityEngine.Random.value <
            preset.safeLaneChangeChance;

        if (!changeLane)
        {
            return previousSafeLane;
        }

        if (previousSafeLane == 0)
        {
            return 1;
        }

        if (previousSafeLane == 2)
        {
            return 1;
        }

        return
            UnityEngine.Random.value < 0.5f
                ? 0
                : 2;
    }

    private void CreateObstacleRow(
        int row,
        int safeLane,
        DifficultyPreset preset
    )
    {
        List<int> blockedLanes =
            new List<int>(2);

        for (
            int lane = 0;
            lane < 3;
            lane++
        )
        {
            if (lane != safeLane)
            {
                blockedLanes.Add(
                    lane
                );
            }
        }

        if (UnityEngine.Random.value < preset.fullLaneClosureChance)
        {
            int closureLane = blockedLanes[
                UnityEngine.Random.Range(0, blockedLanes.Count)
            ];

            ActivateObstacle(
                row,
                closureLane,
                preset,
                RunnerObstacleType.FullLaneClosure
            );

            return;
        }
        bool useTwoObstacles =
            UnityEngine.Random.value <
            preset.twoObstacleChance;

        if (useTwoObstacles)
        {
            bool useJumpSlidePair =
                (generatedTilesInCurrentRoute + row) % 2 == 0;

            if (useJumpSlidePair)
            {
                bool jumpOnFirstLane =
                    (generatedTilesInCurrentRoute + row) % 4 == 0;

                ActivateObstacle(
                    row,
                    blockedLanes[0],
                    preset,
                    jumpOnFirstLane
                        ? RunnerObstacleType.Jump
                        : RunnerObstacleType.Slide
                );

                ActivateObstacle(
                    row,
                    blockedLanes[1],
                    preset,
                    jumpOnFirstLane
                        ? RunnerObstacleType.Slide
                        : RunnerObstacleType.Jump
                );
            }
            else
            {
                ActivateObstacle(
                    row,
                    blockedLanes[0],
                    preset
                );

                ActivateObstacle(
                    row,
                    blockedLanes[1],
                    preset
                );
            }

            return;
        }

        int randomBlockedLane =
            blockedLanes[
                UnityEngine.Random.Range(
                    0,
                    blockedLanes.Count
                )
            ];

        ActivateObstacle(
            row,
            randomBlockedLane,
            preset
        );
    }

    private void ActivateObstacle(
        int row,
        int lane,
        DifficultyPreset preset,
        RunnerObstacleType? forcedType = null
    )
    {
        if (
            obstacleSlots == null ||
            row < 0 ||
            row >= obstacleSlots.GetLength(0) ||
            lane < 0 ||
            lane >= obstacleSlots.GetLength(1)
        )
        {
            return;
        }

        ObstacleVisualController obstacle =
            obstacleSlots[row, lane];

        if (obstacle == null)
        {
            return;
        }

        float laneX =
            (lane - 1) *
            laneDistance;

        float rowZ =
            GetRowZ(
                row,
                preset
            );

        RunnerObstacleType obstacleType;

        if (forcedType.HasValue)
        {
            obstacleType = forcedType.Value;
        }
        else
        {
            bool useSlideObstacle =
                UnityEngine.Random.value <
                preset.slideObstacleChance;

            obstacleType = useSlideObstacle
                ? RunnerObstacleType.Slide
                : RunnerObstacleType.Jump;
        }

        obstacle.transform.localPosition =
            new Vector3(
                laneX,
                0f,
                rowZ
            );

        obstacle.transform.localRotation =
            Quaternion.identity;

        obstacle.transform.localScale =
            Vector3.one;

        obstacle.gameObject.SetActive(
            true
        );

        obstacle.Configure(
            obstacleType
        );
    }

    private bool ActivatePackage(
        int row,
        int safeLane,
        DifficultyPreset preset
    )
    {
        if (
            packageSlots == null ||
            row < 0 ||
            row >= packageSlots.Length
        )
        {
            return false;
        }

        GameObject packageObject =
            packageSlots[row];

        if (packageObject == null)
        {
            return false;
        }

        float laneX =
            (safeLane - 1) *
            laneDistance;

        float obstacleZ =
            GetRowZ(
                row,
                preset
            );

        float packageZ =
            obstacleZ -
            packageLeadDistance;

        packageObject.transform.localPosition =
            new Vector3(
                laneX,
                packageHeight,
                packageZ
            );

        packageObject.transform.localRotation =
            Quaternion.identity;

        packageObject.transform.localScale =
            Vector3.one;

        packageObject.SetActive(
            true
        );

        return true;
    }

    private void ActivatePowerUp(
        int[] safeLanes,
        bool[] packageWasActivated,
        DifficultyPreset preset
    )
    {
        if (
            powerUpSlot == null ||
            safeLanes == null ||
            safeLanes.Length == 0
        )
        {
            return;
        }

        float spawnChance =
            Mathf.Clamp01(
                basePowerUpSpawnChance *
                preset.powerUpChanceMultiplier
            );

        if (
            UnityEngine.Random.value >
            spawnChance
        )
        {
            return;
        }

        List<int> packageFreeRows =
            new List<int>();

        for (
            int row = 0;
            row < safeLanes.Length;
            row++
        )
        {
            bool rowHasPackage =
                packageWasActivated != null &&
                row <
                packageWasActivated.Length &&
                packageWasActivated[row];

            if (!rowHasPackage)
            {
                packageFreeRows.Add(
                    row
                );
            }
        }

        /*
         * On paketlik rotanın paket sayısını
         * bozmamak için boş satır yoksa
         * bu tile üzerinde power-up üretilmez.
         */
        if (packageFreeRows.Count == 0)
        {
            return;
        }

        int selectedRow =
            packageFreeRows[
                UnityEngine.Random.Range(
                    0,
                    packageFreeRows.Count
                )
            ];

        int selectedLane =
            safeLanes[selectedRow];

        float laneX =
            (selectedLane - 1) *
            laneDistance;

        float obstacleZ =
            GetRowZ(
                selectedRow,
                preset
            );

        float powerUpZ =
            obstacleZ -
            powerUpDistanceBeforeObstacle;

        PowerUpType selectedPowerUpType =
            (PowerUpType)
            UnityEngine.Random.Range(
                0,
                3
            );

        powerUpSlot.transform.localPosition =
            new Vector3(
                laneX,
                powerUpHeight,
                powerUpZ
            );

        powerUpSlot.transform.localRotation =
            Quaternion.identity;

        powerUpSlot.transform.localScale =
            Vector3.one;

        powerUpSlot.Configure(
            selectedPowerUpType
        );

        powerUpSlot.gameObject.SetActive(
            true
        );
    }

    private void ActivateDeliveryZone()
    {
        if (deliveryZone == null)
        {
            return;
        }

        deliveryZone.transform.localPosition =
            new Vector3(
                0f,
                deliveryZoneY,
                deliveryZoneZ
            );

        deliveryZone.transform.localRotation =
            Quaternion.identity;

        deliveryZone.transform.localScale =
            Vector3.one;

        var destination = deliveryZone.GetComponent<CourierDeliveryStop>() ?? deliveryZone.gameObject.AddComponent<CourierDeliveryStop>();
        destination.Configure(transform.position.z);
        deliveryZone.gameObject.SetActive(
            true
        );

        deliveryZone.ResetZone();
    }

    private int CalculateFittingRowCount(
        DifficultyPreset preset
    )
    {
        int requestedRows =
            Mathf.Clamp(
                preset.activeRowCount,
                1,
                maximumSupportedRows
            );

        float latestAllowedRowZ =
            deliveryZoneZ -
            minimumDistanceBeforeDelivery;

        int fittingRows = 0;

        for (
            int row = 0;
            row < requestedRows;
            row++
        )
        {
            float rowZ =
                GetRowZ(
                    row,
                    preset
                );

            if (rowZ > latestAllowedRowZ)
            {
                break;
            }

            fittingRows++;
        }

        return fittingRows;
    }

    private float GetRowZ(
        int row,
        DifficultyPreset preset
    )
    {
        return
            firstRowZ +
            row *
            Mathf.Max(
                0.5f,
                preset.rowSpacing
            );
    }

    private int GetDifficultyLevel()
    {
        if (overrideDifficultyForTesting)
        {
            return Mathf.Clamp(
                testDifficultyLevel,
                0,
                3
            );
        }

        if (GameManager.Instance == null)
        {
            return 0;
        }

        return Mathf.Clamp(
            GameManager.Instance.DifficultyLevel,
            0,
            3
        );
    }

    private DifficultyPreset GetDifficultyPreset(
        int difficultyLevel
    )
    {
        switch (difficultyLevel)
        {
            case 1:
                return level1;

            case 2:
                return level2;

            case 3:
                return level3;

            default:
                return level0;
        }
    }

    private void CreateContentSlots()
    {
        if (contentCreated)
        {
            return;
        }

        if (
            obstaclePrefab == null ||
            packagePrefab == null ||
            deliveryZonePrefab == null
        )
        {
            Debug.LogError(
                "TrackTileContent: Obstacle, Package veya Delivery Zone prefab bağlantısı eksik.",
                this
            );

            return;
        }

        maximumSupportedRows =
            Mathf.Max(
                1,
                maximumSupportedRows
            );

        GameObject rootObject =
            new GameObject(
                "GeneratedContent"
            );

        generatedRoot =
            rootObject.transform;

        generatedRoot.SetParent(
            transform,
            false
        );

        generatedRoot.localPosition =
            Vector3.zero;

        generatedRoot.localRotation =
            Quaternion.identity;

        generatedRoot.localScale =
            Vector3.one;

        obstacleSlots =
            new ObstacleVisualController[
                maximumSupportedRows,
                3
            ];

        packageSlots =
            new GameObject[
                maximumSupportedRows
            ];

        for (
            int row = 0;
            row < maximumSupportedRows;
            row++
        )
        {
            for (
                int lane = 0;
                lane < 3;
                lane++
            )
            {
                GameObject obstacleObject =
                    Instantiate(
                        obstaclePrefab,
                        generatedRoot
                    );

                obstacleObject.name =
                    $"ObstacleSlot_{row}_{lane}";

                ObstacleVisualController controller =
                    obstacleObject.GetComponent
                        <ObstacleVisualController>();

                if (controller == null)
                {
                    Debug.LogError(
                        "Obstacle prefabında ObstacleVisualController bulunamadı.",
                        obstacleObject
                    );
                }

                obstacleObject.SetActive(
                    false
                );

                obstacleSlots[row, lane] =
                    controller;
            }

            GameObject packageObject =
                Instantiate(
                    packagePrefab,
                    generatedRoot
                );

            packageObject.name =
                $"PackageSlot_{row}";

            packageObject.SetActive(
                false
            );

            packageSlots[row] =
                packageObject;
        }

        if (powerUpPrefab != null)
        {
            GameObject powerUpObject =
                Instantiate(
                    powerUpPrefab,
                    generatedRoot
                );

            powerUpObject.name =
                "PowerUpSlot";

            powerUpSlot =
                powerUpObject.GetComponent
                    <PowerUpPickup>();

            if (powerUpSlot == null)
            {
                Debug.LogError(
                    "Power-up prefabında PowerUpPickup bulunamadı.",
                    powerUpObject
                );
            }

            powerUpObject.SetActive(
                false
            );
        }

        GameObject deliveryObject =
            Instantiate(
                deliveryZonePrefab,
                generatedRoot
            );

        deliveryObject.name =
            "DeliveryZone";

        deliveryZone =
            deliveryObject.GetComponent
                <DeliveryZone>();

        if (deliveryZone == null)
        {
            Debug.LogError(
                "Delivery Zone prefabında DeliveryZone bulunamadı.",
                deliveryObject
            );
        }

        deliveryObject.SetActive(
            false
        );

        contentCreated =
            deliveryZone != null;
    }

    private void DisableAllContent()
    {
        if (railSection != null) railSection.Clear();
        if (alternateRoute != null) alternateRoute.Clear();
        if (roofCourse) roofCourse.gameObject.SetActive(false);
        if (droneCourse) droneCourse.gameObject.SetActive(false);
        if (scooterCourse) scooterCourse.gameObject.SetActive(false);
        foreach(var street in streetEvents)if(street)street.gameObject.SetActive(false);
        if (packageSlots != null)
        {
            for (
                int row = 0;
                row < packageSlots.Length;
                row++
            )
            {
                GameObject packageObject =
                    packageSlots[row];

                if (packageObject != null)
                {
                    packageObject.SetActive(
                        false
                    );
                }
            }
        }

        if (obstacleSlots != null)
        {
            int rowCount =
                obstacleSlots.GetLength(0);

            int laneCount =
                obstacleSlots.GetLength(1);

            for (
                int row = 0;
                row < rowCount;
                row++
            )
            {
                for (
                    int lane = 0;
                    lane < laneCount;
                    lane++
                )
                {
                    ObstacleVisualController obstacle =
                        obstacleSlots[row, lane];

                    if (obstacle != null)
                    {
                        obstacle.gameObject.SetActive(
                            false
                        );
                    }
                }
            }
        }

        if (powerUpSlot != null)
        {
            powerUpSlot.gameObject.SetActive(
                false
            );
        }

        if (deliveryZone != null)
        {
            deliveryZone.gameObject.SetActive(
                false
            );
        }
    }

    private void RefreshAirCoinRoute()
    {
        AirCoinRouteGenerator coinRoute = GetComponent<AirCoinRouteGenerator>();
        if (coinRoute != null) coinRoute.RefreshForRailRoute();
    }

    private void OnValidate()
    {
        laneDistance =
            Mathf.Max(
                0.1f,
                laneDistance
            );

        maximumSupportedRows =
            Mathf.Max(
                1,
                maximumSupportedRows
            );

        targetPackagesPerDelivery =
            Mathf.Max(
                1,
                targetPackagesPerDelivery
            );

        tilesPerDelivery =
            Mathf.Max(
                1,
                tilesPerDelivery
            );

        minimumDistanceBeforeDelivery =
            Mathf.Max(
                0f,
                minimumDistanceBeforeDelivery
            );

        packageLeadDistance =
            Mathf.Max(
                0f,
                packageLeadDistance
            );

        powerUpDistanceBeforeObstacle =
            Mathf.Max(
                0f,
                powerUpDistanceBeforeObstacle
            );

        ValidatePreset(level0);
        ValidatePreset(level1);
        ValidatePreset(level2);
        ValidatePreset(level3);
    }

    private void ValidatePreset(
        DifficultyPreset preset
    )
    {
        if (preset == null)
        {
            return;
        }

        preset.activeRowCount =
            Mathf.Clamp(
                preset.activeRowCount,
                1,
                maximumSupportedRows
            );

        preset.rowSpacing =
            Mathf.Max(
                0.5f,
                preset.rowSpacing
            );

        preset.maximumSameLaneStreak =
            Mathf.Max(
                1,
                preset.maximumSameLaneStreak
            );

        preset.powerUpChanceMultiplier =
            Mathf.Max(
                0f,
                preset.powerUpChanceMultiplier
            );
    }
}

using TMPro;
using UnityEngine;
using UnityEngine.UI;

public sealed class CourierRunPolishHUD : MonoBehaviour
{
    public static CourierRunPolishHUD Instance { get; private set; }
    private readonly GameObject[] cards=new GameObject[5];
    private readonly TMP_Text[] labels=new TMP_Text[5];
    private readonly Image[] fills=new Image[5];
    private PowerUpHUDController[] legacy;
    private static readonly Color[] colors={new Color(1,.4f,.63f),new Color(.35f,.78f,1),new Color(1,.77f,.25f),new Color(.25f,.94f,1),new Color(.2f,1,.72f)};
    private static readonly string[] tr={"MIKNATIS","ZIRH","COIN x2","KAYKAY","AYAKKABI"};
    private static readonly string[] en={"MAGNET","ARMOR","COIN x2","BOARD","JUMP SHOES"};
    private void Awake(){Instance=this;}
    private void OnDestroy(){if(Instance==this)Instance=null;}
    private void Start()
    {
        legacy=FindObjectsByType<PowerUpHUDController>(FindObjectsInactive.Include,FindObjectsSortMode.None);
        for(int i=0;i<5;i++)
        {
            var card=new GameObject(i==4?"JumpShoesTimer":"PowerTimer"+(PowerUpType)i,typeof(RectTransform),typeof(Image));cards[i]=card;card.transform.SetParent(transform,false);
            CourierMenuLayout.Place((RectTransform)card.transform,new Vector2(.5f,1),new Vector2(0,-280),new Vector2(140,88));
            var bg=card.GetComponent<Image>();bg.color=new Color(.025f,.07f,.11f,.95f);bg.raycastTarget=false;
            var text=new GameObject(i==4?"JumpShoesLabel":"Label",typeof(RectTransform),typeof(TextMeshProUGUI));text.transform.SetParent(card.transform,false);
            CourierMenuLayout.Place((RectTransform)text.transform,new Vector2(.5f,.5f),new Vector2(0,5),new Vector2(134,65));
            var label=text.GetComponent<TextMeshProUGUI>();labels[i]=label;label.font=TMP_Settings.defaultFontAsset;label.fontSize=21;label.color=colors[i];label.alignment=TextAlignmentOptions.Center;label.raycastTarget=false;
            var bar=new GameObject("Remaining",typeof(RectTransform),typeof(Image));bar.transform.SetParent(card.transform,false);
            CourierMenuLayout.Place((RectTransform)bar.transform,new Vector2(0,.5f),new Vector2(10,-32),new Vector2(120,5));
            var rect=(RectTransform)bar.transform;rect.pivot=new Vector2(0,.5f);fills[i]=bar.GetComponent<Image>();fills[i].color=colors[i];fills[i].raycastTarget=false;
            card.SetActive(false);
        }
    }
    private void LateUpdate()
    {
        if(legacy!=null)foreach(var old in legacy)if(old)old.HideForModernHud();
        var p=PowerUpController.Instance;bool show=CourierJourney.Active&&p;
        int count=0;for(int i=0;i<5;i++)if(show&&p.GetRemainingTime((PowerUpType)i)>0)count++;
        int slot=0;bool english=PlayerPrefs.GetInt("NeonCourier.Language",0)==1;
        for(int i=0;i<5;i++)
        {
            if(!cards[i])continue;
            float left=p?p.GetRemainingTime((PowerUpType)i):0;cards[i].SetActive(show&&left>0);if(!cards[i].activeSelf)continue;
            ((RectTransform)cards[i].transform).anchoredPosition=new Vector2(-70+(slot++-(count-1)*.5f)*148,-280);
            labels[i].text=(english?en[i]:tr[i])+"\n"+Mathf.CeilToInt(left)+(english?" s":" sn");
            fills[i].rectTransform.sizeDelta=new Vector2(120*Mathf.Clamp01(left/Mathf.Max(.1f,p.GetDuration((PowerUpType)i))),5);
        }
    }
}

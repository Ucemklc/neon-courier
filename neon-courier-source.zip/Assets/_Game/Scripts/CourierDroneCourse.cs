using UnityEngine;

public sealed class CourierDroneCourse : MonoBehaviour
{
    private bool finished;
    private void OnEnable(){finished=false;}
    public void Pass(bool exit)
    {
        if(finished||!CourierDroneChallenge.Instance)return;
        if(exit){finished=CourierDroneChallenge.Instance.Finish(this);return;}
        CourierDroneChallenge.Instance.Begin(this);
    }
    public void Configure(GameObject[] packages,int count,float height)
    {
        gameObject.SetActive(true);
        for(int i=0;i<Mathf.Min(count,packages.Length);i++)
        {if(!packages[i])continue;int step=Mathf.Min(i,2);packages[i].transform.localPosition=new Vector3(new[]{-2.5f,0f,2.5f}[step],height,6+step*7);packages[i].SetActive(true);}
    }
}

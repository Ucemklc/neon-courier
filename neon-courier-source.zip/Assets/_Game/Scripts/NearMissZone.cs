using System;
using UnityEngine;

[DisallowMultipleComponent]
[RequireComponent(typeof(BoxCollider))]
public sealed class NearMissZone : MonoBehaviour
{
    [Header("Detection")]
    [SerializeField, Min(0f)]
    private float minimumInsideDuration = 0.04f;

    [Tooltip("Oyuncu zıplarken de yakın kaçışın algılanabilmesi için dikey kontrol alanını genişletir.")]
    [SerializeField, Min(0f)]
    private float verticalDetectionPadding = 1f;

    [Header("Debug")]
    [SerializeField]
    private bool debugLogs = false;

    private BoxCollider zoneCollider;

    private RunnerController runnerController;
    private Collider[] runnerColliders =
        Array.Empty<Collider>();

    private bool playerWasInside;
    private int hitVersionAtEntry;
    private float entryTime;

    private float nextRunnerSearchTime;

    private void Awake()
    {
        zoneCollider =
            GetComponent<BoxCollider>();

        ConfigureCollider();
    }

    private void OnEnable()
    {
        ResetDetection();

        ConfigureCollider();
        ResolveRunnerController();
    }

    private void Update()
    {
        if (!CanEvaluateNearMiss())
        {
            ResetDetection();
            return;
        }

        bool playerIsInside =
            IsPlayerInsideZone();

        if (
            playerIsInside &&
            !playerWasInside
        )
        {
            BeginNearMissCheck();
        }
        else if (
            !playerIsInside &&
            playerWasInside
        )
        {
            CompleteNearMissCheck();
        }
    }

    private void OnDisable()
    {
        ResetDetection();
    }

    private void ConfigureCollider()
    {
        if (zoneCollider == null)
        {
            zoneCollider =
                GetComponent<BoxCollider>();
        }

        if (zoneCollider != null)
        {
            zoneCollider.isTrigger = true;
        }
    }

    private bool CanEvaluateNearMiss()
    {
        GameManager gameManager =
            GameManager.Instance;

        if (
            gameManager == null ||
            gameManager.IsGameOver ||
            gameManager.IsPaused ||
            gameManager.IsMainMenuActive ||
            !gameManager.IsRunActive
        )
        {
            return false;
        }

        if (NearMissManager.Instance == null)
        {
            return false;
        }

        if (runnerController == null)
        {
            ResolveRunnerController();
        }

        return
            runnerController != null &&
            zoneCollider != null &&
            zoneCollider.enabled;
    }

    private void ResolveRunnerController()
    {
        if (runnerController != null)
        {
            return;
        }

        if (
            Time.unscaledTime <
            nextRunnerSearchTime
        )
        {
            return;
        }

        nextRunnerSearchTime =
            Time.unscaledTime + 0.5f;

        runnerController =
            FindAnyObjectByType
                <RunnerController>();

        if (runnerController == null)
        {
            runnerColliders =
                Array.Empty<Collider>();

            return;
        }

        runnerColliders =
            runnerController
                .GetComponentsInChildren
                    <Collider>(true);

        if (debugLogs)
        {
            Debug.Log(
                $"NearMissZone: Runner bulundu. Collider sayısı: {runnerColliders.Length}",
                this
            );
        }
    }

    private bool IsPlayerInsideZone()
    {
        if (
            zoneCollider == null ||
            runnerController == null
        )
        {
            return false;
        }

        Bounds detectionBounds =
            zoneCollider.bounds;

        detectionBounds.Expand(
            new Vector3(
                0f,
                verticalDetectionPadding * 2f,
                0f
            )
        );

        bool foundUsableCollider = false;

        if (runnerColliders != null)
        {
            foreach (
                Collider runnerCollider
                in runnerColliders
            )
            {
                if (
                    runnerCollider == null ||
                    !runnerCollider.enabled ||
                    !runnerCollider.gameObject
                        .activeInHierarchy ||
                    runnerCollider.isTrigger
                )
                {
                    continue;
                }

                foundUsableCollider = true;

                if (
                    detectionBounds.Intersects(
                        runnerCollider.bounds
                    )
                )
                {
                    return true;
                }
            }
        }

        /*
         * Oyuncuda kullanılabilir Collider bulunamazsa
         * Player Transform konumuyla yedek kontrol yapar.
         */
        if (!foundUsableCollider)
        {
            Vector3 runnerPosition =
                runnerController.transform.position;

            bool insideX =
                runnerPosition.x >=
                    detectionBounds.min.x &&
                runnerPosition.x <=
                    detectionBounds.max.x;

            bool insideZ =
                runnerPosition.z >=
                    detectionBounds.min.z &&
                runnerPosition.z <=
                    detectionBounds.max.z;

            return
                insideX &&
                insideZ;
        }

        return false;
    }

    private void BeginNearMissCheck()
    {
        NearMissManager manager =
            NearMissManager.Instance;

        if (manager == null)
        {
            return;
        }

        playerWasInside = true;
        entryTime = Time.unscaledTime;

        hitVersionAtEntry =
            manager.HitVersion;

        if (debugLogs)
        {
            Debug.Log(
                $"NearMissZone ENTER: {name}",
                this
            );
        }
    }

    private void CompleteNearMissCheck()
    {
        NearMissManager manager =
            NearMissManager.Instance;

        float insideDuration =
            Time.unscaledTime -
            entryTime;

        bool playerWasNotHit =
            manager != null &&
            manager.HitVersion ==
                hitVersionAtEntry;

        bool stayedLongEnough =
            insideDuration >=
            minimumInsideDuration;

        if (debugLogs)
        {
            Debug.Log(
                $"NearMissZone EXIT: {name} | " +
                $"Duration: {insideDuration:0.000} | " +
                $"No Hit: {playerWasNotHit}",
                this
            );
        }

        ResetDetection();

        if (
            manager != null &&
            playerWasNotHit &&
            stayedLongEnough
        )
        {
            bool registered =
                manager.RegisterNearMiss();

            if (debugLogs)
            {
                Debug.Log(
                    $"NearMiss registered: {registered}",
                    this
                );
            }
        }
    }

    private void ResetDetection()
    {
        playerWasInside = false;
        hitVersionAtEntry = 0;
        entryTime = 0f;
    }

    private void OnValidate()
    {
        minimumInsideDuration =
            Mathf.Max(
                0f,
                minimumInsideDuration
            );

        verticalDetectionPadding =
            Mathf.Max(
                0f,
                verticalDetectionPadding
            );

        ConfigureCollider();
    }
}
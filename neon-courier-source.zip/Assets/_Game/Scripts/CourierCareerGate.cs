using UnityEngine;

public enum CourierGateKind { RoofEntry,RoofExit,GoldParcel,DroneEntry,DroneExit }
public sealed class CourierCareerGate : MonoBehaviour
{
    public CourierGateKind Kind;
    private void OnTriggerEnter(Collider other)
    {
        var runner=other.GetComponentInParent<RunnerController>();if(!runner)return;
        var roof=GetComponentInParent<CourierRoofCourse>();
        if(Kind==CourierGateKind.GoldParcel){if(roof&&roof.TakeGold(runner))gameObject.SetActive(false);return;}
        if(Kind==CourierGateKind.RoofEntry||Kind==CourierGateKind.RoofExit){if(roof)roof.Pass(Kind==CourierGateKind.RoofExit,runner);return;}
        var section=GetComponentInParent<CourierDroneCourse>();
        if(section)section.Pass(Kind==CourierGateKind.DroneExit);
    }
}

using UnityEngine;

[DisallowMultipleComponent]
public sealed class PrivacyPolicyNotice : MonoBehaviour
{
    private const string PolicyText =
        "NEON COURIER — GİZLİLİK POLİTİKASI\n" +
        "Son güncelleme: 25 Eylül 2026\n\n" +
        "Toplanan veya gönderilen bilgiler\n" +
        "Oyun kişisel bilgi istemez, hesap oluşturmaz ve oyun verilerini geliştiriciye ya da başka şirketlere göndermez. Reklam, kullanıcı analitiği, takip veya gerçek para ile uygulama içi satın alma özelliği etkin değildir. Oyun çevrimdışı oynanabilir.\n\n" +
        "Cihazda saklanan veriler\n" +
        "En yüksek skor, oyun içi jetonlar, seçilen karakter, güçlendirici tercihleri, eğitim durumu ve günlük görev ilerlemesi yalnızca bu cihazda saklanır; çevrimiçi hesapla eşitlenmez.\n\n" +
        "Saklama ve silme\n" +
        "Yerel kayıtlar uygulama verisini temizleyene veya oyunu kaldırana kadar kalır. Oyunu kaldırmak ya da cihaz ayarlarından Neon Courier verilerini temizlemek bu kayıtları siler.\n\n" +
        "Çocukların gizliliği ve üçüncü taraflar\n" +
        "Oyun hiçbir yaştaki kullanıcıdan kişisel bilgi istemez veya bilerek toplamaz. Oyun, kişisel verileri paylaşan üçüncü taraf hizmetleri kullanmaz.\n\n" +
        "Bu politikadaki değişiklikler yeni yürürlük tarihiyle yayımlanır. Sorularınız için ulascemkilic@gmail.com adresine yazın.\n\n" +
        "ENGLISH\n" +
        "INFORMATION COLLECTED OR TRANSMITTED\n" +
        "Neon Courier does not request personal information, require an account, or send game data to the developer or other companies. Advertising, user analytics, tracking, and real-money in-app purchase features are not enabled. The game can be played offline.\n\n" +
        "DATA STORED ON YOUR DEVICE\n" +
        "High score, in-game coins, selected character, booster preferences, tutorial status, and daily mission progress are stored only on this device and are not synced to an online account.\n\n" +
        "RETENTION AND DELETION\n" +
        "Local records remain until you clear the app data or uninstall the game. Uninstalling Neon Courier or clearing its data in device settings deletes these records.\n\n" +
        "CHILDREN'S PRIVACY AND THIRD PARTIES\n" +
        "The game does not request or knowingly collect personal information from users of any age. It does not use third-party services that share personal data.\n\n" +
        "Policy changes will be published with a new effective date. For questions, contact ulascemkilic@gmail.com.";

    private static readonly Color AccentColor = new Color(0.12f, 0.88f, 0.91f, 1f);
    private static readonly Color PanelColor = new Color(0.015f, 0.035f, 0.12f, 0.97f);

    private GameManager gameManager;
    private bool isOpen;
    public bool IsOpen => isOpen;
    private Vector2 scrollPosition;
    private GUIStyle titleStyle;
    private GUIStyle bodyStyle;

    [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
    private static void AttachToGameManager()
    {
        GameManager manager = Object.FindFirstObjectByType<GameManager>();
        if (manager != null && manager.GetComponent<PrivacyPolicyNotice>() == null)
        {
            manager.gameObject.AddComponent<PrivacyPolicyNotice>();
        }
    }

    private void Awake()
    {
        gameManager = GetComponent<GameManager>();
    }

    private void OnGUI()
    {
        var missions=FindAnyObjectByType<DailyMissionPanelController>();if(missions&&missions.IsOpen)return;
        var workshop = GetComponent<CourierExpansionUI>();
        if (workshop != null && workshop.WardrobeOpen) return;
        var garage = GetComponent<CourierGarageUI>();
        if (garage != null && garage.IsOpen) return;
        if (gameManager == null || !gameManager.IsMainMenuActive)
        {
            isOpen = false;
            return;
        }

        EnsureStyles();
        bool english = GetComponent<GamePresentationController>() != null &&
            GetComponent<GamePresentationController>().IsEnglish;
        float width = Screen.width;
        float height = Screen.height;
        float margin = width * 0.045f;
        float buttonHeight = height * 0.035f;
        Rect entryRect = new Rect(
            margin,
            height - buttonHeight - height * 0.015f,
            width * 0.25f,
            buttonHeight
        );

        Color oldColor = GUI.color;
        GUI.color = AccentColor;
        if (GUI.Button(entryRect, english ? "PRIVACY" : "GİZLİLİK"))
        {
            isOpen = true;
        }
        GUI.color = oldColor;

        if (!isOpen)
        {
            return;
        }

        Rect panelRect = new Rect(
            width * 0.055f,
            height * 0.075f,
            width * 0.89f,
            height * 0.84f
        );

        GUI.color = PanelColor;
        GUI.Box(panelRect, GUIContent.none);
        GUI.color = oldColor;

        float inset = width * 0.045f;
        Rect titleRect = new Rect(
            panelRect.x + inset,
            panelRect.y + inset,
            panelRect.width - inset * 2f,
            height * 0.07f
        );
        GUI.Label(titleRect, english ? "PRIVACY POLICY" : "GİZLİLİK POLİTİKASI", titleStyle);

        float footerHeight = height * 0.065f;
        Rect closeRect = new Rect(
            panelRect.x + inset,
            panelRect.yMax - footerHeight - inset * 0.5f,
            panelRect.width - inset * 2f,
            footerHeight
        );
        Rect viewportRect = new Rect(
            panelRect.x + inset,
            titleRect.yMax + inset * 0.35f,
            panelRect.width - inset * 2f,
            closeRect.y - titleRect.yMax - inset * 0.7f
        );

        GUI.Box(viewportRect, GUIContent.none);
        float contentWidth = viewportRect.width - width * 0.055f;
        float contentHeight = bodyStyle.CalcHeight(
            new GUIContent(PolicyText),
            contentWidth
        ) + width * 0.04f;
        Rect contentRect = new Rect(0f, 0f, contentWidth, contentHeight);
        scrollPosition = GUI.BeginScrollView(
            viewportRect,
            scrollPosition,
            contentRect,
            false,
            true
        );
        GUI.Label(
            new Rect(width * 0.02f, width * 0.02f, contentWidth - width * 0.04f, contentHeight),
            PolicyText,
            bodyStyle
        );
        GUI.EndScrollView();

        if (GUI.Button(closeRect, english ? "CLOSE" : "KAPAT"))
        {
            isOpen = false;
        }
    }

    private void EnsureStyles()
    {
        float fontSize = Mathf.Clamp(Screen.width * 0.031f, 18f, 40f);
        if (titleStyle == null)
        {
            titleStyle = new GUIStyle(GUI.skin.label)
            {
                alignment = TextAnchor.MiddleCenter,
                fontStyle = FontStyle.Bold,
                wordWrap = true
            };
        }

        if (bodyStyle == null)
        {
            bodyStyle = new GUIStyle(GUI.skin.label)
            {
                alignment = TextAnchor.UpperLeft,
                wordWrap = true,
                richText = false
            };
        }

        titleStyle.fontSize = Mathf.RoundToInt(
            Mathf.Clamp(fontSize * 1.2f, 22f, 48f)
        );
        titleStyle.normal.textColor = AccentColor;
        bodyStyle.fontSize = Mathf.RoundToInt(fontSize);
        bodyStyle.normal.textColor = Color.white;
    }
}


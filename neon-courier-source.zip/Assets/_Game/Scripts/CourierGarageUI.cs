using TMPro;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.UI;

/// <summary>A personal garage with a rendered character, matching bag, display bike and earned trophies.</summary>
public sealed class CourierGarageUI : MonoBehaviour
{
    private GameManager manager;
    private CourierExpansionUI workshop;
    private GameObject entry,panel,previewRoot,garage;
    private TMP_Text career,unlocks,trophies;
    private Button[] outfits=new Button[3];
    private GameObject[] couriers=new GameObject[4];
    private Camera previewCamera;
    private RenderTexture texture;
    private RawImage previewImage;
    private float nextFrame,nextMenuRefresh;
    public bool IsOpen=>panel&&panel.activeSelf;
    public static bool MenuOverlayOpen
    {
        get
        {
            var missions=FindAnyObjectByType<DailyMissionPanelController>();var gm=GameManager.Instance;
            var privacy=gm?gm.GetComponent<PrivacyPolicyNotice>():null;var settings=gm?gm.GetComponent<GamePresentationController>():null;
            return missions&&missions.IsOpen||privacy&&privacy.IsOpen||settings&&settings.IsOverlayOpen;
        }
    }
    private bool English=>PlayerPrefs.GetInt("NeonCourier.Language",0)==1;
    private void Start()
    {
        manager=GameManager.Instance;workshop=manager.GetComponent<CourierExpansionUI>();
        var canvas=new GameObject("CourierGarageCanvas",typeof(RectTransform),typeof(Canvas),typeof(CanvasScaler),typeof(GraphicRaycaster));canvas.transform.SetParent(transform,false);
        canvas.GetComponent<Canvas>().renderMode=RenderMode.ScreenSpaceOverlay;canvas.GetComponent<Canvas>().sortingOrder=205;
        var scaler=canvas.GetComponent<CanvasScaler>();scaler.uiScaleMode=CanvasScaler.ScaleMode.ScaleWithScreenSize;scaler.referenceResolution=new Vector2(1080,1920);scaler.matchWidthOrHeight=.5f;
        entry=ButtonAt(canvas.transform,"OpenGarage",new Vector2(0,228),new Vector2(820,100),"GARAJ & KARİYER",Open,false).gameObject;
        panel=new GameObject("PersonalGarage",typeof(RectTransform),typeof(Image));panel.transform.SetParent(canvas.transform,false);
        var r=(RectTransform)panel.transform;r.anchorMin=Vector2.zero;r.anchorMax=Vector2.one;r.offsetMin=r.offsetMax=Vector2.zero;
        panel.GetComponent<Image>().color=new Color(.016f,.027f,.048f,1);panel.SetActive(false);
        Label(panel.transform,"GarageTitle",new Vector2(0,1770),new Vector2(860,90),English?"YOUR COURIER GARAGE":"KURYE GARAJIN",52,new Color(.2f,.88f,1));
        ButtonAt(panel.transform,"CloseGarage",new Vector2(455,1825),new Vector2(90,85),"X",Close,false);
        career=Label(panel.transform,"CareerRank",new Vector2(0,1645),new Vector2(950,150),"",33,Color.white);
        var preview=new GameObject("GaragePreview",typeof(RectTransform),typeof(RawImage));preview.transform.SetParent(panel.transform,false);
        Place((RectTransform)preview.transform,new Vector2(0,1210),new Vector2(1000,630));previewImage=preview.GetComponent<RawImage>();previewImage.raycastTarget=false;
        trophies=Label(panel.transform,"TrophyStats",new Vector2(0,845),new Vector2(970,85),"",27,new Color(1,.75f,.34f));
        unlocks=Label(panel.transform,"CareerRewards",new Vector2(0,667),new Vector2(940,220),"",27,new Color(.71f,.83f,.9f));
        for(int i=0;i<3;i++){int option=i;outfits[i]=ButtonAt(panel.transform,"CareerOutfit"+i,new Vector2((i-1)*300,463),new Vector2(284,112),"",()=>{CourierCareerProgress.SelectOutfit(option);Refresh();},false);}
        ButtonAt(panel.transform,"GarageWorkshop",new Vector2(0,300),new Vector2(850,112),English?"CUSTOMIZE BACKPACK":"ÇANTANI ÖZELLEŞTİR",()=>{Close();workshop.OpenWardrobe();},false);
        ButtonAt(panel.transform,"GarageRun",new Vector2(0,146),new Vector2(850,122),English?"START DELIVERIES":"TESLİMATA BAŞLA",()=>{Close();manager.StartGameFromMenu();},true);
        CourierCareerProgress.Changed+=Refresh;
    }
    private void OnDestroy()
    {
        CourierCareerProgress.Changed-=Refresh;
        if(previewRoot)Destroy(previewRoot);if(texture){texture.Release();Destroy(texture);}
    }
    public void Open(){if(!manager||!manager.IsMainMenuActive)return;BuildPreview();panel.SetActive(true);previewRoot.SetActive(true);Refresh();}
    public void Close(){if(panel)panel.SetActive(false);if(previewRoot)previewRoot.SetActive(false);}
    private void Update()
    {
        if(!entry||!manager)return;
        bool other=FindAnyObjectByType<CourierCharacterMenu>()||workshop&&workshop.WardrobeOpen||MenuOverlayOpen;
        entry.SetActive(manager.IsMainMenuActive&&!IsOpen&&!other);
        if(!manager.IsMainMenuActive&&IsOpen)Close();
        if(Time.unscaledTime>=nextMenuRefresh){entry.GetComponentInChildren<TMP_Text>().text=(English?"GARAGE & CAREER  •  LV ":"GARAJ & KARİYER  •  SV ")+CourierCareerProgress.Level;nextMenuRefresh=Time.unscaledTime+.5f;}
        if(IsOpen&&previewCamera&&Time.unscaledTime>=nextFrame)
        {
            var request=new RenderPipeline.StandardRequest{destination=texture};
            if(RenderPipeline.SupportsRenderRequest(previewCamera,request))RenderPipeline.SubmitRenderRequest(previewCamera,request);
            nextFrame=Time.unscaledTime+.1f;
        }
    }
    private void Refresh()
    {
        if(!career)return;bool en=English;
        panel.transform.Find("GarageTitle").GetComponent<TMP_Text>().text=en?"YOUR COURIER GARAGE":"KURYE GARAJIN";
        panel.transform.Find("GarageWorkshop").GetComponentInChildren<TMP_Text>().text=en?"CUSTOMIZE BACKPACK":"ÇANTANI ÖZELLEŞTİR";
        panel.transform.Find("GarageRun").GetComponentInChildren<TMP_Text>().text=en?"START DELIVERIES":"TESLİMATA BAŞLA";
        career.text=CourierCareerProgress.Rank(en)+"  •  "+(en?"LEVEL ":"SEVİYE ")+CourierCareerProgress.Level+"\n"+CourierCareerProgress.XP+(CourierCareerProgress.Level==7?(en?" XP · MAX LEVEL":" XP · EN ÜST SEVİYE"):" / "+CourierCareerProgress.NextXP+" XP");
        int contracts=PlayerPrefs.GetInt(CourierCareerProgress.ContractsKey),roofs=PlayerPrefs.GetInt(CourierCareerProgress.RoofsKey),escapes=PlayerPrefs.GetInt(CourierCareerProgress.EscapesKey);
        trophies.text=(en?"CONTRACTS ":"SÖZLEŞME ")+contracts+"  •  "+(en?"ROOFS ":"ÇATI ")+roofs+"  •  "+(en?"ESCAPES ":"KAÇIŞ ")+escapes;
        unlocks.text=en?"LV 3 · Master outfit, badge & Canal Line\nLV 5 · Sky Terminal & garage upgrades\nLV 6 · Legend outfit & gold badge\nDeliver parcels and complete routes to earn XP.":"SV 3 · Usta kıyafeti, arma ve Kanal Hattı\nSV 5 · Gökyüzü Terminali ve garaj yükseltmesi\nSV 6 · Efsane kıyafeti ve altın arma\nTeslimat yap, parkurları tamamla, XP kazan.";
        for(int i=0;i<3;i++)
        {
            bool unlocked=CourierCareerProgress.OutfitUnlocked(i);outfits[i].interactable=unlocked;
            string name=(en?new[]{"COURIER","MASTER","LEGEND"}:new[]{"KURYE","USTA","EFSANE"})[i];
            outfits[i].GetComponentInChildren<TMP_Text>().text=unlocked?(CourierCareerProgress.Outfit==i?"• ":"")+name:name+"\n"+(en?"LV ":"SV ")+(i==1?3:6);
        }
        if(!garage)return;
        garage.transform.Find("ContractTrophy").gameObject.SetActive(contracts>0);garage.transform.Find("RoofTrophy").gameObject.SetActive(roofs>0);garage.transform.Find("DroneTrophy").gameObject.SetActive(escapes>0);
        garage.transform.Find("UpgradeLevel3").gameObject.SetActive(CourierCareerProgress.Level>=3);garage.transform.Find("UpgradeLevel5").gameObject.SetActive(CourierCareerProgress.Level>=5);
        var selection=FindAnyObjectByType<CharacterSelectionManager>();int selected=selection?selection.SelectedIndex:0;
        for(int i=0;i<couriers.Length;i++)if(couriers[i])
        {
            couriers[i].SetActive(i==selected);if(i!=selected)continue;
            foreach(var appearance in couriers[i].GetComponentsInChildren<CourierBackpackAppearance>())appearance.Apply();
            var block=new MaterialPropertyBlock();
            foreach(var renderer in couriers[i].GetComponentsInChildren<Renderer>(true))
            {
                if(!renderer.sharedMaterial)continue;string mat=renderer.sharedMaterial.name;Color color;
                if(mat=="SafetyTangerine")color=CourierBackpackStyle.Accents[CourierBackpackStyle.Skin];
                else if(mat=="Porcelain")color=CourierCareerProgress.Outfit==2?new Color(1,.72f,.22f):renderer.sharedMaterial.GetColor("_BaseColor");
                else if(mat=="BlueSlate")color=CourierCareerProgress.Outfit==1?new Color(.12f,.34f,.44f):CourierCareerProgress.Outfit==2?new Color(.16f,.19f,.29f):renderer.sharedMaterial.GetColor("_BaseColor");
                else continue;
                renderer.GetPropertyBlock(block);block.SetColor("_BaseColor",color);renderer.SetPropertyBlock(block);
            }
        }
    }
    private void BuildPreview()
    {
        if(previewRoot)return;previewRoot=new GameObject("Garage render stage");previewRoot.transform.position=new Vector3(0,-1200,0);
        garage=Instantiate(Resources.Load<GameObject>("CourierCareer/CourierGarage"),previewRoot.transform,false);
        for(int i=0;i<4;i++)
        {
            var asset=Resources.Load<GameObject>("CourierCareer/GarageCourier"+i);if(!asset)continue;
            couriers[i]=Instantiate(asset,previewRoot.transform,false);couriers[i].transform.localPosition=new Vector3(-1.35f,.03f,-.3f);couriers[i].transform.localRotation=Quaternion.Euler(0,160,0);couriers[i].transform.localScale=Vector3.one*1.65f;
        }
        foreach(var t in previewRoot.GetComponentsInChildren<Transform>(true))t.gameObject.layer=31;
        var cameraGO=new GameObject("Garage camera",typeof(Camera));cameraGO.transform.SetParent(previewRoot.transform,false);previewCamera=cameraGO.GetComponent<Camera>();
        cameraGO.transform.localPosition=new Vector3(-4.6f,4.1f,-8);cameraGO.transform.LookAt(previewRoot.transform.position+new Vector3(0,1.1f,.1f));
        previewCamera.enabled=false;previewCamera.cullingMask=1<<31;previewCamera.fieldOfView=39;previewCamera.nearClipPlane=.1f;previewCamera.farClipPlane=35;previewCamera.clearFlags=CameraClearFlags.SolidColor;previewCamera.backgroundColor=new Color(.016f,.027f,.048f);
        var lamp=new GameObject("Garage fill",typeof(Light));lamp.transform.SetParent(previewRoot.transform,false);lamp.transform.localPosition=new Vector3(-1,4,-3);var l=lamp.GetComponent<Light>();l.type=LightType.Point;l.intensity=17;l.range=14;l.cullingMask=1<<31;l.shadows=LightShadows.None;
        texture=new RenderTexture(1000,630,24,RenderTextureFormat.ARGB32);texture.Create();previewImage.texture=texture;
    }
    private static void Place(RectTransform rect,Vector2 position,Vector2 size)=>CourierMenuLayout.Place(rect,new Vector2(.5f,0),position,size);
    private static TMP_Text Label(Transform parent,string name,Vector2 pos,Vector2 size,string value,float font,Color color)
    {var go=new GameObject(name,typeof(RectTransform),typeof(TextMeshProUGUI));go.transform.SetParent(parent,false);Place((RectTransform)go.transform,pos,size);var t=go.GetComponent<TMP_Text>();t.font=TMP_Settings.defaultFontAsset;t.text=value;t.fontSize=font;t.color=color;t.alignment=TextAlignmentOptions.Center;t.raycastTarget=false;return t;}
    private static Button ButtonAt(Transform parent,string name,Vector2 pos,Vector2 size,string label,UnityEngine.Events.UnityAction action,bool primary)
    {
        var go=new GameObject(name,typeof(RectTransform),typeof(Image),typeof(Button));go.transform.SetParent(parent,false);Place((RectTransform)go.transform,pos,size);
        var b=go.GetComponent<Button>();Label(go.transform,"Label",Vector2.zero,size,label,30,Color.white);go.AddComponent<CourierMenuButton>().Style(primary);
        var text=b.GetComponentInChildren<TMP_Text>();text.fontSize=32;text.enableAutoSizing=true;text.fontSizeMin=23;text.fontSizeMax=32;b.onClick.AddListener(action);return b;
    }
}

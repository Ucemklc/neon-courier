using UnityEngine;

/// <summary>Three consecutive pooled road tiles form a single 90-metre scooter route.</summary>
public sealed class CourierScooterSegment : MonoBehaviour
{
    private int part;
    private float routeStart;
    public int Part=>part;
    public void Configure(int section,GameObject[] packages,int quota,float height)
    {
        part=section;routeStart=transform.position.z-part*30f;gameObject.SetActive(true);
        foreach(var child in GetComponentsInChildren<Transform>(true))child.gameObject.SetActive(true);
        var welcome=transform.Find("Scooter pickup");if(welcome)welcome.gameObject.SetActive(part==0);
        var exit=transform.Find("Finish lights");if(exit)exit.gameObject.SetActive(part==2);
        int openLane=part==0?1:part==1?0:2;
        for(int lane=0;lane<3;lane++){var cone=transform.Find("Road crate "+lane);if(cone)cone.gameObject.SetActive(lane!=openLane);}
        for(int i=0;i<packages.Length;i++)
        {var p=packages[i];if(!p)continue;p.SetActive(false);if(i<quota){p.transform.position=transform.TransformPoint(new Vector3((openLane-1)*2.5f,height,6+i*16f/Mathf.Max(1,quota)));p.SetActive(true);}}
    }
    private void Update()
    {
        if(!CourierJourney.Active||!CourierScooterRide.Instance)return;
        var runner=CourierWeather.Runner;
        if(runner&&runner.transform.position.z>=transform.position.z&&runner.transform.position.z<transform.position.z+30)
            CourierScooterRide.Instance.Begin(routeStart,routeStart+88);
    }
}

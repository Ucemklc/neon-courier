using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[DisallowMultipleComponent]
[RequireComponent(typeof(Collider))]
[RequireComponent(typeof(Rigidbody))]
[RequireComponent(typeof(AudioSource))]
public sealed class AirCoinPickup : MonoBehaviour
{
    [Header("Reward")]
    [SerializeField, Min(1)]
    private int coinValue = 1;

    [Header("Visual Movement")]
    [SerializeField]
    private float rotationSpeed = 180f;

    [SerializeField, Min(0f)]
    private float bobHeight = 0.08f;

    [SerializeField, Min(0.1f)]
    private float bobSpeed = 3f;

    [Header("Hoverboard Requirement")]
    [Tooltip(
        "Açıksa bu altın yalnızca Hoverboard aktifken toplanabilir."
    )]
    [SerializeField]
    private bool requireHoverboard = true;

    [Header("Coin Sound")]
    [Tooltip(
        "Coin toplandığında çalacak ses."
    )]
    [SerializeField]
    private AudioClip coinSound;

    [SerializeField, Range(0f, 1f)]
    private float coinSoundVolume = 0.75f;

    [Tooltip(
        "Her coinde sesi çok hafif değiştirerek daha doğal his verir."
    )]
    [SerializeField]
    private bool randomizePitch = true;

    [SerializeField, Range(0.5f, 1.5f)]
    private float minimumPitch = 0.95f;

    [SerializeField, Range(0.5f, 1.5f)]
    private float maximumPitch = 1.05f;

    private Collider triggerCollider;
    private Rigidbody coinRigidbody;
    private AudioSource audioSource;

    private Renderer[] coinRenderers;

    private Vector3 startingLocalPosition;
    private float bobPhase;

    private bool collected;

    private Coroutine deactivateCoroutine;

    private static Material coinPickupSparkleMaterial;
    private static readonly HashSet<AirCoinPickup> activeCoins = new HashSet<AirCoinPickup>();
    private bool beingAttracted;
    private TrailRenderer attractionTrail;
    public bool CanCollect => !collected && isActiveAndEnabled && (!requireHoverboard || (PowerUpController.Instance && PowerUpController.Instance.IsHoverboardActive));
    [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.SubsystemRegistration)]
    private static void ResetRegistry() { activeCoins.Clear(); }
    public static void CopyActiveCoinsTo(List<AirCoinPickup> buffer) { buffer.Clear(); foreach(var coin in activeCoins) if(coin) buffer.Add(coin); }
    public void AttractTowards(Transform target, float speed)
    {
        if (!target || !CanCollect || !CourierJourney.Active) return;
        beingAttracted = true;
        if (attractionTrail) attractionTrail.emitting = true;
        transform.position = Vector3.MoveTowards(transform.position, target.position, speed * Time.deltaTime);
        if ((transform.position-target.position).sqrMagnitude < .42f) CollectCoin(GameManager.Instance);
    }

    private void Awake()
    {
        // The imported gem animation also moves/scales the root and fights attraction/pooling.
        foreach(var behavior in GetComponents<MonoBehaviour>())
            if(behavior.GetType().FullName=="Benjathemaker.SimpleGemsAnim")behavior.enabled=false;
        triggerCollider =
            GetComponent<Collider>();

        coinRigidbody =
            GetComponent<Rigidbody>();

        audioSource =
            GetComponent<AudioSource>();

        var visualAsset = Resources.Load<GameObject>("CourierPowers/Coin");
        if (visualAsset)
        {
            foreach (var old in GetComponentsInChildren<Renderer>(true)) old.forceRenderingOff = true;
            var visual = Instantiate(visualAsset, transform, false);
            visual.name = "CourierCoinVisual";
            Vector3 scale = transform.lossyScale;
            visual.transform.localScale = new Vector3(1/Mathf.Max(.001f,Mathf.Abs(scale.x)),1/Mathf.Max(.001f,Mathf.Abs(scale.y)),1/Mathf.Max(.001f,Mathf.Abs(scale.z)));
            attractionTrail = visual.AddComponent<TrailRenderer>();
            attractionTrail.sharedMaterial = Resources.Load<Material>("CourierPowers/PowerTrail");
            attractionTrail.time=.18f; attractionTrail.minVertexDistance=.07f;
            attractionTrail.startWidth=.045f; attractionTrail.endWidth=0; attractionTrail.emitting=false;
            attractionTrail.shadowCastingMode=UnityEngine.Rendering.ShadowCastingMode.Off;
        }

        coinRenderers =
            GetComponentsInChildren
                <Renderer>(true);

        ConfigurePhysics();
        ConfigureAudio();
    }

    private void OnEnable()
    {
        activeCoins.Add(this); beingAttracted=false;
        if(attractionTrail){attractionTrail.Clear();attractionTrail.emitting=false;}
        collected = false;

        startingLocalPosition =
            transform.localPosition;

        bobPhase =
            Random.Range(
                0f,
                Mathf.PI * 2f
            );

        if (deactivateCoroutine != null)
        {
            StopCoroutine(
                deactivateCoroutine
            );

            deactivateCoroutine = null;
        }

        ConfigurePhysics();
        ConfigureAudio();

        SetVisualsActive(true);

        if (triggerCollider != null)
        {
            triggerCollider.enabled = true;
        }
    }

    private void OnDisable()
    {
        activeCoins.Remove(this);beingAttracted=false;
        if(attractionTrail){attractionTrail.emitting=false;attractionTrail.Clear();}
        if (audioSource != null)
        {
            audioSource.Stop();
        }

        if (deactivateCoroutine != null)
        {
            StopCoroutine(
                deactivateCoroutine
            );

            deactivateCoroutine = null;
        }
    }

    private void Update()
    {
        if (beingAttracted && (!PowerUpController.Instance || !PowerUpController.Instance.IsMagnetActive))
        {
            beingAttracted=false; startingLocalPosition=transform.localPosition;
            if(attractionTrail)attractionTrail.emitting=false;
        }
        if (beingAttracted) return;
        if (collected)
        {
            return;
        }

        transform.Rotate(
            Vector3.up,
            rotationSpeed *
            Time.deltaTime,
            Space.Self
        );

        Vector3 localPosition =
            startingLocalPosition;

        localPosition.y +=
            Mathf.Sin(
                Time.time *
                bobSpeed +
                bobPhase
            ) * bobHeight;

        transform.localPosition =
            localPosition;
    }

    private void OnTriggerEnter(
        Collider other
    )
    {
        if (collected)
        {
            return;
        }

        RunnerController runner =
            other.GetComponentInParent
                <RunnerController>();

        if (runner == null)
        {
            return;
        }

        GameManager gameManager =
            GameManager.Instance;

        if (
            gameManager == null ||
            !gameManager.IsRunActive ||
            gameManager.IsPaused ||
            gameManager.IsGameOver
        )
        {
            return;
        }

        PowerUpController powerUpController =
            PowerUpController.Instance;

        if (
            requireHoverboard &&
            (
                powerUpController == null ||
                !powerUpController
                    .IsHoverboardActive
            )
        )
        {
            return;
        }

        CollectCoin(
            gameManager
        );
    }

    private void CollectCoin(
        GameManager gameManager
    )
    {
        if (collected)
        {
            return;
        }

        collected = true;

        if (triggerCollider != null)
        {
            triggerCollider.enabled = false;
        }

        SetVisualsActive(false);

        int multiplier =
            Mathf.Max(
                1,
                gameManager
                    .CurrentCoinMultiplier
            );

        int finalCoinValue =
            coinValue *
            multiplier;

        gameManager.GrantRunBonus(
            finalCoinValue
        );

        SpawnPickupSparkles();
        if(attractionTrail)attractionTrail.emitting=false;

        PlayCoinSound();
    }

    private void SpawnPickupSparkles()
    {
        GameObject effectObject = new GameObject(
            "CoinPickupSparkle"
        );

        effectObject.transform.position = transform.position;

        ParticleSystem particles =
            effectObject.AddComponent<ParticleSystem>();

        ParticleSystem.MainModule main = particles.main;
        main.loop = false;
        main.playOnAwake = false;
        // AddComponent can start the system before its modules are configured.
        // Stop it first so changing duration and other main settings is safe.
        particles.Stop(
            true,
            ParticleSystemStopBehavior.StopEmittingAndClear
        );
        main.duration = 0.35f;
        main.startLifetime = new ParticleSystem.MinMaxCurve(0.3f, 0.65f);
        main.startSpeed = new ParticleSystem.MinMaxCurve(1.2f, 2.8f);
        main.startSize = new ParticleSystem.MinMaxCurve(0.045f, 0.11f);
        main.startColor = new Color(1f, 0.82f, 0.18f, 1f);
        var fade=particles.colorOverLifetime;fade.enabled=true;
        var gradient=new Gradient();gradient.SetKeys(new[]{new GradientColorKey(new Color(1,.88f,.35f),0),new GradientColorKey(new Color(1,.55f,.06f),1)},new[]{new GradientAlphaKey(1,0),new GradientAlphaKey(0,1)});fade.color=gradient;
        var shrink=particles.sizeOverLifetime;shrink.enabled=true;shrink.size=new ParticleSystem.MinMaxCurve(1,AnimationCurve.EaseInOut(0,1,1,0));
        main.maxParticles = 24;
        main.simulationSpace = ParticleSystemSimulationSpace.World;

        ParticleSystem.EmissionModule emission = particles.emission;
        emission.rateOverTime = 0f;
        emission.SetBursts(
            new[]
            {
                new ParticleSystem.Burst(0f, 16)
            }
        );

        ParticleSystem.ShapeModule shape = particles.shape;
        shape.shapeType = ParticleSystemShapeType.Sphere;
        shape.radius = 0.12f;

        ParticleSystemRenderer particleRenderer =
            effectObject.GetComponent<ParticleSystemRenderer>();

        particleRenderer.renderMode = ParticleSystemRenderMode.Billboard;
        particleRenderer.sortingOrder = 2;

        if (coinPickupSparkleMaterial == null)
        {
            coinPickupSparkleMaterial = Resources.Load<Material>(
                "KenneyParticlePack/CoinSparkle"
            );
        }

        if (coinPickupSparkleMaterial != null)
        {
            particleRenderer.sharedMaterial = coinPickupSparkleMaterial;
        }

        particles.Play();
        Destroy(effectObject, 1.2f);
    }

    private void PlayCoinSound()
    {
        if (
            audioSource == null ||
            coinSound == null || (GameManager.Instance && !GameManager.Instance.IsSoundEnabled)
        )
        {
            gameObject.SetActive(false);
            return;
        }

        audioSource.Stop();

        if (randomizePitch)
        {
            audioSource.pitch =
                Random.Range(
                    minimumPitch,
                    maximumPitch
                );
        }
        else
        {
            audioSource.pitch = 1f;
        }

        audioSource.PlayOneShot(
            coinSound,
            coinSoundVolume
        );

        float soundDuration =
            coinSound.length /
            Mathf.Max(
                0.01f,
                Mathf.Abs(
                    audioSource.pitch
                )
            );

        deactivateCoroutine =
            StartCoroutine(
                DeactivateAfterSound(
                    soundDuration
                )
            );
    }

    private IEnumerator
        DeactivateAfterSound(
            float delay
        )
    {
        yield return
            new WaitForSecondsRealtime(
                Mathf.Max(
                    0.05f,
                    delay
                )
            );

        deactivateCoroutine = null;

        gameObject.SetActive(false);
    }

    public void ResetCoin()
    {
        beingAttracted=false;
        if(attractionTrail){attractionTrail.emitting=false;attractionTrail.Clear();}
        collected = false;

        startingLocalPosition =
            transform.localPosition;

        if (deactivateCoroutine != null)
        {
            StopCoroutine(
                deactivateCoroutine
            );

            deactivateCoroutine = null;
        }

        if (audioSource != null)
        {
            audioSource.Stop();
            audioSource.pitch = 1f;
        }

        SetVisualsActive(true);

        if (triggerCollider != null)
        {
            triggerCollider.enabled = true;
        }

        gameObject.SetActive(true);
    }

    private void SetVisualsActive(
        bool active
    )
    {
        if (coinRenderers == null)
        {
            return;
        }

        for (
            int i = 0;
            i < coinRenderers.Length;
            i++
        )
        {
            Renderer coinRenderer =
                coinRenderers[i];

            if (coinRenderer != null)
            {
                coinRenderer.enabled =
                    active;
            }
        }
    }

    private void ConfigurePhysics()
    {
        if (triggerCollider == null)
        {
            triggerCollider =
                GetComponent<Collider>();
        }

        if (coinRigidbody == null)
        {
            coinRigidbody =
                GetComponent<Rigidbody>();
        }

        if (triggerCollider != null)
        {
            triggerCollider.isTrigger =
                true;
        }

        if (coinRigidbody != null)
        {
            coinRigidbody.useGravity =
                false;

            coinRigidbody.isKinematic =
                true;

            coinRigidbody.detectCollisions =
                true;
        }
    }

    private void ConfigureAudio()
    {
        if (audioSource == null)
        {
            audioSource =
                GetComponent<AudioSource>();
        }

        if (audioSource == null)
        {
            return;
        }

        audioSource.playOnAwake = false;
        audioSource.loop = false;

        /*
         * Coin sesi mobil oyunda her kamerada
         * net duyulsun diye 2D kullanıyoruz.
         */
        audioSource.spatialBlend = 0f;

        audioSource.volume = 1f;

        audioSource.pitch = 1f;
    }

    private void OnValidate()
    {
        coinValue =
            Mathf.Max(
                1,
                coinValue
            );

        rotationSpeed =
            Mathf.Max(
                0f,
                rotationSpeed
            );

        bobHeight =
            Mathf.Max(
                0f,
                bobHeight
            );

        bobSpeed =
            Mathf.Max(
                0.1f,
                bobSpeed
            );

        coinSoundVolume =
            Mathf.Clamp01(
                coinSoundVolume
            );

        minimumPitch =
            Mathf.Clamp(
                minimumPitch,
                0.5f,
                1.5f
            );

        maximumPitch =
            Mathf.Clamp(
                maximumPitch,
                0.5f,
                1.5f
            );

        if (
            maximumPitch <
            minimumPitch
        )
        {
            maximumPitch =
                minimumPitch;
        }
    }
}

using UnityEngine;

public enum RunnerObstacleType
{
    Jump,
    Slide,
    FullLaneClosure
}

[DisallowMultipleComponent]
[RequireComponent(typeof(BoxCollider))]
public class ObstacleVisualController : MonoBehaviour
{
    [Header("Legacy Visual Roots")]
    [SerializeField] private GameObject jumpVisualRoot;
    [SerializeField] private GameObject slideVisualRoot;

    [Header("Jump Collider")]
    [SerializeField] private Vector3 jumpColliderCenter = new Vector3(0f, 0.55f, 0f);
    [SerializeField] private Vector3 jumpColliderSize = new Vector3(1.5f, 1.1f, 1.4f);

    [Header("Slide Collider")]
    [SerializeField] private Vector3 slideColliderCenter = new Vector3(0f, 1.75f, 0f);
    [SerializeField] private Vector3 slideColliderSize = new Vector3(1.5f, 0.5f, 1.4f);

    private BoxCollider obstacleCollider;
    private GameObject generatedJumpVisual;
    private GameObject generatedSlideVisual;
    private GameObject generatedClosureVisual;
    private Transform generatedVisualRoot;
    private Renderer closureWarningRenderer;
    private MaterialPropertyBlock closureWarningBlock;

    private static readonly int BaseColorId = Shader.PropertyToID("_BaseColor");
    private static readonly int ColorId = Shader.PropertyToID("_Color");
    private static readonly int EmissionColorId = Shader.PropertyToID("_EmissionColor");

    private static Material darkMaterial;
    private static Material cyanMaterial;
    private static Material yellowMaterial;
    private static Material redMaterial;
    private static Material whiteMaterial;

    private void Awake()
    {
        PrepareComponents();
        closureWarningBlock = new MaterialPropertyBlock();
    }

    private void OnValidate() => PrepareComponents();

    private void LateUpdate()
    {
        if (
            closureWarningRenderer == null ||
            generatedClosureVisual == null ||
            !generatedClosureVisual.activeInHierarchy
        )
            return;

        if (closureWarningBlock == null)
            closureWarningBlock = new MaterialPropertyBlock();

        float pulse = 0.72f + 0.28f * Mathf.Abs(Mathf.Sin(Time.time * 6.5f));
        Color warningColor = new Color(1f, 0.035f, 0.06f, 1f) * pulse;

        closureWarningRenderer.GetPropertyBlock(closureWarningBlock);
        closureWarningBlock.SetColor(BaseColorId, warningColor);
        closureWarningBlock.SetColor(ColorId, warningColor);
        closureWarningBlock.SetColor(EmissionColorId, warningColor * 2f);
        closureWarningRenderer.SetPropertyBlock(closureWarningBlock);
    }

    public void Configure(RunnerObstacleType obstacleType)
    {
        if (obstacleCollider == null) obstacleCollider = GetComponent<BoxCollider>();
        if (obstacleCollider == null) return;
        HideLegacyVisuals();
        SetGeneratedRootsActive(false);

        switch (obstacleType)
        {
            case RunnerObstacleType.Jump:
                ConfigureJumpObstacle();
                obstacleCollider.center = jumpColliderCenter;
                obstacleCollider.size = jumpColliderSize;
                gameObject.name = "JumpObstacle_NeonBarrier";
                break;
            case RunnerObstacleType.Slide:
                ConfigureSlideObstacle();
                obstacleCollider.center = slideColliderCenter;
                obstacleCollider.size = slideColliderSize;
                gameObject.name = "SlideObstacle_NeonGate";
                break;
            default:
                ConfigureFullLaneClosure();
                obstacleCollider.center = new Vector3(0f, 1.3f, 0f);
                obstacleCollider.size = new Vector3(2.3f, 2.6f, 1.35f);
                gameObject.name = "Obstacle_FullLaneClosure";
                break;
        }

        var district = GetComponent<CourierDistrictObstacle>() ?? gameObject.AddComponent<CourierDistrictObstacle>();
        if (district.Apply(obstacleType)) SetGeneratedRootsActive(false);

        obstacleCollider.enabled = true;
        obstacleCollider.isTrigger = false;
    }

    private void ConfigureJumpObstacle()
    {
        if (generatedJumpVisual == null)
        {
            generatedJumpVisual = CreateVisualRoot("GeneratedJumpBarrier");
            generatedVisualRoot = generatedJumpVisual.transform;
            AddBox("Armored base", new Vector3(0f, 0.14f, 0f), new Vector3(1.65f, 0.28f, 0.9f), Dark);
            AddBox("Warning beam", new Vector3(0f, 0.62f, 0f), new Vector3(1.72f, 0.42f, 0.72f), Yellow);
            AddBox("Beam face", new Vector3(0f, 0.64f, -0.37f), new Vector3(1.52f, 0.23f, 0.035f), Dark);
            AddBox("Top cyan edge", new Vector3(0f, 0.88f, 0f), new Vector3(1.8f, 0.07f, 0.78f), Cyan);
            AddBox("Left support", new Vector3(-0.72f, 0.44f, 0f), new Vector3(0.13f, 0.72f, 0.8f), Dark);
            AddBox("Right support", new Vector3(0.72f, 0.44f, 0f), new Vector3(0.13f, 0.72f, 0.8f), Dark);

            for (int index = 0; index < 5; index++)
            {
                float x = -0.58f + index * 0.29f;
                AddBox("Hazard stripe", new Vector3(x, 0.63f, -0.395f), new Vector3(0.08f, 0.22f, 0.035f), White, Quaternion.Euler(0f, 0f, 24f));
            }
        }

        generatedVisualRoot = generatedJumpVisual.transform;
        generatedJumpVisual.SetActive(true);
    }

    private void ConfigureSlideObstacle()
    {
        if (generatedSlideVisual == null)
        {
            generatedSlideVisual = CreateVisualRoot("GeneratedOverheadGate");
            generatedVisualRoot = generatedSlideVisual.transform;
            AddBox("Left gate post", new Vector3(-0.76f, 1.16f, 0f), new Vector3(0.16f, 2.32f, 0.88f), Dark);
            AddBox("Right gate post", new Vector3(0.76f, 1.16f, 0f), new Vector3(0.16f, 2.32f, 0.88f), Dark);
            AddBox("Overhead frame", new Vector3(0f, 1.9f, 0f), new Vector3(1.68f, 0.25f, 0.92f), Dark);
            AddBox("Laser warning face", new Vector3(0f, 1.74f, -0.47f), new Vector3(1.52f, 0.1f, 0.04f), Red);
            AddBox("Cyan top rail", new Vector3(0f, 2.06f, -0.48f), new Vector3(1.68f, 0.08f, 0.05f), Cyan);
            AddBox("Left cyan status", new Vector3(-0.76f, 1.4f, -0.46f), new Vector3(0.12f, 0.32f, 0.05f), Cyan);
            AddBox("Right cyan status", new Vector3(0.76f, 1.4f, -0.46f), new Vector3(0.12f, 0.32f, 0.05f), Cyan);
        }

        generatedVisualRoot = generatedSlideVisual.transform;
        generatedSlideVisual.SetActive(true);
    }

    private void ConfigureFullLaneClosure()
    {
        // This solid shutter blocks the whole lane; it has no jump or slide opening.
        if (generatedClosureVisual == null)
        {
            generatedClosureVisual = CreateVisualRoot("GeneratedFullLaneShutter");
            generatedVisualRoot = generatedClosureVisual.transform;
            AddBox("Shutter shell", new Vector3(0f, 1.25f, 0f), new Vector3(2.28f, 2.5f, 0.95f), Dark);
            closureWarningRenderer = AddBox(
                "Red warning panel",
                new Vector3(0f, 1.35f, -0.5f),
                new Vector3(1.92f, 1.64f, 0.08f),
                Red
            ).GetComponent<Renderer>();
            AddBox("Upper cyan rail", new Vector3(0f, 2.54f, -0.55f), new Vector3(2.3f, 0.11f, 0.1f), Cyan);
            AddBox("Lower cyan rail", new Vector3(0f, 0.12f, -0.55f), new Vector3(2.3f, 0.11f, 0.1f), Cyan);
            AddBox("Left locking post", new Vector3(-1.02f, 1.3f, -0.58f), new Vector3(0.14f, 2.55f, 0.14f), Yellow);
            AddBox("Right locking post", new Vector3(1.02f, 1.3f, -0.58f), new Vector3(0.14f, 2.55f, 0.14f), Yellow);

            for (int index = 0; index < 7; index++)
            {
                float x = -0.78f + index * 0.26f;
                AddBox("Closure hazard mark", new Vector3(x, 1.35f, -0.56f), new Vector3(0.12f, 1.52f, 0.055f), Yellow, Quaternion.Euler(0f, 0f, 18f));
            }

            AddBox("No entry cross horizontal", new Vector3(0f, 1.4f, -0.62f), new Vector3(0.76f, 0.1f, 0.04f), White, Quaternion.Euler(0f, 0f, 45f));
            AddBox("No entry cross vertical", new Vector3(0f, 1.4f, -0.63f), new Vector3(0.76f, 0.1f, 0.04f), White, Quaternion.Euler(0f, 0f, -45f));
        }

        generatedVisualRoot = generatedClosureVisual.transform;
        generatedClosureVisual.SetActive(true);
    }

    private GameObject CreateVisualRoot(string label)
    {
        GameObject visual = new GameObject(label);
        visual.transform.SetParent(transform, false);
        return visual;
    }

    private void SetGeneratedRootsActive(bool active)
    {
        if (generatedJumpVisual != null) generatedJumpVisual.SetActive(active);
        if (generatedSlideVisual != null) generatedSlideVisual.SetActive(active);
        if (generatedClosureVisual != null) generatedClosureVisual.SetActive(active);
    }

    private GameObject AddBox(string label, Vector3 localPosition, Vector3 localScale, Material material, Quaternion? localRotation = null)
    {
        GameObject box = GameObject.CreatePrimitive(PrimitiveType.Cube);
        box.name = label;
        box.transform.SetParent(generatedVisualRoot, false);
        box.transform.localPosition = localPosition;
        box.transform.localRotation = localRotation ?? Quaternion.identity;
        box.transform.localScale = localScale;

        Collider primitiveCollider = box.GetComponent<Collider>();
        if (primitiveCollider != null) primitiveCollider.enabled = false;

        Renderer renderer = box.GetComponent<Renderer>();
        if (renderer != null)
        {
            renderer.sharedMaterial = material;
            renderer.shadowCastingMode = UnityEngine.Rendering.ShadowCastingMode.Off;
            renderer.receiveShadows = false;
        }

        return box;
    }

    private void HideLegacyVisuals()
    {
        if (jumpVisualRoot != null) jumpVisualRoot.SetActive(false);
        if (slideVisualRoot != null) slideVisualRoot.SetActive(false);
    }

    private void PrepareComponents()
    {
        if (obstacleCollider == null) obstacleCollider = GetComponent<BoxCollider>();
        if (obstacleCollider != null) obstacleCollider.isTrigger = false;

        Collider[] childColliders = GetComponentsInChildren<Collider>(true);
        foreach (Collider childCollider in childColliders)
        {
            if (childCollider != null && childCollider != obstacleCollider)
                childCollider.enabled = false;
        }

        Rigidbody[] childBodies = GetComponentsInChildren<Rigidbody>(true);
        foreach (Rigidbody body in childBodies)
        {
            if (body == null) continue;
            body.isKinematic = true;
            body.useGravity = false;
            body.detectCollisions = false;
        }
    }

    private static Material GetMaterial(ref Material cache, Color color, bool emissive)
    {
        if (cache != null) return cache;

        Shader shader = Shader.Find("Universal Render Pipeline/Lit");
        if (shader == null) shader = Shader.Find("Standard");
        if (shader == null) shader = Shader.Find("Unlit/Color");
        cache = new Material(shader) { name = "Neon Courier Generated Obstacle Material" };
        if (cache.HasProperty("_BaseColor")) cache.SetColor("_BaseColor", color);
        if (cache.HasProperty("_Color")) cache.SetColor("_Color", color);
        if (emissive && cache.HasProperty("_EmissionColor"))
        {
            cache.EnableKeyword("_EMISSION");
            cache.SetColor("_EmissionColor", color * 1.8f);
        }
        return cache;
    }

    private static Material Dark => GetMaterial(ref darkMaterial, new Color(0.025f, 0.055f, 0.09f), false);
    private static Material Cyan => GetMaterial(ref cyanMaterial, new Color(0.05f, 0.92f, 1f), true);
    private static Material Yellow => GetMaterial(ref yellowMaterial, new Color(1f, 0.62f, 0.08f), true);
    private static Material Red => GetMaterial(ref redMaterial, new Color(1f, 0.035f, 0.08f), true);
    private static Material White => GetMaterial(ref whiteMaterial, new Color(0.92f, 1f, 1f), true);
}


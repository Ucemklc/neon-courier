using System.Collections;
using UnityEngine;

[DisallowMultipleComponent]
public sealed class NPCDeliveryFeedback : MonoBehaviour
{
    [Header("NPC Animation")]
    [SerializeField]
    private Animator npcAnimator;

    [SerializeField]
    private bool automaticallyFindAnimator = true;

    [SerializeField]
    private string receiveTriggerName = "Receive";

    [SerializeField] private DeliveryReceiverVisual receiverVisual;

    [Header("Received Package")]
    [SerializeField]
    private GameObject receivedPackageVisual;

    [SerializeField, Min(0.05f)]
    private float packageVisibleDuration = 1.25f;

    [Header("Optional Effects")]
    [SerializeField]
    private ParticleSystem deliveryParticle;

    [SerializeField]
    private AudioSource audioSource;

    [SerializeField]
    private AudioClip deliverySound;

    [Header("Behaviour")]
    [SerializeField]
    private bool requireDeliveredPackage = true;

    [Header("Debug")]
    [SerializeField]
    private bool debugLogs = false;

    private Coroutine feedbackCoroutine;
    private int receiveTriggerHash;

    private bool animatorWarningShown;
    private bool triggerWarningShown;

    private void Awake()
    {
        CacheTriggerHash();
        ResolveAnimator();

        HideReceivedPackage();
        StopDeliveryParticle();
    }

    private void OnEnable()
    {
        CacheTriggerHash();
        ResolveAnimator();

        StopFeedbackCoroutine();
        if (receiverVisual != null) receiverVisual.ResetPose();
        HideReceivedPackage();
        StopDeliveryParticle();
    }

    private void OnDisable()
    {
        StopFeedbackCoroutine();
        if (receiverVisual != null) receiverVisual.ResetPose();
        HideReceivedPackage();
        StopDeliveryParticle();
    }

    public void PlayDeliveryFeedback(
        int deliveredPackageCount
    )
    {
        if (
            requireDeliveredPackage &&
            deliveredPackageCount <= 0
        )
        {
            return;
        }

        if (!gameObject.activeInHierarchy)
        {
            return;
        }

        StopFeedbackCoroutine();
        if (receiverVisual != null) receiverVisual.ResetPose();

        feedbackCoroutine =
            StartCoroutine(
                DeliveryFeedbackRoutine(
                    deliveredPackageCount
                )
            );
    }

    public void ResetFeedback()
    {
        /*
         * Burada Animator triggerı sıfırlamıyoruz.
         * Prefab oluşturulurken Animator henüz
         * initialize edilmemiş olabilir.
         */
        StopFeedbackCoroutine();
        if (receiverVisual != null) receiverVisual.ResetPose();
        HideReceivedPackage();
        StopDeliveryParticle();
    }

    [ContextMenu("Test Delivery Feedback")]
    private void TestDeliveryFeedback()
    {
        PlayDeliveryFeedback(1);
    }

    private IEnumerator DeliveryFeedbackRoutine(
        int deliveredPackageCount
    )
    {
        /*
         * GameObject yeni açılmışsa Animator'ın
         * hazırlanması için bir kare bekliyoruz.
         */
        yield return null;

        if (receiverVisual != null) receiverVisual.Receive(packageVisibleDuration);
        else TriggerReceiveAnimation();
        ShowReceivedPackage();
        PlayDeliveryParticle();
        PlayDeliverySound();

        if (debugLogs)
        {
            Debug.Log(
                $"NPC teslimat geri bildirimi oynatıldı. " +
                $"Teslim edilen paket: {deliveredPackageCount}",
                this
            );
        }

        yield return
            new WaitForSecondsRealtime(
                packageVisibleDuration
            );

        HideReceivedPackage();

        feedbackCoroutine = null;
    }

    private void TriggerReceiveAnimation()
    {
        if (!PrepareAnimator())
        {
            return;
        }

        if (!HasTriggerParameter(
                receiveTriggerHash
            ))
        {
            ShowMissingTriggerWarning();
            return;
        }

        /*
         * ResetTrigger kullanılmıyor.
         * Trigger yalnızca teslimat anında gönderiliyor.
         */
        npcAnimator.SetTrigger(
            receiveTriggerHash
        );

        triggerWarningShown = false;
    }

    private bool PrepareAnimator()
    {
        ResolveAnimator();

        if (
            npcAnimator == null ||
            npcAnimator.runtimeAnimatorController == null
        )
        {
            ShowMissingAnimatorControllerWarning();
            return false;
        }

        if (
            !npcAnimator.enabled ||
            !npcAnimator.gameObject.activeInHierarchy
        )
        {
            return false;
        }

        /*
         * Animator henüz hazır değilse
         * controller ve avatar bağlantısını yeniden kurar.
         */
        if (!npcAnimator.isInitialized)
        {
            npcAnimator.Rebind();
            npcAnimator.Update(0f);
        }

        if (!npcAnimator.isInitialized)
        {
            ShowAnimatorNotInitializedWarning();
            return false;
        }

        animatorWarningShown = false;

        return true;
    }

    private bool HasTriggerParameter(
        int parameterHash
    )
    {
        if (
            npcAnimator == null ||
            npcAnimator.runtimeAnimatorController == null ||
            parameterHash == 0
        )
        {
            return false;
        }

        AnimatorControllerParameter[] parameters =
            npcAnimator.parameters;

        for (
            int index = 0;
            index < parameters.Length;
            index++
        )
        {
            AnimatorControllerParameter parameter =
                parameters[index];

            if (
                parameter.nameHash ==
                parameterHash &&
                parameter.type ==
                AnimatorControllerParameterType
                    .Trigger
            )
            {
                return true;
            }
        }

        return false;
    }

    private void ResolveAnimator()
    {
        if (
            npcAnimator != null &&
            npcAnimator.runtimeAnimatorController != null
        )
        {
            return;
        }

        if (!automaticallyFindAnimator)
        {
            return;
        }

        Animator[] animators =
            GetComponentsInChildren<Animator>(
                true
            );

        /*
         * Önce controller bağlı Animator aranır.
         */
        for (
            int index = 0;
            index < animators.Length;
            index++
        )
        {
            Animator candidate =
                animators[index];

            if (
                candidate != null &&
                candidate.runtimeAnimatorController != null
            )
            {
                npcAnimator = candidate;
                return;
            }
        }

        /*
         * Controller bağlı olan bulunamazsa
         * Inspector'da görülebilmesi için ilk Animator tutulur.
         */
        if (
            npcAnimator == null &&
            animators.Length > 0
        )
        {
            npcAnimator = animators[0];
        }
    }

    private void ShowMissingAnimatorControllerWarning()
    {
        if (
            animatorWarningShown ||
            !debugLogs
        )
        {
            return;
        }

        animatorWarningShown = true;

        Debug.LogWarning(
            "NPCDeliveryFeedback: NPC Animator bulunamadı " +
            "veya Animator Controller bağlı değil. " +
            "DeliveryNPC üzerindeki Animator'a " +
            "AC_NPC_Delivery bağla.",
            this
        );
    }

    private void ShowAnimatorNotInitializedWarning()
    {
        if (
            animatorWarningShown ||
            !debugLogs
        )
        {
            return;
        }

        animatorWarningShown = true;

        Debug.LogWarning(
            "NPCDeliveryFeedback: Animator henüz " +
            "başarıyla initialize edilmedi. " +
            "Controller ve Avatar bağlantısını kontrol et.",
            this
        );
    }

    private void ShowMissingTriggerWarning()
    {
        if (
            triggerWarningShown ||
            !debugLogs
        )
        {
            return;
        }

        triggerWarningShown = true;

        Debug.LogWarning(
            $"NPCDeliveryFeedback: Animator Controller içinde " +
            $"'{receiveTriggerName}' isimli Trigger bulunamadı.",
            this
        );
    }

    private void ShowReceivedPackage()
    {
        if (receivedPackageVisual == null)
        {
            return;
        }

        receivedPackageVisual.SetActive(true);
    }

    private void HideReceivedPackage()
    {
        if (receivedPackageVisual == null)
        {
            return;
        }

        receivedPackageVisual.SetActive(false);
    }

    private void PlayDeliveryParticle()
    {
        if (deliveryParticle == null)
        {
            return;
        }

        deliveryParticle.Stop(
            true,
            ParticleSystemStopBehavior
                .StopEmittingAndClear
        );

        deliveryParticle.Play(true);
    }

    private void StopDeliveryParticle()
    {
        if (deliveryParticle == null)
        {
            return;
        }

        deliveryParticle.Stop(
            true,
            ParticleSystemStopBehavior
                .StopEmittingAndClear
        );
    }

    private void PlayDeliverySound()
    {
        if (
            audioSource == null ||
            deliverySound == null
        )
        {
            return;
        }

        audioSource.PlayOneShot(
            deliverySound
        );
    }

    private void StopFeedbackCoroutine()
    {
        if (feedbackCoroutine == null)
        {
            return;
        }

        StopCoroutine(
            feedbackCoroutine
        );

        feedbackCoroutine = null;
    }

    private void CacheTriggerHash()
    {
        if (
            string.IsNullOrWhiteSpace(
                receiveTriggerName
            )
        )
        {
            receiveTriggerHash = 0;
            return;
        }

        receiveTriggerHash =
            Animator.StringToHash(
                receiveTriggerName
            );
    }

    private void OnValidate()
    {
        packageVisibleDuration =
            Mathf.Max(
                0.05f,
                packageVisibleDuration
            );

        if (
            string.IsNullOrWhiteSpace(
                receiveTriggerName
            )
        )
        {
            receiveTriggerName =
                "Receive";
        }

        CacheTriggerHash();
    }
}
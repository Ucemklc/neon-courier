using TMPro;
using UnityEngine;
using UnityEngine.UI;

/// <summary>The visible card and its pointer target share one RectTransform.</summary>
[DisallowMultipleComponent]
public sealed class CourierMenuButton : MonoBehaviour
{
    public void Style(bool primary)
    {
        var button=GetComponent<Button>(); var image=GetComponent<Image>();
        image.sprite=Resources.Load<Sprite>("CourierPolish/MenuCard"); image.type=Image.Type.Sliced;
        image.enabled=true;image.color=Color.white; image.raycastTarget=true; image.raycastPadding=Vector4.zero;
        button.targetGraphic=image;
        var colors=ColorBlock.defaultColorBlock;
        colors.normalColor=primary?new Color(1,.36f,.08f):new Color(.07f,.17f,.24f);
        colors.highlightedColor=primary?new Color(1,.53f,.18f):new Color(.11f,.32f,.40f);
        colors.selectedColor=colors.normalColor; colors.pressedColor=primary?new Color(.8f,.23f,.025f):new Color(.025f,.55f,.65f);
        colors.disabledColor=new Color(.12f,.20f,.27f);colors.fadeDuration=.075f; button.colors=colors;button.transition=Selectable.Transition.ColorTint;
        var legacy=GetComponentsInChildren<Text>(true);
        if(GetComponentsInChildren<TMP_Text>(true).Length==0)
        {
            var go=new GameObject("CourierButtonLabel",typeof(RectTransform),typeof(TextMeshProUGUI));go.transform.SetParent(transform,false);
            go.GetComponent<TMP_Text>().text=legacy.Length>0?legacy[0].text:"";
        }
        foreach(var text in legacy)text.enabled=false;
        foreach(var graphic in GetComponentsInChildren<Graphic>(true))if(graphic!=image)graphic.raycastTarget=false;
        foreach(var text in GetComponentsInChildren<TMP_Text>(true))
        {
            text.gameObject.SetActive(true);text.enabled=true;
            var r=text.rectTransform;r.localScale=Vector3.one;r.localRotation=Quaternion.identity;
            r.pivot=new Vector2(.5f,.5f);r.anchorMin=Vector2.zero;r.anchorMax=Vector2.one;r.offsetMin=new Vector2(34,12);r.offsetMax=new Vector2(-34,-12);
            text.font=TMP_Settings.defaultFontAsset;text.fontSharedMaterial=text.font.material;
            text.fontSize=primary?56:44;text.fontStyle=FontStyles.Bold;text.color=Color.white;
            text.margin=Vector4.zero;text.alignment=TextAlignmentOptions.Center;text.enableAutoSizing=false;text.outlineWidth=0;
        }
    }
}

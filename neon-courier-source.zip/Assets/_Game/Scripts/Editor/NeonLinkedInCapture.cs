#if UNITY_EDITOR
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using UnityEditor;
using UnityEngine;
using UnityEngine.SceneManagement;

// Opt-in recording of the current scene; no scene or prefab asset is changed.
[InitializeOnLoad]
public static class NeonLinkedInCapture
{
    private const string Request = "Temp/NeonLinkedInCapture.request";
    private const string StateKey = "NeonLinkedInCapture.Settings";
    private const BindingFlags Hidden = BindingFlags.Instance | BindingFlags.NonPublic;
    private static double next;
    private static bool active, background;
    private static int oldCaptureRate, frames, width, height;
    private static float oldVolume;
    private static DateTime lastFrame;
    private static Settings settings;
    private static GameManager manager;
    private static RunnerController runner;
    private static Texture2D texture;
    private static byte[] pixels;
    private static System.Diagnostics.Process encoder;
    private static readonly StringBuilder encoderLog = new StringBuilder();
    [Serializable] private class Settings { public string output, encoder; public int seconds = 42; }
    [Serializable] private class PrefEntry { public string key, text; public bool exists, isText; public int number; }
    [Serializable] private class PrefSnapshot { public List<PrefEntry> entries; }
    static NeonLinkedInCapture() {
        EditorApplication.update += Tick;
        EditorApplication.playModeStateChanged += Changed;
    }
    private static void Log(string message) {
        if (settings != null) File.AppendAllText(Path.Combine(settings.output, "Capture-report.txt"), DateTime.UtcNow.ToString("s") + " " + message + "\n");
    }
    private static void Tick()
    {
        if (!active && !File.Exists(Request) && string.IsNullOrEmpty(SessionState.GetString(StateKey, ""))) return;
        if (EditorApplication.timeSinceStartup < next) return;
        next = EditorApplication.timeSinceStartup + 2;
        if (!Directory.Exists("Temp")) return;
        var scene = SceneManager.GetActiveScene();
        File.WriteAllText("Temp/NeonLinkedInCapture.status", JsonUtility.ToJson(new Status {
            utc = DateTime.UtcNow.ToString("o"), project = Application.dataPath,
            scene = scene.path, playing = EditorApplication.isPlaying,
            compiling = EditorApplication.isCompiling, width = Screen.width, height = Screen.height,
            hasGame = UnityEngine.Object.FindFirstObjectByType<GameManager>() != null
        }, true));
        if (active) {
            if (DateTime.UtcNow - lastFrame > TimeSpan.FromSeconds(90)) Finish("FAIL: capture stalled for 90 seconds");
            return;
        }
        if (EditorApplication.isCompiling || EditorApplication.isUpdating) return;
        if (File.Exists(Request)) {
            if (DateTime.UtcNow - File.GetLastWriteTimeUtc(Request) > TimeSpan.FromMinutes(10)) return;
            settings = JsonUtility.FromJson<Settings>(File.ReadAllText(Request));
            File.Delete(Request);
            if (!Path.IsPathRooted(settings.output) || !File.Exists(settings.encoder)) throw new InvalidOperationException("Invalid capture paths");
            Directory.CreateDirectory(settings.output);
            if (!string.IsNullOrEmpty(SessionState.GetString("CourierPolish.Prefs", ""))) { Log("FAIL: another editor check is active"); return; }
            CourierPolishPreferences.Capture();
            File.WriteAllText(Path.Combine(settings.output, "Preferences-before.json"), SessionState.GetString("CourierPolish.Prefs", ""));
            PlayerPrefs.SetInt("NeonCourier_StoryIntro_Seen_v1", 1);
            PlayerPrefs.SetInt("NeonCourier.TutorialCompleted", 1);
            PlayerPrefs.SetInt("NeonCourier.Language", 0);
            PlayerPrefs.SetInt("NeonCourier.SelectedCharacter", 0);
            SessionState.SetString(StateKey, JsonUtility.ToJson(settings));
            if (!EditorApplication.isPlaying) { Log("Entering Play mode for recording"); EditorApplication.EnterPlaymode(); return; }
        }
        string pending = SessionState.GetString(StateKey, "");
        if (EditorApplication.isPlaying && !string.IsNullOrEmpty(pending)) {
            settings = JsonUtility.FromJson<Settings>(pending);
            manager = UnityEngine.Object.FindFirstObjectByType<GameManager>();
            runner = UnityEngine.Object.FindFirstObjectByType<RunnerController>();
            if (!manager || !runner) return;
            SessionState.EraseString(StateKey);
            active = true; frames = 0; lastFrame = DateTime.UtcNow;
            background = Application.runInBackground; oldCaptureRate = Time.captureFramerate; oldVolume = AudioListener.volume;
            Application.runInBackground = true; Time.captureFramerate = 30; AudioListener.volume = 0;
            manager.StartCoroutine(SafeRun());
        }
    }
    private static IEnumerator SafeRun() {
        var stack = new Stack<IEnumerator>(); stack.Push(Sequence());
        while (active && stack.Count > 0) {
            bool more = false; object nextItem = null; Exception error = null;
            try { more = stack.Peek().MoveNext(); if (more) nextItem = stack.Peek().Current; }
            catch (Exception e) { error = e; }
            if (error != null) { Finish("FAIL: " + error); yield break; }
            if (!more) { (stack.Pop() as IDisposable)?.Dispose(); continue; }
            if (nextItem is IEnumerator nested) stack.Push(nested); else yield return nextItem;
        }
        if (active) Finish("PASS: recorded " + frames + " actual game frames at " + width + "x" + height + ", 30 fps");
    }
    private static IEnumerator Sequence() {
        foreach (var intro in UnityEngine.Object.FindObjectsByType<StoryIntroController>(FindObjectsSortMode.None)) intro.enabled = false;
        foreach (var tutorial in UnityEngine.Object.FindObjectsByType<TutorialController>(FindObjectsSortMode.None)) tutorial.enabled = false;
        var introCanvas = GameObject.Find("StoryIntroCanvas"); if (introCanvas) introCanvas.SetActive(false);
        var selection = UnityEngine.Object.FindFirstObjectByType<CharacterSelectionManager>();
        if (selection) selection.SelectCharacter(0);
        manager.OpenMainMenu();
        for (int i = 0; i < 8; i++) yield return new WaitForEndOfFrame();
        width = Screen.width; height = Screen.height;
        if (width < 360 || height < width) throw new InvalidOperationException("Select a portrait Game view (9:16). Current render: " + width + "x" + height);
        texture = new Texture2D(width, height, TextureFormat.RGB24, false);
        pixels = new byte[width*height*3];
        var start = new System.Diagnostics.ProcessStartInfo(settings.encoder,
            "-y -hide_banner -loglevel warning -f rawvideo -pixel_format rgb24 -video_size " + width + "x" + height + " -framerate 30 -i pipe:0 -an -vf vflip -c:v libx264 -preset ultrafast -crf 17 -pix_fmt yuv420p -movflags +faststart \"" + Path.Combine(settings.output,"NeonCourier-raw.mp4") + "\"")
            { UseShellExecute=false, CreateNoWindow=true, WindowStyle=System.Diagnostics.ProcessWindowStyle.Hidden, RedirectStandardInput=true, RedirectStandardError=true };
        encoderLog.Clear(); encoder = new System.Diagnostics.Process { StartInfo=start };
        encoder.ErrorDataReceived += (s,e) => { if(e.Data!=null) lock(encoderLog) encoderLog.AppendLine(e.Data); };
        encoder.Start(); encoder.BeginErrorReadLine();
        yield return Record(90, false);
        manager.StartGameFromMenu();
        double limit = EditorApplication.timeSinceStartup + 15;
        while (!manager.IsRunActive) { if (EditorApplication.timeSinceStartup>limit) throw new TimeoutException("Game did not start"); yield return null; }
        yield return Record(Mathf.Clamp(settings.seconds,12,60)*30, true);
        encoder.StandardInput.Close();
        if (!encoder.WaitForExit(30000) || encoder.ExitCode!=0) throw new IOException("Video encoder failed: " + encoderLog);
        encoder.Dispose(); encoder=null;
        File.WriteAllText(Path.Combine(settings.output,"Encoder-log.txt"),encoderLog.ToString());
    }
    private static IEnumerator Record(int count, bool play) {
        var power = runner.GetComponent<PowerUpController>();
        for (int i = 0; i < count; i++) {
            if (play) {
                if (manager.IsGameOver) throw new InvalidOperationException("Run ended at captured frame " + frames);
                if (i % 6 == 0) Guide();
                if (i == 240 && power) power.ActivatePowerUp(PowerUpType.Magnet);
                if (i == 540 && power) power.ActivatePowerUp(PowerUpType.Hoverboard);
                if (i == 840 && power) power.ActivatePowerUp(PowerUpType.Shield);
                var delivery = manager.GetComponent<CourierTimedDelivery>();
                if (delivery && delivery.CanThrow && i%6==0) delivery.TryThrow();
            }
            yield return new WaitForEndOfFrame();
            if (Screen.width!=width || Screen.height!=height) throw new InvalidOperationException("Game render dimensions changed during capture");
            texture.ReadPixels(new Rect(0,0,width,height),0,0,false);
            texture.GetRawTextureData<byte>().CopyTo(pixels);
            encoder.StandardInput.BaseStream.Write(pixels,0,pixels.Length); frames++; lastFrame=DateTime.UtcNow;
            if (frames==60 || frames==240 || frames==570 || frames==750 || frames==1020)
                File.WriteAllBytes(Path.Combine(settings.output,"Frame-"+frames.ToString("D4")+".png"),texture.EncodeToPNG());
            if (frames%150==0) Log("FRAME " + frames + " distance=" + manager.DistanceMeters + " lives=" + manager.CurrentLives);
        }
    }
    private static void Guide() {
        var origin=runner.transform.position;
        float[] danger={60,60,60};
        foreach(var col in Physics.OverlapBox(origin+Vector3.forward*18, new Vector3(5,4,20),Quaternion.identity,~0,QueryTriggerInteraction.Ignore)) {
            if(!col || !(col.CompareTag("Obstacle") || col.GetComponentInParent<RailRideSurface>())) continue;
            var b=col.bounds; float dz=b.min.z-origin.z;
            if(dz < -1 || b.max.y < origin.y-.5f || b.min.y>origin.y+2f) continue;
            for(int lane=0;lane<3;lane++) { float x=(lane-1)*runner.LaneDistance; if(x>=b.min.x-.6f&&x<=b.max.x+.6f) danger[lane]=Mathf.Min(danger[lane],dz); }
        }
        int current=runner.CurrentLane, best=current;
        for(int lane=0;lane<3;lane++) if(danger[lane]>danger[best]+2) best=lane;
        if(danger[current]<13 && best!=current) Call(runner,best<current?"MoveLeft":"MoveRight");
        else if(danger[current]<runner.CurrentForwardSpeed*.65f && danger[current]>0 && runner.IsGrounded) Call(runner,"TryJump");
    }
    private static void Call(object target,string method) { target.GetType().GetMethod(method,Hidden).Invoke(target,null); }
    private static void Finish(string result) {
        if (!active) return; active=false; Log(result);
        if (encoder!=null) {
            try { encoder.StandardInput.Close(); if(!encoder.WaitForExit(3000)) encoder.Kill(); } catch {}
            encoder.Dispose(); encoder=null;
        }
        if(texture) UnityEngine.Object.Destroy(texture); texture=null; pixels=null;
        Application.runInBackground=background; Time.captureFramerate=oldCaptureRate; AudioListener.volume=oldVolume;
        SessionState.EraseString(StateKey);
        SessionState.SetString("NeonLinkedInCapture.Verify",settings.output);
        EditorApplication.isPlaying=false;
    }
    private static void Changed(PlayModeStateChange state) {
        if(state==PlayModeStateChange.ExitingPlayMode && active) Finish("INTERRUPTED: left Play mode");
        if(state!=PlayModeStateChange.EnteredEditMode) return;
        string output=SessionState.GetString("NeonLinkedInCapture.Verify",""); if(string.IsNullOrEmpty(output))return;
        SessionState.EraseString("NeonLinkedInCapture.Verify");
        EditorApplication.delayCall+=()=>{
            var snapshot=JsonUtility.FromJson<PrefSnapshot>(File.ReadAllText(Path.Combine(output,"Preferences-before.json")));
            bool equal=snapshot.entries.All(e=>PlayerPrefs.HasKey(e.key)==e.exists && (!e.exists || (e.isText?PlayerPrefs.GetString(e.key)==e.text:PlayerPrefs.GetInt(e.key)==e.number)));
            File.AppendAllText(Path.Combine(output,"Capture-report.txt"),(equal?"PASS":"FAIL")+": original saved preferences restored\n");
        };
    }
    [Serializable] private class Status {
        public string utc, project, scene;
        public bool playing, compiling, hasGame;
        public int width, height;
    }
}
#endif

using System.Collections.Generic;
using UnityEngine;

[DisallowMultipleComponent]
public sealed class AirCoinRouteGenerator :
    MonoBehaviour
{
    [Header("Coin Prefab")]
    [Tooltip(
        "AirCoinPickup bulunan PF_AirCoin prefabını bağla."
    )]
    [SerializeField]
    private GameObject airCoinPrefab;

    [Header("Full Three-Lane Route")]
    [Tooltip(
        "Toplam havada altın sayısı. " +
        "24 değeri üç şeritte sekiz sıra oluşturur."
    )]
    [SerializeField, Min(3)]
    private int coinCount = 24;

    [SerializeField, Min(0.1f)]
    private float laneDistance = 2.5f;

    [SerializeField]
    private float startZ = 1.5f;

    [SerializeField]
    private float endZ = 25.5f;

    [SerializeField]
    private float baseHeight = 2.05f;

    [SerializeField, Min(0f)]
    private float heightWave = 0.15f;

    [Tooltip(
        "Aynı sıradaki altınların tamamen düz görünmemesi için küçük Z farkı."
    )]
    [SerializeField, Min(0f)]
    private float laneZOffset = 0.18f;

    [Header("Route Availability")]
    [Tooltip(
        "1 değerinde her Track Tile havada altın rotasına sahip olur."
    )]
    [SerializeField, Range(0f, 1f)]
    private float routeSpawnChance = 1f;

    [Tooltip(
        "Açıksa altın rotası yalnızca Hoverboard aktifken görünür."
    )]
    [SerializeField]
    private bool onlyVisibleDuringHoverboard = true;

    [Header("Tile Recycling")]
    [Tooltip(
        "Tile başka bir Z konumuna taşındığında altınları yeniden hazırlar."
    )]
    [SerializeField]
    private bool regenerateWhenTileMoves = true;

    [SerializeField, Min(0.1f)]
    private float recycleDetectionDistance = 5f;

    [Header("Debug")]
    [SerializeField]
    private bool logGeneration;

    private readonly List<AirCoinPickup>
        coinPool =
            new List<AirCoinPickup>(32);

    private Transform coinRoot;

    private NeonRailSection railSection;
    private CourierAlternateRoute alternateRoute;

    private PowerUpController
        powerUpController;

    private bool powerUpEventSubscribed;
    private bool routeAvailable;
    private bool hasGenerated;

    private float lastGeneratedWorldZ;

    private void Awake()
    {
        EnsureCoinRoot();
        EnsureCoinPool();
    }

    private void OnEnable()
    {
        EnsureCoinRoot();
        EnsureCoinPool();

        GenerateRoute();
    }

    private void Start()
    {
        ResolvePowerUpController();
        SubscribeToPowerUpEvents();

        RefreshRouteVisibility();
    }

    private void LateUpdate()
    {
        if (powerUpController == null)
        {
            ResolvePowerUpController();
            SubscribeToPowerUpEvents();
            RefreshRouteVisibility();
        }

        if (
            !regenerateWhenTileMoves ||
            !hasGenerated
        )
        {
            return;
        }

        float travelledDistance =
            Mathf.Abs(
                transform.position.z -
                lastGeneratedWorldZ
            );

        if (
            travelledDistance <
            recycleDetectionDistance
        )
        {
            return;
        }

        GenerateRoute();
    }

    private void OnDisable()
    {
        UnsubscribeFromPowerUpEvents();
    }

    private void OnDestroy()
    {
        UnsubscribeFromPowerUpEvents();
    }

    private void EnsureCoinRoot()
    {
        if (coinRoot != null)
        {
            return;
        }

        Transform existingRoot =
            transform.Find(
                "AirCoinRouteRoot"
            );

        if (existingRoot != null)
        {
            coinRoot = existingRoot;
            return;
        }

        GameObject rootObject =
            new GameObject(
                "AirCoinRouteRoot"
            );

        coinRoot =
            rootObject.transform;

        coinRoot.SetParent(
            transform,
            false
        );

        coinRoot.localPosition =
            Vector3.zero;

        coinRoot.localRotation =
            Quaternion.identity;

        coinRoot.localScale =
            Vector3.one;
    }

    private void EnsureCoinPool()
    {
        if (airCoinPrefab == null)
        {
            return;
        }

        EnsureCoinRoot();

        int requiredCoinCount =
            Mathf.Max(
                3,
                coinCount
            );

        while (
            coinPool.Count <
            requiredCoinCount
        )
        {
            int coinIndex =
                coinPool.Count;

            GameObject coinObject =
                Instantiate(
                    airCoinPrefab,
                    coinRoot,
                    false
                );

            coinObject.name =
                $"AirCoin_{coinIndex:00}";

            AirCoinPickup coinPickup =
                coinObject.GetComponent
                    <AirCoinPickup>();

            if (coinPickup == null)
            {
                Debug.LogError(
                    "AirCoinRouteGenerator: " +
                    "PF_AirCoin kökünde " +
                    "AirCoinPickup bulunamadı.",
                    coinObject
                );

                Destroy(coinObject);
                return;
            }

            coinObject.SetActive(false);

            coinPool.Add(
                coinPickup
            );
        }
    }

    /// <summary>
    /// Refresh after TrackTileContent has selected and positioned its rail route.
    /// This also restores ordinary coin heights when a recycled tile has no train.
    /// </summary>
    public void RefreshForRailRoute()
    {
        EnsureCoinRoot();
        GenerateRoute();
    }

    private void GenerateRoute()
    {
        if (!alternateRoute) alternateRoute = GetComponent<CourierAlternateRoute>();
        if (railSection == null)
        {
            railSection = GetComponent<NeonRailSection>();
        }

        lastGeneratedWorldZ =
            transform.position.z;

        hasGenerated = true;

        if (airCoinPrefab == null)
        {
            routeAvailable = false;

            Debug.LogWarning(
                "AirCoinRouteGenerator: " +
                "Air Coin Prefab bağlantısı boş.",
                this
            );

            RefreshRouteVisibility();
            return;
        }

        EnsureCoinPool();

        routeAvailable =
            Random.value <=
            routeSpawnChance;

        if (!routeAvailable)
        {
            RefreshRouteVisibility();
            return;
        }

        if (coinRoot != null)
        {
            /*
             * Coinler hazırlanırken görünmesin.
             * Çocukların activeSelf durumları korunur.
             */
            coinRoot.gameObject.SetActive(
                false
            );
        }

        int activeCoinCount =
            Mathf.Min(
                coinCount,
                coinPool.Count
            );

        int rowCount =
            Mathf.CeilToInt(
                activeCoinCount /
                3f
            );

        rowCount =
            Mathf.Max(
                1,
                rowCount
            );

        for (
            int coinIndex = 0;
            coinIndex < coinPool.Count;
            coinIndex++
        )
        {
            AirCoinPickup coin =
                coinPool[coinIndex];

            if (coin == null)
            {
                continue;
            }

            if (
                coinIndex >=
                activeCoinCount
            )
            {
                coin.gameObject.SetActive(
                    false
                );

                continue;
            }

            int row =
                coinIndex / 3;

            int lane =
                coinIndex % 3;

            float rowProgress =
                rowCount <= 1
                    ? 0f
                    : row /
                        (float)(
                            rowCount - 1
                        );

            float coinZ =
                Mathf.Lerp(
                    startZ,
                    endZ,
                    rowProgress
                );

            coinZ +=
                (lane - 1) *
                laneZOffset;

            float coinX =
                (lane - 1) *
                laneDistance;

            float wavePhase =
                row * 0.85f +
                lane * 0.60f;

            float coinY =
                baseHeight +
                Mathf.Sin(
                    wavePhase
                ) * heightWave;

            // The route provider checks only active trains in this lane, and
            // includes ramp slopes. Keep the existing hoverboard clearance and
            // wave above that surface; open lanes retain their original height.
            if (railSection != null)
            {
                coinY += railSection.GetRideHeightAt(coinX, coinZ);
            }
            if (alternateRoute != null) coinY += alternateRoute.GetRideHeightAt(coinX, coinZ);

            coin.transform.localPosition =
                new Vector3(
                    coinX,
                    coinY,
                    coinZ
                );

            Vector3 localEulerAngles =
                coin.transform
                    .localEulerAngles;

            localEulerAngles.y =
                Random.Range(
                    0f,
                    360f
                );

            coin.transform
                .localEulerAngles =
                localEulerAngles;

            // ResetCoin caches this new position as its bobbing origin, including
            // when the pooled pickup is currently hidden by the hoverboard gate.
            coin.ResetCoin();
        }

        RefreshRouteVisibility();

        if (logGeneration)
        {
            Debug.Log(
                $"AirCoinRouteGenerator | " +
                $"Coin: {activeCoinCount} | " +
                $"Satır: {rowCount} | " +
                $"Tile Z: {transform.position.z}",
                this
            );
        }
    }

    private void ResolvePowerUpController()
    {
        if (powerUpController != null)
        {
            return;
        }

        powerUpController =
            PowerUpController.Instance;

        if (powerUpController != null)
        {
            return;
        }

        powerUpController =
            FindAnyObjectByType
                <PowerUpController>();
    }

    private void SubscribeToPowerUpEvents()
    {
        if (
            powerUpEventSubscribed ||
            powerUpController == null
        )
        {
            return;
        }

        powerUpController
            .PowerUpStateChanged +=
                HandlePowerUpStateChanged;

        powerUpEventSubscribed = true;
    }

    private void UnsubscribeFromPowerUpEvents()
    {
        if (
            !powerUpEventSubscribed ||
            powerUpController == null
        )
        {
            powerUpEventSubscribed = false;
            return;
        }

        powerUpController
            .PowerUpStateChanged -=
                HandlePowerUpStateChanged;

        powerUpEventSubscribed = false;
    }

    private void HandlePowerUpStateChanged()
    {
        RefreshRouteVisibility();
    }

    private void RefreshRouteVisibility()
    {
        if (coinRoot == null)
        {
            return;
        }

        bool hoverboardActive =
            powerUpController != null &&
            powerUpController
                .IsHoverboardActive;

        bool shouldShowRoute =
            routeAvailable &&
            (
                !onlyVisibleDuringHoverboard ||
                hoverboardActive
            );

        coinRoot.gameObject.SetActive(
            shouldShowRoute
        );
    }

    private void OnValidate()
    {
        coinCount =
            Mathf.Max(
                3,
                coinCount
            );

        laneDistance =
            Mathf.Max(
                0.1f,
                laneDistance
            );

        heightWave =
            Mathf.Max(
                0f,
                heightWave
            );

        laneZOffset =
            Mathf.Max(
                0f,
                laneZOffset
            );

        routeSpawnChance =
            Mathf.Clamp01(
                routeSpawnChance
            );

        recycleDetectionDistance =
            Mathf.Max(
                0.1f,
                recycleDetectionDistance
            );

        if (endZ < startZ)
        {
            float temporaryZ =
                startZ;

            startZ =
                endZ;

            endZ =
                temporaryZ;
        }
    }
}

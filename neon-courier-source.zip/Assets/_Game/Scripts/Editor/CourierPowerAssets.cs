#if UNITY_EDITOR
using System.IO;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.SceneManagement;
using Object=UnityEngine.Object;

public static class CourierPowerAssets
{
    private const string Folder="Assets/Resources/CourierPowers";
    private static Material navy,slate,cyan,orange,white,gold,pink,blue,glass,trail,boardCyan;
    [MenuItem("Neon Courier/Generate Power Assets")]
    public static void Generate()
    {
        if(EditorApplication.isPlayingOrWillChangePlaymode)return;
        Directory.CreateDirectory(Folder);AssetDatabase.Refresh();
        navy=Load("MidnightShell");slate=Load("BlueSlate");cyan=Load("SignalCyan");orange=Load("SafetyTangerine");white=Load("Porcelain");
        gold=Mat("CourierGold",new Color(1,.66f,.10f),.3f);gold.SetFloat("_Metallic",.75f);gold.SetFloat("_Smoothness",.72f);
        pink=Mat("MagnetCoral",new Color(1,.19f,.48f),.55f);blue=Mat("ArmorBlue",new Color(.12f,.64f,1),.65f);
        boardCyan=Mat("BoardCyan",new Color(.08f,.85f,1),1.8f);
        glass=Mat("ArmorGlass",new Color(.08f,.55f,1,.065f),.1f,true);trail=Mat("PowerTrail",new Color(.1f,.82f,1,.26f),.25f,true);
        var scene=EditorSceneManager.NewPreviewScene();var build=new GameObject("Power asset build");SceneManager.MoveGameObjectToScene(build,scene);
        try
        {
            var coin=Root("Coin",build.transform);Token(coin,Vector3.zero,.56f);Save(coin,"Coin");
            var magnet=Root("MagnetPickup",build.transform);Magnet(magnet,Vector3.zero,1);Ring(magnet,"Pickup halo",.58f,.022f,Quaternion.Euler(90,0,0),pink);Save(magnet,"MagnetPickup");
            var shield=Root("ShieldPickup",build.transform);Shield(shield,Vector3.zero,1);Ring(shield,"Pickup halo",.61f,.023f,Quaternion.Euler(90,0,0),blue);Save(shield,"ShieldPickup");
            var doubleCoin=Root("DoubleCoinPickup",build.transform);Token(doubleCoin,new Vector3(-.20f,.04f,.06f),.68f);Token(doubleCoin,new Vector3(.21f,-.06f,-.08f),.68f);Text(doubleCoin,"x2",new Vector3(0,.51f,-.03f),gold,4);Save(doubleCoin,"DoubleCoinPickup");
            var board=Root("Hoverboard",build.transform);Board(board);Save(board,"Hoverboard");
            var pickup=Root("HoverboardPickup",build.transform);var miniature=Object.Instantiate(board,pickup.transform,false);miniature.SetActive(true);miniature.transform.localScale=Vector3.one*.62f;miniature.transform.localRotation=Quaternion.Euler(-24,0,0);
            foreach(var t in miniature.GetComponentsInChildren<TrailRenderer>(true))Object.DestroyImmediate(t);Save(pickup,"HoverboardPickup");
            Field(build.transform);AssetDatabase.SaveAssets();Directory.CreateDirectory("Logs");File.WriteAllText("Logs/CourierPowerAssets.txt","PASS Coin, four power pickups, hoverboard, armor field/break, magnet field and coin aura generated.\n");
        }
        finally{EditorSceneManager.ClosePreviewScene(scene);}
    }
    private static Material Load(string name)=>AssetDatabase.LoadAssetAtPath<Material>("Assets/_Game/Art/CourierSet/Materials/"+name+".mat");
    private static Material Mat(string name,Color color,float glow,bool transparent=false)
    {
        var path=Folder+"/"+name+".mat";var m=AssetDatabase.LoadAssetAtPath<Material>(path);if(!m){m=new Material(Shader.Find("Universal Render Pipeline/Lit"));AssetDatabase.CreateAsset(m,path);}
        m.SetColor("_BaseColor",color);m.EnableKeyword("_EMISSION");m.SetColor("_EmissionColor",new Color(color.r,color.g,color.b)*glow);m.SetFloat("_Smoothness",.6f);
        if(transparent){m.SetFloat("_Surface",1);m.SetFloat("_SrcBlend",(int)BlendMode.SrcAlpha);m.SetFloat("_DstBlend",(int)BlendMode.OneMinusSrcAlpha);m.SetFloat("_ZWrite",0);m.EnableKeyword("_SURFACE_TYPE_TRANSPARENT");m.renderQueue=3000;m.SetOverrideTag("RenderType","Transparent");m.SetShaderPassEnabled("ShadowCaster",false);}
        EditorUtility.SetDirty(m);return m;
    }
    private static GameObject Root(string name,Transform parent){var go=new GameObject(name);go.transform.SetParent(parent,false);return go;}
    private static GameObject Shape(GameObject root,string name,PrimitiveType type,Vector3 pos,Vector3 size,Material m)
    {var go=GameObject.CreatePrimitive(type);go.name=name;go.transform.SetParent(root.transform,false);go.transform.localPosition=pos;go.transform.localScale=size;var r=go.GetComponent<Renderer>();r.sharedMaterial=m;r.shadowCastingMode=ShadowCastingMode.Off;Object.DestroyImmediate(go.GetComponent<Collider>());return go;}
    private static GameObject Box(GameObject root,string name,Vector3 pos,Vector3 size,Material m)=>Shape(root,name,PrimitiveType.Cube,pos,size,m);
    private static void Save(GameObject root,string name){PrefabUtility.SaveAsPrefabAsset(root,Folder+"/"+name+".prefab");root.SetActive(false);}
    private static void Token(GameObject root,Vector3 pos,float size)
    {
        var token=Root("Courier token",root.transform);token.transform.localPosition=pos;token.transform.localScale=Vector3.one*size;
        Shape(token,"Gold rim",PrimitiveType.Cylinder,Vector3.zero,new Vector3(1,.08f,1),gold).transform.localRotation=Quaternion.Euler(90,0,0);
        Shape(token,"Inset face",PrimitiveType.Cylinder,Vector3.zero,new Vector3(.78f,.087f,.78f),navy).transform.localRotation=Quaternion.Euler(90,0,0);
        foreach(float z in new[]{-.095f,.095f})
        {
            Box(token,"N left",new Vector3(-.17f,0,z),new Vector3(.08f,.47f,.03f),gold);Box(token,"N right",new Vector3(.17f,0,z),new Vector3(.08f,.47f,.03f),gold);
            Box(token,"N centre",new Vector3(0,0,z),new Vector3(.07f,.53f,.03f),gold).transform.localRotation=Quaternion.Euler(0,0,34);
        }
    }
    private static void Magnet(GameObject root,Vector3 pos,float size)
    {
        var shape=Root("U magnet",root.transform);shape.transform.localPosition=pos;shape.transform.localScale=Vector3.one*size;
        Box(shape,"U base",new Vector3(0,-.2f,0),new Vector3(.69f,.22f,.24f),pink);
        foreach(float x in new[]{-.24f,.24f}){Box(shape,"Magnet arm",new Vector3(x,.05f,0),new Vector3(.21f,.47f,.24f),pink);Box(shape,"Silver pole",new Vector3(x,.32f,0),new Vector3(.23f,.18f,.26f),white);}
    }
    private static void Shield(GameObject root,Vector3 pos,float size)
    {
        var shape=Root("Courier armor",root.transform);shape.transform.localPosition=pos;shape.transform.localScale=Vector3.one*size;
        Box(shape,"Armor face",Vector3.zero,new Vector3(.62f,.63f,.18f),slate);
        Box(shape,"Armor point",new Vector3(0,-.3f,0),new Vector3(.43f,.43f,.18f),slate).transform.localRotation=Quaternion.Euler(0,0,45);
        foreach(float x in new[]{-.30f,.30f})Box(shape,"Blue edge",new Vector3(x,0,-.10f),new Vector3(.07f,.63f,.05f),blue);
        Box(shape,"Armor crest",new Vector3(0,0,-.12f),new Vector3(.11f,.40f,.04f),white);Box(shape,"Armor crest bar",new Vector3(0,.02f,-.12f),new Vector3(.34f,.11f,.04f),white);
    }
    private static void Text(GameObject root,string text,Vector3 pos,Material color,float size)
    {
        var obj=Root(text,root.transform);obj.transform.localPosition=pos;var t=obj.AddComponent<TMPro.TextMeshPro>();t.font=TMPro.TMP_Settings.defaultFontAsset;t.text=text;t.fontSize=size;t.alignment=TMPro.TextAlignmentOptions.Center;t.rectTransform.sizeDelta=new Vector2(1.2f,.5f);t.color=color.GetColor("_BaseColor");
    }
    private static void Board(GameObject root)
    {
        Box(root,"Deck",Vector3.zero,new Vector3(.73f,.15f,1.24f),navy);
        foreach(float z in new[]{-.60f,.60f})Shape(root,"Rounded nose",PrimitiveType.Cylinder,new Vector3(0,0,z),new Vector3(.73f,.075f,.48f),navy);
        foreach(float x in new[]{-.34f,.34f})Box(root,"Cyan edge",new Vector3(x,.02f,0),new Vector3(.065f,.09f,1.27f),boardCyan);
        foreach(float z in new[]{-.33f,.33f}){Box(root,"Grip pad",new Vector3(0,.09f,z),new Vector3(.57f,.035f,.45f),slate);Box(root,"Accent stripe",new Vector3(0,.112f,z),new Vector3(.42f,.012f,.065f),orange);}
        foreach(float x in new[]{-.24f,.24f})
        {
            var engine=Shape(root,"Hover thruster",PrimitiveType.Cylinder,new Vector3(x,-.10f,-.53f),new Vector3(.19f,.10f,.19f),boardCyan);
            var wake=Root("Cyan wake",engine.transform);var t=wake.AddComponent<TrailRenderer>();t.sharedMaterial=trail;t.time=.28f;t.minVertexDistance=.08f;t.startWidth=.09f;t.endWidth=0;t.emitting=false;t.shadowCastingMode=ShadowCastingMode.Off;t.startColor=new Color(.08f,.86f,1,.5f);t.endColor=new Color(.08f,.86f,1,0);
        }
    }
    private static void Ring(GameObject root,string name,float radius,float width,Quaternion rotation,Material mat)
    {
        var go=Root(name,root.transform);go.transform.localRotation=rotation;var line=go.AddComponent<LineRenderer>();line.useWorldSpace=false;line.loop=true;line.positionCount=48;line.widthMultiplier=width;line.sharedMaterial=mat;line.shadowCastingMode=ShadowCastingMode.Off;
        for(int i=0;i<48;i++){float a=i*Mathf.PI*2/48;line.SetPosition(i,new Vector3(Mathf.Cos(a)*radius,0,Mathf.Sin(a)*radius));}
    }
    private static void Field(Transform parent)
    {
        var field=Root("ShieldField",parent);Shape(field,"Protective membrane",PrimitiveType.Sphere,Vector3.zero,new Vector3(1.55f,2.15f,1.55f),glass);
        Ring(field,"Armor arc",.8f,.025f,Quaternion.Euler(85,0,0),blue);Ring(field,"Armor arc 2",.79f,.018f,Quaternion.Euler(25,0,60),blue);
        for(int i=0;i<3;i++){float a=i*Mathf.PI*2/3;var plate=Root("Orbiting armor",field.transform);plate.transform.localPosition=new Vector3(Mathf.Cos(a)*.76f,.2f,Mathf.Sin(a)*.76f);plate.transform.localRotation=Quaternion.Euler(0,-a*Mathf.Rad2Deg+90,0);Shield(plate,Vector3.zero,.24f);}Save(field,"ShieldField");
        field=Root("ShieldBreak",parent);for(int i=0;i<10;i++){float a=i*Mathf.PI*2/10;Box(field,"Armor fragment",new Vector3(Mathf.Cos(a)*.8f,Mathf.Sin(a*2)*.5f,Mathf.Sin(a)*.8f),new Vector3(.11f,.20f,.07f),blue).transform.localRotation=Quaternion.Euler(i*13,i*37,25);}Save(field,"ShieldBreak");
        field=Root("MagnetField",parent);Ring(field,"Attraction ring",.85f,.023f,Quaternion.identity,pink);Ring(field,"Attraction arc",.95f,.017f,Quaternion.Euler(20,0,30),pink);Magnet(field,new Vector3(.75f,.40f,0),.28f);Save(field,"MagnetField");
        field=Root("CoinField",parent);Ring(field,"Coin reward ring",.62f,.018f,Quaternion.Euler(0,0,10),gold);for(int i=0;i<3;i++){float a=i*Mathf.PI*2/3;Token(field,new Vector3(Mathf.Cos(a)*.6f,.30f,Mathf.Sin(a)*.6f),.18f);}Save(field,"CoinField");
    }
}
#endif

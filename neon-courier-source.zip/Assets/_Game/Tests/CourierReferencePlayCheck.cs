#if UNITY_EDITOR
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using TMPro;
using UnityEditor;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;
using Object=UnityEngine.Object;

public sealed class CourierReferencePlayCheck:MonoBehaviour
{
    private const BindingFlags Hidden=BindingFlags.Instance|BindingFlags.NonPublic;
    private readonly List<string> report=new List<string>();
    private GameManager gm;private RunnerController runner;private CharacterSelectionManager selection;
    [MenuItem("Neon Courier/Run Reference Character Checks")]
    public static void Run()
    {
        if(EditorApplication.isPlayingOrWillChangePlaymode)return;CourierPolishPreferences.Capture();
        PlayerPrefs.SetInt("NeonCourier_StoryIntro_Seen_v1",1);PlayerPrefs.SetInt("NeonCourier.TutorialCompleted",1);PlayerPrefs.SetInt("NeonCourier.Language",0);
        for(int i=1;i<=4;i++)PlayerPrefs.DeleteKey("NeonCourier.CharacterUnlocked.courier_0"+i);
        PlayerPrefs.SetInt("NeonCourier.SelectedCharacter",3);PlayerPrefs.SetInt("NeonCourier.BagSkin",0);PlayerPrefs.SetInt("NeonCourier.BagPatch",0);PlayerPrefs.SetInt("NeonCourier.BagGlow",0);
        SessionState.SetBool("CourierReference.QA",true);EditorApplication.EnterPlaymode();
    }
    [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
    private static void Boot()
    {
        if(!SessionState.GetBool("CourierReference.QA",false))return;SessionState.SetBool("CourierReference.QA",false);
        foreach(var intro in Object.FindObjectsByType<StoryIntroController>(FindObjectsSortMode.None))intro.enabled=false;
        foreach(var tutorial in Object.FindObjectsByType<TutorialController>(FindObjectsSortMode.None))tutorial.enabled=false;
        var story=GameObject.Find("StoryIntroCanvas");if(story)story.SetActive(false);
        new GameObject("Reference checks").AddComponent<CourierReferencePlayCheck>();
    }
    private IEnumerator Start()
    {
        float oldDelta=Time.captureDeltaTime;int oldRate=Application.targetFrameRate;
        Time.timeScale=1;Time.captureDeltaTime=1f/60;Application.targetFrameRate=120;
        Directory.CreateDirectory("Logs");Application.logMessageReceived+=Log;
        var stack=new Stack<IEnumerator>();stack.Push(Checks());double deadline=EditorApplication.timeSinceStartup+240;
        while(stack.Count>0)
        {
            bool moved=false;object next=null;Exception error=null;
            try{if(EditorApplication.timeSinceStartup>deadline)throw new TimeoutException("Reference QA deadline");moved=stack.Peek().MoveNext();if(moved)next=stack.Peek().Current;}catch(Exception e){error=e;}
            if(error!=null){Check(false,error.ToString());break;}if(!moved){(stack.Pop() as IDisposable)?.Dispose();continue;}
            if(next is IEnumerator nested)stack.Push(nested);else yield return next;
        }
        while(stack.Count>0)(stack.Pop() as IDisposable)?.Dispose();
        Application.logMessageReceived-=Log;Time.timeScale=1;Time.captureDeltaTime=oldDelta;Application.targetFrameRate=oldRate;
        report.Add("COMPLETE failures="+report.Count(s=>s.StartsWith("FAIL")));File.WriteAllLines("Logs/CourierReferenceChecks.txt",report);EditorApplication.isPlaying=false;
    }
    private void Log(string message,string trace,LogType type){if(type==LogType.Error||type==LogType.Exception)Check(false,"Unity: "+message);}
    private void Check(bool value,string message){report.Add((value?"PASS ":"FAIL ")+message);File.WriteAllLines("Logs/CourierReferenceChecks.txt",report);}
    private IEnumerator Frames(int count){for(int i=0;i<count;i++)yield return null;}
    private IEnumerator Capture(string name){yield return Frames(10);ScreenCapture.CaptureScreenshot("Logs/Reference-"+name+".png");yield return Frames(6);}
    private IEnumerator Checks()
    {
        yield return Frames(15);gm=GameManager.Instance;runner=Object.FindAnyObjectByType<RunnerController>();selection=Object.FindAnyObjectByType<CharacterSelectionManager>();gm.OpenMainMenu();yield return Frames(2);
        Check(selection.CharacterCount==4&&selection.SelectedIndex==0,"New profile falls back to first/free Aki");
        Check(selection.GetPrice(0)==0&&selection.IsUnlocked(0),"Aki is free without a saved unlock");
        var names=new[]{"AKI","TANAKA","REN","LYRA"};var entries=new SerializedObject(selection).FindProperty("characters");
        for(int i=0;i<4;i++)
        {
            Check(selection.GetDisplayName(i).StartsWith(names[i]),"Reference order and character name: "+names[i]);
            Check(selection.GetPrice(i)==new[]{0,500,1200,2000}[i],"Existing price is preserved for "+names[i]);
            Check(entries.GetArrayElementAtIndex(i).FindPropertyRelative("characterId").stringValue=="courier_0"+(i+1),"Saved ownership ID is retained for "+names[i]);
            if(i>0)Check(!selection.IsUnlocked(i),names[i]+" remains locked on a new profile");
            foreach(string part in new[]{"Head","Torso","Hips","Arm","Leg","Glove","Boot","Bag"})
            {
                var asset=Resources.Load<GameObject>("CourierReference/"+part+i);
                Check(asset&&asset.GetComponentsInChildren<Collider>(true).Length==0,"New visual "+part+i+" preserves the runner collision shape");
                Check(asset&&asset.GetComponentsInChildren<MeshRenderer>(true).All(r=>r.sharedMaterial&&r.sharedMaterial.shader.isSupported),"Materials render for "+part+i);
            }
            Check(Resources.Load<Sprite>("CourierReference/Portrait"+i),"Portrait is generated from "+names[i]+" model");
        }
        int money=gm.TotalCoins;selection.SelectCharacter(0);Check(gm.TotalCoins==money,"Selecting free Aki spends no coins");
        Click(Button("CharacterButton"));yield return Frames(3);yield return Capture("Menu-FreeAki");
        var panel=Object.FindAnyObjectByType<CharacterSelectionPanelController>();var cards=new SerializedObject(panel).FindProperty("cards");
        for(int i=0;i<4;i++)
        {
            var card=cards.GetArrayElementAtIndex(i);var title=(TMP_Text)card.FindPropertyRelative("nameText").objectReferenceValue;title.ForceMeshUpdate();
            Check(title.text.Contains(names[i])&&title.textInfo.lineCount==1,names[i]+" menu title fits one line");
            var root=(GameObject)card.FindPropertyRelative("cardRoot").objectReferenceValue;var icon=root.transform.Find("CourierPortrait").GetComponent<Image>();Check(icon.sprite.name=="Portrait"+i,names[i]+" card uses the matching portrait");
            PlayerPrefs.SetInt("NeonCourier.CharacterUnlocked.courier_0"+(i+1),1);
        }
        Click(Button("CloseCharacterButton"));Click(Button("CharacterButton"));yield return Frames(2);
        for(int i=0;i<4;i++)
        {
            var button=(Button)cards.GetArrayElementAtIndex(i).FindPropertyRelative("actionButton").objectReferenceValue;
            if(i==0)selection.SelectCharacter(1);yield return Frames(2);Pointer(button,names[i]);Click(button);yield return Frames(2);
            Check(selection.SelectedIndex==i&&PlayerPrefs.GetInt("NeonCourier.SelectedCharacter")==i,"Selecting "+names[i]+" changes and saves the active model");
            Check(runner.CurrentAnimator&&runner.CurrentAnimator.isHuman,"Humanoid animations remain bound for "+names[i]);
            var mount=runner.GetComponentInChildren<CourierBackpackMount>();Check(mount.ActiveStyle==i&&mount.ActiveBag.activeInHierarchy,names[i]+" equips the corresponding backpack");
            Check(mount.transform.Cast<Transform>().Count(t=>t.name.StartsWith("CharacterBackpack")&&t.gameObject.activeSelf)==1,"Only one backpack is shown for "+names[i]);
        }
        yield return Capture("Menu");Click(Button("CloseCharacterButton"));
        for(int i=0;i<4;i++)
        {
            selection.SelectCharacter(i);var workshop=gm.GetComponent<CourierExpansionUI>();workshop.OpenWardrobe();yield return Frames(2);
            var bag=(Transform)Get(workshop,"previewBag");Check(bag.name.StartsWith("Bag"+i),"Workshop preview follows "+names[i]);workshop.CloseWardrobe();
        }
        selection.SelectCharacter(0);gm.StartGameFromMenu();float deadline=Time.realtimeSinceStartup+7;while(!gm.IsRunActive&&Time.realtimeSinceStartup<deadline)yield return null;Check(gm.IsRunActive,"Run starts after character replacement");
        runner.enabled=false;Set(gm,"speedGainPerSecond",0f);Property(gm,"CurrentSpeed",9.5f);foreach(var track in Object.FindObjectsByType<TrackManager>(FindObjectsSortMode.None))track.gameObject.SetActive(false);
        var world=new GameObject("Reference test road");for(int j=0;j<6;j++){var tile=Instantiate(AssetDatabase.LoadAssetAtPath<GameObject>("Assets/_Game/Prefabs/TrackTile_Prototype.prefab"),world.transform);tile.transform.localPosition=new Vector3(0,0,-10+j*30);tile.GetComponent<TrackTileContent>().ClearPattern();tile.GetComponent<CityTileDecorator>()?.RefreshLayout();}
        for(int i=0;i<4;i++)
        {
            selection.SelectCharacter(i);Warp();runner.SetForwardSpeed(9.5f);runner.enabled=true;yield return Frames(16);var rig=runner.CurrentAnimator;
            var foot=rig.GetBoneTransform(HumanBodyBones.LeftFoot).position;yield return Frames(10);
            Check((foot-rig.GetBoneTransform(HumanBodyBones.LeftFoot).position).sqrMagnitude>.02f,names[i]+" skeleton animates while running");
            var uniform=rig.GetComponent<CourierUniform>();Check(uniform.HasReferenceOutfit&&uniform.StyleIndex==i,names[i]+" uses the new full outfit");
            var head=rig.transform.Find("CourierUniformVisual/Head"+i+"(Clone)");Check(head&&head.GetComponentsInChildren<Renderer>().All(r=>r.enabled&&!r.forceRenderingOff),names[i]+" head renders in game");
            var old=rig.GetComponentsInChildren<SkinnedMeshRenderer>(true);Check(old.All(r=>r.forceRenderingOff),"Old body mesh stays hidden for "+names[i]);
            yield return Capture(names[i]+"-Run");
            Call(runner,"TryJump");yield return Frames(14);Check(runner.transform.position.y>1.5f,names[i]+" can jump with the new outfit");
            yield return Frames(70);Call(runner,"TrySlide");yield return Frames(5);Check(runner.IsSliding,names[i]+" can slide with the new outfit");yield return Frames(60);
            var power=PowerUpController.Instance;power.ActivatePowerUp(PowerUpType.Hoverboard);yield return Frames(35);Check(CourierPowerEffects.Instance.StanceWeight>.99f,names[i]+" keeps the hoverboard stance");yield return Capture(names[i]+"-Board");
            bool aligned=true;foreach(var limb in (IEnumerable)Get(uniform,"limbs"))
            {var flags=BindingFlags.Public|BindingFlags.Instance;var a=(Transform)limb.GetType().GetField("start",flags).GetValue(limb);var b=(Transform)limb.GetType().GetField("end",flags).GetValue(limb);var part=(Transform)limb.GetType().GetField("part",flags).GetValue(limb);aligned&=Vector3.Dot(part.up,(b.position-a.position).normalized)>.999f;}
            Check(aligned,names[i]+" sleeves and trousers stay aligned with bent elbows and knees");
            var mount=runner.GetComponentInChildren<CourierBackpackMount>();var chest=rig.GetBoneTransform(HumanBodyBones.Chest);if(!chest)chest=rig.GetBoneTransform(HumanBodyBones.Spine);Check(Vector3.Distance(mount.transform.position,chest.position)<.8f,names[i]+" backpack follows the posed chest");
            gm.PauseGame();var pos=head.position;yield return Frames(5);Check(Vector3.Distance(pos,head.position)<.015f,names[i]+" pose freezes on pause");gm.ResumeGame();Call(power,"ResetAllPowerUps");yield return Frames(65);runner.enabled=false;
        }
        Destroy(world);gm.OpenMainMenu();yield return Frames(3);Check(gm.IsMainMenuActive,"Character tests return to the menu cleanly");
    }
    private void Warp(){runner.enabled=false;var cc=runner.GetComponent<CharacterController>();cc.enabled=false;runner.transform.position=new Vector3(0,1.08f,4);Set(runner,"currentLane",1);Set(runner,"verticalVelocity",-2f);Set(runner,"horizontalVelocity",0f);cc.enabled=true;Physics.SyncTransforms();var camera=Camera.main.GetComponent<CameraFollow>();Set(camera,"movementVelocity",Vector3.zero);Call(camera,"InitializeFollowPosition");camera.transform.LookAt(runner.transform.position+new Vector3(0,1.35f,5.2f));}
    private static Button Button(string name)=>Object.FindObjectsByType<Button>(FindObjectsInactive.Include,FindObjectsSortMode.None).First(b=>b.name==name);
    private static void Click(Button button){ExecuteEvents.Execute(button.gameObject,new PointerEventData(EventSystem.current){button=PointerEventData.InputButton.Left},ExecuteEvents.pointerClickHandler);}
    private void Pointer(Button button,string label)
    {
        Canvas.ForceUpdateCanvases();var corners=new Vector3[4];((RectTransform)button.transform).GetWorldCorners(corners);
        foreach(float x in new[]{.15f,.5f,.85f}){var p=Vector3.Lerp(Vector3.Lerp(corners[0],corners[3],x),Vector3.Lerp(corners[1],corners[2],x),.5f);var hits=new List<RaycastResult>();EventSystem.current.RaycastAll(new PointerEventData(EventSystem.current){position=p},hits);Check(hits.Count>0&&hits[0].gameObject.GetComponentInParent<Button>()==button,label+" button receives clicks at "+x);}
    }
    private static object Get(object obj,string field)=>obj.GetType().GetField(field,Hidden).GetValue(obj);
    private static void Set(object obj,string field,object value)=>obj.GetType().GetField(field,Hidden).SetValue(obj,value);
    private static void Property(object obj,string name,object value)=>obj.GetType().GetProperty(name).SetValue(obj,value);
    private static object Call(object obj,string name,params object[] args)=>obj.GetType().GetMethod(name,Hidden).Invoke(obj,args);
}
#endif

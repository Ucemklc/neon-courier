#if UNITY_EDITOR
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using UnityEditor;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using Object=UnityEngine.Object;

/// <summary>Opt-in real-prefab/physics checks. Restores preferences and global state even on failure.</summary>
public sealed class CityExpansionPlayCheck : MonoBehaviour
{
    private const BindingFlags Hidden=BindingFlags.Instance|BindingFlags.NonPublic;
    private readonly List<string> report=new List<string>();
    private readonly Dictionary<string,int?> prefs=new Dictionary<string,int?>();
    private readonly Dictionary<FieldInfo,object> counters=new Dictionary<FieldInfo,object>();
    private GameManager oldManager,manager;
    private PowerUpController oldPower;
    private CourierCargoManifest oldManifest,manifest;
    private UnityEngine.Random.State oldRandom;
    private float oldScale,oldDelta;
    private int oldFrameRate;
    private bool captured;

    [MenuItem("Neon Courier/Run City Expansion Checks")]
    public static void Run(){if(EditorApplication.isPlayingOrWillChangePlaymode)return;SessionState.SetBool("CourierExpansion.QA",true);EditorApplication.EnterPlaymode();}
    [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
    private static void Boot()
    {
        if(!SessionState.GetBool("CourierExpansion.QA",false))return;
        SessionState.SetBool("CourierExpansion.QA",false);
        foreach(var root in SceneManager.GetActiveScene().GetRootGameObjects())root.SetActive(false);
        new GameObject("City expansion checks").AddComponent<CityExpansionPlayCheck>();
    }
    private IEnumerator Start()
    {
        oldManager=GameManager.Instance;oldPower=PowerUpController.Instance;oldManifest=CourierCargoManifest.Instance;
        oldRandom=UnityEngine.Random.state;oldScale=Time.timeScale;oldDelta=Time.captureDeltaTime;oldFrameRate=Application.targetFrameRate;
        foreach(string key in new[]{"NeonCourier.TotalCoins","NeonCourier.BagSkin","NeonCourier.BagPatch","NeonCourier.BagGlow","NeonCourier.Language"})prefs[key]=PlayerPrefs.HasKey(key)?PlayerPrefs.GetInt(key):(int?)null;
        foreach(var field in typeof(TrackTileContent).GetFields(BindingFlags.Static|BindingFlags.NonPublic))if(!field.IsInitOnly && field.FieldType==typeof(int))counters[field]=field.GetValue(null);
        captured=true;Time.timeScale=1;Time.captureDeltaTime=1f/60;Application.targetFrameRate=-1;UnityEngine.Random.InitState(926);
        Singleton(typeof(PowerUpController),null);Singleton(typeof(CourierCargoManifest),null);
        Application.logMessageReceived+=OnLog;
        var pending=new Stack<IEnumerator>();pending.Push(Checks());double deadline=EditorApplication.timeSinceStartup+120;
        try
        {
            while(pending.Count>0)
            {
                bool moved=false;object next=null;Exception error=null;
                try{if(EditorApplication.timeSinceStartup>deadline)throw new TimeoutException("120 second deadline");moved=pending.Peek().MoveNext();if(moved)next=pending.Peek().Current;}catch(Exception e){error=e;}
                if(error!=null){Check(false,error.ToString());break;}
                if(!moved){(pending.Pop() as IDisposable)?.Dispose();continue;}
                if(next is IEnumerator nested)pending.Push(nested);else yield return next;
            }
        }
        finally{while(pending.Count>0)(pending.Pop() as IDisposable)?.Dispose();Restore();}
        Directory.CreateDirectory("Logs");File.WriteAllLines("Logs/CityExpansionPlayChecks.txt",report);
        Debug.Log("CITY_EXPANSION_QA_COMPLETE failures="+report.Count(x=>x.StartsWith("FAIL")));
        EditorApplication.isPlaying=false;
    }
    private void OnLog(string message,string trace,LogType type){if(type==LogType.Exception || type==LogType.Error)report.Add("FAIL Unity log: "+message);}
    private void Restore()
    {
        if(!captured)return;captured=false;Application.logMessageReceived-=OnLog;
        foreach(var pair in prefs){if(pair.Value.HasValue)PlayerPrefs.SetInt(pair.Key,pair.Value.Value);else PlayerPrefs.DeleteKey(pair.Key);}PlayerPrefs.Save();
        Singleton(typeof(GameManager),oldManager);Singleton(typeof(PowerUpController),oldPower);Singleton(typeof(CourierCargoManifest),oldManifest);
        foreach(var pair in counters)pair.Key.SetValue(null,pair.Value);
        UnityEngine.Random.state=oldRandom;Time.timeScale=oldScale;Time.captureDeltaTime=oldDelta;Application.targetFrameRate=oldFrameRate;
    }
    private void OnDisable(){Restore();}
    private IEnumerator Checks()
    {
        var stats=Root("Inactive test stats");stats.SetActive(false);manager=stats.AddComponent<GameManager>();Singleton(typeof(GameManager),manager);
        Property(manager,"IsRunActive",true);Property(manager,"ComboMultiplier",1);Property(manager,"CurrentLives",3);
        manifest=stats.AddComponent<CourierCargoManifest>();Call(manifest,"Awake");Call(manifest,"Start");
        yield return Cargo();
        Pooling();
        foreach(float speed in new[]{9.5f,15.5f})yield return RoofTraverse(speed);
        yield return TunnelTraverse(true);
        yield return TunnelTraverse(false);
        yield return MovingTrain();
        yield return Stops();
        yield return Workshop();
        bool absent=true;
        foreach(var text in Resources.FindObjectsOfTypeAll<TMPro.TMP_Text>())if(text.gameObject.scene.IsValid())absent &= !text.name.Contains("NearMiss") && !(text.text??"").Contains("YAKIN KAÇIŞ") && !(text.text??"").Contains("NEAR MISS");
        Check(absent,"Near-miss labels remain absent");
    }
    private IEnumerator Cargo()
    {
        manager.CollectPackage(CourierCargoKind.Express);manager.CollectPackage(CourierCargoKind.Fragile);manager.CollectPackage(CourierCargoKind.Heavy);
        Check(manager.CarriedPackages==3 && manifest.Items.Count==3,"Pickup ledger stays synchronized with carried packages");
        Check(Mathf.Abs(manifest.SpeedMultiplier-.92f)<.001,"One heavy parcel slows movement by 8 percent");
        yield return null;Call(manifest,"Update");float before=manifest.RunClock;
        Property(manager,"IsPaused",true);for(int i=0;i<20;i++){yield return null;Call(manifest,"Update");}
        Check(Mathf.Approximately(before,manifest.RunClock),"Express clock freezes while paused");Property(manager,"IsPaused",false);
        int payoutBefore=manager.TotalCoins;int baseReward=(int)Get(manager,"coinPerDeliveredPackage");
        int delivered=manager.DeliverCarriedPackages();
        Check(delivered==3 && manager.TotalCoins-payoutBefore==3*baseReward+15,"Actual GameManager delivery pays base reward plus 6/5/4 special bonuses");
        Check(manifest.LastDeliveryBonus==15 && manifest.Items.Count==0 && manifest.SpeedMultiplier==1,"Delivery clears weight and reports the special payout");
        int coins=manager.TotalCoins;manager.DeliverCarriedPackages();Check(manager.TotalCoins==coins,"Empty delivery cannot duplicate rewards");
        manager.CollectPackage(CourierCargoKind.Express);Property(manifest,"RunClock",manifest.RunClock+18.01f);
        Check(manifest.CompleteDelivery(1)==0,"Expired express parcel receives no special bonus");Property(manager,"CarriedPackages",0);
        manager.CollectPackage(CourierCargoKind.Fragile);manifest.DamageFragileCargo();Check(manifest.CompleteDelivery(1)==0,"Damaged fragile parcel receives no special bonus");Property(manager,"CarriedPackages",0);
        for(int i=0;i<5;i++)manager.CollectPackage(CourierCargoKind.Heavy);
        Check(Mathf.Abs(manifest.SpeedMultiplier-.84f)<.001,"Heavy cargo penalty is capped at 16 percent");
        Property(manager,"CarriedPackages",2);Call(manifest,"SyncCount");Check(manifest.Items.Count==2,"Dropped parcels are removed from the ledger");
        Check(manifest.CompleteDelivery(2,2)==8 && manifest.LastDeliveryBonus==16,"Doubled reward notice matches the credited special bonus");Property(manager,"CarriedPackages",0);
        var parcel=Instantiate(AssetDatabase.LoadAssetAtPath<GameObject>("Assets/_Game/Prefabs/PF_Package.prefab"),transform);
        var pickup=parcel.GetComponent<PackagePickup>();pickup.ConfigureCargo(CourierCargoKind.Fragile);
        Check(parcel.GetComponentsInChildren<Transform>().Any(t=>t.name.StartsWith("CargoBadge2")),"Fragile pickup displays its distinct glass badge");
        parcel.SetActive(false);parcel.transform.position=new Vector3(0,1,5);parcel.SetActive(true);
        Check(pickup.CargoKind==CourierCargoKind.Standard,"Recycled starting-area parcel resets its cargo type");Destroy(parcel);yield return null;
    }
    private void Pooling()
    {
        typeof(TrackTileContent).GetMethod("ResetStaticRouteState",BindingFlags.Static|BindingFlags.NonPublic).Invoke(null,null);
        var root=Root("Tile pool");root.SetActive(false);var content=root.AddComponent<TrackTileContent>();
        var template=Root("Templates");template.SetActive(false);var obstacle=new GameObject("Obstacle");obstacle.tag="Obstacle";obstacle.transform.SetParent(template.transform);obstacle.AddComponent<ObstacleVisualController>();
        Set(content,"obstaclePrefab",obstacle);Set(content,"packagePrefab",AssetDatabase.LoadAssetAtPath<GameObject>("Assets/_Game/Prefabs/PF_Package.prefab"));Set(content,"deliveryZonePrefab",AssetDatabase.LoadAssetAtPath<GameObject>("Assets/_Game/Prefabs/PF_DeliveryZone.prefab"));Set(content,"overrideDifficultyForTesting",true);root.SetActive(true);
        var district=root.AddComponent<CourierDistrictTile>();
        int packages=0,deliveries=0,rails=0,alternates=0;bool safety=true,bounded=true;HashSet<int> warm=null;
        for(int i=0;i<180;i++)
        {
            root.transform.position=new Vector3(0,0,i*30-10);Set(content,"testDifficultyLevel",i%4);content.RefreshPattern();district.Refresh();
            var slots=(GameObject[])Get(content,"packageSlots");packages+=slots.Count(p=>p.activeSelf);
            if(((DeliveryZone)Get(content,"deliveryZone")).gameObject.activeSelf)deliveries++;

            var alt=root.GetComponent<CourierAlternateRoute>();bool isAlt=alt && alt.Active;if(isAlt)alternates++;
            if(!isAlt && root.GetComponentsInChildren<RailRideSurface>().Length>0)rails++;
            if(isAlt)foreach(var p in slots.Where(p=>p.activeSelf))safety &= alt.IsRoof?!(p.transform.localPosition.z>12 && p.transform.localPosition.z<16):Mathf.Abs(p.transform.localPosition.z-12.8f)>2f;
            var ids=new HashSet<int>(root.GetComponentsInChildren<RailRideSurface>(true).SelectMany(s=>s.GetComponentsInChildren<Transform>(true)).Select(t=>t.GetInstanceID()));
            if(i==71)warm=ids;else if(i>71)bounded &= warm.SetEquals(ids);
        }
        Check(packages==450 && deliveries==45,"180 pooled tiles preserve 10 parcels per 4 tiles ("+packages+" parcels, "+deliveries+" stops)");
        Check(rails==55 && alternates==25,"Train and shortcut patterns coexist: 55 train routes and 25 shortcuts alongside scooter sections");
        Check(safety,"Shortcut parcels avoid the rooftop gap and tunnel slide bar");Check(bounded,"Train and shortcut geometry reuses instances after warmup");
        Check(CourierWorldRules.DistrictAt(0)==CourierDistrict.Neon && CourierWorldRules.DistrictAt(300)==CourierDistrict.Industrial && CourierWorldRules.DistrictAt(600)==CourierDistrict.Harbor && CourierWorldRules.DistrictAt(CourierCareerProgress.DistrictCount*300)==CourierDistrict.Neon,"District rotation wraps after the career-unlocked environments");
        Check(root.GetComponentsInChildren<Transform>(true).Count(t=>t.name.StartsWith("District")&&t.name.EndsWith("(Clone)"))==CourierCareerProgress.DistrictCount,"Districts pool exactly one instance of each unlocked environment");
        content.ClearPattern();Check(root.GetComponentsInChildren<RailRideSurface>().Length==0,"Clearing a pooled tile disables all ride surfaces");Destroy(root);Destroy(template);
    }
    private IEnumerator RoofTraverse(float speed)
    {
        var root=Root("Roof traversal");Ground(root.transform);var route=root.AddComponent<CourierAlternateRoute>();route.Configure(2.5f,4,Array.Empty<GameObject>(),0,1,null);
        var runner=Runner(root.transform,new Vector3(-2.5f,1.01f,0),speed);Set(runner,"currentLane",0);
        Physics.SyncTransforms();bool jumped=false,onFirst=false,onSecond=false;float maxY=0;int frame=0;
        while(runner.transform.position.z<31 && frame++<420)
        {
            Vector3 p=runner.transform.position;maxY=Mathf.Max(maxY,p.y);
            if(p.z>7.2f && p.z<11 && runner.IsGrounded && p.y>3.2f)onFirst=true;
            if(!jumped && p.z>9.7f){Call(runner,"TryJump");jumped=true;}
            if(p.z>16 && p.z<20 && p.y>3.2f)onSecond=true;
            yield return null;
        }
        Check(onFirst && maxY>5.1f && onSecond,"speed="+speed+" climbs ramp and crosses the gap above roof height");
        Check(route.Active && Mathf.Abs(runner.transform.position.y-1)<.16f,"speed="+speed+" returns to road without colliding with roof");
        Check(manifest.HasRouteBoost,"speed="+speed+" clean shortcut awards speed boost");
        Call(manifest,"MenuChanged",true);Destroy(root);yield return null;
    }
    private IEnumerator TunnelTraverse(bool slide)
    {
        Call(manifest,"MenuChanged",true);Property(manager,"CurrentLives",3);
        var root=Root("Tunnel traversal");Ground(root.transform);
        var obstacle=new GameObject("Tunnel slide bar");obstacle.transform.SetParent(root.transform);obstacle.tag="Obstacle";
        var visual=obstacle.AddComponent<ObstacleVisualController>();
        var route=root.AddComponent<CourierAlternateRoute>();route.Configure(2.5f,10,Array.Empty<GameObject>(),0,1,visual);
        var runner=Runner(root.transform,new Vector3(2.5f,1.01f,0),9.5f);Set(runner,"currentLane",2);Physics.SyncTransforms();bool slid=false;
        int frames=0;while(runner.transform.position.z<28 && frames++<250)
        {if(slide && !slid && runner.transform.position.z>10.8f){Call(runner,"TrySlide");slid=true;}yield return null;}
        Check(slide?manager.CurrentLives==3:manager.CurrentLives==2,slide?"Sliding clears the tunnel bar without losing a life":"Standing at the tunnel bar registers a collision");
        Check(manifest.HasRouteBoost==slide,slide?"Clean tunnel exit awards shortcut boost":"Tunnel collision prevents shortcut reward");
        Call(manifest,"MenuChanged",true);Property(manager,"CurrentLives",3);Destroy(root);yield return null;
    }
    private IEnumerator MovingTrain()
    {
        var root=Root("Moving wagon");Ground(root.transform);var train=NeonRailFactory.CreateTrain(root.transform,2.5f,false);train.transform.localPosition=new Vector3(0,0,7.5f);
        var motion=train.AddComponent<CourierMovingTrain>();motion.Configure(true);var runner=Runner(root.transform,new Vector3(0,3.41f,10),0);
        Physics.SyncTransforms();yield return null;
        for(int i=0;i<65;i++)yield return null;
        Check(motion.IsWarning && Mathf.Abs(train.transform.position.z-7.5f)<.001f,"Moving wagon warns before changing position");
        Property(manager,"IsPaused",true);float z=train.transform.position.z;for(int i=0;i<25;i++)yield return null;
        Check(train.transform.position.z==z && motion.FrameDeltaZ==0,"Paused wagon freezes with zero carry delta");Property(manager,"IsPaused",false);
        float initialRunnerZ=runner.transform.position.z;for(int i=0;i<190;i++)yield return null;
        Check(Mathf.Abs(train.transform.position.z-10.2f)<.02f,"Wagon departure remains inside its 2.7m reservation");
        Check(runner.IsGrounded && runner.transform.position.z>initialRunnerZ+2.5f && runner.transform.position.y>3.2f,"Standing courier is carried along safely on a moving roof");
        train.SetActive(false);train.transform.localPosition=new Vector3(0,0,7.5f);train.SetActive(true);motion.Configure(true);
        Check(!motion.IsWarning && motion.FrameDeltaZ==0 && train.transform.localPosition.z==7.5f,"Recycled moving wagon resets warning, position and carry delta");Destroy(root);yield return null;
    }
    private IEnumerator Stops()
    {
        var zone=Instantiate(AssetDatabase.LoadAssetAtPath<GameObject>("Assets/_Game/Prefabs/PF_DeliveryZone.prefab"),transform);var stop=zone.AddComponent<CourierDeliveryStop>();var receiver=zone.GetComponentInChildren<DeliveryReceiverVisual>(true);
        bool valid=true;for(int i=0;i<8;i++){stop.Configure(i*120);valid &= stop.Variant==i%4 && receiver.gameObject.activeSelf==(i%4!=3);}
        Check(valid,"Robot, shop, apartment and parcel-locker destinations cycle and reset correctly");
        stop.Configure(360);stop.PlayFeedback();yield return new WaitForSeconds(.5f);
        var door=zone.GetComponentsInChildren<Transform>().First(t=>t.name=="DoorPivot");Check(Quaternion.Angle(door.localRotation,Quaternion.identity)>40,"Successful locker delivery opens the compartment");
        stop.Configure(360);Check(Quaternion.Angle(door.localRotation,Quaternion.identity)<.01f,"Recycling a locker closes the compartment");Destroy(zone);yield return null;
    }
    private IEnumerator Workshop()
    {
        Property(manager,"IsRunActive",false);Property(manager,"IsMainMenuActive",true);PlayerPrefs.SetInt("NeonCourier.Language",0);
        var root=Root("Workshop test");var ui=root.AddComponent<CourierExpansionUI>();yield return null;Set(ui,"manager",manager);ui.OpenWardrobe();
        yield return new WaitForSeconds(.5f);Check(ui.WardrobeOpen,"Backpack workshop opens from the main menu");
        var rt=(RenderTexture)Get(ui,"previewTexture");Check(rt && rt.IsCreated(),"Workshop creates its live 3D preview texture");
        if(rt)
        {
            var previous=RenderTexture.active;RenderTexture.active=rt;var pixels=new Texture2D(rt.width,rt.height,TextureFormat.RGB24,false);pixels.ReadPixels(new Rect(0,0,rt.width,rt.height),0,0);pixels.Apply();RenderTexture.active=previous;
            int colorful=pixels.GetPixels32().Count(c=>c.r>45||c.g>70||c.b>90);Check(colorful>rt.width*rt.height/30,"Backpack preview contains visible rendered geometry");
            Directory.CreateDirectory("Logs");File.WriteAllBytes("Logs/Expansion-BackpackPreview.png",pixels.EncodeToPNG());Destroy(pixels);
        }
        root.GetComponentsInChildren<Button>().First(b=>b.name=="Skin2").onClick.Invoke();ui.SelectPatch(2);ui.SelectGlow(1);
        Check(CourierBackpackStyle.Skin==2 && CourierBackpackStyle.Patch==2 && CourierBackpackStyle.Glow==1,"Color, patch and light buttons persist their selections");
        var bag=(Transform)Get(ui,"previewBag");Check(bag.GetComponentsInChildren<Transform>().Any(t=>t.name.StartsWith("BagPatch2")),"Selected star patch appears on the preview bag");
        ui.SelectSkin(0);ui.SelectPatch(0);ui.SelectGlow(0);yield return new WaitForSeconds(.3f);
        ScreenCapture.CaptureScreenshot("Logs/Expansion-Workshop.png");yield return null;yield return null;yield return null;
        ui.CloseWardrobe();Check(!ui.WardrobeOpen && !((GameObject)Get(ui,"previewRoot")).activeSelf,"Closing wardrobe disables preview rendering");
        PlayerPrefs.SetInt("NeonCourier.Language",1);ui.OpenWardrobe();Check(root.GetComponentsInChildren<TMPro.TMP_Text>().Any(t=>t.name=="Title"&&t.text=="COURIER WORKSHOP"),"Reopening workshop respects a changed language");ui.CloseWardrobe();Destroy(root);
    }
    private GameObject Root(string name){var root=new GameObject(name);root.transform.SetParent(transform);return root;}
    private static void Ground(Transform parent){var g=GameObject.CreatePrimitive(PrimitiveType.Cube);g.transform.SetParent(parent);g.transform.position=new Vector3(0,-.25f,15);g.transform.localScale=new Vector3(15,.5f,90);}
    private static RunnerController Runner(Transform parent,Vector3 position,float speed)
    {
        var go=new GameObject("Runner");go.transform.SetParent(parent);go.transform.position=position;var cc=go.AddComponent<CharacterController>();cc.height=2;cc.radius=.5f;cc.center=Vector3.zero;cc.skinWidth=.08f;cc.slopeLimit=45;cc.stepOffset=.3f;
        var runner=go.AddComponent<RunnerController>();go.AddComponent<PlayerCollisionHandler>();runner.SetForwardSpeed(speed);return runner;
    }
    private void Check(bool success,string message){report.Add((success?"PASS ":"FAIL ")+message);}
    private static object Get(object target,string field)=>target.GetType().GetField(field,Hidden).GetValue(target);
    private static void Set(object target,string field,object value)=>target.GetType().GetField(field,Hidden).SetValue(target,value);
    private static void Call(object target,string method,params object[] args)=>target.GetType().GetMethod(method,Hidden).Invoke(target,args);
    private static void Property(object target,string name,object value)=>target.GetType().GetProperty(name).GetSetMethod(true).Invoke(target,new[]{value});
    private static void Singleton(Type type,object value)=>type.GetProperty("Instance").GetSetMethod(true).Invoke(null,new[]{value});
}
#endif


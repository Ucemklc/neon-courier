using System.Collections;
using UnityEngine;

[RequireComponent(typeof(AudioSource))]
public class GameFeedbackController : MonoBehaviour
{
    private const string VibrationEnabledKey = "NeonCourier.VibrationEnabled";

    [Header("Audio Clips")]
    [SerializeField]
    private AudioClip packagePickupClip;

    [SerializeField]
    private AudioClip deliveryClip;

    [SerializeField]
    private AudioClip playerHitClip;

    [SerializeField]
    private AudioClip gameOverClip;

    [Header("Background Music")]
    [SerializeField]
    private AudioClip menuMusicClip;

    [SerializeField]
    private AudioClip gameplayMusicClip;

    [SerializeField]
    private AudioClip laneChangeClip;

    [SerializeField]
    private AudioClip backgroundMusicClip;

    [SerializeField, Range(0f, 1f)]
    private float backgroundMusicVolume = 0.4f;

    [Header("Volume")]
    [SerializeField, Range(0f, 1f)]
    private float packagePickupVolume = 0.75f;

    [SerializeField, Range(0f, 1f)]
    private float deliveryVolume = 0.9f;

    [SerializeField, Range(0f, 1f)]
    private float playerHitVolume = 1f;

    [SerializeField, Range(0f, 1f)]
    private float gameOverVolume = 1f;

    [Header("Pitch Variation")]
    [SerializeField]
    private Vector2 packagePitchRange = new Vector2(0.95f, 1.08f);

    [Header("Mobile Vibration")]
    [SerializeField]
    private bool vibrationEnabled = true;

    [SerializeField, Min(0f)]
    private float vibrationCooldown = 0.3f;

    private AudioSource audioSource;
    private AudioSource musicSource;
    private GameManager gameManager;
    private RunnerController runnerController;
    private Coroutine musicFadeRoutine;

    private int previousCarriedPackages;
    private float lastVibrationTime = -100f;

    public bool IsVibrationEnabled => vibrationEnabled;

    private void Awake()
    {
        vibrationEnabled = PlayerPrefs.GetInt(
            VibrationEnabledKey,
            vibrationEnabled ? 1 : 0
        ) == 1;

        audioSource = GetComponent<AudioSource>();
        ConfigureAudioSource();

        // Arka plan müziği için ikinci AudioSource
        musicSource = gameObject.AddComponent<AudioSource>();
        musicSource.playOnAwake = false;
        musicSource.loop = true;
        musicSource.spatialBlend = 0f;
        musicSource.volume = 0f;
        menuMusicClip = menuMusicClip != null ? menuMusicClip : Resources.Load<AudioClip>("Audio/MenuLoop");
        gameplayMusicClip = gameplayMusicClip != null ? gameplayMusicClip : Resources.Load<AudioClip>("Audio/GameplayLoop");
        laneChangeClip = laneChangeClip != null ? laneChangeClip : Resources.Load<AudioClip>("Audio/LaneWhoosh");
        if (gameplayMusicClip == null) gameplayMusicClip = backgroundMusicClip;
    }

    private IEnumerator Start()
    {
        yield return null;

        gameManager = GameManager.Instance;

        if (gameManager == null)
        {
            Debug.LogError(
                "GameFeedbackController: GameManager bulunamadı.",
                this
            );

            enabled = false;
            yield break;
        }

        previousCarriedPackages = gameManager.CarriedPackages;

        gameManager.StatsChanged += HandleStatsChanged;
        gameManager.DeliveryCompleted += HandleDeliveryCompleted;
        gameManager.PlayerHit += HandlePlayerHit;
        gameManager.GameOverTriggered += HandleGameOver;
        gameManager.MainMenuChanged += HandleMainMenuChanged;
        gameManager.RunStateChanged += HandleRunStateChanged;
        gameManager.SoundStateChanged += HandleSoundStateChanged;

        runnerController = FindAnyObjectByType<RunnerController>();
        if (runnerController != null) runnerController.LaneChanged += HandleLaneChanged;

        if (gameManager.IsMainMenuActive) PlayMusic(menuMusicClip);
        else if (gameManager.IsRunActive) PlayMusic(gameplayMusicClip);
    }

    private void OnDestroy()
    {
        if (gameManager == null)
        {
            return;
        }

        gameManager.StatsChanged -= HandleStatsChanged;
        gameManager.DeliveryCompleted -= HandleDeliveryCompleted;
        gameManager.PlayerHit -= HandlePlayerHit;
        gameManager.GameOverTriggered -= HandleGameOver;
        gameManager.MainMenuChanged -= HandleMainMenuChanged;
        gameManager.RunStateChanged -= HandleRunStateChanged;
        gameManager.SoundStateChanged -= HandleSoundStateChanged;
        if (runnerController != null) runnerController.LaneChanged -= HandleLaneChanged;
    }

    public bool IsRunMusicPlaying => musicSource != null && musicSource.clip == gameplayMusicClip && musicSource.isPlaying;
    public float RunMusicLength => gameplayMusicClip ? gameplayMusicClip.length : 0f;

    private void HandleMainMenuChanged(bool isMainMenu)
    {
        if (isMainMenu) PlayMusic(menuMusicClip);
        else PlayMusic(null);
    }

    private void HandleRunStateChanged(bool isRunning)
    {
        if (isRunning) PlayMusic(gameplayMusicClip);
        else if (gameManager != null && gameManager.IsMainMenuActive) PlayMusic(menuMusicClip);
        else PlayMusic(null);
    }

    private void HandleSoundStateChanged(bool enabled)
    {
        if (!enabled)
        {
            if (musicFadeRoutine != null) StopCoroutine(musicFadeRoutine);
            musicSource.Stop();
            return;
        }
        if (gameManager != null && gameManager.IsMainMenuActive) PlayMusic(menuMusicClip);
        else if (gameManager != null && gameManager.IsRunActive) PlayMusic(gameplayMusicClip);
    }

    private void HandleLaneChanged(int lane)
    {
        PlayClip(laneChangeClip, 0.48f, Random.Range(0.94f, 1.08f));
    }

    private void ConfigureAudioSource()
    {
        audioSource.playOnAwake = false;
        audioSource.loop = false;
        audioSource.spatialBlend = 0f;
        audioSource.volume = 1f;
    }

    private void HandleStatsChanged()
    {
        if (gameManager == null)
        {
            return;
        }

        int currentCarriedPackages = gameManager.CarriedPackages;

        bool packageCollected =
            currentCarriedPackages > previousCarriedPackages;

        if (packageCollected)
        {
            PlayPackagePickupSound();
        }

        previousCarriedPackages = currentCarriedPackages;
    }

    private void HandleDeliveryCompleted(int deliveredPackageCount)
    {
        previousCarriedPackages = 0;

        if (deliveredPackageCount <= 0)
        {
            return;
        }

        PlayClip(
            deliveryClip,
            deliveryVolume,
            1f
        );

        TriggerVibration();
    }

    private void HandlePlayerHit()
    {
        if (gameManager != null)
        {
            previousCarriedPackages = gameManager.CarriedPackages;
        }

        PlayClip(
            playerHitClip,
            playerHitVolume,
            1f
        );

        TriggerVibration();
    }

    private void HandleGameOver()
    {
        PlayClip(
            gameOverClip,
            gameOverVolume,
            1f
        );

        TriggerVibration();
    }

    private void PlayPackagePickupSound()
    {
        float randomPitch = Random.Range(
            packagePitchRange.x,
            packagePitchRange.y
        );

        PlayClip(
            packagePickupClip,
            packagePickupVolume,
            randomPitch
        );
    }

    private void PlayClip(
        AudioClip clip,
        float volume,
        float pitch
    )
    {
        if (clip == null)
        {
            return;
        }

        if (
            gameManager != null &&
            !gameManager.IsSoundEnabled
        )
        {
            return;
        }

        audioSource.pitch = pitch;

        audioSource.PlayOneShot(
            clip,
            volume
        );
    }

    private void PlayMusic(AudioClip clip)
    {
        if (musicSource == null) return;
        if (gameManager != null && !gameManager.IsSoundEnabled)
        {
            if (musicFadeRoutine != null) StopCoroutine(musicFadeRoutine);
            musicFadeRoutine = null;
            musicSource.Stop();
            return;
        }
        if (musicSource.isPlaying && musicSource.clip == clip) return;
        if (musicFadeRoutine != null) StopCoroutine(musicFadeRoutine);
        musicFadeRoutine = StartCoroutine(FadeMusicRoutine(clip));
    }

    private IEnumerator FadeMusicRoutine(AudioClip nextClip)
    {
        while (musicSource.volume > 0.01f)
        {
            musicSource.volume = Mathf.MoveTowards(
                musicSource.volume, 0f, Time.unscaledDeltaTime * 1.8f
            );
            yield return null;
        }

        musicSource.Stop();
        musicSource.clip = nextClip;

        if (nextClip != null)
        {
            musicSource.volume = 0f;
            musicSource.Play();
            while (musicSource.volume < backgroundMusicVolume)
            {
                musicSource.volume = Mathf.MoveTowards(
                    musicSource.volume, backgroundMusicVolume,
                    Time.unscaledDeltaTime * 1.8f
                );
                yield return null;
            }
        }
        else
        {
            musicSource.volume = 0f;
        }

        musicFadeRoutine = null;
    }
    private void TriggerVibration()
    {
        if (!vibrationEnabled)
        {
            return;
        }

        if (
            Time.unscaledTime -
            lastVibrationTime <
            vibrationCooldown
        )
        {
            return;
        }

        lastVibrationTime = Time.unscaledTime;

#if UNITY_ANDROID || UNITY_IOS
        Handheld.Vibrate();
#endif
    }

    public void SetVibrationEnabled(bool enabled)
    {
        vibrationEnabled = enabled;
        PlayerPrefs.SetInt(VibrationEnabledKey, enabled ? 1 : 0);
        PlayerPrefs.Save();
    }
}

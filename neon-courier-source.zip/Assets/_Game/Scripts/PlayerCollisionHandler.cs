using System.Collections;
using UnityEngine;

[RequireComponent(typeof(CharacterController))]
public class PlayerCollisionHandler : MonoBehaviour
{
    [Header("Player References")]
    [SerializeField]
    private RunnerController runnerController;

    [SerializeField]
    private Transform visualRoot;

    [Header("Invulnerability")]
    [SerializeField, Min(0.1f)]
    private float invulnerabilityDuration = 1.5f;

    [SerializeField, Min(0.03f)]
    private float blinkInterval = 0.1f;

    [Header("Dropped Package Visuals")]
    [SerializeField]
    private GameObject packageDropPrefab;

    [SerializeField, Min(0)]
    private int maximumDropVisuals = 5;

    [SerializeField, Min(0f)]
    private float horizontalDropForce = 3.5f;

    [SerializeField, Min(0f)]
    private float upwardDropForce = 3f;

    [SerializeField, Min(0f)]
    private float backwardDropForce = 2f;

    [SerializeField, Min(0.1f)]
    private float droppedPackageLifetime = 2f;

    private bool isInvulnerable;

    public bool IsInvulnerable => isInvulnerable;

    private Renderer[] visualRenderers;

    private void Awake()
    {
        if (runnerController == null)
        {
            runnerController =
                GetComponent<RunnerController>();
        }

        if (visualRoot == null)
        {
            visualRoot =
                transform.Find(
                    "PlayerVisual"
                );
        }

        CacheVisualRenderers();
    }

    private void OnDisable()
    {
        StopAllCoroutines();

        isInvulnerable = false;

        SetVisualVisible(true);
    }

    private void OnControllerColliderHit(
        ControllerColliderHit hit
    )
    {
        if (hit.collider == null || !hit.collider.gameObject.activeInHierarchy)
        {
            return;
        }

        RailRideSurface railSurface =
            hit.collider.GetComponentInParent<RailRideSurface>();

        if (railSurface != null)
        {
            if (railSurface.IsSafeContact(hit.normal))
            {
                return;
            }

            // Clear the whole train even during invulnerability so its
            // remaining colliders cannot pin the runner against its side.
            railSurface.gameObject.SetActive(false);
        }
        else
        {
            if (!hit.collider.CompareTag("Obstacle"))
            {
                return;
            }

            hit.collider.gameObject.SetActive(false);
        }

        if (isInvulnerable)
        {
            return;
        }

        if (GameManager.Instance == null || GameManager.Instance.IsGameOver)
        {
            return;
        }

        int lostPackages =
            GameManager.Instance
                .HandlePlayerHit();

        SpawnDroppedPackages(
            lostPackages
        );

        if (
            !GameManager.Instance
                .IsGameOver
        )
        {
            StartCoroutine(
                InvulnerabilityRoutine()
            );
        }
    }

    private IEnumerator InvulnerabilityRoutine()
    {
        isInvulnerable = true;

        /*
         * Paket görselleri oyun başladıktan
         * sonra üretildiği için her çarpışmada
         * Renderer listesini yeniliyoruz.
         */
        CacheVisualRenderers();

        float elapsedTime = 0f;

        while (
            elapsedTime <
            invulnerabilityDuration
        )
        {
            if (
                GameManager.Instance != null &&
                GameManager.Instance.IsGameOver
            )
            {
                break;
            }

            SetVisualVisible(false);

            yield return
                new WaitForSecondsRealtime(
                    blinkInterval
                );

            SetVisualVisible(true);

            yield return
                new WaitForSecondsRealtime(
                    blinkInterval
                );

            elapsedTime +=
                blinkInterval * 2f;
        }

        SetVisualVisible(true);

        isInvulnerable = false;
    }

    private void SpawnDroppedPackages(
        int lostPackages
    )
    {
        if (
            packageDropPrefab == null ||
            lostPackages <= 0
        )
        {
            return;
        }

        int visualCount =
            Mathf.Min(
                lostPackages,
                maximumDropVisuals
            );

        for (
            int index = 0;
            index < visualCount;
            index++
        )
        {
            Vector3 spawnPosition =
                transform.position +
                Vector3.up * 1.2f;

            GameObject droppedPackage =
                Instantiate(
                    packageDropPrefab,
                    spawnPosition,
                    Random.rotation
                );

            ConfigureDroppedPackage(
                droppedPackage
            );

            Rigidbody packageRigidbody =
                droppedPackage
                    .GetComponent<Rigidbody>();

            if (packageRigidbody != null)
            {
                float horizontalDirection =
                    visualCount <= 1
                        ? 0f
                        : Mathf.Lerp(
                            -1f,
                            1f,
                            index /
                            (float)(
                                visualCount - 1
                            )
                        );

                Vector3 force =
                    transform.right *
                    horizontalDirection *
                    horizontalDropForce;

                force +=
                    Vector3.up *
                    upwardDropForce;

                force -=
                    transform.forward *
                    backwardDropForce;

                packageRigidbody.AddForce(
                    force,
                    ForceMode.Impulse
                );

                packageRigidbody.AddTorque(
                    Random.insideUnitSphere *
                    5f,
                    ForceMode.Impulse
                );
            }

            Destroy(
                droppedPackage,
                droppedPackageLifetime
            );
        }
    }

    private void ConfigureDroppedPackage(
        GameObject droppedPackage
    )
    {
        droppedPackage.tag =
            "Untagged";

        PackagePickup packagePickup =
            droppedPackage
                .GetComponent<PackagePickup>();

        if (packagePickup != null)
        {
            packagePickup.enabled = false;
        }

        Collider packageCollider =
            droppedPackage
                .GetComponent<Collider>();

        if (packageCollider != null)
        {
            packageCollider.enabled = true;
            packageCollider.isTrigger = false;
        }

        Rigidbody packageRigidbody =
            droppedPackage
                .GetComponent<Rigidbody>();

        if (packageRigidbody != null)
        {
            packageRigidbody.isKinematic =
                false;

            packageRigidbody.useGravity =
                true;

            packageRigidbody.detectCollisions =
                true;
        }
    }

    private void CacheVisualRenderers()
    {
        if (visualRoot == null)
        {
            visualRenderers =
                new Renderer[0];

            return;
        }

        visualRenderers =
            visualRoot.GetComponentsInChildren
                <Renderer>(true);
    }

    private void SetVisualVisible(
        bool isVisible
    )
    {
        if (visualRenderers == null)
        {
            return;
        }

        foreach (
            Renderer visualRenderer
            in visualRenderers
        )
        {
            if (visualRenderer != null)
            {
                visualRenderer.enabled =
                    isVisible;
            }
        }
    }
}

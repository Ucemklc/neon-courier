using UnityEngine;

/// <summary>A pooled, self-contained elevated route occupying z=3..24 on a 30 m tile.</summary>
[DisallowMultipleComponent]
public sealed class NeonRailSection : MonoBehaviour
{
    public const float TrainStartZ = 7.5f;
    public const float RouteEndZ = 24f;
    private GameObject mainTrain;
    private GameObject adjacentTrain;
    private GameObject routeSign;
    private float builtLaneDistance;

    public void Clear()
    {
        if (mainTrain != null) mainTrain.SetActive(false);
        if (adjacentTrain != null) adjacentTrain.SetActive(false);
        if (routeSign != null) routeSign.SetActive(false);
    }

    public void Configure(float laneDistance, int difficulty, int sequence,
        GameObject[] packages, int packageCount, float packageHeight,
        PowerUpPickup powerUp, ObstacleVisualController roofObstacle, float powerUpChance)
    {
        EnsureAssets(laneDistance);
        Clear();

        // The first rail route is centered and has no roof obstacle.
        int lane = sequence == 2 ? 1 : Random.Range(0, 3);
        float laneX = (lane - 1) * laneDistance;
        mainTrain.transform.localPosition = new Vector3(laneX, 0f, TrainStartZ);
        mainTrain.SetActive(true);

        bool hasAdjacentTrain = difficulty >= 1;
        bool hasMovingTrain = hasAdjacentTrain && sequence >= 8 && sequence % 2 == 0;
        int adjacentLane = lane == 1 ? (sequence % 2 == 0 ? 0 : 2) : 1;
        float adjacentX = (adjacentLane - 1) * laneDistance;
        if (hasAdjacentTrain)
        {
            adjacentTrain.transform.localPosition = new Vector3(adjacentX, 0f, TrainStartZ);
            adjacentTrain.SetActive(true);
            var motion = adjacentTrain.GetComponent<CourierMovingTrain>() ?? adjacentTrain.AddComponent<CourierMovingTrain>();
            motion.Configure(hasMovingTrain);
        }

        routeSign.transform.localPosition = new Vector3(lane == 0 ? -4.9f : 4.9f, 0.025f, 3f);
        routeSign.SetActive(true);

        int count = Mathf.Min(packageCount, packages.Length);
        for (int i = 0; i < count; i++)
        {
            GameObject package = packages[i];
            if (package == null) continue;
            // A visible line leads from the ramp to the roof. Position before enabling:
            // PackagePickup caches its bobbing origin in OnEnable.
            float lastPackageZ = difficulty >= 2 ? 11.8f : 18.4f;
            float z = count <= 1 ? 11f : Mathf.Lerp(6f, lastPackageZ, i / (float)(count - 1));
            package.transform.localPosition = new Vector3(laneX, HeightAt(z) + packageHeight, z);
            package.transform.localRotation = Quaternion.identity;
            package.transform.localScale = Vector3.one;
            package.SetActive(true);
            mainTrain.GetComponent<RailRideSurface>().RegisterContent(package);
        }

        // All three ground lanes are clear on the first encounter. Later sections
        // keep one ground lane open and offer a parallel roof as an optional shortcut.
        if (difficulty >= 2 && roofObstacle != null && sequence > 2)
        {
            roofObstacle.transform.localPosition = new Vector3(laneX, NeonRailFactory.RoofHeight, 15f);
            roofObstacle.transform.localRotation = Quaternion.identity;
            roofObstacle.transform.localScale = Vector3.one;
            roofObstacle.gameObject.SetActive(true);
            roofObstacle.Configure(RunnerObstacleType.Jump);
            mainTrain.GetComponent<RailRideSurface>().RegisterContent(roofObstacle.gameObject);
        }

        if (powerUp != null && Random.value < Mathf.Clamp01(powerUpChance * 1.5f))
        {
            powerUp.transform.localPosition = new Vector3(
                hasAdjacentTrain && !hasMovingTrain ? adjacentX : laneX, NeonRailFactory.RoofHeight + 1.1f, 13f);
            powerUp.transform.localRotation = Quaternion.identity;
            powerUp.transform.localScale = Vector3.one;
            powerUp.Configure((PowerUpType)Random.Range(0, 3));
            powerUp.gameObject.SetActive(true);
            (hasAdjacentTrain && !hasMovingTrain ? adjacentTrain : mainTrain).GetComponent<RailRideSurface>()
                .RegisterContent(powerUp.gameObject);
        }
    }

    public static float HeightAt(float tileZ)
    {
        float localZ = tileZ - TrainStartZ;
        if (localZ < -NeonRailFactory.RampLength ||
            localZ > NeonRailFactory.BodyLength + NeonRailFactory.RampLength) return 0f;
        if (localZ < 0f)
            return Mathf.InverseLerp(-NeonRailFactory.RampLength, 0f, localZ) * NeonRailFactory.RoofHeight;
        if (localZ <= NeonRailFactory.BodyLength) return NeonRailFactory.RoofHeight;
        return (1f - Mathf.InverseLerp(NeonRailFactory.BodyLength,
            NeonRailFactory.BodyLength + NeonRailFactory.RampLength, localZ)) * NeonRailFactory.RoofHeight;
    }

    public float GetRideHeightAt(float laneX, float tileZ)
    {
        if (mainTrain != null && mainTrain.activeSelf &&
            Mathf.Abs(laneX - mainTrain.transform.localPosition.x) < .96f)
            return HeightAt(tileZ);
        if (adjacentTrain != null && adjacentTrain.activeSelf &&
            Mathf.Abs(laneX - adjacentTrain.transform.localPosition.x) < .96f &&
            tileZ >= adjacentTrain.transform.localPosition.z && tileZ <= adjacentTrain.transform.localPosition.z + NeonRailFactory.BodyLength)
            return NeonRailFactory.RoofHeight;
        return 0f;
    }

    private void EnsureAssets(float laneDistance)
    {
        if (mainTrain != null && Mathf.Approximately(builtLaneDistance, laneDistance)) return;
        Clear();
        if (mainTrain != null) Destroy(mainTrain);
        if (adjacentTrain != null) Destroy(adjacentTrain);
        if (routeSign != null) Destroy(routeSign);
        builtLaneDistance = laneDistance;
        mainTrain = CreateTrainAsset("NeonRail/NeonCargoTrain", laneDistance, true);
        adjacentTrain = CreateTrainAsset("NeonRail/NeonCargoCar", laneDistance, false);
        GameObject signPrefab = Resources.Load<GameObject>("NeonRail/RampRouteSign");
        routeSign = signPrefab != null ? Instantiate(signPrefab, transform) :
            NeonRailFactory.CreateRouteSign(transform);
    }

    private GameObject CreateTrainAsset(string path, float laneDistance, bool withRamps)
    {
        GameObject prefab = Resources.Load<GameObject>(path);
        GameObject train = prefab != null && Mathf.Approximately(laneDistance, 2.5f)
            ? Instantiate(prefab, transform)
            : NeonRailFactory.CreateTrain(transform, laneDistance, withRamps);
        train.SetActive(false);
        return train;
    }
}

#if UNITY_EDITOR
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using TMPro;
using UnityEditor;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;
using Object=UnityEngine.Object;

/// <summary>Opt-in checks of real panel clicks, mission rewards and the paid revive flow.</summary>
public sealed class CourierPanelPlayCheck : MonoBehaviour
{
    private const BindingFlags Hidden=BindingFlags.Instance|BindingFlags.NonPublic;
    private readonly List<string> report=new List<string>();
    private GameManager gm;private RunnerController runner;private DailyMissionPanelController missions;
    private DailyMissionManager daily;private RevivePanelController revive;
    private float oldDelta,oldScale;private int oldRate;
    [MenuItem("Neon Courier/Run Panel Checks")]
    public static void Run()
    {
        if(EditorApplication.isPlayingOrWillChangePlaymode)return;
        CourierPolishPreferences.Capture();
        PlayerPrefs.SetInt("NeonCourier_StoryIntro_Seen_v1",1);PlayerPrefs.SetInt("NeonCourier.TutorialCompleted",1);PlayerPrefs.SetInt("NeonCourier.Language",0);
        SessionState.SetBool("CourierPanels.QA",true);EditorApplication.EnterPlaymode();
    }
    [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
    private static void Boot()
    {
        if(!SessionState.GetBool("CourierPanels.QA",false))return;SessionState.SetBool("CourierPanels.QA",false);
        foreach(var intro in Object.FindObjectsByType<StoryIntroController>(FindObjectsSortMode.None))intro.enabled=false;
        foreach(var tutorial in Object.FindObjectsByType<TutorialController>(FindObjectsSortMode.None))tutorial.enabled=false;
        var story=GameObject.Find("StoryIntroCanvas");if(story)story.SetActive(false);
        new GameObject("Panel checks").AddComponent<CourierPanelPlayCheck>();
    }
    private IEnumerator Start()
    {
        oldScale=Time.timeScale;oldDelta=Time.captureDeltaTime;oldRate=Application.targetFrameRate;
        Time.timeScale=1;Time.captureDeltaTime=1f/60;Application.targetFrameRate=120;
        Directory.CreateDirectory("Logs");Application.logMessageReceived+=Log;
        var stack=new Stack<IEnumerator>();stack.Push(Checks());double deadline=EditorApplication.timeSinceStartup+120;
        while(stack.Count>0)
        {
            bool moved=false;object next=null;Exception error=null;
            try{if(EditorApplication.timeSinceStartup>deadline)throw new TimeoutException("Panel QA deadline");moved=stack.Peek().MoveNext();if(moved)next=stack.Peek().Current;}catch(Exception e){error=e;}
            if(error!=null){Check(false,error.ToString());break;}
            if(!moved){(stack.Pop() as IDisposable)?.Dispose();continue;}
            if(next is IEnumerator nested)stack.Push(nested);else yield return next;
        }
        while(stack.Count>0)(stack.Pop() as IDisposable)?.Dispose();
        Application.logMessageReceived-=Log;Time.timeScale=oldScale;Time.captureDeltaTime=oldDelta;Application.targetFrameRate=oldRate;
        File.WriteAllLines("Logs/CourierPanelChecks.txt",report);Debug.Log("PANEL_CHECKS_COMPLETE failures="+report.Count(l=>l.StartsWith("FAIL")));EditorApplication.isPlaying=false;
    }
    private void Log(string message,string trace,LogType type){if(type==LogType.Error||type==LogType.Exception)Check(false,"Unity: "+message);}
    private void Check(bool value,string message){report.Add((value?"PASS ":"FAIL ")+message);File.WriteAllLines("Logs/CourierPanelChecks.txt",report);}
    private IEnumerator Capture(string name){yield return new WaitForSecondsRealtime(.4f);ScreenCapture.CaptureScreenshot("Logs/"+name+".png");for(int i=0;i<5;i++)yield return null;}
    private IEnumerator Checks()
    {
        for(int i=0;i<10;i++)yield return null;
        gm=GameManager.Instance;runner=Object.FindAnyObjectByType<RunnerController>();missions=Object.FindAnyObjectByType<DailyMissionPanelController>();daily=DailyMissionManager.Instance;revive=Object.FindAnyObjectByType<RevivePanelController>();
        gm.OpenMainMenu();yield return null;
        string[] fields={"distanceMission","collectMission","deliverMission","comboMission"};
        string[] progress={"distanceProgress","collectProgress","deliverProgress","comboProgress"};
        string[] claimed={"distanceClaimed","collectClaimed","deliverClaimed","comboClaimed"};
        for(int i=0;i<4;i++){Set(daily,progress[i],0);Set(daily,claimed[i],false);}
        Click(Button("MissionsButton"));yield return null;yield return null;
        Check(missions.IsOpen,"Missions button opens the rebuilt panel");
        var panel=(GameObject)Get(missions,"missionPanel");
        Check(panel.GetComponent<CourierPanelSurface>()&&panel.GetComponent<Canvas>().sortingOrder==240,"Mission modal covers underlying menu controls (order "+panel.GetComponent<Canvas>().sortingOrder+")");
        Check(!Button("OpenGarage").gameObject.activeInHierarchy&&!Button("BagWorkshop").gameObject.activeInHierarchy,"Garage and workshop hide while missions are open");
        Check(panel.GetComponentsInChildren<Slider>().All(s=>s.fillRect&&s.fillRect.GetComponent<Image>()&&!s.interactable),"All four mission bars have visible, noninteractive fills");
        foreach(string field in fields){var row=Get(missions,field);var button=(Button)Get(row,"claimButton");Check(!button.interactable,"Incomplete "+field+" reward is disabled");int coins=gm.TotalCoins;Click(button);Check(gm.TotalCoins==coins,"Incomplete "+field+" cannot award coins");}
        Set(daily,progress[0],daily.GetTarget(DailyMissionType.RunDistance)/2);
        Set(daily,progress[1],daily.GetTarget(DailyMissionType.CollectPackages));
        Set(daily,progress[2],daily.GetTarget(DailyMissionType.DeliverPackages));Set(daily,claimed[2],true);
        Call(missions,"RefreshAllMissions");yield return null;
        Layout(panel,"Turkish missions");yield return Capture("Panels-Missions");
        for(int i=0;i<4;i++)
        {
            var type=(DailyMissionType)i;Set(daily,progress[i],daily.GetTarget(type));Set(daily,claimed[i],false);Call(missions,"RefreshAllMissions");yield return null;
            var row=Get(missions,fields[i]);var button=(Button)Get(row,"claimButton");Pointer(button,fields[i]);
            int coins=gm.TotalCoins;Click(button);yield return null;
            Check(daily.IsClaimed(type)&&gm.TotalCoins==coins+daily.GetReward(type)&&!button.interactable,"Claim "+fields[i]+" awards its exact reward and disables the button");
            Click(button);Check(gm.TotalCoins==coins+daily.GetReward(type),"Repeated "+fields[i]+" click cannot duplicate coins");
        }
        Pointer(Button("CloseMissionButton"),"Close missions");Click(Button("CloseMissionButton"));yield return null;Check(!missions.IsOpen,"Mission close returns to the main menu");
        PlayerPrefs.SetInt("NeonCourier.Language",1);missions.OpenMissionPanel();yield return null;
        Check(panel.GetComponentsInChildren<TMP_Text>().Any(t=>t.text=="DAILY MISSIONS")&&panel.GetComponentsInChildren<TMP_Text>().Count(t=>t.text=="CLAIMED")==4,"Mission titles and completed states switch to English");
        Layout(panel,"English missions");missions.CloseMissionPanel();PlayerPrefs.SetInt("NeonCourier.Language",0);
        gm.AddCoins(500);gm.StartGameFromMenu();float limit=Time.realtimeSinceStartup+8;while(!gm.IsRunActive&&Time.realtimeSinceStartup<limit)yield return null;
        runner.enabled=false;foreach(var track in Object.FindObjectsByType<TrackManager>(FindObjectsSortMode.None))track.gameObject.SetActive(false);
        Check(gm.IsRunActive,"Real countdown starts a run for revive validation");
        Set(gm,"bonusScore",321);Property(gm,"DistanceMeters",123);int balance=gm.TotalCoins;
        gm.TriggerGameOver();yield return new WaitForSecondsRealtime(1.2f);
        var root=(GameObject)Get(revive,"revivePanelRoot");var results=(GameObject)Get(revive,"gameOverPanelRoot");var resume=(Button)Get(revive,"reviveButton");var giveUp=(Button)Get(revive,"giveUpButton");
        Check(root.activeInHierarchy&&!results.activeInHierarchy,"First crash opens Continue instead of overlapping results");
        Pointer(resume,"Continue");Pointer(giveUp,"Finish run");Layout(root,"Turkish continue");
        Check(((TMP_Text)Get(revive,"reviveCostText")).text=="50 COIN"&&resume.GetComponentInChildren<TMP_Text>().text.Contains("50"),"Continue price is visible both in the card and on the button");
        yield return Capture("Panels-Continue");
        int score=gm.Score,distance=gm.DistanceMeters;Click(resume);yield return null;Click(resume);
        Check(!root.activeInHierarchy&&!results.activeInHierarchy&&gm.ReviveUsedThisRun,"Continue closes its modal and consumes the single continue allowance");
        Check(gm.TotalCoins==balance-50&&gm.CurrentLives==1,"Continue deducts exactly 50 coins once and restores one life");
        Check(gm.Score==score&&gm.DistanceMeters==distance,"Continue preserves score and distance");
        limit=Time.realtimeSinceStartup+8;while(!gm.IsRunActive&&Time.realtimeSinceStartup<limit)yield return null;runner.enabled=false;
        Check(gm.IsRunActive&&!gm.IsGameOver,"Continue completes countdown and resumes the run");
        gm.TriggerGameOver();yield return new WaitForSecondsRealtime(.4f);
        Check(!root.activeInHierarchy&&results.activeInHierarchy,"Second crash skips the already used continue offer");
        // Isolate a fresh eligible crash and insufficient funds without touching saved user progress.
        Property(gm,"ReviveUsedThisRun",false);Property(gm,"TotalCoins",20);Call(revive,"HandleGameOver");yield return null;yield return null;
        Check(root.activeInHierarchy&&!resume.interactable,"Insufficient coins show a disabled Continue button");
        Check(((TMP_Text)Get(revive,"informationText")).text.Contains("30"),"Insufficient balance explains the exact missing coin amount");
        int poorBalance=gm.TotalCoins;Click(resume);Check(gm.TotalCoins==poorBalance&&gm.IsGameOver,"Disabled Continue cannot charge coins");
        yield return Capture("Panels-Insufficient-Coins");
        PlayerPrefs.SetInt("NeonCourier.Language",1);Call(revive,"RefreshPanel");yield return null;Layout(root,"English continue");
        Check(root.GetComponentsInChildren<TMP_Text>().Any(t=>t.text=="CONTINUE?")&&giveUp.GetComponentInChildren<TMP_Text>().text=="FINISH RUN","Continue labels switch to English");
        Click(giveUp);yield return null;Check(!root.activeInHierarchy&&results.activeInHierarchy&&gm.TotalCoins==poorBalance,"Finish run opens results without charging coins");
    }
    private void Layout(GameObject panel,string name)
    {
        Canvas.ForceUpdateCanvases();bool fits=true,readable=true;
        var safe=new Rect(0,0,Screen.width,Screen.height);
        foreach(var text in panel.GetComponentsInChildren<TMP_Text>())
        {
            if(!text.enabled)continue;text.ForceMeshUpdate();var rect=Bounds(text.rectTransform);
            fits&=safe.Contains(rect.min+Vector2.one)&&safe.Contains(rect.max-Vector2.one);
            readable&=!text.isTextOverflowing&&text.margin==Vector4.zero&&text.color.a>.9f;
        }
        Check(fits,name+" text stays within the screen");Check(readable,name+" text fits its bounds with readable styling");
    }
    private void Pointer(Button button,string label)
    {
        Canvas.ForceUpdateCanvases();bool matches=true;var rect=Bounds((RectTransform)button.transform);
        foreach(float x in new[]{.08f,.5f,.92f})foreach(float y in new[]{.12f,.5f,.88f})
        {
            var data=new PointerEventData(EventSystem.current){position=new Vector2(Mathf.Lerp(rect.xMin,rect.xMax,x),Mathf.Lerp(rect.yMin,rect.yMax,y))};var hits=new List<RaycastResult>();EventSystem.current.RaycastAll(data,hits);
            matches&=hits.Count>0&&hits[0].gameObject.GetComponentInParent<Button>()==button;
        }
        Check(matches,label+" receives clicks across all nine visible test points");
    }
    private static Rect Bounds(RectTransform transform){var c=new Vector3[4];transform.GetWorldCorners(c);return Rect.MinMaxRect(c[0].x,c[0].y,c[2].x,c[2].y);}
    private static Button Button(string name)=>Object.FindObjectsByType<Button>(FindObjectsInactive.Include,FindObjectsSortMode.None).First(b=>b.name==name);
    private static void Click(Button b)=>ExecuteEvents.Execute(b.gameObject,new PointerEventData(EventSystem.current){button=PointerEventData.InputButton.Left},ExecuteEvents.pointerClickHandler);
    private static object Get(object o,string field)=>o.GetType().GetField(field,Hidden|BindingFlags.Public).GetValue(o);
    private static void Set(object o,string field,object value)=>o.GetType().GetField(field,Hidden|BindingFlags.Public).SetValue(o,value);
    private static object Call(object o,string method,params object[] values)=>o.GetType().GetMethod(method,Hidden).Invoke(o,values);
    private static void Property(object o,string property,object value)=>o.GetType().GetProperty(property).GetSetMethod(true).Invoke(o,new[]{value});
}
#endif

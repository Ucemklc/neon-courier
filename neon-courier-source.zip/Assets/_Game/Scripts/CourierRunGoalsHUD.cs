using TMPro;
using UnityEngine;
using UnityEngine.UI;

public sealed class CourierRunGoalsHUD : MonoBehaviour
{
    private GameManager manager;
    private CourierRunGoals goals;
    private GameObject card;
    private TMP_Text label;
    private Image progress;
    private float nextRefresh;
    private void Start()
    {
        manager=GameManager.Instance;goals=manager.GetComponent<CourierRunGoals>();
        card=new GameObject("RunGoalCard",typeof(RectTransform),typeof(Image));card.transform.SetParent(transform,false);
        CourierMenuLayout.Place((RectTransform)card.transform,new Vector2(.5f,1),new Vector2(0,-426),new Vector2(940,140));
        var background=card.GetComponent<Image>();background.color=new Color(.025f,.06f,.10f,.85f);background.raycastTarget=false;
        var text=new GameObject("RunGoalLabel",typeof(RectTransform),typeof(TextMeshProUGUI));text.transform.SetParent(card.transform,false);
        CourierMenuLayout.Place((RectTransform)text.transform,new Vector2(.5f,.5f),new Vector2(0,7),new Vector2(900,122));
        label=text.GetComponent<TMP_Text>();label.font=TMP_Settings.defaultFontAsset;label.fontSize=25;label.enableAutoSizing=true;label.fontSizeMin=21;label.fontSizeMax=25;label.alignment=TextAlignmentOptions.Center;label.raycastTarget=false;
        var bar=new GameObject("DistanceGoalProgress",typeof(RectTransform),typeof(Image));bar.transform.SetParent(card.transform,false);
        var r=(RectTransform)bar.transform;r.anchorMin=r.anchorMax=new Vector2(0,0);r.pivot=Vector2.zero;r.anchoredPosition=new Vector2(15,6);r.sizeDelta=new Vector2(910,5);
        progress=bar.GetComponent<Image>();progress.color=new Color(.2f,.85f,1);progress.raycastTarget=false;
    }
    private void Update()
    {
        if(!card||!goals)return;
        card.SetActive(manager.IsRunActive&&!manager.IsPaused&&!manager.IsGameOver&&!manager.IsMainMenuActive);
        if(!card.activeSelf||Time.unscaledTime<nextRefresh)return;nextRefresh=Time.unscaledTime+.15f;
        bool en=PlayerPrefs.GetInt("NeonCourier.Language",0)==1;
        int left=Mathf.Max(0,goals.StartingRecord-manager.Score);
        string record=left==0?(en?"NEW RECORD!":"YENİ REKOR!"):(en?"TO RECORD ":"REKORA ")+left;
        label.text=(goals.HasNotice?goals.Notice(en):goals.NextDistance>0?(en?"NEXT ":"HEDEF ")+goals.NextDistance+" m  •  +"+goals.NextReward+" COIN":en?"ALL DISTANCE GOALS COMPLETE":"TÜM MESAFE HEDEFLERİ TAMAM")+
            "\n<color=#8DB4CA>"+record+"  •  "+(en?"DELIVERY":"TESLİMAT")+" x"+manager.ComboMultiplier+"</color>";
        if(CourierRouteContract.Instance)label.text+="\n<color=#FFD277>"+CourierRouteContract.Instance.RouteText(en)+"</color>";
        float fraction=goals.NextDistance>0?Mathf.Clamp01((float)manager.DistanceMeters/goals.NextDistance):1;
        progress.rectTransform.sizeDelta=new Vector2(910*fraction,5);
    }
}

#if UNITY_EDITOR
using System;
using System.IO;
using UnityEditor;

/// <summary>Runs the opt-in project checks in the current editor, one Play session at a time.</summary>
[InitializeOnLoad]
public static class CourierCheckQueue
{
    private const string Request="Temp/CourierChecks.request";
    private static double nextCheck;
    static CourierCheckQueue(){EditorApplication.update+=Tick;}

    [MenuItem("Neon Courier/Run All Courier Checks")]
    public static void RunAll()
    {
        if(EditorApplication.isPlayingOrWillChangePlaymode)return;
        Directory.CreateDirectory("Temp");
        File.WriteAllLines(Request,new[]{"Neon Courier/Run City Expansion Checks","Neon Courier/Run Courier Visual Checks","Neon Courier/Run Rail Physics Checks"});
    }
    private static void Tick()
    {
        if(EditorApplication.timeSinceStartup<nextCheck)return;nextCheck=EditorApplication.timeSinceStartup+.5;
        if(EditorApplication.isCompiling || EditorApplication.isUpdating || EditorApplication.isPlayingOrWillChangePlaymode || !File.Exists(Request))return;
        // A request is short-lived and never starts checks unexpectedly on a later day.
        if(DateTime.UtcNow-File.GetLastWriteTimeUtc(Request)>TimeSpan.FromMinutes(10)){File.Delete(Request);return;}
        string[] commands=File.ReadAllLines(Request);
        if(commands.Length==0){File.Delete(Request);return;}
        string command=commands[0];
        if(command!="Neon Courier/Generate Reference Characters" && command!="Neon Courier/Capture Reference Characters" && command!="Neon Courier/Run Reference Character Checks" && command!="Neon Courier/Generate Power Assets" && command!="Neon Courier/Run Power Checks" && command!="Neon Courier/Generate Journey Assets" && command!="Neon Courier/Run Journey Checks" && command!="Neon Courier/Run Panel Checks" && command!="Neon Courier/Generate Career Assets" && command!="Neon Courier/Run Career Checks" && command!="Neon Courier/Capture Courier Uniforms" && command!="Neon Courier/Apply Courier Polish" && command!="Neon Courier/Run Courier Polish Checks" && command!="Neon Courier/Run City Expansion Checks" && command!="Neon Courier/Run Courier Visual Checks" && command!="Neon Courier/Run Rail Physics Checks")
        {File.Delete(Request);throw new InvalidOperationException("Unrecognized courier check request.");}
        if(commands.Length==1)File.Delete(Request);else File.WriteAllLines(Request,new ArraySegment<string>(commands,1,commands.Length-1));
        Directory.CreateDirectory("Logs");File.AppendAllText("Logs/CourierChecksQueue.txt",DateTime.Now.ToString("s")+" START "+command+Environment.NewLine);
        if(command.Contains("Checks"))CourierPolishPreferences.Capture();
        if(!EditorApplication.ExecuteMenuItem(command))throw new InvalidOperationException("Check menu unavailable: "+command);
    }
}
#endif

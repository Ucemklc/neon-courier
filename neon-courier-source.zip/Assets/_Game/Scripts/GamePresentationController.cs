using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using TMPro;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

[DisallowMultipleComponent]
public sealed class GamePresentationController : MonoBehaviour
{
    private sealed class TextState
    {
        public string source;
        public string lastApplied;
        public float baseFontSize;
        public Color baseColor;
        public FontStyles baseFontStyle;
    }

    private const string LanguageKey = "NeonCourier.Language";
    private static readonly Color Accent = new Color(0.15f, 0.91f, 1f, 1f);
    private static readonly Color Panel = new Color(0.015f, 0.035f, 0.12f, 0.97f);
    private static readonly Dictionary<string, string> TurkishToEnglish = BuildTurkishDictionary();
    private static readonly Dictionary<string, string> EnglishToTurkish = BuildEnglishDictionary();
    private static readonly Dictionary<string, Regex> WordRegexes = new Dictionary<string, Regex>(StringComparer.OrdinalIgnoreCase);

    private readonly Dictionary<TMP_Text, TextState> tmpStates = new Dictionary<TMP_Text, TextState>();
    private readonly Dictionary<Text, TextState> legacyStates = new Dictionary<Text, TextState>();
    private readonly List<TMP_Text> tmpCache = new List<TMP_Text>();
    private readonly List<Text> legacyCache = new List<Text>();
    private readonly HashSet<Button> styledMenuButtons = new HashSet<Button>();

    private GameManager gameManager;
    private GameFeedbackController feedbackController;
    private HUDController hudController;
    public bool IsEnglish => english;
    private bool english;
    private bool showControls;
    private bool showSettings;
    public bool IsOverlayOpen => showControls || showSettings;
    private float nextRefreshTime;
    private float nextCacheTime;
    private AudioClip buttonClip;
    private GUIStyle buttonStyle;
    private GUIStyle panelStyle;
    private GUIStyle headerStyle;
    private GUIStyle helpStyle;

    [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
    private static void AttachToGameManager()
    {
        SceneManager.sceneLoaded -= AttachToLoadedScene;
        SceneManager.sceneLoaded += AttachToLoadedScene;
        AttachToLoadedScene(SceneManager.GetActiveScene(), LoadSceneMode.Single);
    }

    private static void AttachToLoadedScene(Scene scene, LoadSceneMode mode)
    {
        GameManager manager = FindAnyObjectByType<GameManager>();
        if (manager != null && manager.GetComponent<GamePresentationController>() == null)
            manager.gameObject.AddComponent<GamePresentationController>();
    }

    private void Awake()
    {
        gameManager = GetComponent<GameManager>();
        feedbackController = FindAnyObjectByType<GameFeedbackController>();
        hudController = FindAnyObjectByType<HUDController>();
        english = PlayerPrefs.GetInt(LanguageKey, 0) == 1;
        buttonClip = Resources.Load<AudioClip>("Audio/ButtonClick");
        RebuildTextCache();
        TranslateCachedText();
    }

    private void Update()
    {
        if (Time.unscaledTime >= nextCacheTime)
        {
            RebuildTextCache();
            nextCacheTime = Time.unscaledTime + 0.9f;
        }

        if (Time.unscaledTime >= nextRefreshTime)
        {
            TranslateCachedText();
            nextRefreshTime = Time.unscaledTime + 0.2f;
        }
    }

    private void RebuildTextCache()
    {
        tmpCache.Clear();
        legacyCache.Clear();

        TMP_Text[] tmpTexts = Resources.FindObjectsOfTypeAll<TMP_Text>();
        foreach (TMP_Text text in tmpTexts)
        {
            if (text == null || !text.gameObject.scene.IsValid()) continue;
            if (text.GetComponentInParent<CourierPanelSurface>(true) != null || text.GetComponentInParent<CourierJourneyHUD>(true) != null) continue;
            if (text.GetComponentInParent<CourierExpansionUI>() != null) continue;
            if (text.GetComponentInParent<CourierGarageUI>(true) != null) continue;
            tmpCache.Add(text);
        }

        Text[] legacyTexts = Resources.FindObjectsOfTypeAll<Text>();
        foreach (Text text in legacyTexts)
        {
            if (text == null || !text.gameObject.scene.IsValid()) continue;
            if (text.GetComponentInParent<CourierExpansionUI>() != null) continue;
            legacyCache.Add(text);
        }
    }

    private void TranslateCachedText()
    {
        for (int index = 0; index < tmpCache.Count; index++)
        {
            TMP_Text text = tmpCache[index];
            if (text == null) continue;
            if (text.GetComponentInParent<CourierPanelSurface>(true) != null || text.GetComponentInParent<CourierJourneyHUD>(true) != null) continue;

            if (!tmpStates.TryGetValue(text, out TextState state))
            {
                state = new TextState
                {
                    source = text.text ?? string.Empty,
                    baseFontSize = text.fontSize,
                    baseColor = text.color,
                    baseFontStyle = text.fontStyle
                };
                tmpStates.Add(text, state);
            }
            else if (!string.Equals(text.text, state.lastApplied, StringComparison.Ordinal))
            {
                state.source = text.text ?? string.Empty;
            }

            string localized = Translate(state.source);
            if (!string.Equals(text.text, localized, StringComparison.Ordinal))
                text.text = localized;
            state.lastApplied = localized;

            // These layouts own their contrast and typography, including while closed.
            if (text.GetComponentInParent<CourierMenuButton>(true) || text.GetComponentInParent<CourierCharacterMenu>(true) || text.GetComponentInParent<CourierResultsMenu>(true)) continue;

            bool isMainMenu = gameManager != null && gameManager.IsMainMenuActive;
            bool title = isMainMenu && IsMenuTitle(text, state.source);
            Button menuButton = isMainMenu
                ? text.GetComponentInParent<Button>()
                : null;
            if (title)
            {
                text.fontStyle = FontStyles.Bold;
                text.fontSize = state.baseFontSize * 1.08f;
                text.color = Accent;
            }
            else if (menuButton != null)
            {
                text.fontSize = state.baseFontSize;
                text.color = Color.white;
                text.fontStyle = FontStyles.Bold;
                StyleMenuButton(menuButton);
            }
            else
            {
                text.fontSize = state.baseFontSize;
                text.color = state.baseColor;
                text.fontStyle = state.baseFontStyle;
            }
        }

        for (int index = 0; index < legacyCache.Count; index++)
        {
            Text text = legacyCache[index];
            if (text == null) continue;

            if (!legacyStates.TryGetValue(text, out TextState state))
            {
                state = new TextState { source = text.text };
                legacyStates.Add(text, state);
            }
            else if (!string.Equals(text.text, state.lastApplied, StringComparison.Ordinal))
            {
                state.source = text.text;
            }

            string localized = Translate(state.source);
            if (!string.Equals(text.text, localized, StringComparison.Ordinal))
                text.text = localized;
            state.lastApplied = localized;
        }
    }

    private bool IsMenuTitle(TMP_Text text, string source)
    {
        if (text == null || string.IsNullOrEmpty(source)) return false;

        string name = text.gameObject.name.ToLowerInvariant();
        string content = source.ToUpperInvariant();
        return name.Contains("title") || name.Contains("logo") ||
               content.Contains("NEON COURIER") || content.Contains("NEON RUNNER");
    }

    private string Translate(string source)
    {
        if (string.IsNullOrEmpty(source)) return source;

        string trimmed = source.Trim();
        string exact;
        Dictionary<string, string> exactMap = english ? TurkishToEnglish : EnglishToTurkish;
        if (exactMap.TryGetValue(trimmed, out exact))
            return source.Substring(0, source.Length - source.TrimStart().Length) + exact +
                   source.Substring(source.TrimEnd().Length);

        string result = source;
        Dictionary<string, string> words = exactMap;
        foreach (KeyValuePair<string, string> pair in words)
        {
            if (pair.Key.Length < 3 || pair.Key.Contains("\n")) continue;
            Regex wordRegex;
            if (!WordRegexes.TryGetValue(pair.Key, out wordRegex))
            {
                string pattern = "(?<![\\p{L}])" + Regex.Escape(pair.Key) + "(?![\\p{L}])";
                wordRegex = new Regex(pattern, RegexOptions.IgnoreCase | RegexOptions.CultureInvariant | RegexOptions.Compiled);
                WordRegexes.Add(pair.Key, wordRegex);
            }
            result = wordRegex.Replace(result, match => MatchCase(match.Value, pair.Value));
        }

        return result;
    }

    private static string MatchCase(string original, string replacement)
    {
        if (original.ToUpperInvariant() == original) return replacement.ToUpperInvariant();
        if (original.ToLowerInvariant() == original) return replacement.ToLowerInvariant();
        if (original.Length > 0 && char.IsUpper(original[0]))
            return char.ToUpperInvariant(replacement[0]) + replacement.Substring(1);
        return replacement;
    }

    private void OnGUI()
    {
        var missions=FindAnyObjectByType<DailyMissionPanelController>();if(missions&&missions.IsOpen)return;
        var workshop = GetComponent<CourierExpansionUI>();
        if (workshop != null && workshop.WardrobeOpen) return;
        if (gameManager == null || !gameManager.IsMainMenuActive) return;
        var characterMenu=FindAnyObjectByType<CourierCharacterMenu>();
        var garage=gameManager?gameManager.GetComponent<CourierGarageUI>():null;
        if(garage&&garage.IsOpen)return;
        if (characterMenu && characterMenu.gameObject.activeInHierarchy) return;
        EnsureStyles();
        Color oldBackgroundColor = GUI.backgroundColor;
        GUI.backgroundColor = new Color(0.025f, 0.32f, 0.42f, 0.96f);
        Rect safeArea = Screen.safeArea;
        if (safeArea.width <= 0f || safeArea.height <= 0f)
            safeArea = new Rect(0f, 0f, Screen.width, Screen.height);

        float margin = Mathf.Max(14f, Screen.width * 0.025f);
        float width = Mathf.Min(
            Mathf.Clamp(safeArea.width * 0.21f, 118f, 190f),
            safeArea.width - margin * 2f
        );
        float height = Mathf.Clamp(Screen.height * 0.052f, 38f, 58f);
        float safeTop = Screen.height - safeArea.yMax;
        float safeBottom = Screen.height - safeArea.yMin;
        Rect languageRect = new Rect(
            safeArea.xMax - width - margin,
            safeTop + margin,
            width,
            height
        );
        string languageLabel = english ? "TÜRKÇE  •  EN" : "ENGLISH  •  TR";

        if (GUI.Button(languageRect, languageLabel, buttonStyle))
        {
            english = !english;
            PlayerPrefs.SetInt(LanguageKey, english ? 1 : 0);
            PlayerPrefs.Save();
            TranslateCachedText();
            PlayButtonSound();
        }

        if (gameManager == null || !gameManager.IsMainMenuActive)
        {
            showControls = false;
            showSettings = false;
            SetMainMenuButtonsVisible(false);
            GUI.backgroundColor = oldBackgroundColor;
            return;
        }

        Rect settingsRect = new Rect(
            safeArea.xMin + margin,
            safeTop + margin,
            width,
            height
        );
        if (GUI.Button(settingsRect, english ? "SETTINGS" : "AYARLAR", buttonStyle))
        {
            showSettings = true;
            showControls = false;
            SetMainMenuButtonsVisible(false);
            PlayButtonSound();
        }

        Rect controlsRect = new Rect(
            safeArea.xMax - width - margin,
            safeBottom - height - margin,
            width,
            height
        );
        string controlsLabel = english ? "CONTROLS" : "KONTROLLER";
        if (GUI.Button(controlsRect, controlsLabel, buttonStyle))
        {
            showControls = true;
            showSettings = false;
            SetMainMenuButtonsVisible(false);
            PlayButtonSound();
        }

        if (showSettings)
        {
            DrawSettingsPanel(safeArea);
            GUI.backgroundColor = oldBackgroundColor;
            return;
        }

        if (!showControls)
        {
            GUI.backgroundColor = oldBackgroundColor;
            return;
        }

        Rect controlsPanel = GetPanelRect(safeArea);
        DrawPanelBackground(controlsPanel);

        float inset = controlsPanel.width * 0.07f;
        GUI.Label(
            new Rect(controlsPanel.x + inset, controlsPanel.y + inset * 0.45f, controlsPanel.width - inset * 2f, controlsPanel.height * 0.16f),
            english ? "HOW TO PLAY" : "NASIL OYNANIR?",
            headerStyle
        );

        string instructions = english
            ? "SWIPE LEFT / RIGHT   Change lanes\n\nSWIPE UP   Jump over low barriers\n\nSWIPE DOWN   Slide under overhead gates\n\nCollect parcels and deliver them at the glowing drop zone. A red shutter closes the whole lane: switch lanes before it reaches you."
            : "SOLA / SAĞA KAYDIR   Şerit değiştir\n\nYUKARI KAYDIR   Alçak engellerden zıpla\n\nAŞAĞI KAYDIR   Üst kapıların altından kay\n\nPaketleri topla ve ışıklı teslim alanına ulaştır. Kırmızı kapalı bariyer tüm şeridi kapatır; sana ulaşmadan şerit değiştir.";
        GUI.Label(
            new Rect(controlsPanel.x + inset, controlsPanel.y + controlsPanel.height * 0.24f, controlsPanel.width - inset * 2f, controlsPanel.height * 0.53f),
            instructions,
            helpStyle
        );

        Rect closeRect = new Rect(
            controlsPanel.x + inset,
            controlsPanel.yMax - controlsPanel.height * 0.17f,
            controlsPanel.width - inset * 2f,
            controlsPanel.height * 0.12f
        );
        if (GUI.Button(closeRect, english ? "CLOSE" : "KAPAT", buttonStyle))
        {
            showControls = false;
            SetMainMenuButtonsVisible(true);
            PlayButtonSound();
        }
    }

    private void DrawSettingsPanel(Rect safeArea)
    {
        Rect panelRect = GetPanelRect(safeArea);
        DrawPanelBackground(panelRect);

        float inset = panelRect.width * 0.07f;
        GUI.Label(
            new Rect(panelRect.x + inset, panelRect.y + panelRect.height * 0.07f, panelRect.width - inset * 2f, panelRect.height * 0.16f),
            english ? "GAME SETTINGS" : "OYUN AYARLARI",
            headerStyle
        );

        float rowHeight = panelRect.height * 0.15f;
        float rowY = panelRect.y + panelRect.height * 0.29f;
        Rect soundRect = new Rect(
            panelRect.x + inset,
            rowY,
            panelRect.width - inset * 2f,
            rowHeight
        );
        string soundLabel = english
            ? (gameManager.IsSoundEnabled ? "SOUND  •  ON" : "SOUND  •  OFF")
            : (gameManager.IsSoundEnabled ? "SES  •  AÇIK" : "SES  •  KAPALI");
        if (GUI.Button(soundRect, soundLabel, buttonStyle))
        {
            gameManager.ToggleSound();
            PlayButtonSound();
        }

        Rect vibrationRect = new Rect(
            panelRect.x + inset,
            rowY + rowHeight + panelRect.height * 0.06f,
            panelRect.width - inset * 2f,
            rowHeight
        );
        bool hasVibrationSetting = feedbackController != null;
        bool vibrationEnabled = hasVibrationSetting && feedbackController.IsVibrationEnabled;
        string vibrationLabel = !hasVibrationSetting
            ? (english ? "VIBRATION  •  N/A" : "TİTREŞİM  •  YOK")
            : english
                ? (vibrationEnabled ? "VIBRATION  •  ON" : "VIBRATION  •  OFF")
                : (vibrationEnabled ? "TİTREŞİM  •  AÇIK" : "TİTREŞİM  •  KAPALI");
        bool previousGuiEnabled = GUI.enabled;
        GUI.enabled = feedbackController != null;
        if (GUI.Button(vibrationRect, vibrationLabel, buttonStyle))
        {
            feedbackController.SetVibrationEnabled(!vibrationEnabled);
            PlayButtonSound();
        }
        GUI.enabled = previousGuiEnabled;

        GUI.Label(
            new Rect(panelRect.x + inset, vibrationRect.yMax + panelRect.height * 0.045f, panelRect.width - inset * 2f, panelRect.height * 0.11f),
            english ? "Separate music plays in the menu and during runs." : "Ana menü ve koşu sırasında farklı müzik çalar.",
            helpStyle
        );

        Rect closeRect = new Rect(
            panelRect.x + inset,
            panelRect.yMax - panelRect.height * 0.17f,
            panelRect.width - inset * 2f,
            panelRect.height * 0.12f
        );
        if (GUI.Button(closeRect, english ? "DONE" : "TAMAM", buttonStyle))
        {
            showSettings = false;
            SetMainMenuButtonsVisible(true);
            PlayButtonSound();
        }
    }

    private void SetMainMenuButtonsVisible(bool visible)
    {
        if (hudController != null)
            hudController.SetMainMenuPanelVisible(visible);
    }

    private Rect GetPanelRect(Rect safeArea)
    {
        float panelWidth = Mathf.Min(safeArea.width * 0.88f, 760f);
        float panelHeight = Mathf.Min(safeArea.height * 0.66f, 520f);
        float safeTop = Screen.height - safeArea.yMax;
        return new Rect(
            safeArea.xMin + (safeArea.width - panelWidth) * 0.5f,
            safeTop + (safeArea.height - panelHeight) * 0.5f,
            panelWidth,
            panelHeight
        );
    }

    private void DrawPanelBackground(Rect panelRect)
    {
        Color oldGuiColor = GUI.color;
        GUI.color = Panel;
        GUI.Box(panelRect, GUIContent.none, panelStyle);
        GUI.color = oldGuiColor;
    }

    private void StyleMenuButton(Button button)
    {
        if (button == null || button.GetComponent<CourierMenuButton>() != null || !styledMenuButtons.Add(button))
            return;

        ColorBlock colors = button.colors;
        colors.normalColor = new Color(0.035f, 0.11f, 0.27f, 0.98f);
        colors.highlightedColor = new Color(0.08f, 0.55f, 0.72f, 1f);
        colors.pressedColor = new Color(0.04f, 0.78f, 0.88f, 1f);
        colors.selectedColor = colors.highlightedColor;
        colors.disabledColor = new Color(0.16f, 0.2f, 0.3f, 0.75f);
        colors.colorMultiplier = 1f;
        colors.fadeDuration = 0.08f;
        button.colors = colors;
        button.transition = Selectable.Transition.ColorTint;
    }

    private void EnsureStyles()
    {
        if (buttonStyle == null)
        {
            buttonStyle = new GUIStyle(GUI.skin.button)
            {
                alignment = TextAnchor.MiddleCenter,
                fontStyle = FontStyle.Bold,
                wordWrap = true
            };
            panelStyle = new GUIStyle(GUI.skin.box);
            headerStyle = new GUIStyle(GUI.skin.label)
            {
                alignment = TextAnchor.MiddleCenter,
                fontStyle = FontStyle.Bold
            };
            helpStyle = new GUIStyle(GUI.skin.label)
            {
                alignment = TextAnchor.UpperLeft,
                wordWrap = true
            };
        }

        int fontSize = Mathf.RoundToInt(Mathf.Clamp(Screen.width * 0.025f, 15f, 27f));
        buttonStyle.fontSize = fontSize;
        buttonStyle.normal.textColor = Color.white;
        buttonStyle.hover.textColor = Accent;
        buttonStyle.active.textColor = Accent;
        panelStyle.normal.background = GUI.skin.box.normal.background;
        panelStyle.normal.textColor = Color.white;
        headerStyle.fontSize = Mathf.RoundToInt(fontSize * 1.45f);
        headerStyle.normal.textColor = Accent;
        helpStyle.fontSize = Mathf.RoundToInt(fontSize * 0.92f);
        helpStyle.normal.textColor = Color.white;
    }

    private void PlayButtonSound()
    {
        if (buttonClip == null || (gameManager != null && !gameManager.IsSoundEnabled)) return;
        Vector3 position = Camera.main != null ? Camera.main.transform.position : transform.position;
        AudioSource.PlayClipAtPoint(buttonClip, position, 0.35f);
    }

    private static Dictionary<string, string> BuildTurkishDictionary()
    {
        var map = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        Add(map,
            "OYNA|PLAY", "ANA MENÜ|MAIN MENU", "SES AÇIK|SOUND ON", "SES KAPALI|SOUND OFF",
            "OYUN DURAKLATILDI|GAME PAUSED", "OYUN BİTTİ|GAME OVER", "GÜNLÜK GÖREVLER|DAILY MISSIONS",
            "KARAKTERLER|CHARACTERS", "KARAKTER|CHARACTER", "ŞEHRİ GEÇ • PAKETLERİ TESLİM ET|RACE THE CITY • DELIVER THE PACKAGES",
            "SOLA KAYDIR\nŞERİT DEĞİŞTİR|SWIPE LEFT\nCHANGE LANES", "ATLA|JUMP", "DURAKLAT|PAUSE",
            "DEVAM ET|RESUME", "YENİDEN BAŞLA|RESTART", "GİZLİLİK|PRIVACY", "KAPAT / CLOSE|CLOSE",
            "Diyalog metni burada görünecek.|Dialogue will appear here.", "EN İYİ|BEST", "DOKUN|TAP",
            "EN İYİ SKOR|BEST SCORE", "TOPLAM COIN|TOTAL COINS", "TESLİM EDİLEN PAKET|PACKAGES DELIVERED",
            "KAZANILAN COIN|COINS EARNED", "500 METRE KOS|RUN 500 METERS",
            "AYNI KOSUYA 1 CANLA DEVAM ET|CONTINUE THIS RUN WITH 1 LIFE", "AYNI KOŞUYA 1 CANLA DEVAM ET|CONTINUE THIS RUN WITH 1 LIFE",
            "X3 SEVİYESİNE ULAŞ|REACH LEVEL 3", "MESAFE|DISTANCE", "SKOR|SCORE", "COIN|COIN", "PAKET|PACKAGE",
            "GÖREVLER|MISSIONS", "GÖREV|MISSION", "TAMAMLA|COMPLETE", "SEÇİLİ|SELECTED", "KİLİTLİ|LOCKED",
            "ÜCRETSİZ|FREE", "ÇİFT COIN|DOUBLE COINS", "MIKNATIS|MAGNET",
            "KALKAN|SHIELD", "CAN|LIFE", "TOPLA|COLLECT", "TESLİM ET|DELIVER", "BAŞLA|START",
            "YENİDEN|AGAIN", "AÇ|UNLOCK", "SAĞ|RIGHT", "SOL|LEFT", "SOLA|LEFT", "YUKARI|UP", "AŞAĞI|DOWN",
            "KAYDIR|SWIPE", "ŞERİT|LANE", "DEĞİŞTİR|CHANGE", "ÇIKIŞ|EXIT", "KONTROLLER|CONTROLS",
            "ANLATICIF|NARRATOR", "KAZAN|EARN", "KOŞ|RUN", "GÜNLÜK|DAILY", "METRE|METERS", "SONUÇLARI GÖR|VIEW RESULTS");
        return map;
    }

    private static Dictionary<string, string> BuildEnglishDictionary()
    {
        var map = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        Add(map,
            "PLAY|OYNA", "MAIN MENU|ANA MENÜ", "SOUND ON|SES AÇIK", "SOUND OFF|SES KAPALI",
            "GAME PAUSED|OYUN DURAKLATILDI", "GAME OVER|OYUN BİTTİ", "DAILY MISSIONS|GÜNLÜK GÖREVLER",
            "CHARACTERS|KARAKTERLER", "CHARACTER|KARAKTER", "RACE THE CITY • DELIVER THE PACKAGES|ŞEHRİ GEÇ • PAKETLERİ TESLİM ET",
            "SWIPE LEFT\nCHANGE LANES|SOLA KAYDIR\nŞERİT DEĞİŞTİR", "JUMP|ATLA", "PAUSE|DURAKLAT",
            "RESUME|DEVAM ET", "RESTART|YENİDEN BAŞLA", "PRIVACY|GİZLİLİK", "CLOSE|KAPAT",
            "DIALOGUE WILL APPEAR HERE.|Diyalog metni burada görünecek.", "BEST|EN İYİ", "TAP|DOKUN",
            "BEST SCORE|EN İYİ SKOR", "TOTAL COINS|TOPLAM COIN", "PACKAGES DELIVERED|TESLİM EDİLEN PAKET",
            "COINS EARNED|KAZANILAN COIN", "RUN 500 METERS|500 METRE KOŞ",
            "CONTINUE THIS RUN WITH 1 LIFE|AYNI KOŞUYA 1 CANLA DEVAM ET", "REACH LEVEL 3|X3 SEVİYESİNE ULAŞ",
            "DISTANCE|MESAFE", "SCORE|SKOR", "COIN|COIN", "PACKAGE|PAKET",
            "MISSIONS|GÖREVLER", "MISSION|GÖREV", "COMPLETE|TAMAMLA", "SELECTED|SEÇİLİ", "LOCKED|KİLİTLİ",
            "FREE|ÜCRETSİZ", "DOUBLE COINS|ÇİFT COIN", "MAGNET|MIKNATIS",
            "SHIELD|KALKAN", "LIFE|CAN", "COLLECT|TOPLA", "DELIVER|TESLİM ET", "START|BAŞLA",
            "AGAIN|YENİDEN", "UNLOCK|AÇ", "RIGHT|SAĞ", "LEFT|SOL", "UP|YUKARI", "DOWN|AŞAĞI",
            "SWIPE|KAYDIR", "LANE|ŞERİT", "CHANGE|DEĞİŞTİR", "EXIT|ÇIKIŞ", "CONTROLS|KONTROLLER",
            "STORY|ANLATICI", "EARN|KAZAN", "RUN|KOŞ", "DAILY|GÜNLÜK", "METERS|METRE", "VIEW RESULTS|SONUÇLARI GÖR");
        return map;
    }

    private static void Add(Dictionary<string, string> map, params string[] pairs)
    {
        foreach (string pair in pairs)
        {
            int divider = pair.IndexOf('|');
            if (divider <= 0 || divider >= pair.Length - 1) continue;
            map[pair.Substring(0, divider)] = pair.Substring(divider + 1);
        }
    }
}

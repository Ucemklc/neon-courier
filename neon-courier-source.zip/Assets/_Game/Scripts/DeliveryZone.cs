using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[DisallowMultipleComponent]
[RequireComponent(typeof(Collider))]
[RequireComponent(typeof(Rigidbody))]
public sealed class DeliveryZone : MonoBehaviour
{
    [Header("Visual Feedback")]
    [SerializeField]
    private Transform visualRoot;

    [SerializeField]
    private ParticleSystem deliveryParticles;

    [SerializeField, Min(0.05f)]
    private float pulseDuration =
        0.4f;

    [SerializeField, Min(1f)]
    private float pulseScale =
        1.35f;

    [Header("NPC Delivery Feedback")]
    [SerializeField]
    private NPCDeliveryFeedback npcDeliveryFeedback;

    [SerializeField]
    private bool automaticallyFindNPCFeedback =
        true;

    [Header("Delivery Camera Focus")]
    [SerializeField]
    private CameraFollow cameraFollow;

    [Tooltip(
        "Teslimat sÄ±rasÄ±nda kameranÄ±n bakacaÄŸÄ± NPC kÃ¶kÃ¼. " +
        "DeliveryNPC veya Ã¼st gÃ¶vde hedefi baÄŸlanabilir."
    )]
    [SerializeField]
    private Transform npcCameraFocusTarget;

    [SerializeField]
    private bool automaticallyFindCameraFollow =
        true;

    [Header("Debug")]
    [SerializeField]
    private bool debugLogs =
        false;

    public static readonly HashSet<DeliveryZone> ActiveStops=new HashSet<DeliveryZone>();
    [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.SubsystemRegistration)]
    private static void ClearStops(){ActiveStops.Clear();}
    public bool IsDelivered=>deliveryProcessed;
    public bool ThrowAttempted {get;set;}
    public Vector3 DestinationPosition=>npcCameraFocusTarget?npcCameraFocusTarget.position+Vector3.up:transform.position+new Vector3(4.8f,1.4f,2);
    private bool deliveryProcessed;
    public void SetDestinationFocus(Transform focus) { npcCameraFocusTarget = focus; }

    private Vector3 normalVisualScale =
        Vector3.one;

    private Coroutine pulseCoroutine;

    private Collider zoneCollider;
    private Rigidbody zoneRigidbody;

    private void Awake()
    {
        ResolveComponents();
        ConfigurePhysics();
        CacheVisualScale();

        ResolveNPCFeedback();
        ResolveCameraFollow();
        ResolveNPCFocusTarget();
    }

    private void OnEnable()
    {
        ActiveStops.Add(this);
        ResolveComponents();
        ConfigurePhysics();

        ResolveNPCFeedback();
        ResolveCameraFollow();
        ResolveNPCFocusTarget();

        ResetZone();
    }

    private void OnDisable()
    {
        ActiveStops.Remove(this);
        StopPulseCoroutine();
        RestoreVisual();
        StopDeliveryParticles();

        if (npcDeliveryFeedback != null)
        {
            npcDeliveryFeedback.ResetFeedback();
        }
    }

    public void ResetZone()
    {
        deliveryProcessed = false;ThrowAttempted=false;

        StopPulseCoroutine();
        RestoreVisual();
        StopDeliveryParticles();

        ResolveNPCFeedback();
        ResolveCameraFollow();
        ResolveNPCFocusTarget();

        if (npcDeliveryFeedback != null)
        {
            npcDeliveryFeedback.ResetFeedback();
        }
    }

    private void OnTriggerEnter(Collider other)
    {if(IsPlayerCollider(other))TryDeliver();}
    public int TryDeliver()
    {
        if(deliveryProcessed||!isActiveAndEnabled||!CourierJourney.Active)return 0;
        int count=GameManager.Instance.DeliverCarriedPackages();if(count<=0)return 0;
        deliveryProcessed=true;var stop=GetComponent<CourierDeliveryStop>();
        CourierRouteContract.Instance?.CompleteStop(stop?stop.Variant:0,transform.position.z,count);
        PlayDeliveryFeedback(count);return count;
    }

    private bool IsPlayerCollider(
        Collider other
    )
    {
        if (other == null)
        {
            return false;
        }

        if (other.CompareTag("Player"))
        {
            return true;
        }

        RunnerController runner =
            other.GetComponentInParent
                <RunnerController>();

        return runner != null;
    }

    private void PlayDeliveryFeedback(
        int deliveredPackageCount
    )
    {
        PlayDeliveryParticles();

        ResolveNPCFeedback();

        if (npcDeliveryFeedback != null)
        {
            npcDeliveryFeedback
                .PlayDeliveryFeedback(
                    deliveredPackageCount
                );
        }
        else if (debugLogs)
        {
            Debug.LogWarning(
                "DeliveryZone: NPCDeliveryFeedback bulunamadÄ±.",
                this
            );
        }

        PlayDeliveryCameraFocus();
        GetComponent<CourierDeliveryStop>()?.PlayFeedback();

        if (visualRoot == null)
        {
            return;
        }

        StopPulseCoroutine();

        pulseCoroutine =
            StartCoroutine(
                PulseRoutine()
            );
    }

    private void PlayDeliveryCameraFocus()
    {
        ResolveCameraFollow();
        ResolveNPCFocusTarget();

        if (
            cameraFollow == null ||
            npcCameraFocusTarget == null
        )
        {
            if (debugLogs)
            {
                Debug.LogWarning(
                    "DeliveryZone: Kamera veya NPC kamera hedefi bulunamadÄ±.",
                    this
                );
            }

            return;
        }

        cameraFollow.PlayDeliveryFocus(
            npcCameraFocusTarget
        );
    }

    private IEnumerator PulseRoutine()
    {
        float elapsedTime = 0f;

        while (
            elapsedTime <
            pulseDuration
        )
        {
            elapsedTime +=
                Time.unscaledDeltaTime;

            float progress =
                Mathf.Clamp01(
                    elapsedTime /
                    pulseDuration
                );

            float wave =
                Mathf.Sin(
                    progress *
                    Mathf.PI
                );

            float currentScale =
                Mathf.Lerp(
                    1f,
                    pulseScale,
                    wave
                );

            if (visualRoot != null)
            {
                visualRoot.localScale =
                    normalVisualScale *
                    currentScale;
            }

            yield return null;
        }

        RestoreVisual();

        pulseCoroutine = null;
    }

    private void PlayDeliveryParticles()
    {
        if (deliveryParticles == null)
        {
            return;
        }

        deliveryParticles.Stop(
            true,
            ParticleSystemStopBehavior
                .StopEmittingAndClear
        );

        deliveryParticles.Play(true);
    }

    private void StopDeliveryParticles()
    {
        if (deliveryParticles == null)
        {
            return;
        }

        deliveryParticles.Stop(
            true,
            ParticleSystemStopBehavior
                .StopEmittingAndClear
        );
    }

    private void StopPulseCoroutine()
    {
        if (pulseCoroutine == null)
        {
            return;
        }

        StopCoroutine(
            pulseCoroutine
        );

        pulseCoroutine = null;
    }

    private void RestoreVisual()
    {
        if (visualRoot == null)
        {
            return;
        }

        visualRoot.localScale =
            normalVisualScale;
    }

    private void ResolveComponents()
    {
        if (zoneCollider == null)
        {
            zoneCollider =
                GetComponent<Collider>();
        }

        if (zoneRigidbody == null)
        {
            zoneRigidbody =
                GetComponent<Rigidbody>();
        }

        if (visualRoot == null)
        {
            visualRoot =
                transform.Find(
                    "DeliveryPad"
                );
        }
    }

    private void ConfigurePhysics()
    {
        if (zoneCollider != null)
        {
            zoneCollider.isTrigger =
                true;
        }

        if (zoneRigidbody != null)
        {
            zoneRigidbody.useGravity =
                false;

            zoneRigidbody.isKinematic =
                true;

            zoneRigidbody.detectCollisions =
                true;
        }
    }

    private void CacheVisualScale()
    {
        if (visualRoot == null)
        {
            return;
        }

        normalVisualScale =
            visualRoot.localScale;
    }

    private void ResolveNPCFeedback()
    {
        if (npcDeliveryFeedback != null)
        {
            return;
        }

        if (!automaticallyFindNPCFeedback)
        {
            return;
        }

        npcDeliveryFeedback =
            GetComponentInChildren
                <NPCDeliveryFeedback>(
                    true
                );
    }

    private void ResolveCameraFollow()
    {
        if (cameraFollow != null)
        {
            return;
        }

        if (!automaticallyFindCameraFollow)
        {
            return;
        }

        Camera mainCamera =
            Camera.main;

        if (mainCamera != null)
        {
            cameraFollow =
                mainCamera.GetComponent
                    <CameraFollow>();
        }

        if (cameraFollow == null)
        {
            cameraFollow =
                FindAnyObjectByType
                    <CameraFollow>();
        }
    }

    private void ResolveNPCFocusTarget()
    {
        if (npcCameraFocusTarget != null)
        {
            return;
        }

        Animator npcAnimator =
            GetComponentInChildren
                <Animator>(
                    true
                );

        if (npcAnimator != null)
        {
            npcCameraFocusTarget =
                npcAnimator.transform;
        }
    }

    private void OnValidate()
    {
        pulseDuration =
            Mathf.Max(
                0.05f,
                pulseDuration
            );

        pulseScale =
            Mathf.Max(
                1f,
                pulseScale
            );

        if (
            npcDeliveryFeedback == null &&
            automaticallyFindNPCFeedback
        )
        {
            npcDeliveryFeedback =
                GetComponentInChildren
                    <NPCDeliveryFeedback>(
                        true
                    );
        }
    }
}

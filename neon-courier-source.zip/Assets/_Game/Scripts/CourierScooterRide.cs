using UnityEngine;

[DefaultExecutionOrder(80)]
public sealed class CourierScooterRide : MonoBehaviour
{
    public static CourierScooterRide Instance{get;private set;}
    private RunnerController runner;
    private Transform bike;
    private Renderer[] panels;
    private int lastSkin=-1;
    private float startZ=float.PositiveInfinity,endZ=float.NegativeInfinity;
    public bool IsRiding=>runner&&runner.transform.position.z>=startZ&&runner.transform.position.z<endZ&&!runner.IsHoverboardMovementActive&&GameManager.Instance&&!GameManager.Instance.IsGameOver&&!GameManager.Instance.IsMainMenuActive;
    public float SpeedFactor=>IsRiding?1.10f:1;
    public float Remaining=>runner?Mathf.Max(0,endZ-runner.transform.position.z):0;
    private void Awake(){Instance=this;}
    private void Start()
    {
        runner=FindAnyObjectByType<RunnerController>();var prefab=Resources.Load<GameObject>("CourierJourney/RideScooter");
        if(prefab&&runner){bike=Instantiate(prefab,runner.transform,false).transform;panels=bike.GetComponentsInChildren<Renderer>();bike.gameObject.SetActive(false);}
        GetComponent<GameManager>().MainMenuChanged+=Menu;
    }
    private void OnDestroy(){GetComponent<GameManager>().MainMenuChanged-=Menu;if(bike)Destroy(bike.gameObject);if(Instance==this)Instance=null;}
    private void Menu(bool open){if(open){startZ=float.PositiveInfinity;endZ=float.NegativeInfinity;if(bike)bike.gameObject.SetActive(false);}}
    public void Begin(float start,float end){if(!CourierJourney.Active||end<=start)return;startZ=start;endZ=end;}
    private void LateUpdate()
    {
        if(!bike)return;bike.gameObject.SetActive(IsRiding);
        if(IsRiding)
        {
            var scale=runner.transform.lossyScale;
            bike.localScale=new Vector3(1/Mathf.Max(.01f,Mathf.Abs(scale.x)),1/Mathf.Max(.01f,Mathf.Abs(scale.y)),1/Mathf.Max(.01f,Mathf.Abs(scale.z)));
            bike.SetPositionAndRotation(runner.transform.position+Vector3.down*.82f,runner.transform.rotation);
            if(lastSkin!=CourierBackpackStyle.Skin)
            {
                lastSkin=CourierBackpackStyle.Skin;var block=new MaterialPropertyBlock();block.SetColor("_BaseColor",CourierBackpackStyle.Accents[lastSkin]);
                foreach(var panel in panels)if(panel.sharedMaterial&&panel.sharedMaterial.name=="SafetyTangerine")panel.SetPropertyBlock(block);
            }
        }
    }
    public void ApplyPose(Animator rig)
    {
        if(!IsRiding||!rig||rig!=runner.CurrentAnimator||!rig.isHuman||!CourierJourney.Active)return;
        // A standing delivery scooter keeps the normal controller's jump/slide collision shape.
        Align(rig,HumanBodyBones.LeftUpperArm,HumanBodyBones.LeftLowerArm,new Vector3(-.08f,-.50f,.25f));
        Align(rig,HumanBodyBones.LeftLowerArm,HumanBodyBones.LeftHand,new Vector3(0,-.08f,.45f));
        Align(rig,HumanBodyBones.RightUpperArm,HumanBodyBones.RightLowerArm,new Vector3(.08f,-.50f,.25f));
        Align(rig,HumanBodyBones.RightLowerArm,HumanBodyBones.RightHand,new Vector3(0,-.08f,.45f));
        if(!runner.IsSliding)
        {
            Align(rig,HumanBodyBones.LeftUpperLeg,HumanBodyBones.LeftLowerLeg,new Vector3(-.1f,-.7f,.08f));
            Align(rig,HumanBodyBones.LeftLowerLeg,HumanBodyBones.LeftFoot,new Vector3(0,-.7f,-.08f));
            Align(rig,HumanBodyBones.RightUpperLeg,HumanBodyBones.RightLowerLeg,new Vector3(.1f,-.7f,-.12f));
            Align(rig,HumanBodyBones.RightLowerLeg,HumanBodyBones.RightFoot,new Vector3(0,-.7f,.12f));
        }
    }
    private static void Align(Animator rig,HumanBodyBones a,HumanBodyBones b,Vector3 direction)
    {var from=rig.GetBoneTransform(a);var to=rig.GetBoneTransform(b);if(from&&to)from.rotation=Quaternion.FromToRotation(to.position-from.position,rig.transform.TransformDirection(direction))*from.rotation;}
}


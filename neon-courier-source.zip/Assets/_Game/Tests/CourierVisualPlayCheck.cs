#if UNITY_EDITOR
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using UnityEditor;
using UnityEngine;
using UnityEngine.SceneManagement;

/// <summary>Opt-in checks against the actual installed prefabs; never changes saved progress.</summary>
public sealed class CourierVisualPlayCheck : MonoBehaviour
{
    private const BindingFlags Fields = BindingFlags.Instance | BindingFlags.NonPublic;
    private readonly List<string> results = new List<string>();
    private GameManager originalManager;
    private float originalTimeScale;
    private bool restored;

    [MenuItem("Neon Courier/Run Courier Visual Checks")]
    public static void Run()
    {
        if (EditorApplication.isPlayingOrWillChangePlaymode) return;
        SessionState.SetBool("CourierLook.QA", true);
        EditorApplication.EnterPlaymode();
    }

    [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
    private static void Boot()
    {
        if (!SessionState.GetBool("CourierLook.QA", false)) return;
        SessionState.SetBool("CourierLook.QA", false);
        foreach(var root in SceneManager.GetActiveScene().GetRootGameObjects()) root.SetActive(false);
        new GameObject("Courier visual checks").AddComponent<CourierVisualPlayCheck>();
    }

    private IEnumerator Start()
    {
        originalManager=GameManager.Instance; originalTimeScale=Time.timeScale; Time.timeScale=1f;
        var pending=new Stack<IEnumerator>(); pending.Push(Checks());
        double deadline=EditorApplication.timeSinceStartup+30d;
        try
        {
            while(pending.Count>0)
            {
                bool moved=false; object next=null; Exception error=null;
                try
                {
                    if(EditorApplication.timeSinceStartup>deadline)throw new TimeoutException("Visual checks timed out");
                    moved=pending.Peek().MoveNext(); if(moved)next=pending.Peek().Current;
                }
                catch(Exception e){error=e;}
                if(error!=null){results.Add("FAIL "+error);break;}
                if(!moved){(pending.Pop() as IDisposable)?.Dispose();continue;}
                if(next is IEnumerator nested)pending.Push(nested);else yield return next;
            }
        }
        finally
        {
            while(pending.Count>0)(pending.Pop() as IDisposable)?.Dispose();
            Restore();
        }
        Directory.CreateDirectory("Logs");File.WriteAllLines("Logs/CourierVisualPlayChecks.txt",results);
        Debug.Log("COURIER_VISUAL_PLAY_CHECKS: "+string.Join("; ",results));
        EditorApplication.isPlaying=false;
    }

    private IEnumerator Checks()
    {
        // An inactive test manager has no Awake/Start, profile reads, or saving callbacks.
        var managerRoot=new GameObject("Temporary stats");managerRoot.SetActive(false);
        var manager=managerRoot.AddComponent<GameManager>(); Singleton(manager); Property(manager,"IsRunActive",true);
        var bag=Instantiate(AssetDatabase.LoadAssetAtPath<GameObject>("Assets/_Game/Art/CourierSet/CourierBackpack.prefab"));
        var core=bag.GetComponent<CargoCoreController>();
        yield return null;
        Check(ActiveLights(core)==0,"Empty backpack has zero lit capacity indicators");
        var package=Instantiate(AssetDatabase.LoadAssetAtPath<GameObject>("Assets/_Game/Prefabs/PF_Package.prefab"));
        var target=new GameObject("Attraction target").transform;target.position=package.transform.position;
        package.GetComponent<PackagePickup>().AttractTowards(target,20f);
        Check(manager.CarriedPackages==1 && !package.activeSelf,"New package can be collected through the existing magnet pickup path");
        Check(ActiveLights(core)==1,"Collecting a package lights the backpack indicator");
        for(int i=1;i<10;i++)manager.CollectPackage();
        Check(ActiveLights(core)==5,"Ten packages light all five backpack indicators");
        Vector3 fullScale=bag.transform.localScale;
        yield return new WaitForSeconds(.2f);
        Check(Vector3.Distance(fullScale,bag.transform.localScale)>.001f,"Full backpack retains its subtle pulse");
        Property(manager,"CarriedPackages",0);
        typeof(CargoCoreController).GetMethod("RefreshVisuals",Fields).Invoke(core,null);
        Check(ActiveLights(core)==0,"Emptying the backpack clears its capacity indicators");

        var zone=Instantiate(AssetDatabase.LoadAssetAtPath<GameObject>("Assets/_Game/Prefabs/PF_DeliveryZone.prefab"));
        var feedback=zone.GetComponentInChildren<NPCDeliveryFeedback>(true);
        var receiver=zone.GetComponentInChildren<DeliveryReceiverVisual>(true);
        var arm=(Transform)typeof(DeliveryReceiverVisual).GetField("leftArm",Fields).GetValue(receiver);
        var held=(GameObject)typeof(NPCDeliveryFeedback).GetField("receivedPackageVisual",Fields).GetValue(feedback);
        yield return null;
        Quaternion rest=arm.localRotation;
        Check(!held.activeSelf,"Receiver starts without a floating parcel");
        feedback.PlayDeliveryFeedback(0);yield return null;
        Check(!held.activeSelf,"Empty delivery does not display a parcel");
        feedback.PlayDeliveryFeedback(10);yield return new WaitForSeconds(.35f);
        Check(held.activeSelf,"Successful delivery displays the matching parcel");
        Check(Quaternion.Angle(rest,arm.localRotation)>30f,"Android raises its arms to receive the parcel");
        yield return new WaitForSeconds(1.3f);
        Check(!held.activeSelf,"Received parcel hides after the delivery feedback");
        feedback.PlayDeliveryFeedback(1);yield return new WaitForSeconds(.15f);
        zone.SetActive(false);zone.SetActive(true);yield return null;
        Check(!held.activeSelf && Quaternion.Angle(rest,arm.localRotation)<5f,"Recycled delivery NPC resets parcel and pose");

        bool nearMissAbsent=true;
        foreach(var root in SceneManager.GetActiveScene().GetRootGameObjects())
            foreach(var text in root.GetComponentsInChildren<TMPro.TMP_Text>(true))
                nearMissAbsent &= !text.name.Contains("NearMiss") && !text.text.Contains("YAKIN KAÇIŞ") && !text.text.Contains("NEAR MISS");
        Check(nearMissAbsent,"No near-miss labels remain, including inactive menus");
        Destroy(zone);Destroy(bag);Destroy(package);Destroy(target.gameObject);Destroy(managerRoot);
    }
    private static int ActiveLights(CargoCoreController core)
    {
        int count=0;for(int i=1;i<=5;i++)if(((GameObject)typeof(CargoCoreController).GetField("capacityLight0"+i,Fields).GetValue(core)).activeSelf)count++;
        return count;
    }
    private void Check(bool condition,string message){results.Add((condition?"PASS ":"FAIL ")+message);}
    private static void Property(object target,string property,object value)=>target.GetType().GetProperty(property).GetSetMethod(true).Invoke(target,new[]{value});
    private static void Singleton(GameManager value)=>typeof(GameManager).GetProperty("Instance").GetSetMethod(true).Invoke(null,new object[]{value});
    private void Restore(){if(restored)return;restored=true;Singleton(originalManager);Time.timeScale=originalTimeScale;}
    private void OnDisable(){Restore();}
}
#endif

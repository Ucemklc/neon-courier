#if UNITY_EDITOR
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;
using Object=UnityEngine.Object;

/// <summary>Original, rig-ready meshes based on the four supplied courier concepts.</summary>
public static class CourierReferenceAssets
{
    private const string Folder="Assets/Resources/CourierReference";
    private static Material ink,skin,white,pink,cyan,yellow,purple,steel,orange,green,lime,brown,hood,eye,glass;
    private static readonly List<Mesh> temporary=new List<Mesh>();
    [MenuItem("Neon Courier/Generate Reference Characters")]
    public static void Generate()
    {
        if(EditorApplication.isPlayingOrWillChangePlaymode)return;
        Directory.CreateDirectory(Folder+"/Meshes");AssetDatabase.Refresh();
        ink=Mat("Ink",new Color(.025f,.025f,.06f));skin=Mat("Peach",new Color(1,.67f,.46f));white=Mat("Pearl",new Color(.91f,.95f,1));
        pink=Mat("AkiPink",new Color(.94f,.12f,.60f));cyan=Mat("AkiCyan",new Color(.08f,.80f,.96f),.14f);yellow=Mat("AkiYellow",new Color(1,.66f,.08f));purple=Mat("AkiPurple",new Color(.34f,.12f,.57f));
        steel=Mat("TanakaSteel",new Color(.20f,.23f,.30f),0,.5f);orange=Mat("TanakaOrange",new Color(1,.32f,.06f),.08f);
        green=Mat("RenGreen",new Color(.12f,.38f,.10f));lime=Mat("RenLeaf",new Color(.43f,.78f,.17f));brown=Mat("RenCanvas",new Color(.25f,.17f,.09f));
        hood=Mat("LyraHood",new Color(.12f,.045f,.23f));eye=Mat("LyraGlow",new Color(.80f,.30f,1),.6f);glass=Mat("GoggleGlass",new Color(.2f,.74f,1,.16f),.05f);
        glass.SetFloat("_Surface",1);glass.SetFloat("_SrcBlend",5);glass.SetFloat("_DstBlend",10);glass.SetFloat("_ZWrite",0);glass.EnableKeyword("_SURFACE_TYPE_TRANSPARENT");glass.renderQueue=3000;glass.SetOverrideTag("RenderType","Transparent");glass.SetShaderPassEnabled("ShadowCaster",false);EditorUtility.SetDirty(glass);
        var scene=EditorSceneManager.NewPreviewScene();var root=new GameObject("Reference courier build");SceneManager.MoveGameObjectToScene(root,scene);
        try
        {
            for(int i=0;i<4;i++)
            {
                var h=Node("Head"+i,root.transform);if(i==0)Aki(h);else if(i==1)Tanaka(h);else if(i==2)Ren(h);else Lyra(h);Save(h,"Head"+i);
                Save(Torso(root.transform,i),"Torso"+i);Save(Hips(root.transform,i),"Hips"+i);
                Save(Limb(root.transform,i,false),"Arm"+i);Save(Limb(root.transform,i,true),"Leg"+i);
                var joint=Node("Joint"+i,root.transform);Sphere(joint,"Suit connection",Vector3.zero,V(.91f,1.05f,.91f),i==0?yellow:i==1?ink:i==2?green:hood);Save(joint,"Joint"+i);
                Save(Glove(root.transform,i),"Glove"+i);Save(Boot(root.transform,i),"Boot"+i);Save(Bag(root.transform,i),"Bag"+i);
                Portrait(i);
            }
            AssetDatabase.SaveAssets();Directory.CreateDirectory("Logs");File.WriteAllText("Logs/CourierReferenceAssets.txt","PASS 4 original animated outfits, 4 themed backpacks and 4 model portraits generated.\n");
        }
        finally{EditorSceneManager.ClosePreviewScene(scene);foreach(var mesh in temporary)if(mesh)Object.DestroyImmediate(mesh);temporary.Clear();}
    }
    private static Material Mat(string name,Color color,float emission=0,float metal=0)
    {
        string path=Folder+"/"+name+".mat";var m=AssetDatabase.LoadAssetAtPath<Material>(path);if(!m){m=new Material(Shader.Find("Universal Render Pipeline/Lit"));AssetDatabase.CreateAsset(m,path);}
        m.SetColor("_BaseColor",color);m.SetFloat("_Smoothness",.28f);m.SetFloat("_Metallic",metal);m.EnableKeyword("_EMISSION");m.SetColor("_EmissionColor",color*emission);m.enableInstancing=true;EditorUtility.SetDirty(m);return m;
    }
    private static Transform Node(string name,Transform parent){var go=new GameObject(name);go.transform.SetParent(parent,false);return go.transform;}
    private static Vector3 V(float x,float y,float z)=>new Vector3(x,y,z);
    private static void Sphere(Transform p,string name,Vector3 pos,Vector3 size,Material mat,Vector3 rotation=default)
    {var go=GameObject.CreatePrimitive(PrimitiveType.Sphere);go.name=name;go.transform.SetParent(p,false);go.transform.localPosition=pos;go.transform.localScale=size;go.transform.localRotation=Quaternion.Euler(rotation);go.GetComponent<Renderer>().sharedMaterial=mat;Object.DestroyImmediate(go.GetComponent<Collider>());}
    private static void Box(Transform p,string name,Vector3 pos,Vector3 size,Material mat,float bevel=.035f,Vector3 rotation=default)
    {var node=Node(name,p);node.localPosition=pos;node.localRotation=Quaternion.Euler(rotation);var mesh=BeveledBox(size,bevel);temporary.Add(mesh);node.gameObject.AddComponent<MeshFilter>().sharedMesh=mesh;node.gameObject.AddComponent<MeshRenderer>().sharedMaterial=mat;}
    private static void Curve(Transform p,string name,Vector3[] points,float radius,Material mat,bool taper=false)
    {
        if(points.Length>=3)
        {
            var smooth=new List<Vector3>();
            for(int k=0;k<points.Length-1;k++)for(int step=0;step<5;step++)
            {
                float u=step/5f;var a=points[Math.Max(0,k-1)];var b=points[k];var c=points[k+1];var d=points[Math.Min(points.Length-1,k+2)];
                smooth.Add(.5f*((2*b)+(-a+c)*u+(2*a-5*b+4*c-d)*u*u+(-a+3*b-3*c+d)*u*u*u));
            }
            smooth.Add(points[points.Length-1]);points=smooth.ToArray();
        }
        const int sides=8;var verts=new List<Vector3>();var triangles=new List<int>();
        for(int i=0;i<points.Length;i++)
        {
            Vector3 tangent=(points[Math.Min(i+1,points.Length-1)]-points[Math.Max(0,i-1)]).normalized;
            Vector3 normal=Vector3.Cross(tangent,Mathf.Abs(tangent.z)<.85f?Vector3.forward:Vector3.up).normalized;Vector3 binormal=Vector3.Cross(tangent,normal);
            float r=radius*(taper?Mathf.Lerp(1,.05f,(float)i/(points.Length-1)):1);
            for(int j=0;j<sides;j++){float a=j*Mathf.PI*2/sides;verts.Add(points[i]+r*(normal*Mathf.Cos(a)+binormal*Mathf.Sin(a)));}
        }
        for(int i=0;i<points.Length-1;i++)for(int j=0;j<sides;j++){int a=i*sides+j,b=i*sides+(j+1)%sides;triangles.AddRange(new[]{a,b,a+sides,b,b+sides,a+sides});}
        // End caps keep hair locks and small seams closed from every view.
        for(int j=1;j<sides-1;j++){triangles.AddRange(new[]{0,j+1,j});int end=(points.Length-1)*sides;triangles.AddRange(new[]{end,end+j,end+j+1});}
        var mesh=new Mesh{name=name};mesh.SetVertices(verts);mesh.SetTriangles(triangles,0);mesh.RecalculateNormals();temporary.Add(mesh);
        var t=Node(name,p);t.gameObject.AddComponent<MeshFilter>().sharedMesh=mesh;t.gameObject.AddComponent<MeshRenderer>().sharedMaterial=mat;
    }
    private static void Leaf(Transform p,string name,Vector3 pos,Vector3 size,Material mat,Vector3 rotation=default)
    {
        var node=Node(name,p);node.localPosition=pos;node.localScale=size;node.localRotation=Quaternion.Euler(rotation);
        var mesh=new Mesh{name=name};mesh.vertices=new[]{V(0,-.5f,0),V(-.45f,0,0),V(0,.5f,0),V(.45f,0,0),V(0,0,.18f),V(0,0,-.10f)};
        mesh.triangles=new[]{0,4,1,1,4,2,2,4,3,3,4,0,0,1,5,1,2,5,2,3,5,3,0,5};mesh.RecalculateNormals();temporary.Add(mesh);node.gameObject.AddComponent<MeshFilter>().sharedMesh=mesh;node.gameObject.AddComponent<MeshRenderer>().sharedMaterial=mat;
    }
    private static void Face(Transform h,Material iris,bool smile)
    {
        Sphere(h,"Rounded face",V(0,-.005f,.04f),V(.61f,.59f,.51f),skin);
        foreach(float x in new[]{-.145f,.145f})
        {
            Sphere(h,"Eye outline",V(x,.035f,.270f),V(.176f,.213f,.05f),ink);
            Sphere(h,"Eye white",V(x,.04f,.293f),V(.145f,.182f,.038f),white);
            Sphere(h,"Iris",V(x,.025f,.311f),V(.105f,.145f,.027f),iris);
            Sphere(h,"Pupil",V(x,.024f,.325f),V(.050f,.09f,.019f),ink);
            Sphere(h,"Eye sparkle",V(x-.025f,.072f,.339f),V(.032f,.036f,.013f),white);
            Sphere(h,"Cheek",V(x*1.24f,-.09f,.272f),V(.085f,.036f,.016f),pink);
        }
        Sphere(h,"Nose",V(0,-.055f,.302f),V(.065f,.073f,.065f),skin);
        if(smile){Sphere(h,"Smile",V(0,-.145f,.28f),V(.126f,.10f,.027f),ink);Sphere(h,"Tongue",V(0,-.17f,.30f),V(.070f,.035f,.012f),pink);Box(h,"Smile teeth",V(0,-.117f,.299f),V(.073f,.025f,.014f),white,.006f);}
        else Curve(h,"Smile",new[]{V(-.065f,-.135f,.29f),V(0,-.155f,.31f),V(.065f,-.135f,.29f)},.012f,brown);
    }
    private static void Aki(Transform h)
    {
        Face(h,cyan,true);Sphere(h,"Turquoise hair",V(0,.17f,-.07f),V(.70f,.55f,.53f),cyan);
        foreach(float x in new[]{-.28f,.28f})
        {
            Sphere(h,"Space bun",V(x,.37f,-.06f),V(.285f,.25f,.26f),pink);
            Curve(h,"Bun ribbon",new[]{V(x-.07f,.40f,.04f),V(x,.46f,.025f),V(x+.08f,.40f,.05f)},.035f,purple);
            Box(h,"Headset",V(x*1.2f,.04f,.02f),V(.10f,.19f,.19f),purple,.04f);
            Box(h,"Headset light",V(x*1.36f,.04f,.055f),V(.018f,.11f,.085f),cyan,.008f);
        }
        Curve(h,"Swept pink fringe",new[]{V(.27f,.25f,.14f),V(.06f,.33f,.24f),V(-.17f,.24f,.31f),V(-.32f,.05f,.26f),V(-.35f,-.1f,.18f)},.085f,pink,true);
        Curve(h,"Cyan fringe stripe",new[]{V(.14f,.31f,.25f),V(-.05f,.32f,.31f),V(-.25f,.17f,.34f),V(-.33f,-.03f,.23f)},.045f,cyan,true);
        for(int i=0;i<5;i++)Curve(h,"Ponytail strand",new[]{V((i-2)*.07f,.16f,-.24f),V(.25f+(i-2)*.07f,.03f,-.36f),V(.43f+(i-2)*.06f,-.24f,-.36f),V(.46f+(i-2)*.08f,-.48f,-.22f)},.058f,i%2==0?pink:cyan,true);
        Box(h,"Goggle upper rim",V(0,.143f,.312f),V(.58f,.038f,.048f),purple,.012f);Box(h,"Goggle lower rim",V(0,-.073f,.316f),V(.55f,.026f,.038f),purple,.008f);
        foreach(float x in new[]{-.278f,.278f})Box(h,"Goggle side",V(x,.035f,.31f),V(.032f,.23f,.04f),purple,.008f);
        Box(h,"Transparent goggles",V(0,.035f,.351f),V(.51f,.185f,.012f),glass,.003f);
    }
    private static void Tanaka(Transform h)
    {
        Sphere(h,"Armored helmet",V(0,.025f,0),V(.69f,.68f,.61f),steel);
        Box(h,"Visor gasket",V(0,.04f,.281f),V(.61f,.29f,.12f),ink,.065f);
        Box(h,"Magenta visor",V(0,.045f,.352f),V(.51f,.155f,.036f),pink,.035f);
        Box(h,"Visor gleam",V(-.14f,.091f,.374f),V(.19f,.018f,.008f),white,.003f, V(0,0,6));
        Box(h,"Chin armor",V(0,-.19f,.20f),V(.45f,.22f,.21f),steel,.06f);
        foreach(float x in new[]{-.32f,.32f}){Box(h,"Helmet side",V(x,0,.04f),V(.13f,.36f,.36f),ink,.04f);Box(h,"Orange temple",V(x*1.09f,.01f,.065f),V(.06f,.23f,.25f),orange,.025f);}
        Curve(h,"Helmet orange seam",new[]{V(.2f,.30f,-.10f),V(.20f,.34f,.02f),V(.19f,.27f,.20f)},.018f,orange);
        for(int i=-1;i<=1;i++)Box(h,"Vent",V(i*.072f,-.215f,.312f),V(.035f,.053f,.02f),ink,.007f);
    }
    private static void Ren(Transform h)
    {
        Face(h,lime,false);Sphere(h,"Moss hair",V(0,.205f,-.07f),V(.67f,.45f,.52f),green);
        foreach(float side in new[]{-1f,1f}){Leaf(h,"Elven ear",V(side*.34f,.065f,.02f),V(.2f,.36f,.18f),skin,V(0,0,side*-58));Leaf(h,"Inner ear",V(side*.36f,.07f,.083f),V(.09f,.24f,.05f),brown,V(0,0,side*-58));}
        for(int i=0;i<9;i++){float a=i*Mathf.PI*2/9;Leaf(h,"Leaf hair",V(Mathf.Cos(a)*.22f,.31f+Mathf.Sin(a)*.06f,Mathf.Sin(a)*.18f),V(.19f,.40f,.18f),i%2==0?lime:green,V(-25+Mathf.Sin(a)*20,i*40,-20+Mathf.Cos(a)*30));}
        Curve(h,"Swept forelock",new[]{V(-.23f,.24f,.2f),V(-.05f,.31f,.28f),V(.19f,.3f,.23f),V(.3f,.38f,.05f)},.065f,green,true);
        Leaf(h,"Forehead leaf",V(-.16f,.225f,.28f),V(.15f,.24f,.07f),lime,V(5,0,-35));
    }
    private static void Lyra(Transform h)
    {
        Sphere(h,"Deep hood",V(0,.06f,-.065f),V(.78f,.82f,.70f),hood);
        Sphere(h,"Hood opening",V(0,-.015f,.273f),V(.59f,.60f,.075f),ink);
        Sphere(h,"Shadow face",V(0,-.01f,.312f),V(.46f,.43f,.035f),purple);
        foreach(float x in new[]{-.135f,.135f}){Sphere(h,"Glowing eye",V(x,.045f,.341f),V(.135f,.14f,.026f),eye);Sphere(h,"Eye highlight",V(x-.02f,.078f,.36f),V(.028f,.036f,.01f),white);}
        Box(h,"Face mask",V(0,-.145f,.34f),V(.45f,.205f,.10f),hood,.054f);
        Curve(h,"Mask smile",new[]{V(-.055f,-.145f,.398f),V(0,-.17f,.405f),V(.055f,-.145f,.398f)},.012f,eye);
        foreach(float x in new[]{-.17f,.17f})Curve(h,"Mask whisker",new[]{V(x,-.155f,.398f),V(x*.8f,-.13f,.402f)},.012f,eye);
        Curve(h,"Hood neon seam",new[]{V(-.28f,-.26f,.24f),V(-.34f,.03f,.25f),V(-.26f,.28f,.23f),V(0,.40f,.16f),V(.28f,.25f,.22f),V(.34f,.0f,.24f),V(.27f,-.27f,.24f)},.02f,purple);
        Curve(h,"Purple fringe",new[]{V(.17f,.22f,.34f),V(-.04f,.24f,.35f),V(-.23f,.10f,.35f)},.045f,purple,true);
        for(int i=0;i<6;i++)Sphere(h,"Hood star",V((i%2==0?-1:1)*(.22f+i*.011f),.24f-i*.035f,.25f),V(.017f,.019f,.012f),eye);
    }
    private static Transform Torso(Transform p,int i)
    {
        var t=Node("Torso"+i,p);var baseMat=i==0?purple:i==1?steel:i==2?brown:hood;
        Box(t,"Jacket body",Vector3.zero,V(i==1?.65f:.52f,.51f,.32f),baseMat,.09f);
        Sphere(t,"Neck",V(0,.30f,0),V(.16f,.21f,.16f),i==0||i==2?skin:ink);
        if(i==0)
        {
            foreach(float x in new[]{-.20f,.20f}){Box(t,"Yellow jacket",V(x,.035f,.025f),V(.19f,.48f,.37f),yellow,.065f);Box(t,"Pink lapel",V(x*.69f,.06f,.217f),V(.045f,.40f,.035f),pink,.01f,V(0,0,x>0?-12:12));Box(t,"Cyan pocket",V(x,-.1f,.222f),V(.13f,.065f,.02f),cyan,.01f);}
            Curve(t,"Shirt neon mark",new[]{V(-.085f,.08f,.182f),V(0,0,.185f),V(.085f,.08f,.182f)},.018f,cyan);
        }
        else if(i==1)
        {
            Box(t,"Breastplate",V(0,.07f,.19f),V(.56f,.32f,.12f),steel,.045f);
            foreach(float x in new[]{-.24f,.24f})Box(t,"Armor rails",V(x,0,.25f),V(.047f,.44f,.045f),orange,.012f);
            for(int j=0;j<3;j++)Box(t,"Abdominal plate",V(0,-.14f-j*.045f,.18f),V(.40f,.047f,.08f),ink,.012f);
            Box(t,"Parcel emblem",V(0,.07f,.261f),V(.17f,.14f,.025f),orange,.012f);
        }
        else if(i==2)
        {
            foreach(float x in new[]{-.15f,.15f})Leaf(t,"Living armor",V(x,.07f,.19f),V(.30f,.48f,.15f),lime,V(0,0,x>0?-18:18));
            Curve(t,"Chest vine",new[]{V(-.20f,-.22f,.19f),V(.04f,0,.25f),V(.17f,.23f,.16f)},.025f,green);
            Box(t,"Canvas belt",V(0,-.22f,0),V(.54f,.08f,.36f),brown,.02f);
        }
        else
        {
            Box(t,"Violet chest wrap",V(0,.035f,.18f),V(.48f,.40f,.055f),purple,.02f);
            foreach(float x in new[]{-.16f,.16f})Box(t,"Shadow harness",V(x,0,.22f),V(.065f,.50f,.055f),ink,.015f,V(0,0,x>0?-22:22));
            Sphere(t,"Neon clasp",V(0,.16f,.245f),V(.095f,.09f,.025f),eye);
            foreach(float side in new[]{-1f,1f}){var cape=Node(side<0?"CapeTailL":"CapeTailR",t);cape.localPosition=V(side*.25f,.16f,-.13f);Leaf(cape,"Cape panel",V(side*.09f,-.26f,-.12f),V(.48f,.95f,.09f),hood,V(-17,side*15,side*25));Curve(cape,"Cape neon seam",new[]{V(side*.12f,.02f,-.20f),V(side*.32f,-.30f,-.21f),V(side*.25f,-.66f,-.10f)},.017f,purple);}
        }
        foreach(float x in new[]{-.21f,.21f})Box(t,"Backpack straps",V(x,0,.20f),V(.044f,.47f,.042f),i==2?brown:ink,.012f);
        return t;
    }
    private static Transform Hips(Transform p,int i)
    {var t=Node("Hips"+i,p);Box(t,"Hip suit",Vector3.zero,V(i==1?.49f:.43f,.22f,.29f),i==0?pink:i==1?steel:i==2?brown:hood,.045f);Box(t,"Belt",V(0,.055f,0),V(.47f,.08f,.32f),ink,.025f);Box(t,"Buckle",V(0,.055f,.18f),V(.105f,.085f,.024f),Accent(i),.016f);return t;}
    private static Material Accent(int i)=>i==0?cyan:i==1?orange:i==2?lime:eye;
    private static Transform Limb(Transform p,int i,bool leg)
    {
        var t=Node((leg?"Leg":"Arm")+i,p);var cloth=i==0?(leg?pink:yellow):i==1?ink:i==2?brown:hood;
        Sphere(t,"Rounded suit",Vector3.zero,V(.93f,.99f,.94f),cloth);
        foreach(float end in new[]{-.48f,.48f})Sphere(t,"Joint",V(0,end,0),V(.84f,.28f,.84f),i==0?purple:i==2?green:ink);
        if(i==1){Box(t,"Heavy plate",V(0,.06f,.40f),V(.98f,.72f,.37f),steel,.08f);Box(t,"Orange armor seam",V(0,.28f,.605f),V(.78f,.10f,.02f),orange,.006f);}
        else if(i==2){Leaf(t,"Leaf armor",V(0,.0f,.43f),V(.88f,.86f,.35f),green);Leaf(t,"Leaf vein",V(0,.06f,.58f),V(.56f,.70f,.10f),lime);}
        else if(i==3){Box(t,"Shadow plate",V(0,.07f,.41f),V(.8f,.67f,.15f),purple,.06f);Box(t,"Violet seam",V(.25f,.10f,.505f),V(.055f,.56f,.01f),eye,.004f);}
        else {Box(t,"Suit stripe",V(0,.08f,.46f),V(.72f,.16f,.045f),cyan,.01f,V(0,0,-20));Box(t,"Suit pink stripe",V(.18f,-.06f,.46f),V(.33f,.12f,.045f),purple,.01f,V(0,0,25));}
        return t;
    }
    private static Transform Glove(Transform p,int i)
    {var t=Node("Glove"+i,p);Box(t,"Palm",V(0,-.016f,0),V(i==1?.21f:.17f,.17f,.18f),i==0?purple:i==1?steel:i==2?green:hood,.04f);Box(t,"Knuckles",V(0,0,.093f),V(.14f,.08f,.036f),Accent(i),.015f);return t;}
    private static Transform Boot(Transform p,int i)
    {
        var t=Node("Boot"+i,p);Box(t,"Sole",V(0,-.065f,.055f),V(.26f,.08f,.39f),ink,.034f);Box(t,"Sneaker",V(0,.014f,.075f),V(.25f,.16f,.35f),i==0?purple:i==1?steel:i==2?brown:hood,.055f);
        Box(t,"Heel",V(0,.06f,-.06f),V(.22f,.21f,.15f),i==0?yellow:Accent(i),.03f);
        Box(t,"Toe band",V(0,-.005f,.205f),V(.245f,.08f,.05f),i==0?yellow:Accent(i),.014f);
        Box(t,"Sole light",V(0,-.055f,.065f),V(.264f,.021f,.35f),Accent(i),.01f);
        for(int j=0;j<3;j++)Box(t,"Laces",V(0,.105f,.02f+j*.044f),V(.14f,.015f,.014f),i==0?pink:white,.003f);return t;
    }
    private static Transform Bag(Transform p,int i)
    {
        var b=Node("Bag"+i,p);var body=i==0?purple:i==1?steel:i==2?brown:hood;var accent=Accent(i);
        Box(b,"Pack body",V(0,0,-.10f),V(i==1?.72f:.55f,i==1?.79f:.63f,.40f),body,.075f);
        Box(b,"Back panel",V(0,-.015f,-.322f),V(i==1?.57f:.46f,i==1?.62f:.47f,.07f),i==0?pink:i==1?orange:i==2?green:purple,.055f);
        Box(b,"Upper flap",V(0,.26f,-.13f),V(.59f,.16f,.43f),i==0?cyan:i==1?steel:i==2?lime:hood,.055f);
        foreach(float x in new[]{-.19f,.19f}){Box(b,"Reflective clasp",V(x,-.05f,-.373f),V(.045f,.37f,.017f),accent,.005f);Box(b,"Pack buckle",V(x,-.21f,-.379f),V(.077f,.077f,.025f),white,.01f);}
        Curve(b,"Handle",new[]{V(-.12f,.30f,-.04f),V(-.11f,.40f,-.06f),V(.11f,.40f,-.06f),V(.12f,.30f,-.04f)},.031f,body);
        if(i==0){Sphere(b,"Pack heart left",V(-.04f,.02f,-.375f),V(.11f,.11f,.025f),yellow);Sphere(b,"Pack heart right",V(.04f,.02f,-.375f),V(.11f,.11f,.025f),yellow);Leaf(b,"Pack heart point",V(0,-.04f,-.375f),V(.16f,.13f,.02f),yellow);}
        if(i==1){var camera=Node("Cargo camera",b);Box(camera,"Camera housing",V(0,.51f,-.08f),V(.29f,.22f,.26f),ink,.04f);Sphere(camera,"Lens",V(0,.52f,-.226f),V(.12f,.12f,.033f),purple);Sphere(camera,"Lens reflection",V(-.02f,.54f,-.247f),V(.035f,.035f,.011f),eye);foreach(float x in new[]{-.37f,.37f})Box(b,"Cargo rail",V(x,0,-.12f),V(.07f,.73f,.42f),ink,.025f);}
        if(i==2){Leaf(b,"Canvas leaf emblem",V(0,.035f,-.375f),V(.20f,.29f,.025f),lime,V(0,0,-25));foreach(float x in new[]{-.33f,.33f}){Sphere(b,"Botanical vial",V(x,-.13f,-.05f),V(.13f,.44f,.13f),lime);Box(b,"Bottle lid",V(x,.08f,-.05f),V(.15f,.07f,.15f),brown,.025f);}Leaf(b,"Pack sprout",V(.16f,.40f,-.10f),V(.17f,.32f,.08f),green,V(0,0,-25));}
        if(i==3){Leaf(b,"Shadow sigil",V(0,.025f,-.375f),V(.19f,.28f,.025f),eye);foreach(float x in new[]{-.29f,.29f})Box(b,"Side pouch",V(x,-.10f,-.10f),V(.16f,.27f,.24f),purple,.035f);}
        // The existing wardrobe remains available through a small customizable badge and patches.
        var custom=AssetDatabase.LoadAssetAtPath<Material>("Assets/_Game/Art/CourierSet/Materials/SafetyTangerine.mat");
        Box(b,"Custom delivery badge",V(0,-.245f,-.37f),V(.17f,.05f,.02f),custom,.008f);
        var glow=Mat("ReferenceSignalCyan",new Color(.15f,.8f,1),.3f);Box(b,"Workshop light",V(0,.21f,-.355f),V(.38f,.018f,.018f),glow,.004f);return b;
    }
    private static void Portrait(int index)
    {
        var preview=new PreviewRenderUtility();Texture2D image=null;
        try
        {
            var root=new GameObject("Portrait");preview.AddSingleGO(root);
            var head=Object.Instantiate(AssetDatabase.LoadAssetAtPath<GameObject>(Folder+"/Head"+index+".prefab"),root.transform);head.transform.localPosition=V(0,.31f,0);
            var body=Object.Instantiate(AssetDatabase.LoadAssetAtPath<GameObject>(Folder+"/Torso"+index+".prefab"),root.transform);body.transform.localPosition=V(0,-.30f,0);
            root.transform.rotation=Quaternion.Euler(0,-12,0);
            preview.camera.transform.position=V(0,.20f,3);preview.camera.transform.LookAt(V(0,.16f,0));preview.camera.orthographic=true;preview.camera.orthographicSize=.72f;preview.camera.nearClipPlane=.01f;preview.camera.farClipPlane=10;
            preview.camera.clearFlags=CameraClearFlags.SolidColor;preview.camera.backgroundColor=new Color(.055f,.065f,.11f,1);
            preview.ambientColor=new Color(.65f,.65f,.7f);preview.lights[0].intensity=1.5f;preview.lights[0].transform.rotation=Quaternion.Euler(25,165,0);preview.lights[1].intensity=.8f;preview.lights[1].transform.rotation=Quaternion.Euler(0,-35,0);
            preview.BeginStaticPreview(new Rect(0,0,512,512));preview.Render(true,false);image=preview.EndStaticPreview();string path=Folder+"/Portrait"+index+".png";File.WriteAllBytes(path,image.EncodeToPNG());AssetDatabase.ImportAsset(path);
            var importer=(TextureImporter)AssetImporter.GetAtPath(path);importer.textureType=TextureImporterType.Sprite;importer.spriteImportMode=SpriteImportMode.Single;importer.mipmapEnabled=false;importer.SaveAndReimport();
        }
        finally{if(image)Object.DestroyImmediate(image);preview.Cleanup();}
    }

    private static void Save(Transform root,string name){Save(root.gameObject,name);root.gameObject.SetActive(false);}
    private static Mesh BeveledBox(Vector3 size,float bevel)
    {
        Vector3 h=size*.5f; float r=Mathf.Min(bevel,Mathf.Min(h.x,Mathf.Min(h.y,h.z))*.8f);
        var verts=new List<Vector3>(); var tris=new List<int>();
        Action<Vector3[]> face=points=>
        {
            Vector3 center=Vector3.zero; foreach(var p in points) center+=p;
            if(Vector3.Dot(Vector3.Cross(points[1]-points[0],points[2]-points[0]),center)<0) Array.Reverse(points);
            int start=verts.Count; verts.AddRange(points);
            for(int i=1;i<points.Length-1;i++){tris.Add(start);tris.Add(start+i);tris.Add(start+i+1);}
        };
        for(int axis=0;axis<3;axis++) for(int sign=-1;sign<=1;sign+=2)
        {
            int b=(axis+1)%3,c=(axis+2)%3; var q=new Vector3[4]; int k=0;
            foreach(var pair in new[]{new Vector2(-1,-1),new Vector2(1,-1),new Vector2(1,1),new Vector2(-1,1)})
            {var p=Vector3.zero;p[axis]=sign*h[axis];p[b]=pair.x*(h[b]-r);p[c]=pair.y*(h[c]-r);q[k++]=p;} face(q);
        }
        for(int axis=0;axis<3;axis++) for(int sb=-1;sb<=1;sb+=2) for(int sc=-1;sc<=1;sc+=2)
        {
            int b=(axis+1)%3,c=(axis+2)%3;var q=new Vector3[4];
            for(int i=0;i<4;i++){var p=Vector3.zero;p[axis]=(i<2?-1:1)*(h[axis]-r);bool outerB=i==0||i==3;p[b]=sb*(h[b]-(outerB?0:r));p[c]=sc*(h[c]-(outerB?r:0));q[i]=p;}face(q);
        }
        for(int sx=-1;sx<=1;sx+=2)for(int sy=-1;sy<=1;sy+=2)for(int sz=-1;sz<=1;sz+=2)
            face(new[]{V(sx*h.x,sy*(h.y-r),sz*(h.z-r)),V(sx*(h.x-r),sy*h.y,sz*(h.z-r)),V(sx*(h.x-r),sy*(h.y-r),sz*h.z)});
        var mesh=new Mesh{name="ChamferedShell"};mesh.SetVertices(verts);mesh.SetTriangles(tris,0);mesh.RecalculateNormals();mesh.RecalculateBounds();return mesh;
    }
    private static void Save(GameObject root,string name)
    {
        // Combine direct static parts per material. Animated pivots and capacity LEDs remain independent.
        foreach(var parent in root.GetComponentsInChildren<Transform>(true).Reverse().ToArray())
        {
            var parts=parent.Cast<Transform>().Where(t=>t.GetComponent<MeshFilter>()!=null).ToArray();
            foreach(var group in parts.GroupBy(t=>t.GetComponent<MeshRenderer>().sharedMaterial))
            {
                var mesh=new Mesh{name=name+"_"+parent.name+"_"+group.Key.name};
                mesh.CombineMeshes(group.Select(t=>new CombineInstance{mesh=t.GetComponent<MeshFilter>().sharedMesh,transform=Matrix4x4.TRS(t.localPosition,t.localRotation,t.localScale)}).ToArray(),true,true);
                string path=Folder+"/Meshes/"+mesh.name+".asset";var saved=AssetDatabase.LoadAssetAtPath<Mesh>(path);
                if(saved){EditorUtility.CopySerialized(mesh,saved);Object.DestroyImmediate(mesh);}else{saved=mesh;AssetDatabase.CreateAsset(saved,path);}
                foreach(var part in group) Object.DestroyImmediate(part.gameObject);
                var combined=Node(group.Key.name,parent);combined.gameObject.AddComponent<MeshFilter>().sharedMesh=saved;combined.gameObject.AddComponent<MeshRenderer>().sharedMaterial=group.Key;
            }
        }
        PrefabUtility.SaveAsPrefabAsset(root,Folder+"/"+name+".prefab",out bool ok);
        if(!ok)throw new Exception("Could not save "+name);
    }
}
#endif

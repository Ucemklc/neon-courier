using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class HUDController : MonoBehaviour
{
    [Header("Gameplay HUD")]
    [SerializeField]
    private GameObject gameplayHudRoot;

    [SerializeField]
    private TMP_Text scoreText;

    [SerializeField]
    private TMP_Text distanceText;

    [SerializeField]
    private TMP_Text packageText;

    [SerializeField]
    private TMP_Text comboText;

    [SerializeField]
    private TMP_Text lifeText;

    [SerializeField]
    private TMP_Text coinText;

    [SerializeField]
    private Button pauseButton;

    [Header("Main Menu")]
    [SerializeField]
    private GameObject mainMenuPanel;

    [SerializeField]
    private Button playButton;

    [SerializeField]
    private TMP_Text mainMenuHighScoreText;

    [SerializeField]
    private TMP_Text mainMenuCoinText;

    [Header("Countdown")]
    [SerializeField]
    private TMP_Text countdownText;

    [Header("Pause Menu")]
    [SerializeField]
    private GameObject pausePanel;

    [SerializeField]
    private Button resumeButton;

    [SerializeField]
    private Button soundButton;

    [SerializeField]
    private TMP_Text soundButtonText;

    [SerializeField]
    private Button pauseRestartButton;

    [SerializeField]
    private Button pauseMainMenuButton;

    [Header("Game Over")]
    [SerializeField]
    private GameObject gameOverPanel;

    [SerializeField]
    private TMP_Text finalScoreText;

    [SerializeField]
    private TMP_Text highScoreText;

    [SerializeField]
    private TMP_Text finalDistanceText;

    [SerializeField]
    private TMP_Text finalDeliveredPackagesText;

    [SerializeField]
    private TMP_Text finalEarnedCoinsText;

    [SerializeField]
    private TMP_Text finalTotalCoinsText;

    [SerializeField]
    private Button restartButton;

    [SerializeField]
    private Button gameOverMainMenuButton;

    private GameManager gameManager;
    private GameObject powerUpHudRoot;

    private void Start()
    {
        gameManager =
            GameManager.Instance;


        Transform powerUpHud = transform.Find("PowerUpHUD");
        powerUpHudRoot = powerUpHud != null ? powerUpHud.gameObject : null;

        if (gameManager == null)
        {
            Debug.LogError(
                "HUDController: GameManager bulunamadı.",
                this
            );

            enabled = false;
            return;
        }

        SubscribeToGameEvents();
        AddButtonListeners();

        if (mainMenuPanel != null)
        {
            mainMenuPanel.SetActive(false);
        }

        if (pausePanel != null)
        {
            pausePanel.SetActive(false);
        }

        if (gameOverPanel != null)
        {
            gameOverPanel.SetActive(false);
        }

        if (countdownText != null)
        {
            countdownText.gameObject
                .SetActive(false);
        }

        RefreshHUD();

        UpdateSoundButton(
            gameManager.IsSoundEnabled
        );

        UpdateRunState(
            gameManager.IsRunActive
        );

        UpdatePausePanel(
            gameManager.IsPaused
        );

        UpdateMainMenuPanel(
            gameManager.IsMainMenuActive
        );
    }

    private void OnDestroy()
    {
        UnsubscribeFromGameEvents();
        RemoveButtonListeners();
    }

    private void SubscribeToGameEvents()
    {
        gameManager.StatsChanged +=
            RefreshHUD;

        gameManager.GameOverTriggered +=
            ShowGameOver;

        gameManager.CountdownChanged +=
            UpdateCountdown;

        gameManager.PauseChanged +=
            UpdatePausePanel;

        gameManager.SoundStateChanged +=
            UpdateSoundButton;

        gameManager.MainMenuChanged +=
            UpdateMainMenuPanel;

        gameManager.RunStateChanged +=
            UpdateRunState;
    }

    private void UnsubscribeFromGameEvents()
    {
        if (gameManager == null)
        {
            return;
        }

        gameManager.StatsChanged -=
            RefreshHUD;

        gameManager.GameOverTriggered -=
            ShowGameOver;

        gameManager.CountdownChanged -=
            UpdateCountdown;

        gameManager.PauseChanged -=
            UpdatePausePanel;

        gameManager.SoundStateChanged -=
            UpdateSoundButton;

        gameManager.MainMenuChanged -=
            UpdateMainMenuPanel;

        gameManager.RunStateChanged -=
            UpdateRunState;
    }

    private void AddButtonListeners()
    {
        if (playButton != null)
        {
            playButton.onClick.AddListener(
                StartGame
            );
        }

        if (pauseButton != null)
        {
            pauseButton.onClick.AddListener(
                PauseGame
            );
        }

        if (resumeButton != null)
        {
            resumeButton.onClick.AddListener(
                ResumeGame
            );
        }

        if (soundButton != null)
        {
            soundButton.onClick.AddListener(
                ToggleSound
            );
        }

        if (pauseRestartButton != null)
        {
            pauseRestartButton.onClick
                .AddListener(
                    RestartGame
                );
        }

        if (pauseMainMenuButton != null)
        {
            pauseMainMenuButton.onClick
                .AddListener(
                    ReturnToMainMenu
                );
        }

        if (restartButton != null)
        {
            restartButton.onClick
                .AddListener(
                    RestartGame
                );
        }

        if (gameOverMainMenuButton != null)
        {
            gameOverMainMenuButton.onClick
                .AddListener(
                    ReturnToMainMenu
                );
        }
    }

    private void RemoveButtonListeners()
    {
        if (playButton != null)
        {
            playButton.onClick.RemoveListener(
                StartGame
            );
        }

        if (pauseButton != null)
        {
            pauseButton.onClick.RemoveListener(
                PauseGame
            );
        }

        if (resumeButton != null)
        {
            resumeButton.onClick.RemoveListener(
                ResumeGame
            );
        }

        if (soundButton != null)
        {
            soundButton.onClick.RemoveListener(
                ToggleSound
            );
        }

        if (pauseRestartButton != null)
        {
            pauseRestartButton.onClick
                .RemoveListener(
                    RestartGame
                );
        }

        if (pauseMainMenuButton != null)
        {
            pauseMainMenuButton.onClick
                .RemoveListener(
                    ReturnToMainMenu
                );
        }

        if (restartButton != null)
        {
            restartButton.onClick
                .RemoveListener(
                    RestartGame
                );
        }

        if (gameOverMainMenuButton != null)
        {
            gameOverMainMenuButton.onClick
                .RemoveListener(
                    ReturnToMainMenu
                );
        }
    }

    private void RefreshHUD()
    {
        if (gameManager == null)
        {
            return;
        }

        if (scoreText != null)
        {
            scoreText.text =
                $"SKOR {gameManager.Score:N0}";
        }

        if (distanceText != null)
        {
            distanceText.text =
                $"{gameManager.DistanceMeters:N0} m";
        }

        if (packageText != null)
        {
            packageText.text =
                $"PAKET {gameManager.CarriedPackages}";
        }

        if (comboText != null)
        {
            comboText.text =
                $"COMBO x{gameManager.ComboMultiplier}";
        }

        if (lifeText != null)
        {
            lifeText.text =
                $"CAN {gameManager.CurrentLives}";
        }

        if (coinText != null)
        {
            coinText.text =
                $"COIN {gameManager.TotalCoins:N0}";
        }

        RefreshMainMenuInformation();
    }

    private void RefreshMainMenuInformation()
    {
        if (gameManager == null)
        {
            return;
        }

        if (mainMenuHighScoreText != null)
        {
            mainMenuHighScoreText.text =
                $"EN İYİ SKOR\n{gameManager.HighScore:N0}";
        }

        if (mainMenuCoinText != null)
        {
            mainMenuCoinText.text =
                $"COIN\n{gameManager.TotalCoins:N0}";
        }
    }

    private void UpdateMainMenuPanel(
        bool isMainMenuOpen
    )
    {
        if (mainMenuPanel != null)
        {
            mainMenuPanel.SetActive(
                isMainMenuOpen
            );
        }

        SetGameplayHudVisible(
            !isMainMenuOpen && !gameManager.IsGameOver
        );

        if (isMainMenuOpen)
        {
            if (pausePanel != null)
            {
                pausePanel.SetActive(false);
            }

            if (gameOverPanel != null)
            {
                gameOverPanel.SetActive(false);
            }

            if (countdownText != null)
            {
                countdownText.gameObject
                    .SetActive(false);
            }
        }

        RefreshMainMenuInformation();
        RefreshPauseButtonVisibility();
    }

    private void UpdateRunState(
        bool isRunActive
    )
    {
        RefreshPauseButtonVisibility();
    }

    public void SetMainMenuPanelVisible(bool visible)
    {
        if (mainMenuPanel == null || gameManager == null)
            return;

        mainMenuPanel.SetActive(
            visible && gameManager.IsMainMenuActive
        );
    }

    private void SetGameplayHudVisible(bool visible)
    {
        if (gameplayHudRoot != null)
        {
            gameplayHudRoot.SetActive(visible);
            return;
        }

        // Older scenes have no grouped gameplay HUD reference. Hide the known
        // gameplay-only widgets individually so they do not sit over the menu.
        SetWidgetVisible(scoreText, visible);
        SetWidgetVisible(distanceText, visible);
        SetWidgetVisible(packageText, visible);
        SetWidgetVisible(comboText, visible);
        SetWidgetVisible(lifeText, visible);
        SetWidgetVisible(coinText, visible);


        if (powerUpHudRoot != null)
            powerUpHudRoot.SetActive(visible);

        if (pauseButton != null)
            pauseButton.gameObject.SetActive(visible);
    }

    private static void SetWidgetVisible(Component widget, bool visible)
    {
        if (widget != null)
            widget.gameObject.SetActive(visible);
    }

    private void UpdateCountdown(
        string value
    )
    {
        if (countdownText == null)
        {
            return;
        }

        bool shouldShow =
            !string.IsNullOrWhiteSpace(
                value
            );

        countdownText.gameObject.SetActive(
            shouldShow
        );

        if (shouldShow)
        {
            countdownText.text = value;
        }

        RefreshPauseButtonVisibility();
    }

    private void UpdatePausePanel(
        bool isPaused
    )
    {
        if (pausePanel != null)
        {
            pausePanel.SetActive(
                isPaused
            );
        }

        RefreshPauseButtonVisibility();
    }

    private void RefreshPauseButtonVisibility()
    {
        if (
            pauseButton == null ||
            gameManager == null
        )
        {
            return;
        }

        bool shouldShow =
            gameManager.IsRunActive &&
            !gameManager.IsPaused &&
            !gameManager.IsGameOver &&
            !gameManager.IsMainMenuActive;

        pauseButton.gameObject.SetActive(
            shouldShow
        );
    }

    private void UpdateSoundButton(
        bool soundEnabled
    )
    {
        if (soundButtonText == null)
        {
            return;
        }

        soundButtonText.text =
            soundEnabled
                ? "SES AÇIK"
                : "SES KAPALI";
    }

    private void ShowGameOver()
    {
        RefreshHUD();

        if (mainMenuPanel != null)
        {
            mainMenuPanel.SetActive(false);
        }

        SetGameplayHudVisible(false);

        if (countdownText != null)
        {
            countdownText.gameObject
                .SetActive(false);
        }

        if (pausePanel != null)
        {
            pausePanel.SetActive(false);
        }

        if (pauseButton != null)
        {
            pauseButton.gameObject
                .SetActive(false);
        }

        if (finalScoreText != null)
        {
            finalScoreText.text =
                $"SKOR\n{gameManager.Score:N0}";
        }

        if (highScoreText != null)
        {
            highScoreText.text =
                $"EN İYİ SKOR\n{gameManager.HighScore:N0}";
        }

        if (finalDistanceText != null)
        {
            finalDistanceText.text =
                $"MESAFE\n{gameManager.DistanceMeters:N0} m";
        }

        if (finalDeliveredPackagesText != null)
        {
            finalDeliveredPackagesText.text =
                $"TESLİM EDİLEN PAKET\n{gameManager.DeliveredPackages:N0}";
        }

        if (finalEarnedCoinsText != null)
        {
            finalEarnedCoinsText.text =
                $"KAZANILAN COIN\n+{gameManager.EarnedCoinsThisRun:N0}";
        }

        if (finalTotalCoinsText != null)
        {
            finalTotalCoinsText.text =
                $"TOPLAM COIN\n{gameManager.TotalCoins:N0}";
        }

        if (gameOverPanel != null)
        {
            var results = gameOverPanel.GetComponent<CourierResultsMenu>();
            if (!results) results = gameOverPanel.AddComponent<CourierResultsMenu>();
            results.Apply(gameManager, new[] { finalScoreText, highScoreText, finalDistanceText, finalDeliveredPackagesText, finalEarnedCoinsText, finalTotalCoinsText }, restartButton, gameOverMainMenuButton);
            gameOverPanel.SetActive(true);
        }
    }

    private void StartGame()
    {
        if (gameManager != null)
        {
            gameManager.StartGameFromMenu();
        }
    }

    private void PauseGame()
    {
        if (gameManager != null)
        {
            gameManager.PauseGame();
        }
    }

    private void ResumeGame()
    {
        if (gameManager != null)
        {
            gameManager.ResumeGame();
        }
    }

    private void ToggleSound()
    {
        if (gameManager != null)
        {
            gameManager.ToggleSound();
        }
    }

    private void RestartGame()
    {
        if (gameManager != null)
        {
            gameManager.RestartGame();
        }
    }

    private void ReturnToMainMenu()
    {
        if (gameManager != null)
        {
            gameManager.ReturnToMainMenu();
        }
    }
}

using UnityEngine;

[DisallowMultipleComponent]
public sealed class SecurityDroneChase : MonoBehaviour
{
    [Header("Target")]
    [SerializeField]
    private Transform target;

    [Header("Follow Position")]
    [Tooltip(
        "Drone'un oyuncunun sağında veya solunda duracağı mesafe."
    )]
    [SerializeField]
    private float sideOffset = 2.1f;

    [Tooltip(
        "Drone'un oyuncunun üzerindeki yüksekliği."
    )]
    [SerializeField]
    private float heightOffset = 2.7f;

    [Tooltip(
        "Drone'un oyuncunun arkasında duracağı normal mesafe."
    )]
    [SerializeField, Min(0.5f)]
    private float normalFollowDistance = 5.2f;

    [Tooltip(
        "Drone oyuncuya yaklaştığında kullanılabilecek en düşük mesafe."
    )]
    [SerializeField, Min(0.5f)]
    private float minimumFollowDistance = 3.4f;

    [Tooltip(
        "Drone geri itildiğinde kullanılabilecek en yüksek mesafe."
    )]
    [SerializeField, Min(0.5f)]
    private float maximumFollowDistance = 6.8f;

    [Tooltip(
        "1 değerinde oyuncunun şerit hareketini tamamen takip eder."
    )]
    [SerializeField, Range(0f, 1f)]
    private float horizontalFollowMultiplier = 0.65f;

    [SerializeField, Min(0.01f)]
    private float positionSmoothTime = 0.18f;

    [SerializeField, Min(0.01f)]
    private float distanceSmoothTime = 0.25f;

    [Header("Rotation")]
    [SerializeField]
    private Vector3 lookTargetOffset =
        new Vector3(0f, 1.2f, 0f);

    [SerializeField, Min(0.1f)]
    private float rotationSharpness = 8f;

    [Header("Hover")]
    [SerializeField]
    private Transform visualRoot;

    [SerializeField, Min(0f)]
    private float hoverAmplitude = 0.18f;

    [SerializeField, Min(0f)]
    private float hoverFrequency = 1.8f;

    [SerializeField, Min(0f)]
    private float bankAmount = 7f;

    [Header("Rotating Parts")]
    [SerializeField]
    private Transform[] rotatingParts;

    [SerializeField]
    private Vector3 rotatingAxis =
        Vector3.up;

    [SerializeField]
    private float rotatingSpeed = 600f;

    [Header("Optional Search Light")]
    [SerializeField]
    private Light searchLight;

    [SerializeField]
    private bool searchLightEnabled = true;

    [Header("Debug")]
    [SerializeField]
    private bool debugLogs = false;

    private Vector3 movementVelocity;

    private float currentFollowDistance;
    private float targetFollowDistance;
    private float distanceVelocity;

    private float startingTargetX;

    private Vector3 visualInitialLocalPosition;
    private Quaternion visualInitialLocalRotation;

    private bool initialized;

    private void Awake()
    {
        Initialize();
    }

    private void OnEnable()
    {
        Initialize();
    }

    private void LateUpdate()
    {
        if (target == null)
        {
            return;
        }

        if (!initialized)
        {
            Initialize();
        }

        UpdateFollowDistance();
        UpdatePosition();
        UpdateRotation();
        UpdateVisualHover();
        UpdateRotatingParts();
        UpdateSearchLight();
    }

    public void SetTarget(
        Transform newTarget
    )
    {
        target = newTarget;

        initialized = false;

        Initialize();
    }

    public void MoveCloser(
        float distanceAmount = 1.25f
    )
    {
        targetFollowDistance =
            Mathf.Clamp(
                targetFollowDistance -
                Mathf.Abs(distanceAmount),
                minimumFollowDistance,
                maximumFollowDistance
            );

        if (debugLogs)
        {
            Debug.Log(
                $"Security Drone yaklaştı. " +
                $"Hedef mesafe: {targetFollowDistance:0.00}",
                this
            );
        }
    }

    public void PushBack(
        float distanceAmount = 1.5f
    )
    {
        targetFollowDistance =
            Mathf.Clamp(
                targetFollowDistance +
                Mathf.Abs(distanceAmount),
                minimumFollowDistance,
                maximumFollowDistance
            );

        if (debugLogs)
        {
            Debug.Log(
                $"Security Drone geriye itildi. " +
                $"Hedef mesafe: {targetFollowDistance:0.00}",
                this
            );
        }
    }

    public void ResetChaseDistance()
    {
        targetFollowDistance =
            Mathf.Clamp(
                normalFollowDistance,
                minimumFollowDistance,
                maximumFollowDistance
            );
    }

    [ContextMenu("Test / Move Closer")]
    private void TestMoveCloser()
    {
        MoveCloser();
    }

    [ContextMenu("Test / Push Back")]
    private void TestPushBack()
    {
        PushBack();
    }

    [ContextMenu("Test / Reset Distance")]
    private void TestResetDistance()
    {
        ResetChaseDistance();
    }

    private void Initialize()
    {
        if (target == null)
        {
            initialized = false;
            return;
        }

        minimumFollowDistance =
            Mathf.Max(
                0.5f,
                minimumFollowDistance
            );

        maximumFollowDistance =
            Mathf.Max(
                minimumFollowDistance,
                maximumFollowDistance
            );

        normalFollowDistance =
            Mathf.Clamp(
                normalFollowDistance,
                minimumFollowDistance,
                maximumFollowDistance
            );

        startingTargetX =
            target.position.x;

        currentFollowDistance =
            normalFollowDistance;

        targetFollowDistance =
            normalFollowDistance;

        if (visualRoot == null)
        {
            visualRoot = transform;
        }

        visualInitialLocalPosition =
            visualRoot.localPosition;

        visualInitialLocalRotation =
            visualRoot.localRotation;

        transform.position =
            CalculateDesiredPosition();

        initialized = true;
    }

    private void UpdateFollowDistance()
    {
        currentFollowDistance =
            Mathf.SmoothDamp(
                currentFollowDistance,
                targetFollowDistance,
                ref distanceVelocity,
                distanceSmoothTime,
                Mathf.Infinity,
                Time.deltaTime
            );
    }

    private void UpdatePosition()
    {
        Vector3 desiredPosition =
            CalculateDesiredPosition();

        transform.position =
            Vector3.SmoothDamp(
                transform.position,
                desiredPosition,
                ref movementVelocity,
                positionSmoothTime,
                Mathf.Infinity,
                Time.deltaTime
            );
    }

    private Vector3 CalculateDesiredPosition()
    {
        float playerLaneOffset =
            target.position.x -
            startingTargetX;

        float followedHorizontalPosition =
            startingTargetX +
            playerLaneOffset *
            horizontalFollowMultiplier;

        return new Vector3(
            followedHorizontalPosition +
            sideOffset,
            target.position.y +
            heightOffset,
            target.position.z -
            currentFollowDistance
        );
    }

    private void UpdateRotation()
    {
        Vector3 lookTarget =
            target.position +
            lookTargetOffset;

        Vector3 lookDirection =
            lookTarget -
            transform.position;

        if (
            lookDirection.sqrMagnitude <
            0.0001f
        )
        {
            return;
        }

        Quaternion desiredRotation =
            Quaternion.LookRotation(
                lookDirection.normalized,
                Vector3.up
            );

        float rotationBlend =
            1f -
            Mathf.Exp(
                -rotationSharpness *
                Time.deltaTime
            );

        transform.rotation =
            Quaternion.Slerp(
                transform.rotation,
                desiredRotation,
                rotationBlend
            );
    }

    private void UpdateVisualHover()
    {
        if (
            visualRoot == null ||
            visualRoot == transform
        )
        {
            return;
        }

        float hoverWave =
            Mathf.Sin(
                Time.time *
                hoverFrequency *
                Mathf.PI *
                2f
            );

        visualRoot.localPosition =
            visualInitialLocalPosition +
            Vector3.up *
            hoverWave *
            hoverAmplitude;

        float horizontalVelocity =
            movementVelocity.x;

        float targetBank =
            Mathf.Clamp(
                -horizontalVelocity *
                bankAmount,
                -bankAmount,
                bankAmount
            );

        visualRoot.localRotation =
            visualInitialLocalRotation *
            Quaternion.Euler(
                0f,
                0f,
                targetBank
            );
    }

    private void UpdateRotatingParts()
    {
        if (rotatingParts == null)
        {
            return;
        }

        Vector3 frameRotation =
            rotatingAxis.normalized *
            rotatingSpeed *
            Time.deltaTime;

        for (
            int index = 0;
            index < rotatingParts.Length;
            index++
        )
        {
            Transform rotatingPart =
                rotatingParts[index];

            if (rotatingPart == null)
            {
                continue;
            }

            rotatingPart.Rotate(
                frameRotation,
                Space.Self
            );
        }
    }

    private void UpdateSearchLight()
    {
        if (searchLight == null)
        {
            return;
        }

        searchLight.enabled =
            searchLightEnabled;
    }

    private void OnValidate()
    {
        minimumFollowDistance =
            Mathf.Max(
                0.5f,
                minimumFollowDistance
            );

        maximumFollowDistance =
            Mathf.Max(
                minimumFollowDistance,
                maximumFollowDistance
            );

        normalFollowDistance =
            Mathf.Clamp(
                normalFollowDistance,
                minimumFollowDistance,
                maximumFollowDistance
            );

        positionSmoothTime =
            Mathf.Max(
                0.01f,
                positionSmoothTime
            );

        distanceSmoothTime =
            Mathf.Max(
                0.01f,
                distanceSmoothTime
            );

        rotationSharpness =
            Mathf.Max(
                0.1f,
                rotationSharpness
            );

        hoverAmplitude =
            Mathf.Max(
                0f,
                hoverAmplitude
            );

        hoverFrequency =
            Mathf.Max(
                0f,
                hoverFrequency
            );
    }
}
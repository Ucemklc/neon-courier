using System.Collections.Generic;
using UnityEngine;

[DisallowMultipleComponent]
[RequireComponent(typeof(Collider))]
[RequireComponent(typeof(Rigidbody))]
public class PackagePickup : MonoBehaviour
{
    private static readonly HashSet
        <PackagePickup>
        ActivePickups =
            new HashSet<PackagePickup>();

    [Header("Visual Movement")]
    [SerializeField]
    private float rotationSpeed = 75f;

    [SerializeField]
    private float bobHeight = 0.1f;

    [SerializeField]
    private float bobSpeed = 2.5f;

    [Header("Magnet")]
    [SerializeField, Min(0.05f)]
    private float magnetCollectDistance =
        0.65f;

    private Collider pickupCollider;
    private Rigidbody pickupRigidbody;

    private Vector3 initialLocalPosition;
    private float bobPhase;

    private bool collected;
    private bool beingAttracted;
    public CourierCargoKind CargoKind { get; private set; }
    private CourierParcelKindVisual kindVisual;
    public void ConfigureCargo(CourierCargoKind kind)
    {
        CargoKind = kind;
        if (!kindVisual) kindVisual = GetComponent<CourierParcelKindVisual>() ?? gameObject.AddComponent<CourierParcelKindVisual>();
        kindVisual.Apply(kind);
    }

    private void Awake()
    {
        pickupCollider =
            GetComponent<Collider>();

        pickupRigidbody =
            GetComponent<Rigidbody>();

        ConfigurePhysics();
    }

    private void OnEnable()
    {
        ConfigureCargo(CourierWorldRules.CargoAt(transform.position));
        collected = false;
        beingAttracted = false;

        initialLocalPosition =
            transform.localPosition;

        bobPhase =
            Random.Range(
                0f,
                Mathf.PI * 2f
            );

        ConfigurePhysics();

        ActivePickups.Add(this);
    }

    private void OnDisable()
    {
        ActivePickups.Remove(this);
    }

    private void Update()
    {
        if (beingAttracted && (!PowerUpController.Instance || !PowerUpController.Instance.IsMagnetActive))
        {
            beingAttracted = false;
            initialLocalPosition = transform.localPosition;
        }
        if (
            collected ||
            beingAttracted
        )
        {
            return;
        }

        transform.Rotate(
            Vector3.up,
            rotationSpeed *
            Time.deltaTime,
            Space.Self
        );

        Vector3 localPosition =
            initialLocalPosition;

        localPosition.y +=
            Mathf.Sin(
                Time.time *
                bobSpeed +
                bobPhase
            ) * bobHeight;

        transform.localPosition =
            localPosition;
    }

    private void OnTriggerEnter(
        Collider other
    )
    {
        if (collected)
        {
            return;
        }

        RunnerController runner =
            other.GetComponentInParent
                <RunnerController>();

        if (runner == null)
        {
            return;
        }

        Collect();
    }

    public void AttractTowards(
        Transform target,
        float pullSpeed
    )
    {
        if (
            collected ||
            target == null ||
            !gameObject.activeInHierarchy
        )
        {
            return;
        }

        beingAttracted = true;

        transform.position =
            Vector3.MoveTowards(
                transform.position,
                target.position,
                pullSpeed *
                Time.deltaTime
            );

        float distanceSquared =
            (
                transform.position -
                target.position
            ).sqrMagnitude;

        float collectDistanceSquared =
            magnetCollectDistance *
            magnetCollectDistance;

        if (
            distanceSquared <=
            collectDistanceSquared
        )
        {
            Collect();
        }
    }

    public static void CopyActivePickupsTo(
        List<PackagePickup> targetList
    )
    {
        if (targetList == null)
        {
            return;
        }

        foreach (
            PackagePickup packagePickup
            in ActivePickups
        )
        {
            if (packagePickup != null)
            {
                targetList.Add(
                    packagePickup
                );
            }
        }
    }

    private void Collect()
    {
        if (collected)
        {
            return;
        }

        GameManager gameManager =
            GameManager.Instance;

        if (gameManager == null)
        {
            gameManager =
                FindAnyObjectByType
                    <GameManager>();
        }

        if (gameManager == null)
        {
            Debug.LogError(
                "PackagePickup: GameManager bulunamadı.",
                this
            );

            return;
        }

        if (
            !gameManager.IsRunActive ||
            gameManager.IsPaused ||
            gameManager.IsGameOver
        )
        {
            return;
        }

        collected = true;

        gameManager.CollectPackage(CargoKind);

        gameObject.SetActive(false);
    }

    private void ConfigurePhysics()
    {
        if (pickupCollider == null)
        {
            pickupCollider =
                GetComponent<Collider>();
        }

        if (pickupRigidbody == null)
        {
            pickupRigidbody =
                GetComponent<Rigidbody>();
        }

        if (pickupCollider != null)
        {
            pickupCollider.isTrigger =
                true;
        }

        if (pickupRigidbody != null)
        {
            pickupRigidbody.isKinematic =
                true;

            pickupRigidbody.useGravity =
                false;

            pickupRigidbody.detectCollisions =
                true;
        }
    }
}

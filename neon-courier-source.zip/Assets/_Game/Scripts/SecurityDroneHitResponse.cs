using System.Collections;
using UnityEngine;

[DisallowMultipleComponent]
public sealed class SecurityDroneHitResponse : MonoBehaviour
{
    [Header("References")]
    [SerializeField] private SecurityDroneChase securityDroneChase;
    [SerializeField] private GameManager gameManager;

    [Header("Hit Response")]
    [SerializeField] private bool moveCloserOnPlayerHit = true;
    [SerializeField, Min(0f)] private float redAlertDuration = 1.15f;
    [SerializeField, Min(0.1f)] private float redAlertIntensity = 4.2f;
    [SerializeField, Min(1f)] private float redAlertRange = 14f;
    [SerializeField] private AudioClip alertSound;

    private bool subscribed;
    private Light redAlertLight;
    private AudioSource alertAudioSource;
    private Coroutine alertRoutine;

    private void Awake()
    {
        ResolveReferences();
        CreateAlertComponents();
    }

    private void Start()
    {
        ResolveReferences();
        CreateAlertComponents();
        Subscribe();
    }

    private void OnEnable()
    {
        ResolveReferences();
        Subscribe();
    }

    private void OnDisable()
    {
        Unsubscribe();
        if (alertRoutine != null)
        {
            StopCoroutine(alertRoutine);
            alertRoutine = null;
        }
        if (redAlertLight != null) redAlertLight.enabled = false;
    }

    private void OnDestroy()
    {
        Unsubscribe();
    }

    private void ResolveReferences()
    {
        if (securityDroneChase == null)
            securityDroneChase = GetComponent<SecurityDroneChase>();
        if (securityDroneChase == null)
            securityDroneChase = FindAnyObjectByType<SecurityDroneChase>();
        if (gameManager == null)
            gameManager = GameManager.Instance;
        if (gameManager == null)
            gameManager = FindAnyObjectByType<GameManager>();
    }

    private void CreateAlertComponents()
    {
        if (alertSound == null)
            alertSound = Resources.Load<AudioClip>("Audio/DroneAlert");

        if (redAlertLight == null)
        {
            Transform existing = transform.Find("HitAlertRedLight");
            if (existing != null) redAlertLight = existing.GetComponent<Light>();
            if (redAlertLight == null)
            {
                GameObject lightObject = new GameObject("HitAlertRedLight");
                lightObject.transform.SetParent(transform, false);
                lightObject.transform.localPosition = new Vector3(0f, 0.45f, 0f);
                redAlertLight = lightObject.AddComponent<Light>();
                redAlertLight.type = LightType.Point;
                redAlertLight.color = new Color(1f, 0.015f, 0.025f);
                redAlertLight.range = redAlertRange;
                redAlertLight.intensity = 0f;
                redAlertLight.shadows = LightShadows.None;
                redAlertLight.enabled = false;
            }
        }

        if (alertAudioSource == null)
        {
            Transform existing = transform.Find("HitAlertAudio");
            if (existing != null) alertAudioSource = existing.GetComponent<AudioSource>();
            if (alertAudioSource == null)
            {
                GameObject soundObject = new GameObject("HitAlertAudio");
                soundObject.transform.SetParent(transform, false);
                alertAudioSource = soundObject.AddComponent<AudioSource>();
                alertAudioSource.playOnAwake = false;
                alertAudioSource.loop = false;
                alertAudioSource.spatialBlend = 0.85f;
                alertAudioSource.minDistance = 2f;
                alertAudioSource.maxDistance = 42f;
                alertAudioSource.rolloffMode = AudioRolloffMode.Logarithmic;
            }
        }
    }

    private void Subscribe()
    {
        if (subscribed || gameManager == null) return;
        gameManager.PlayerHit += HandlePlayerHit;
        subscribed = true;
    }

    private void Unsubscribe()
    {
        if (!subscribed || gameManager == null)
        {
            subscribed = false;
            return;
        }
        gameManager.PlayerHit -= HandlePlayerHit;
        subscribed = false;
    }

    private void HandlePlayerHit()
    {
        ResolveReferences();
        CreateAlertComponents();

        if (moveCloserOnPlayerHit && securityDroneChase != null)
            securityDroneChase.MoveCloser();

        if (alertAudioSource != null && alertSound != null &&
            (gameManager == null || gameManager.IsSoundEnabled))
        {
            alertAudioSource.PlayOneShot(alertSound, 0.95f);
        }

        if (alertRoutine != null) StopCoroutine(alertRoutine);
        alertRoutine = StartCoroutine(RedAlertRoutine());
    }

    private IEnumerator RedAlertRoutine()
    {
        if (redAlertLight == null) yield break;

        redAlertLight.color = new Color(1f, 0.012f, 0.025f);
        redAlertLight.range = redAlertRange;
        redAlertLight.enabled = true;

        float elapsed = 0f;
        while (elapsed < redAlertDuration)
        {
            elapsed += Time.unscaledDeltaTime;
            float pulse = 0.35f + 0.65f * Mathf.Abs(Mathf.Sin(elapsed * 16f));
            redAlertLight.intensity = redAlertIntensity * pulse;
            yield return null;
        }

        redAlertLight.intensity = 0f;
        redAlertLight.enabled = false;
        alertRoutine = null;
    }

    [ContextMenu("Test / Drone Hit Alert")]
    private void TestHitAlert()
    {
        ResolveReferences();
        HandlePlayerHit();
    }
}
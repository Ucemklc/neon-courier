using UnityEngine;

[DisallowMultipleComponent]
[RequireComponent(typeof(Camera))]
public sealed class CameraFollow : MonoBehaviour
{
    [Header("Target")]
    [SerializeField]
    private Transform target;

    [Header("Stable Runner Framing")]
    [SerializeField]
    private Vector3 offset =
        new Vector3(0f, 4.4f, -5.8f);

    [SerializeField]
    private Vector3 lookOffset =
        new Vector3(0f, 1.35f, 5.2f);

    [Tooltip(
        "0 değerinde kamera şerit değişimlerinde yatay hareket etmez. " +
        "1 değerinde oyuncuyu tamamen takip eder."
    )]
    [SerializeField, Range(0f, 1f)]
    private float horizontalFollowMultiplier =
        0.35f;

    [SerializeField, Min(0.01f)]
    private float positionSmoothTime =
        0.10f;

    [SerializeField, Min(0.1f)]
    private float rotationSharpness =
        12f;

    [Header("Speed FOV")]
    [SerializeField, Range(35f, 90f)]
    private float normalFieldOfView =
        56f;

    [SerializeField, Range(35f, 90f)]
    private float maximumFieldOfView =
        60f;

    [SerializeField]
    private float minimumRunnerSpeed =
        8f;

    [SerializeField]
    private float maximumRunnerSpeed =
        13f;

    [SerializeField, Min(0.01f)]
    private float fieldOfViewSmoothTime =
        0.20f;

    [Header("Hit Shake")]
    [SerializeField, Min(0f)]
    private float shakeDuration =
        0.3f;

    [SerializeField, Min(0f)]
    private float shakeStrength =
        0.22f;

    private Camera controlledCamera;

    private Vector3 movementVelocity;
    private Vector3 followPosition;

    private float fieldOfViewVelocity;
    private float shakeTimeRemaining;

    private bool followPositionInitialized;
    private float trackCenterX;

    private GameManager subscribedGameManager;

    private void Awake()
    {
        controlledCamera =
            GetComponent<Camera>();

        controlledCamera.fieldOfView =
            normalFieldOfView;
    }

    private void Start()
    {
        TrySubscribeToGameManager();
        InitializeFollowPosition();
    }

    private void LateUpdate()
    {
        TrySubscribeToGameManager();

        if (target == null)
        {
            return;
        }

        if (!followPositionInitialized)
        {
            InitializeFollowPosition();
        }

        UpdateFollowPosition();
        UpdateCameraRotation();
        UpdateFieldOfView();
    }

    private void OnDestroy()
    {
        UnsubscribeFromGameManager();
    }

    /*
     * DeliveryZone mevcut sürümünde bu metodu
     * çağırıyor olabilir.
     *
     * Metodu kaldırmıyoruz; böylece derleme hatası
     * oluşmaz. Fakat kamera artık NPC'ye dönmez.
     */
    public void PlayDeliveryFocus(
        Transform npcTarget
    )
    {
        // Bilerek boş bırakıldı.
    }

    public void CancelDeliveryFocus()
    {
        // Bilerek boş bırakıldı.
    }

    private void UpdateFollowPosition()
    {
        float playerHorizontalOffset =
            target.position.x -
            trackCenterX;

        float cameraHorizontalPosition =
            trackCenterX +
            playerHorizontalOffset *
            horizontalFollowMultiplier;

        Vector3 desiredPosition =
            new Vector3(
                cameraHorizontalPosition +
                offset.x,
                target.position.y +
                offset.y,
                target.position.z +
                offset.z
            );

        followPosition =
            Vector3.SmoothDamp(
                followPosition,
                desiredPosition,
                ref movementVelocity,
                positionSmoothTime,
                Mathf.Infinity,
                Time.unscaledDeltaTime
            );

        transform.position =
            followPosition +
            CalculateShakeOffset();
    }

    private void UpdateCameraRotation()
    {
        Vector3 lookTarget =
            target.position +
            lookOffset;
        // Give the board and crouched stance room above the bottom HUD.
        if (CourierPowerEffects.Instance)
            lookTarget += Vector3.down * (1.3f * CourierPowerEffects.Instance.StanceWeight);

        Vector3 lookDirection =
            lookTarget -
            transform.position;

        if (
            lookDirection.sqrMagnitude <
            0.0001f
        )
        {
            return;
        }

        Quaternion desiredRotation =
            Quaternion.LookRotation(
                lookDirection.normalized,
                Vector3.up
            );

        float rotationBlend =
            1f -
            Mathf.Exp(
                -rotationSharpness *
                Time.unscaledDeltaTime
            );

        transform.rotation =
            Quaternion.Slerp(
                transform.rotation,
                desiredRotation,
                rotationBlend
            );
    }

    private void UpdateFieldOfView()
    {
        if (controlledCamera == null)
        {
            return;
        }

        float currentRunnerSpeed =
            minimumRunnerSpeed;

        if (GameManager.Instance != null)
        {
            currentRunnerSpeed =
                GameManager.Instance.CurrentSpeed;
        }

        float speedProgress =
            Mathf.InverseLerp(
                minimumRunnerSpeed,
                maximumRunnerSpeed,
                currentRunnerSpeed
            );

        float targetFieldOfView =
            Mathf.Lerp(
                normalFieldOfView,
                maximumFieldOfView,
                speedProgress
            );

        controlledCamera.fieldOfView =
            Mathf.SmoothDamp(
                controlledCamera.fieldOfView,
                targetFieldOfView,
                ref fieldOfViewVelocity,
                fieldOfViewSmoothTime,
                Mathf.Infinity,
                Time.unscaledDeltaTime
            );
    }

    private void InitializeFollowPosition()
    {
        if (target == null)
        {
            return;
        }

        trackCenterX =
            target.position.x;

        followPosition =
            new Vector3(
                trackCenterX +
                offset.x,
                target.position.y +
                offset.y,
                target.position.z +
                offset.z
            );

        transform.position =
            followPosition;

        followPositionInitialized =
            true;

        UpdateCameraRotation();
    }

    private void TrySubscribeToGameManager()
    {
        if (subscribedGameManager != null)
        {
            return;
        }

        if (GameManager.Instance == null)
        {
            return;
        }

        subscribedGameManager =
            GameManager.Instance;

        subscribedGameManager.PlayerHit +=
            TriggerShake;
    }

    private void UnsubscribeFromGameManager()
    {
        if (subscribedGameManager == null)
        {
            return;
        }

        subscribedGameManager.PlayerHit -=
            TriggerShake;

        subscribedGameManager = null;
    }

    private void TriggerShake()
    {
        shakeTimeRemaining =
            shakeDuration;
    }

    private Vector3 CalculateShakeOffset()
    {
        if (
            shakeTimeRemaining <= 0f ||
            shakeDuration <= 0f ||
            shakeStrength <= 0f
        )
        {
            return Vector3.zero;
        }

        shakeTimeRemaining -=
            Time.unscaledDeltaTime;

        float remainingFraction =
            Mathf.Clamp01(
                shakeTimeRemaining /
                shakeDuration
            );

        return
            Random.insideUnitSphere *
            shakeStrength *
            remainingFraction;
    }

    private void OnValidate()
    {
        positionSmoothTime =
            Mathf.Max(
                0.01f,
                positionSmoothTime
            );

        rotationSharpness =
            Mathf.Max(
                0.1f,
                rotationSharpness
            );

        fieldOfViewSmoothTime =
            Mathf.Max(
                0.01f,
                fieldOfViewSmoothTime
            );

        if (
            maximumFieldOfView <
            normalFieldOfView
        )
        {
            maximumFieldOfView =
                normalFieldOfView;
        }

        if (
            maximumRunnerSpeed <=
            minimumRunnerSpeed
        )
        {
            maximumRunnerSpeed =
                minimumRunnerSpeed +
                0.1f;
        }
    }
}
